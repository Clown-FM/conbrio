#!/bin/bash
cp ./inputs/crash.jpg ./crash.jpg

../../target/jpegtran-1.3.1/jpegtran -rotate 90 -outfile ./output.jpg ./crash.jpg

rm crash.jpg output.jpg
