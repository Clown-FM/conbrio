#!/bin/bash
cp ./inputs/crash2.gif ./crash2.gif

../../target/gif2png-2.5.11/gif2png -m ./crash2.gif

rm crash2.gif
