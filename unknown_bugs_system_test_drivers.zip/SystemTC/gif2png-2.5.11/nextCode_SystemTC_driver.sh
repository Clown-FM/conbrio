#!/bin/bash
cp ./inputs/crash1.gif ./crash1.gif

../../target/gif2png-2.5.11/gif2png -p ./crash1.gif

rm crash1.gif
