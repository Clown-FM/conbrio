#!/bin/bash
cp ./inputs/crash2.mp3 ./crash2.mp3

../../target/mp3gain-1.5.2/mp3gain ./crash2.mp3

rm crash2.mp3
