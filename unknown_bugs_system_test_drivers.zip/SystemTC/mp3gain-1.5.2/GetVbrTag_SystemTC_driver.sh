#!/bin/bash
cp ./inputs/crash1.mp3 ./crash1.mp3

../../target/mp3gain-1.5.2/mp3gain -s i ./crash1.mp3

rm crash1.mp3
