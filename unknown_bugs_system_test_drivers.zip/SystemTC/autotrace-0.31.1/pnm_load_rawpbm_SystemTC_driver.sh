#!/bin/bash
cp ./inputs/pnm_load_rawpbm.pbm ./pnm_load_rawpbm.pbm

../../target/autotrace-0.31.1/autotrace pnm_load_rawpbm.pbm

rm pnm_load_rawpbm.pbm
