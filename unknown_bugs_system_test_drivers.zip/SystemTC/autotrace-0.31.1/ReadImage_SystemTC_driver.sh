#!/bin/bash
cp ./inputs/ReadImage.bmp ./ReadImage.bmp

../../target/autotrace-0.31.1/autotrace -dpi 100 ReadImage.bmp

rm ReadImage.bmp
