#!/bin/bash
cp ./inputs/read_png.png ./read_png.png

../../target/autotrace-0.31.1/autotrace read_png.png

rm read_png.png
