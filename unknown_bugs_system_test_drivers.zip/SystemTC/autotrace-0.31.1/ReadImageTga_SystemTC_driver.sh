#!/bin/bash
cp ./inputs/ReadImageTga.tga ./ReadImageTga.tga

../../target/autotrace-0.31.1/autotrace -dpi 100 ReadImageTga.tga

rm ReadImageTga.tga
