#!/bin/bash
cp ./inputs/pnmscanner_gettoken.pbm ./pnmscanner_gettoken.pbm

../../target/autotrace-0.31.1/autotrace pnmscanner_gettoken.pbm

rm pnmscanner_gettoken.pbm
