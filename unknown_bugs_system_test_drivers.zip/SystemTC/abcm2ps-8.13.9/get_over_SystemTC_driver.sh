#!/bin/bash
cp ./inputs/crash1 ./crash1

../../target/abcm2ps-8.13.9/abcm2ps ./crash1

rm crash1
