#!/bin/bash
cp ./inputs/crash2 ./crash2

../../target/abcm2ps-8.13.9/abcm2ps ./crash2

rm crash2
