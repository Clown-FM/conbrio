#!/bin/bash
cp ./inputs/exif_entry_cb.jpg exif_entry_cb.jpg

Xvfb :0 >& /dev/null &
export DISPLAY=:0
../../target/eog-3.14.1/src/eog ./exif_entry_cb.jpg
killall Xvfb

rm exif_entry_cb.jpg
