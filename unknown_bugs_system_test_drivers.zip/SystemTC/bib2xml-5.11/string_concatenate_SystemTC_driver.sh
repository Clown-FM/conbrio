#!/bin/bash
cp ./inputs/crash.bib ./crash.bib

../../target/bib2xml-5.11/bin/bib2xml ./crash.bib
rm crash.bib
