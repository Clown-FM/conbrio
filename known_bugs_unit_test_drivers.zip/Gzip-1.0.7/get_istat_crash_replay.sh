#!/bin/bash
cp get_istat_crash_input input
./get_istat_driver
rm -f input
