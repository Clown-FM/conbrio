#!/bin/bash
cp make_ofname_crash_input input
./make_ofname_driver
rm -f input
