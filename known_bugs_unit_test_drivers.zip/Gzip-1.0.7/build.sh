#!/bin/bash

gcc -g -w -o get_istat_driver get_istat_driver.c -lcrestr -L../lib -D__H_
gcc -g -w -o make_ofname_driver make_ofname_driver.c -lcrestr -L../lib -D__H_

