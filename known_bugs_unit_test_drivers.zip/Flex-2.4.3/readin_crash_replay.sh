#!/bin/bash
cp readin_crash_input input
./readin_driver
rm -f input
