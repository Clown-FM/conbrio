#!/bin/bash
gcc -g -w -o readin_driver readin_driver.c -lcrestr -L../lib -D__H_
