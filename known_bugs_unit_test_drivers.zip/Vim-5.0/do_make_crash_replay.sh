#!/bin/bash
cp do_make_crash_input input
./do_make_driver
rm -f input
