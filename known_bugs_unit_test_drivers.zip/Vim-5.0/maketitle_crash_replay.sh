#!/bin/bash
cp maketitle_crash_input input
./maketitle_driver
rm -f input
