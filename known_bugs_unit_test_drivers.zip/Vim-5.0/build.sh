#!/bin/bash
  gcc -g -w  -o do_cmdline_driver do_cmdline_driver.c -lcrestr -L../lib -D__H_
  gcc -g -w  -o do_make_driver do_make_driver.c -lcrestr -L../lib -D__H_
  gcc -g -w  -o find_tags_driver find_tags_driver.c -lcrestr -L../lib -D__H_
  gcc -g -w  -o do_addsub_driver do_addsub_driver.c -lcrestr -L../lib -D__H_
  gcc -g -w  -o maketitle_driver maketitle_driver.c -lcrestr -L../lib -D__H_
