#!/bin/bash
cp do_addsub_crash_input input
./do_addsub_driver
rm -f input
