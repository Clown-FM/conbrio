#!/bin/bash
cp find_tags_crash_input input
./find_tags_driver
rm -f input
