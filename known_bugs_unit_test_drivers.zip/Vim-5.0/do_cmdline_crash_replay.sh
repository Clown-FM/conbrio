#!/bin/bash
cp do_cmdline_crash_input input
./do_cmdline_driver
rm -f input
