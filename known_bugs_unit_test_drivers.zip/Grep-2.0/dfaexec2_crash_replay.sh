#!/bin/bash
cp dfaexec2_crash_input input
./dfaexec2_driver
rm -f input
