#!/bin/bash

gcc -g -w -o prepending_driver prepending_driver.c -lcrestr -L../lib -D__H_
gcc -g -w -o dfaexec1_driver  dfaexec1_driver.c -lcrestr -L../lib -D__H_
gcc -g -w -o kwsincr_driver  kwsincr_driver.c -lcrestr -L../lib -D__H_
gcc -g -w -o dfaexec2_driver  dfaexec2_driver.c -lcrestr -L../lib -D__H_


