#!/bin/bash
cp kwsincr_crash_input input
./kwsincr_driver
rm -f input
