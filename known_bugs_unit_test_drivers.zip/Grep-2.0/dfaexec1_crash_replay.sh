#!/bin/bash
cp dfaexec1_crash_input input
./dfaexec1_driver
rm -f input
