#!/bin/bash
cp prepending_crash_input input
./prepending_driver
rm -f input
