#!/bin/bash

gcc -g -w -o pattern_search_driver pattern_search_driver.c -lcrestr -L../lib -D__H_
gcc -g -w -o construct_command_argv_internal_driver construct_command_argv_internal_driver.c -lcrestr -L../lib -D__H_
gcc -g -w -o expand_function_driver expand_function_driver.c -lcrestr -L../lib -D__H_


