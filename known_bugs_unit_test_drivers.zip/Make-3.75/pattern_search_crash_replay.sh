#!/bin/bash
cp pattern_search_crash_input input
./pattern_search_driver
rm -f input
