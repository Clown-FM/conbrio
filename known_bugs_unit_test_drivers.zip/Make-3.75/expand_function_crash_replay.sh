#!/bin/bash
cp expand_function_crash_input input
./expand_function_driver
rm -f input
