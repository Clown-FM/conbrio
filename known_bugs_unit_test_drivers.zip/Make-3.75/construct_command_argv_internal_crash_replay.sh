#!/bin/bash
cp construct_command_argv_internal_crash_input input
./construct_command_argv_internal_driver
rm -f input
