#include <assert.h>











































typedef long unsigned int size_t;








typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;







typedef long int __quad_t;
typedef unsigned long int __u_quad_t;





typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned long int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef long int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef __quad_t *__qaddr_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;


struct _IO_FILE;



typedef struct _IO_FILE FILE;


#ifdef __H_



typedef struct _IO_FILE __FILE;













typedef struct
{
  int __count;
  union
  {

    unsigned int __wch;



    char __wchb[4];
  } __value;
} __mbstate_t;

typedef struct
{
  __off_t __pos;
  __mbstate_t __state;
} _G_fpos_t;
typedef struct
{
  __off64_t __pos;
  __mbstate_t __state;
} _G_fpos64_t;




typedef __builtin_va_list __gnuc_va_list;


struct _IO_jump_t; struct _IO_FILE;

typedef void _IO_lock_t;





struct _IO_marker {
  struct _IO_marker *_next;
  struct _IO_FILE *_sbuf;



  int _pos;

};


enum __codecvt_result
{
  __codecvt_ok,
  __codecvt_partial,
  __codecvt_error,
  __codecvt_noconv
};

struct _IO_FILE {
  int _flags;




  char* _IO_read_ptr;
  char* _IO_read_end;
  char* _IO_read_base;
  char* _IO_write_base;
  char* _IO_write_ptr;
  char* _IO_write_end;
  char* _IO_buf_base;
  char* _IO_buf_end;

  char *_IO_save_base;
  char *_IO_backup_base;
  char *_IO_save_end;

  struct _IO_marker *_markers;

  struct _IO_FILE *_chain;

  int _fileno;



  int _flags2;

  __off_t _old_offset;



  unsigned short _cur_column;
  signed char _vtable_offset;
  char _shortbuf[1];



  _IO_lock_t *_lock;

  __off64_t _offset;

  void *__pad1;
  void *__pad2;
  void *__pad3;
  void *__pad4;
  size_t __pad5;

  int _mode;

  char _unused2[15 * sizeof (int) - 4 * sizeof (void *) - sizeof (size_t)];

};


typedef struct _IO_FILE _IO_FILE;


struct _IO_FILE_plus;

extern struct _IO_FILE_plus _IO_2_1_stdin_;
extern struct _IO_FILE_plus _IO_2_1_stdout_;
extern struct _IO_FILE_plus _IO_2_1_stderr_;

typedef __ssize_t __io_read_fn (void *__cookie, char *__buf, size_t __nbytes);







typedef __ssize_t __io_write_fn (void *__cookie, const char *__buf,
     size_t __n);







typedef int __io_seek_fn (void *__cookie, __off64_t *__pos, int __w);


typedef int __io_close_fn (void *__cookie);

/*extern*/ int __underflow (_IO_FILE *);
/*extern*/ int __uflow (_IO_FILE *);
/*extern*/ int __overflow (_IO_FILE *, int);

/*extern*/ int _IO_getc (_IO_FILE *__fp);
/*extern*/ int _IO_putc (int __c, _IO_FILE *__fp);
/*extern*/ int _IO_feof (_IO_FILE *__fp) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int _IO_ferror (_IO_FILE *__fp) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ int _IO_peekc_locked (_IO_FILE *__fp);





/*extern*/ void _IO_flockfile (_IO_FILE *) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ void _IO_funlockfile (_IO_FILE *) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int _IO_ftrylockfile (_IO_FILE *) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ int _IO_vfscanf (_IO_FILE * __restrict, const char * __restrict,
   __gnuc_va_list, int *__restrict);
/*extern*/ int _IO_vfprintf (_IO_FILE *__restrict, const char *__restrict,
    __gnuc_va_list);
/*extern*/ __ssize_t _IO_padn (_IO_FILE *, int, __ssize_t);
/*extern*/ size_t _IO_sgetn (_IO_FILE *, void *, size_t);

/*extern*/ __off64_t _IO_seekoff (_IO_FILE *, __off64_t, int, int);
/*extern*/ __off64_t _IO_seekpos (_IO_FILE *, __off64_t, int);

/*extern*/ void _IO_free_backup_area (_IO_FILE *) __attribute__ ((__nothrow__ , __leaf__));





typedef __gnuc_va_list va_list;

typedef __off_t off_t;

typedef __ssize_t ssize_t;







typedef _G_fpos_t fpos_t;










/*extern*/ struct _IO_FILE *stdin;
/*extern*/ struct _IO_FILE *stdout;
/*extern*/ struct _IO_FILE *stderr;







/*extern*/ int remove (const char *__filename) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ int rename (const char *__old, const char *__new) __attribute__ ((__nothrow__ , __leaf__));




/*extern*/ int renameat (int __oldfd, const char *__old, int __newfd,
       const char *__new) __attribute__ ((__nothrow__ , __leaf__));








/*extern*/ FILE *tmpfile (void) ;

/*extern*/ char *tmpnam (char *__s) __attribute__ ((__nothrow__ , __leaf__)) ;





/*extern*/ char *tmpnam_r (char *__s) __attribute__ ((__nothrow__ , __leaf__)) ;

/*extern*/ char *tempnam (const char *__dir, const char *__pfx)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) ;








/*extern*/ int fclose (FILE *__stream);




/*extern*/ int fflush (FILE *__stream);


/*extern*/ int fflush_unlocked (FILE *__stream);







/*extern*/ FILE *fopen (const char *__restrict __filename,
      const char *__restrict __modes) ;




/*extern*/ FILE *freopen (const char *__restrict __filename,
        const char *__restrict __modes,
        FILE *__restrict __stream) ;



/*extern*/ FILE *fdopen (int __fd, const char *__modes) __attribute__ ((__nothrow__ , __leaf__)) ;

/*extern*/ FILE *fmemopen (void *__s, size_t __len, const char *__modes)
  __attribute__ ((__nothrow__ , __leaf__)) ;




/*extern*/ FILE *open_memstream (char **__bufloc, size_t *__sizeloc) __attribute__ ((__nothrow__ , __leaf__)) ;






/*extern*/ void setbuf (FILE *__restrict __stream, char *__restrict __buf) __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ int setvbuf (FILE *__restrict __stream, char *__restrict __buf,
      int __modes, size_t __n) __attribute__ ((__nothrow__ , __leaf__));





/*extern*/ void setbuffer (FILE *__restrict __stream, char *__restrict __buf,
         size_t __size) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ void setlinebuf (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__));








/*extern*/ int fprintf (FILE *__restrict __stream,
      const char *__restrict __format, ...);




/*extern*/ int printf (const char *__restrict __format, ...);

/*extern*/ int sprintf (char *__restrict __s,
      const char *__restrict __format, ...) __attribute__ ((__nothrow__));





/*extern*/ int vfprintf (FILE *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg);




/*extern*/ int vprintf (const char *__restrict __format, __gnuc_va_list __arg);

/*extern*/ int vsprintf (char *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg) __attribute__ ((__nothrow__));





/*extern*/ int snprintf (char *__restrict __s, size_t __maxlen,
       const char *__restrict __format, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 4)));

/*extern*/ int vsnprintf (char *__restrict __s, size_t __maxlen,
        const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 0)));


/*extern*/ int vdprintf (int __fd, const char *__restrict __fmt,
       __gnuc_va_list __arg)
     __attribute__ ((__format__ (__printf__, 2, 0)));
/*extern*/ int dprintf (int __fd, const char *__restrict __fmt, ...)
     __attribute__ ((__format__ (__printf__, 2, 3)));








/*extern*/ int fscanf (FILE *__restrict __stream,
     const char *__restrict __format, ...) ;




/*extern*/ int scanf (const char *__restrict __format, ...) ;

/*extern*/ int sscanf (const char *__restrict __s,
     const char *__restrict __format, ...) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ int fscanf (FILE *__restrict __stream, const char *__restrict __format, ...) __asm__ ("" "__isoc99_fscanf")

                               ;
/*extern*/ int scanf (const char *__restrict __format, ...) __asm__ ("" "__isoc99_scanf")
                              ;
/*extern*/ int sscanf (const char *__restrict __s, const char *__restrict __format, ...) __asm__ ("" "__isoc99_sscanf") __attribute__ ((__nothrow__ , __leaf__))

                      ;









/*extern*/ int vfscanf (FILE *__restrict __s, const char *__restrict __format,
      __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 2, 0))) ;





/*extern*/ int vscanf (const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 1, 0))) ;


/*extern*/ int vsscanf (const char *__restrict __s,
      const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__format__ (__scanf__, 2, 0)));

/*extern*/ int vfscanf (FILE *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc99_vfscanf")



     __attribute__ ((__format__ (__scanf__, 2, 0))) ;
/*extern*/ int vscanf (const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc99_vscanf")

     __attribute__ ((__format__ (__scanf__, 1, 0))) ;
/*extern*/ int vsscanf (const char *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc99_vsscanf") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__format__ (__scanf__, 2, 0)));










/*extern*/ int fgetc (FILE *__stream);
/*extern*/ int getc (FILE *__stream);





/*extern*/ int getchar ();


/*extern*/ int getc_unlocked (FILE *__stream);
/*extern*/ int getchar_unlocked ();

/*extern*/ int fgetc_unlocked (FILE *__stream);











/*extern*/ int fputc (int __c, FILE *__stream);
/*extern*/ int putc (int __c, FILE *__stream);





/*extern*/ int putchar (int __c);


/*extern*/ int fputc_unlocked (int __c, FILE *__stream);







/*extern*/ int putc_unlocked (int __c, FILE *__stream);
/*extern*/ int putchar_unlocked (int __c);






/*extern*/ int getw (FILE *__stream);


/*extern*/ int putw (int __w, FILE *__stream);








/*extern*/ char *fgets (char *__restrict __s, int __n, FILE *__restrict __stream)
     ;

/*extern*/ char *gets (char *__s) __attribute__ ((__deprecated__));



/*extern*/ __ssize_t __getdelim (char **__restrict __lineptr,
          size_t *__restrict __n, int __delimiter,
          FILE *__restrict __stream) ;
/*extern*/ __ssize_t getdelim (char **__restrict __lineptr,
        size_t *__restrict __n, int __delimiter,
        FILE *__restrict __stream) ;







/*extern*/ __ssize_t getline (char **__restrict __lineptr,
       size_t *__restrict __n,
       FILE *__restrict __stream) ;








/*extern*/ int fputs (const char *__restrict __s, FILE *__restrict __stream);





/*extern*/ int puts (const char *__s);






/*extern*/ int ungetc (int __c, FILE *__stream);






/*extern*/ size_t fread (void *__restrict __ptr, size_t __size,
       size_t __n, FILE *__restrict __stream) ;




/*extern*/ size_t fwrite (const void *__restrict __ptr, size_t __size,
        size_t __n, FILE *__restrict __s);


/*extern*/ size_t fread_unlocked (void *__restrict __ptr, size_t __size,
         size_t __n, FILE *__restrict __stream) ;
/*extern*/ size_t fwrite_unlocked (const void *__restrict __ptr, size_t __size,
          size_t __n, FILE *__restrict __stream);








/*extern*/ int fseek (FILE *__stream, long int __off, int __whence);




/*extern*/ long int ftell (FILE *__stream) ;




/*extern*/ void rewind (FILE *__stream);


/*extern*/ int fseeko (FILE *__stream, __off_t __off, int __whence);




/*extern*/ __off_t ftello (FILE *__stream) ;







/*extern*/ int fgetpos (FILE *__restrict __stream, fpos_t *__restrict __pos);




/*extern*/ int fsetpos (FILE *__stream, const fpos_t *__pos);





/*extern*/ void clearerr (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ int feof (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) ;

/*extern*/ int ferror (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) ;




/*extern*/ void clearerr_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int feof_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) ;
/*extern*/ int ferror_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) ;








/*extern*/ void perror (const char *__s);








/*extern*/ int sys_nerr;
/*extern*/ const char *const sys_errlist[];





/*extern*/ int fileno (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) ;




/*extern*/ int fileno_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) ;

/*extern*/ FILE *popen (const char *__command, const char *__modes) ;





/*extern*/ int pclose (FILE *__stream);





/*extern*/ char *ctermid (char *__s) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ void flockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ int ftrylockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) ;


/*extern*/ void funlockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__));



static int __sym_vfprintf(FILE * param0, const char * param1, __gnuc_va_list param2, ...);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
vprintf (const char *__restrict __fmt, __gnuc_va_list __arg)
{
  return __sym_vfprintf (stdout, __fmt, __arg);
}



static int __sym__IO_getc(_IO_FILE * param0, ...);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
getchar (void)
{
  return __sym__IO_getc (stdin);
}




static int __sym___uflow(_IO_FILE * param0, ...);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
fgetc_unlocked (FILE *__fp)
{
  return (__builtin_expect (((__fp)->_IO_read_ptr >= (__fp)->_IO_read_end), 0) ? __sym___uflow (__fp) : *(unsigned char *) (__fp)->_IO_read_ptr++);
}





/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
getc_unlocked (FILE *__fp)
{
  return (__builtin_expect (((__fp)->_IO_read_ptr >= (__fp)->_IO_read_end), 0) ? __sym___uflow (__fp) : *(unsigned char *) (__fp)->_IO_read_ptr++);
}


/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
getchar_unlocked (void)
{
  return (__builtin_expect (((stdin)->_IO_read_ptr >= (stdin)->_IO_read_end), 0) ? __sym___uflow (stdin) : *(unsigned char *) (stdin)->_IO_read_ptr++);
}




static int __sym__IO_putc(int param0, _IO_FILE * param1, ...);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
putchar (int __c)
{
  return __sym__IO_putc (__c, stdout);
}




static int __sym___overflow(_IO_FILE * param0, int param1, ...);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
fputc_unlocked (int __c, FILE *__stream)
{
  return (__builtin_expect (((__stream)->_IO_write_ptr >= (__stream)->_IO_write_end), 0) ? __sym___overflow (__stream, (unsigned char) (__c)) : (unsigned char) (*(__stream)->_IO_write_ptr++ = (__c)));
}





/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
putc_unlocked (int __c, FILE *__stream)
{
  return (__builtin_expect (((__stream)->_IO_write_ptr >= (__stream)->_IO_write_end), 0) ? __sym___overflow (__stream, (unsigned char) (__c)) : (unsigned char) (*(__stream)->_IO_write_ptr++ = (__c)));
}


/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
putchar_unlocked (int __c)
{
  return (__builtin_expect (((stdout)->_IO_write_ptr >= (stdout)->_IO_write_end), 0) ? __sym___overflow (stdout, (unsigned char) (__c)) : (unsigned char) (*(stdout)->_IO_write_ptr++ = (__c)));
}

/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) feof_unlocked (FILE *__stream)
{
  return (((__stream)->_flags & 0x10) != 0);
}


/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) ferror_unlocked (FILE *__stream)
{
  return (((__stream)->_flags & 0x20) != 0);
}


























static __inline unsigned int
__bswap_32 (unsigned int __bsx)
{
  return __builtin_bswap32 (__bsx);
}

static __inline __uint64_t
__bswap_64 (__uint64_t __bsx)
{
  return __builtin_bswap64 (__bsx);
}








enum
{
  _ISupper = ((0) < 8 ? ((1 << (0)) << 8) : ((1 << (0)) >> 8)),
  _ISlower = ((1) < 8 ? ((1 << (1)) << 8) : ((1 << (1)) >> 8)),
  _ISalpha = ((2) < 8 ? ((1 << (2)) << 8) : ((1 << (2)) >> 8)),
  _ISdigit = ((3) < 8 ? ((1 << (3)) << 8) : ((1 << (3)) >> 8)),
  _ISxdigit = ((4) < 8 ? ((1 << (4)) << 8) : ((1 << (4)) >> 8)),
  _ISspace = ((5) < 8 ? ((1 << (5)) << 8) : ((1 << (5)) >> 8)),
  _ISprint = ((6) < 8 ? ((1 << (6)) << 8) : ((1 << (6)) >> 8)),
  _ISgraph = ((7) < 8 ? ((1 << (7)) << 8) : ((1 << (7)) >> 8)),
  _ISblank = ((8) < 8 ? ((1 << (8)) << 8) : ((1 << (8)) >> 8)),
  _IScntrl = ((9) < 8 ? ((1 << (9)) << 8) : ((1 << (9)) >> 8)),
  _ISpunct = ((10) < 8 ? ((1 << (10)) << 8) : ((1 << (10)) >> 8)),
  _ISalnum = ((11) < 8 ? ((1 << (11)) << 8) : ((1 << (11)) >> 8))
};

/*extern*/ const unsigned short int **__ctype_b_loc (void)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
/*extern*/ const __int32_t **__ctype_tolower_loc (void)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
/*extern*/ const __int32_t **__ctype_toupper_loc (void)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));







/*extern*/ int isalnum (int) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int isalpha (int) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int iscntrl (int) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int isdigit (int) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int islower (int) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int isgraph (int) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int isprint (int) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int ispunct (int) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int isspace (int) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int isupper (int) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int isxdigit (int) __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ int tolower (int __c) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ int toupper (int __c) __attribute__ ((__nothrow__ , __leaf__));








/*extern*/ int isblank (int) __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ int isascii (int __c) __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ int toascii (int __c) __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ int _toupper (int) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int _tolower (int) __attribute__ ((__nothrow__ , __leaf__));

static const int ** __sym___ctype_tolower_loc();
/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) tolower (int __c)
{
  return __c >= -128 && __c < 256 ? (*__sym___ctype_tolower_loc ())[__c] : __c;
}

static const int ** __sym___ctype_toupper_loc();
/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) toupper (int __c)
{
  return __c >= -128 && __c < 256 ? (*__sym___ctype_toupper_loc ())[__c] : __c;
}



typedef struct __locale_struct
{

  struct __locale_data *__locales[13];


  const unsigned short int *__ctype_b;
  const int *__ctype_tolower;
  const int *__ctype_toupper;


  const char *__names[13];
} *__locale_t;


typedef __locale_t locale_t;


/*extern*/ int isalnum_l (int, __locale_t) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int isalpha_l (int, __locale_t) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int iscntrl_l (int, __locale_t) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int isdigit_l (int, __locale_t) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int islower_l (int, __locale_t) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int isgraph_l (int, __locale_t) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int isprint_l (int, __locale_t) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int ispunct_l (int, __locale_t) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int isspace_l (int, __locale_t) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int isupper_l (int, __locale_t) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int isxdigit_l (int, __locale_t) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ int isblank_l (int, __locale_t) __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ int __tolower_l (int __c, __locale_t __l) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int tolower_l (int __c, __locale_t __l) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ int __toupper_l (int __c, __locale_t __l) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int toupper_l (int __c, __locale_t __l) __attribute__ ((__nothrow__ , __leaf__));


#endif
//time_command_driver(){
//  vio("real != 0", __FILE__, 7992, "time_command");
//}

#ifdef __H_





typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;




typedef __loff_t loff_t;



typedef __ino_t ino_t;

typedef __dev_t dev_t;




typedef __gid_t gid_t;




typedef __mode_t mode_t;




typedef __nlink_t nlink_t;




typedef __uid_t uid_t;

typedef __pid_t pid_t;





typedef __id_t id_t;

typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;





typedef __key_t key_t;





typedef __clock_t clock_t;






typedef __time_t time_t;




typedef __clockid_t clockid_t;

typedef __timer_t timer_t;







typedef unsigned long int ulong;
typedef unsigned short int ushort;
typedef unsigned int uint;

typedef int int8_t __attribute__ ((__mode__ (__QI__)));
typedef int int16_t __attribute__ ((__mode__ (__HI__)));
typedef int int32_t __attribute__ ((__mode__ (__SI__)));
typedef int int64_t __attribute__ ((__mode__ (__DI__)));


typedef unsigned int u_int8_t __attribute__ ((__mode__ (__QI__)));
typedef unsigned int u_int16_t __attribute__ ((__mode__ (__HI__)));
typedef unsigned int u_int32_t __attribute__ ((__mode__ (__SI__)));
typedef unsigned int u_int64_t __attribute__ ((__mode__ (__DI__)));

typedef int register_t __attribute__ ((__mode__ (__word__)));












typedef int __sig_atomic_t;




typedef struct
  {
    unsigned long int __val[(1024 / (8 * sizeof (unsigned long int)))];
  } __sigset_t;




typedef __sigset_t sigset_t;







struct timespec
  {
    __time_t tv_sec;
    __syscall_slong_t tv_nsec;
  };




struct timeval
  {
    __time_t tv_sec;
    __suseconds_t tv_usec;
  };



typedef __suseconds_t suseconds_t;





typedef long int __fd_mask;

typedef struct
  {






    __fd_mask __fds_bits[1024 / (8 * (int) sizeof (__fd_mask))];


  } fd_set;






typedef __fd_mask fd_mask;



/*extern*/ int select (int __nfds, fd_set *__restrict __readfds,
     fd_set *__restrict __writefds,
     fd_set *__restrict __exceptfds,
     struct timeval *__restrict __timeout);

/*extern*/ int pselect (int __nfds, fd_set *__restrict __readfds,
      fd_set *__restrict __writefds,
      fd_set *__restrict __exceptfds,
      const struct timespec *__restrict __timeout,
      const __sigset_t *__restrict __sigmask);









__extension__
/*extern*/ unsigned int gnu_dev_major (unsigned long long int __dev)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
__extension__
/*extern*/ unsigned int gnu_dev_minor (unsigned long long int __dev)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
__extension__
/*extern*/ unsigned long long int gnu_dev_makedev (unsigned int __major,
            unsigned int __minor)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


__extension__ /*extern*/ __inline __attribute__ ((__gnu_inline__)) __attribute__ ((__const__)) unsigned int
__attribute__ ((__nothrow__ , __leaf__)) gnu_dev_major (unsigned long long int __dev)
{
  return ((__dev >> 8) & 0xfff) | ((unsigned int) (__dev >> 32) & ~0xfff);
}

__extension__ /*extern*/ __inline __attribute__ ((__gnu_inline__)) __attribute__ ((__const__)) unsigned int
__attribute__ ((__nothrow__ , __leaf__)) gnu_dev_minor (unsigned long long int __dev)
{
  return (__dev & 0xff) | ((unsigned int) (__dev >> 12) & ~0xff);
}

__extension__ /*extern*/ __inline __attribute__ ((__gnu_inline__)) __attribute__ ((__const__)) unsigned long long int
__attribute__ ((__nothrow__ , __leaf__)) gnu_dev_makedev (unsigned int __major, unsigned int __minor)
{
  return ((__minor & 0xff) | ((__major & 0xfff) << 8)
   | (((unsigned long long int) (__minor & ~0xff)) << 12)
   | (((unsigned long long int) (__major & ~0xfff)) << 32));
}








typedef __blksize_t blksize_t;






typedef __blkcnt_t blkcnt_t;



typedef __fsblkcnt_t fsblkcnt_t;



typedef __fsfilcnt_t fsfilcnt_t;






typedef unsigned long int pthread_t;


union pthread_attr_t
{
  char __size[56];
  long int __align;
};

typedef union pthread_attr_t pthread_attr_t;





typedef struct __pthread_internal_list
{
  struct __pthread_internal_list *__prev;
  struct __pthread_internal_list *__next;
} __pthread_list_t;

typedef union
{
  struct __pthread_mutex_s
  {
    int __lock;
    unsigned int __count;
    int __owner;

    unsigned int __nusers;



    int __kind;

    short __spins;
    short __elision;
    __pthread_list_t __list;

  } __data;
  char __size[40];
  long int __align;
} pthread_mutex_t;

typedef union
{
  char __size[4];
  int __align;
} pthread_mutexattr_t;




typedef union
{
  struct
  {
    int __lock;
    unsigned int __futex;
    __extension__ unsigned long long int __total_seq;
    __extension__ unsigned long long int __wakeup_seq;
    __extension__ unsigned long long int __woken_seq;
    void *__mutex;
    unsigned int __nwaiters;
    unsigned int __broadcast_seq;
  } __data;
  char __size[48];
  __extension__ long long int __align;
} pthread_cond_t;

typedef union
{
  char __size[4];
  int __align;
} pthread_condattr_t;



typedef unsigned int pthread_key_t;



typedef int pthread_once_t;





typedef union
{

  struct
  {
    int __lock;
    unsigned int __nr_readers;
    unsigned int __readers_wakeup;
    unsigned int __writer_wakeup;
    unsigned int __nr_readers_queued;
    unsigned int __nr_writers_queued;
    int __writer;
    int __shared;
    unsigned long int __pad1;
    unsigned long int __pad2;


    unsigned int __flags;

  } __data;

  char __size[56];
  long int __align;
} pthread_rwlock_t;

typedef union
{
  char __size[8];
  long int __align;
} pthread_rwlockattr_t;





typedef volatile int pthread_spinlock_t;




typedef union
{
  char __size[32];
  long int __align;
} pthread_barrier_t;

typedef union
{
  char __size[4];
  int __align;
} pthread_barrierattr_t;



















struct flock
  {
    short int l_type;
    short int l_whence;

    __off_t l_start;
    __off_t l_len;




    __pid_t l_pid;
  };













struct stat
  {
    __dev_t st_dev;




    __ino_t st_ino;







    __nlink_t st_nlink;
    __mode_t st_mode;

    __uid_t st_uid;
    __gid_t st_gid;

    int __pad0;

    __dev_t st_rdev;




    __off_t st_size;



    __blksize_t st_blksize;

    __blkcnt_t st_blocks;

    struct timespec st_atim;
    struct timespec st_mtim;
    struct timespec st_ctim;

    __syscall_slong_t __glibc_reserved[3];

  };


/*extern*/ int fcntl (int __fd, int __cmd, ...);

/*extern*/ int open (const char *__file, int __oflag, ...) __attribute__ ((__nonnull__ (1)));

/*extern*/ int openat (int __fd, const char *__file, int __oflag, ...)
     __attribute__ ((__nonnull__ (2)));

/*extern*/ int creat (const char *__file, mode_t __mode) __attribute__ ((__nonnull__ (1)));

/*extern*/ int lockf (int __fd, int __cmd, off_t __len);

/*extern*/ int posix_fadvise (int __fd, off_t __offset, off_t __len,
     int __advise) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ int posix_fallocate (int __fd, off_t __offset, off_t __len);







/*extern*/ int flock (int __fd, int __operation) __attribute__ ((__nothrow__ , __leaf__));


















/*extern*/ int stat (const char *__restrict __file,
   struct stat *__restrict __buf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



/*extern*/ int fstat (int __fd, struct stat *__buf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

/*extern*/ int fstatat (int __fd, const char *__restrict __file,
      struct stat *__restrict __buf, int __flag)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));

/*extern*/ int lstat (const char *__restrict __file,
    struct stat *__restrict __buf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ int chmod (const char *__file, __mode_t __mode)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





/*extern*/ int lchmod (const char *__file, __mode_t __mode)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));




/*extern*/ int fchmod (int __fd, __mode_t __mode) __attribute__ ((__nothrow__ , __leaf__));





/*extern*/ int fchmodat (int __fd, const char *__file, __mode_t __mode,
       int __flag)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) ;






/*extern*/ __mode_t umask (__mode_t __mask) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ int mkdir (const char *__path, __mode_t __mode)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





/*extern*/ int mkdirat (int __fd, const char *__path, __mode_t __mode)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));






/*extern*/ int mknod (const char *__path, __mode_t __mode, __dev_t __dev)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





/*extern*/ int mknodat (int __fd, const char *__path, __mode_t __mode,
      __dev_t __dev) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));





/*extern*/ int mkfifo (const char *__path, __mode_t __mode)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





/*extern*/ int mkfifoat (int __fd, const char *__path, __mode_t __mode)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));





/*extern*/ int utimensat (int __fd, const char *__path,
        const struct timespec __times[2],
        int __flags)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));




/*extern*/ int futimens (int __fd, const struct timespec __times[2]) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ int __fxstat (int __ver, int __fildes, struct stat *__stat_buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
/*extern*/ int __xstat (int __ver, const char *__filename,
      struct stat *__stat_buf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));
/*extern*/ int __lxstat (int __ver, const char *__filename,
       struct stat *__stat_buf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));
/*extern*/ int __fxstatat (int __ver, int __fildes, const char *__filename,
         struct stat *__stat_buf, int __flag)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4)));

/*extern*/ int __xmknod (int __ver, const char *__path, __mode_t __mode,
       __dev_t *__dev) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)));

/*extern*/ int __xmknodat (int __ver, int __fd, const char *__path,
         __mode_t __mode, __dev_t *__dev)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 5)));




static int __sym___xstat(int param0, const char * param1, struct stat * param2, ...);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) stat (const char *__path, struct stat *__statbuf)
{
  return __sym___xstat (1, __path, __statbuf);
}


static int __sym___lxstat(int param0, const char * param1, struct stat * param2, ...);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) lstat (const char *__path, struct stat *__statbuf)
{
  return __sym___lxstat (1, __path, __statbuf);
}


static int __sym___fxstat(int param0, int param1, struct stat * param2, ...);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) fstat (int __fd, struct stat *__statbuf)
{
  return __sym___fxstat (1, __fd, __statbuf);
}


static int __sym___fxstatat(int param0, int param1, const char * param2, struct stat * param3, int param4, ...);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) fstatat (int __fd, const char *__filename, struct stat *__statbuf, int __flag)

{
  return __sym___fxstatat (1, __fd, __filename, __statbuf, __flag);
}



static int __sym___xmknod(int param0, const char * param1, __mode_t param2, __dev_t * param3, ...);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) mknod (const char *__path, __mode_t __mode, __dev_t __dev)
{
  return __sym___xmknod (0, __path, __mode, &__dev);
}



static int __sym___xmknodat(int param0, int param1, const char * param2, __mode_t param3, __dev_t * param4, ...);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) mknodat (int __fd, const char *__path, __mode_t __mode, __dev_t __dev)

{
  return __sym___xmknodat (0, __fd, __path, __mode, &__dev);
}










/*extern*/ int __sigismember (const __sigset_t *, int);
/*extern*/ int __sigaddset (__sigset_t *, int);
/*extern*/ int __sigdelset (__sigset_t *, int);

/*extern*/ __inline __attribute__ ((__gnu_inline__)) int __sigismember (const __sigset_t *__set, int __sig) { unsigned long int __mask = (((unsigned long int) 1) << (((__sig) - 1) % (8 * sizeof (unsigned long int)))); unsigned long int __word = (((__sig) - 1) / (8 * sizeof (unsigned long int))); return (__set->__val[__word] & __mask) ? 1 : 0; }
/*extern*/ __inline __attribute__ ((__gnu_inline__)) int __sigaddset ( __sigset_t *__set, int __sig) { unsigned long int __mask = (((unsigned long int) 1) << (((__sig) - 1) % (8 * sizeof (unsigned long int)))); unsigned long int __word = (((__sig) - 1) / (8 * sizeof (unsigned long int))); return ((__set->__val[__word] |= __mask), 0); }
/*extern*/ __inline __attribute__ ((__gnu_inline__)) int __sigdelset ( __sigset_t *__set, int __sig) { unsigned long int __mask = (((unsigned long int) 1) << (((__sig) - 1) % (8 * sizeof (unsigned long int)))); unsigned long int __word = (((__sig) - 1) / (8 * sizeof (unsigned long int))); return ((__set->__val[__word] &= ~__mask), 0); }








typedef __sig_atomic_t sig_atomic_t;






















typedef union sigval
  {
    int sival_int;
    void *sival_ptr;
  } sigval_t;

typedef __clock_t __sigchld_clock_t;



typedef struct
  {
    int si_signo;
    int si_errno;

    int si_code;

    union
      {
 int _pad[((128 / sizeof (int)) - 4)];


 struct
   {
     __pid_t si_pid;
     __uid_t si_uid;
   } _kill;


 struct
   {
     int si_tid;
     int si_overrun;
     sigval_t si_sigval;
   } _timer;


 struct
   {
     __pid_t si_pid;
     __uid_t si_uid;
     sigval_t si_sigval;
   } _rt;


 struct
   {
     __pid_t si_pid;
     __uid_t si_uid;
     int si_status;
     __sigchld_clock_t si_utime;
     __sigchld_clock_t si_stime;
   } _sigchld;


 struct
   {
     void *si_addr;
     short int si_addr_lsb;
   } _sigfault;


 struct
   {
     long int si_band;
     int si_fd;
   } _sigpoll;


 struct
   {
     void *_call_addr;
     int _syscall;
     unsigned int _arch;
   } _sigsys;
      } _sifields;
  } siginfo_t ;

enum
{
  SI_ASYNCNL = -60,

  SI_TKILL = -6,

  SI_SIGIO,

  SI_ASYNCIO,

  SI_MESGQ,

  SI_TIMER,

  SI_QUEUE,

  SI_USER,

  SI_KERNEL = 0x80

};



enum
{
  ILL_ILLOPC = 1,

  ILL_ILLOPN,

  ILL_ILLADR,

  ILL_ILLTRP,

  ILL_PRVOPC,

  ILL_PRVREG,

  ILL_COPROC,

  ILL_BADSTK

};


enum
{
  FPE_INTDIV = 1,

  FPE_INTOVF,

  FPE_FLTDIV,

  FPE_FLTOVF,

  FPE_FLTUND,

  FPE_FLTRES,

  FPE_FLTINV,

  FPE_FLTSUB

};


enum
{
  SEGV_MAPERR = 1,

  SEGV_ACCERR

};


enum
{
  BUS_ADRALN = 1,

  BUS_ADRERR,

  BUS_OBJERR,

  BUS_MCEERR_AR,

  BUS_MCEERR_AO

};


enum
{
  TRAP_BRKPT = 1,

  TRAP_TRACE

};


enum
{
  CLD_EXITED = 1,

  CLD_KILLED,

  CLD_DUMPED,

  CLD_TRAPPED,

  CLD_STOPPED,

  CLD_CONTINUED

};


enum
{
  POLL_IN = 1,

  POLL_OUT,

  POLL_MSG,

  POLL_ERR,

  POLL_PRI,

  POLL_HUP

};

typedef struct sigevent
  {
    sigval_t sigev_value;
    int sigev_signo;
    int sigev_notify;

    union
      {
 int _pad[((64 / sizeof (int)) - 4)];



 __pid_t _tid;

 struct
   {
     void (*_function) (sigval_t);
     pthread_attr_t *_attribute;
   } _sigev_thread;
      } _sigev_un;
  } sigevent_t;






enum
{
  SIGEV_SIGNAL = 0,

  SIGEV_NONE,

  SIGEV_THREAD,


  SIGEV_THREAD_ID = 4

};





typedef void (*__sighandler_t) (int);




/*extern*/ __sighandler_t __sysv_signal (int __sig, __sighandler_t __handler)
     __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ __sighandler_t signal (int __sig, __sighandler_t __handler)
     __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ int kill (__pid_t __pid, int __sig) __attribute__ ((__nothrow__ , __leaf__));






/*extern*/ int killpg (__pid_t __pgrp, int __sig) __attribute__ ((__nothrow__ , __leaf__));




/*extern*/ int raise (int __sig) __attribute__ ((__nothrow__ , __leaf__));




/*extern*/ __sighandler_t ssignal (int __sig, __sighandler_t __handler)
     __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int gsignal (int __sig) __attribute__ ((__nothrow__ , __leaf__));




/*extern*/ void psignal (int __sig, const char *__s);




/*extern*/ void psiginfo (const siginfo_t *__pinfo, const char *__s);

/*extern*/ int __sigpause (int __sig_or_mask, int __is_sig);

/*extern*/ int sigblock (int __mask) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__deprecated__));


/*extern*/ int sigsetmask (int __mask) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__deprecated__));


/*extern*/ int siggetmask (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__deprecated__));

typedef __sighandler_t sig_t;





/*extern*/ int sigemptyset (sigset_t *__set) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


/*extern*/ int sigfillset (sigset_t *__set) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


/*extern*/ int sigaddset (sigset_t *__set, int __signo) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


/*extern*/ int sigdelset (sigset_t *__set, int __signo) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


/*extern*/ int sigismember (const sigset_t *__set, int __signo)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



struct sigaction
  {


    union
      {

 __sighandler_t sa_handler;

 void (*sa_sigaction) (int, siginfo_t *, void *);
      }
    __sigaction_handler;







    __sigset_t sa_mask;


    int sa_flags;


    void (*sa_restorer) ();
  };



/*extern*/ int sigprocmask (int __how, const sigset_t *__restrict __set,
   sigset_t *__restrict __oset) __attribute__ ((__nothrow__ , __leaf__));






/*extern*/ int sigsuspend (const sigset_t *__set) __attribute__ ((__nonnull__ (1)));


/*extern*/ int sigaction (int __sig, const struct sigaction *__restrict __act,
        struct sigaction *__restrict __oact) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ int sigpending (sigset_t *__set) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






/*extern*/ int sigwait (const sigset_t *__restrict __set, int *__restrict __sig)
     __attribute__ ((__nonnull__ (1, 2)));






/*extern*/ int sigwaitinfo (const sigset_t *__restrict __set,
   siginfo_t *__restrict __info) __attribute__ ((__nonnull__ (1)));






/*extern*/ int sigtimedwait (const sigset_t *__restrict __set,
    siginfo_t *__restrict __info,
    const struct timespec *__restrict __timeout)
     __attribute__ ((__nonnull__ (1)));



/*extern*/ int sigqueue (__pid_t __pid, int __sig, const union sigval __val)
     __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ const char *const _sys_siglist[65];
/*extern*/ const char *const sys_siglist[65];


struct sigvec
  {
    __sighandler_t sv_handler;
    int sv_mask;

    int sv_flags;

  };

/*extern*/ int sigvec (int __sig, const struct sigvec *__vec,
     struct sigvec *__ovec) __attribute__ ((__nothrow__ , __leaf__));





struct _fpx_sw_bytes
{
  __uint32_t magic1;
  __uint32_t extended_size;
  __uint64_t xstate_bv;
  __uint32_t xstate_size;
  __uint32_t padding[7];
};

struct _fpreg
{
  unsigned short significand[4];
  unsigned short exponent;
};

struct _fpxreg
{
  unsigned short significand[4];
  unsigned short exponent;
  unsigned short padding[3];
};

struct _xmmreg
{
  __uint32_t element[4];
};

struct _fpstate
{

  __uint16_t cwd;
  __uint16_t swd;
  __uint16_t ftw;
  __uint16_t fop;
  __uint64_t rip;
  __uint64_t rdp;
  __uint32_t mxcsr;
  __uint32_t mxcr_mask;
  struct _fpxreg _st[8];
  struct _xmmreg _xmm[16];
  __uint32_t padding[24];
};

struct sigcontext
{
  __uint64_t r8;
  __uint64_t r9;
  __uint64_t r10;
  __uint64_t r11;
  __uint64_t r12;
  __uint64_t r13;
  __uint64_t r14;
  __uint64_t r15;
  __uint64_t rdi;
  __uint64_t rsi;
  __uint64_t rbp;
  __uint64_t rbx;
  __uint64_t rdx;
  __uint64_t rax;
  __uint64_t rcx;
  __uint64_t rsp;
  __uint64_t rip;
  __uint64_t eflags;
  unsigned short cs;
  unsigned short gs;
  unsigned short fs;
  unsigned short __pad0;
  __uint64_t err;
  __uint64_t trapno;
  __uint64_t oldmask;
  __uint64_t cr2;
  __extension__ union
    {
      struct _fpstate * fpstate;
      __uint64_t __fpstate_word;
    };
  __uint64_t __reserved1 [8];
};



struct _xsave_hdr
{
  __uint64_t xstate_bv;
  __uint64_t reserved1[2];
  __uint64_t reserved2[5];
};

struct _ymmh_state
{
  __uint32_t ymmh_space[64];
};

struct _xstate
{
  struct _fpstate fpstate;
  struct _xsave_hdr xstate_hdr;
  struct _ymmh_state ymmh;
};



/*extern*/ int sigreturn (struct sigcontext *__scp) __attribute__ ((__nothrow__ , __leaf__));












/*extern*/ int siginterrupt (int __sig, int __interrupt) __attribute__ ((__nothrow__ , __leaf__));



struct sigstack
  {
    void *ss_sp;
    int ss_onstack;
  };



enum
{
  SS_ONSTACK = 1,

  SS_DISABLE

};

typedef struct sigaltstack
  {
    void *ss_sp;
    int ss_flags;
    size_t ss_size;
  } stack_t;








__extension__ typedef long long int greg_t;





typedef greg_t gregset_t[23];

struct _libc_fpxreg
{
  unsigned short int significand[4];
  unsigned short int exponent;
  unsigned short int padding[3];
};

struct _libc_xmmreg
{
  __uint32_t element[4];
};

struct _libc_fpstate
{

  __uint16_t cwd;
  __uint16_t swd;
  __uint16_t ftw;
  __uint16_t fop;
  __uint64_t rip;
  __uint64_t rdp;
  __uint32_t mxcsr;
  __uint32_t mxcr_mask;
  struct _libc_fpxreg _st[8];
  struct _libc_xmmreg _xmm[16];
  __uint32_t padding[24];
};


typedef struct _libc_fpstate *fpregset_t;


typedef struct
  {
    gregset_t gregs;

    fpregset_t fpregs;
    __extension__ unsigned long long __reserved1 [8];
} mcontext_t;


typedef struct ucontext
  {
    unsigned long int uc_flags;
    struct ucontext *uc_link;
    stack_t uc_stack;
    mcontext_t uc_mcontext;
    __sigset_t uc_sigmask;
    struct _libc_fpstate __fpregs_mem;
  } ucontext_t;






/*extern*/ int sigstack (struct sigstack *__ss, struct sigstack *__oss)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__deprecated__));



/*extern*/ int sigaltstack (const struct sigaltstack *__restrict __ss,
   struct sigaltstack *__restrict __oss) __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ int pthread_sigmask (int __how,
       const __sigset_t *__restrict __newmask,
       __sigset_t *__restrict __oldmask)__attribute__ ((__nothrow__ , __leaf__));


/*extern*/ int pthread_kill (pthread_t __threadid, int __signo) __attribute__ ((__nothrow__ , __leaf__));







/*extern*/ int __libc_current_sigrtmin (void) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ int __libc_current_sigrtmax (void) __attribute__ ((__nothrow__ , __leaf__));














































































typedef __useconds_t useconds_t;

typedef __intptr_t intptr_t;






typedef __socklen_t socklen_t;

/*extern*/ int access (const char *__name, int __type) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

/*extern*/ int faccessat (int __fd, const char *__file, int __type, int __flag)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) ;

/*extern*/ __off_t lseek (int __fd, __off_t __offset, int __whence) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ int close (int __fd);






/*extern*/ ssize_t read (int __fd, void *__buf, size_t __nbytes) ;





/*extern*/ ssize_t write (int __fd, const void *__buf, size_t __n) ;

/*extern*/ ssize_t pread (int __fd, void *__buf, size_t __nbytes,
        __off_t __offset) ;






/*extern*/ ssize_t pwrite (int __fd, const void *__buf, size_t __n,
         __off_t __offset) ;

/*extern*/ int pipe (int __pipedes[2]) __attribute__ ((__nothrow__ , __leaf__)) ;

/*extern*/ unsigned int alarm (unsigned int __seconds) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ unsigned int sleep (unsigned int __seconds);







/*extern*/ __useconds_t ualarm (__useconds_t __value, __useconds_t __interval)
     __attribute__ ((__nothrow__ , __leaf__));






/*extern*/ int usleep (__useconds_t __useconds);

/*extern*/ int pause ();



/*extern*/ int chown (const char *__file, __uid_t __owner, __gid_t __group)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;



/*extern*/ int fchown (int __fd, __uid_t __owner, __gid_t __group) __attribute__ ((__nothrow__ , __leaf__)) ;




/*extern*/ int lchown (const char *__file, __uid_t __owner, __gid_t __group)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;






/*extern*/ int fchownat (int __fd, const char *__file, __uid_t __owner,
       __gid_t __group, int __flag)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) ;



/*extern*/ int chdir (const char *__path) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;



/*extern*/ int fchdir (int __fd) __attribute__ ((__nothrow__ , __leaf__)) ;

/*extern*/ char *getcwd (char *__buf, size_t __size) __attribute__ ((__nothrow__ , __leaf__)) ;

/*extern*/ char *getwd (char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__deprecated__)) ;




/*extern*/ int dup (int __fd) __attribute__ ((__nothrow__ , __leaf__)) ;


/*extern*/ int dup2 (int __fd, int __fd2) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ char **__environ;







/*extern*/ int execve (const char *__path, char *const __argv[],
     char *const __envp[]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




/*extern*/ int fexecve (int __fd, char *const __argv[], char *const __envp[])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));




/*extern*/ int execv (const char *__path, char *const __argv[])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



/*extern*/ int execle (const char *__path, const char *__arg, ...)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



/*extern*/ int execl (const char *__path, const char *__arg, ...)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



/*extern*/ int execvp (const char *__file, char *const __argv[])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




/*extern*/ int execlp (const char *__file, const char *__arg, ...)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ int nice (int __inc) __attribute__ ((__nothrow__ , __leaf__)) ;




/*extern*/ void _exit (int __status) __attribute__ ((__noreturn__));







enum
  {
    _PC_LINK_MAX,

    _PC_MAX_CANON,

    _PC_MAX_INPUT,

    _PC_NAME_MAX,

    _PC_PATH_MAX,

    _PC_PIPE_BUF,

    _PC_CHOWN_RESTRICTED,

    _PC_NO_TRUNC,

    _PC_VDISABLE,

    _PC_SYNC_IO,

    _PC_ASYNC_IO,

    _PC_PRIO_IO,

    _PC_SOCK_MAXBUF,

    _PC_FILESIZEBITS,

    _PC_REC_INCR_XFER_SIZE,

    _PC_REC_MAX_XFER_SIZE,

    _PC_REC_MIN_XFER_SIZE,

    _PC_REC_XFER_ALIGN,

    _PC_ALLOC_SIZE_MIN,

    _PC_SYMLINK_MAX,

    _PC_2_SYMLINKS

  };


enum
  {
    _SC_ARG_MAX,

    _SC_CHILD_MAX,

    _SC_CLK_TCK,

    _SC_NGROUPS_MAX,

    _SC_OPEN_MAX,

    _SC_STREAM_MAX,

    _SC_TZNAME_MAX,

    _SC_JOB_CONTROL,

    _SC_SAVED_IDS,

    _SC_REALTIME_SIGNALS,

    _SC_PRIORITY_SCHEDULING,

    _SC_TIMERS,

    _SC_ASYNCHRONOUS_IO,

    _SC_PRIORITIZED_IO,

    _SC_SYNCHRONIZED_IO,

    _SC_FSYNC,

    _SC_MAPPED_FILES,

    _SC_MEMLOCK,

    _SC_MEMLOCK_RANGE,

    _SC_MEMORY_PROTECTION,

    _SC_MESSAGE_PASSING,

    _SC_SEMAPHORES,

    _SC_SHARED_MEMORY_OBJECTS,

    _SC_AIO_LISTIO_MAX,

    _SC_AIO_MAX,

    _SC_AIO_PRIO_DELTA_MAX,

    _SC_DELAYTIMER_MAX,

    _SC_MQ_OPEN_MAX,

    _SC_MQ_PRIO_MAX,

    _SC_VERSION,

    _SC_PAGESIZE,


    _SC_RTSIG_MAX,

    _SC_SEM_NSEMS_MAX,

    _SC_SEM_VALUE_MAX,

    _SC_SIGQUEUE_MAX,

    _SC_TIMER_MAX,




    _SC_BC_BASE_MAX,

    _SC_BC_DIM_MAX,

    _SC_BC_SCALE_MAX,

    _SC_BC_STRING_MAX,

    _SC_COLL_WEIGHTS_MAX,

    _SC_EQUIV_CLASS_MAX,

    _SC_EXPR_NEST_MAX,

    _SC_LINE_MAX,

    _SC_RE_DUP_MAX,

    _SC_CHARCLASS_NAME_MAX,


    _SC_2_VERSION,

    _SC_2_C_BIND,

    _SC_2_C_DEV,

    _SC_2_FORT_DEV,

    _SC_2_FORT_RUN,

    _SC_2_SW_DEV,

    _SC_2_LOCALEDEF,


    _SC_PII,

    _SC_PII_XTI,

    _SC_PII_SOCKET,

    _SC_PII_INTERNET,

    _SC_PII_OSI,

    _SC_POLL,

    _SC_SELECT,

    _SC_UIO_MAXIOV,

    _SC_IOV_MAX = _SC_UIO_MAXIOV,

    _SC_PII_INTERNET_STREAM,

    _SC_PII_INTERNET_DGRAM,

    _SC_PII_OSI_COTS,

    _SC_PII_OSI_CLTS,

    _SC_PII_OSI_M,

    _SC_T_IOV_MAX,



    _SC_THREADS,

    _SC_THREAD_SAFE_FUNCTIONS,

    _SC_GETGR_R_SIZE_MAX,

    _SC_GETPW_R_SIZE_MAX,

    _SC_LOGIN_NAME_MAX,

    _SC_TTY_NAME_MAX,

    _SC_THREAD_DESTRUCTOR_ITERATIONS,

    _SC_THREAD_KEYS_MAX,

    _SC_THREAD_STACK_MIN,

    _SC_THREAD_THREADS_MAX,

    _SC_THREAD_ATTR_STACKADDR,

    _SC_THREAD_ATTR_STACKSIZE,

    _SC_THREAD_PRIORITY_SCHEDULING,

    _SC_THREAD_PRIO_INHERIT,

    _SC_THREAD_PRIO_PROTECT,

    _SC_THREAD_PROCESS_SHARED,


    _SC_NPROCESSORS_CONF,

    _SC_NPROCESSORS_ONLN,

    _SC_PHYS_PAGES,

    _SC_AVPHYS_PAGES,

    _SC_ATEXIT_MAX,

    _SC_PASS_MAX,


    _SC_XOPEN_VERSION,

    _SC_XOPEN_XCU_VERSION,

    _SC_XOPEN_UNIX,

    _SC_XOPEN_CRYPT,

    _SC_XOPEN_ENH_I18N,

    _SC_XOPEN_SHM,


    _SC_2_CHAR_TERM,

    _SC_2_C_VERSION,

    _SC_2_UPE,


    _SC_XOPEN_XPG2,

    _SC_XOPEN_XPG3,

    _SC_XOPEN_XPG4,


    _SC_CHAR_BIT,

    _SC_CHAR_MAX,

    _SC_CHAR_MIN,

    _SC_INT_MAX,

    _SC_INT_MIN,

    _SC_LONG_BIT,

    _SC_WORD_BIT,

    _SC_MB_LEN_MAX,

    _SC_NZERO,

    _SC_SSIZE_MAX,

    _SC_SCHAR_MAX,

    _SC_SCHAR_MIN,

    _SC_SHRT_MAX,

    _SC_SHRT_MIN,

    _SC_UCHAR_MAX,

    _SC_UINT_MAX,

    _SC_ULONG_MAX,

    _SC_USHRT_MAX,


    _SC_NL_ARGMAX,

    _SC_NL_LANGMAX,

    _SC_NL_MSGMAX,

    _SC_NL_NMAX,

    _SC_NL_SETMAX,

    _SC_NL_TEXTMAX,


    _SC_XBS5_ILP32_OFF32,

    _SC_XBS5_ILP32_OFFBIG,

    _SC_XBS5_LP64_OFF64,

    _SC_XBS5_LPBIG_OFFBIG,


    _SC_XOPEN_LEGACY,

    _SC_XOPEN_REALTIME,

    _SC_XOPEN_REALTIME_THREADS,


    _SC_ADVISORY_INFO,

    _SC_BARRIERS,

    _SC_BASE,

    _SC_C_LANG_SUPPORT,

    _SC_C_LANG_SUPPORT_R,

    _SC_CLOCK_SELECTION,

    _SC_CPUTIME,

    _SC_THREAD_CPUTIME,

    _SC_DEVICE_IO,

    _SC_DEVICE_SPECIFIC,

    _SC_DEVICE_SPECIFIC_R,

    _SC_FD_MGMT,

    _SC_FIFO,

    _SC_PIPE,

    _SC_FILE_ATTRIBUTES,

    _SC_FILE_LOCKING,

    _SC_FILE_SYSTEM,

    _SC_MONOTONIC_CLOCK,

    _SC_MULTI_PROCESS,

    _SC_SINGLE_PROCESS,

    _SC_NETWORKING,

    _SC_READER_WRITER_LOCKS,

    _SC_SPIN_LOCKS,

    _SC_REGEXP,

    _SC_REGEX_VERSION,

    _SC_SHELL,

    _SC_SIGNALS,

    _SC_SPAWN,

    _SC_SPORADIC_SERVER,

    _SC_THREAD_SPORADIC_SERVER,

    _SC_SYSTEM_DATABASE,

    _SC_SYSTEM_DATABASE_R,

    _SC_TIMEOUTS,

    _SC_TYPED_MEMORY_OBJECTS,

    _SC_USER_GROUPS,

    _SC_USER_GROUPS_R,

    _SC_2_PBS,

    _SC_2_PBS_ACCOUNTING,

    _SC_2_PBS_LOCATE,

    _SC_2_PBS_MESSAGE,

    _SC_2_PBS_TRACK,

    _SC_SYMLOOP_MAX,

    _SC_STREAMS,

    _SC_2_PBS_CHECKPOINT,


    _SC_V6_ILP32_OFF32,

    _SC_V6_ILP32_OFFBIG,

    _SC_V6_LP64_OFF64,

    _SC_V6_LPBIG_OFFBIG,


    _SC_HOST_NAME_MAX,

    _SC_TRACE,

    _SC_TRACE_EVENT_FILTER,

    _SC_TRACE_INHERIT,

    _SC_TRACE_LOG,


    _SC_LEVEL1_ICACHE_SIZE,

    _SC_LEVEL1_ICACHE_ASSOC,

    _SC_LEVEL1_ICACHE_LINESIZE,

    _SC_LEVEL1_DCACHE_SIZE,

    _SC_LEVEL1_DCACHE_ASSOC,

    _SC_LEVEL1_DCACHE_LINESIZE,

    _SC_LEVEL2_CACHE_SIZE,

    _SC_LEVEL2_CACHE_ASSOC,

    _SC_LEVEL2_CACHE_LINESIZE,

    _SC_LEVEL3_CACHE_SIZE,

    _SC_LEVEL3_CACHE_ASSOC,

    _SC_LEVEL3_CACHE_LINESIZE,

    _SC_LEVEL4_CACHE_SIZE,

    _SC_LEVEL4_CACHE_ASSOC,

    _SC_LEVEL4_CACHE_LINESIZE,



    _SC_IPV6 = _SC_LEVEL1_ICACHE_SIZE + 50,

    _SC_RAW_SOCKETS,


    _SC_V7_ILP32_OFF32,

    _SC_V7_ILP32_OFFBIG,

    _SC_V7_LP64_OFF64,

    _SC_V7_LPBIG_OFFBIG,


    _SC_SS_REPL_MAX,


    _SC_TRACE_EVENT_NAME_MAX,

    _SC_TRACE_NAME_MAX,

    _SC_TRACE_SYS_MAX,

    _SC_TRACE_USER_EVENT_MAX,


    _SC_XOPEN_STREAMS,


    _SC_THREAD_ROBUST_PRIO_INHERIT,

    _SC_THREAD_ROBUST_PRIO_PROTECT

  };


enum
  {
    _CS_PATH,


    _CS_V6_WIDTH_RESTRICTED_ENVS,



    _CS_GNU_LIBC_VERSION,

    _CS_GNU_LIBPTHREAD_VERSION,


    _CS_V5_WIDTH_RESTRICTED_ENVS,



    _CS_V7_WIDTH_RESTRICTED_ENVS,



    _CS_LFS_CFLAGS = 1000,

    _CS_LFS_LDFLAGS,

    _CS_LFS_LIBS,

    _CS_LFS_LINTFLAGS,

    _CS_LFS64_CFLAGS,

    _CS_LFS64_LDFLAGS,

    _CS_LFS64_LIBS,

    _CS_LFS64_LINTFLAGS,


    _CS_XBS5_ILP32_OFF32_CFLAGS = 1100,

    _CS_XBS5_ILP32_OFF32_LDFLAGS,

    _CS_XBS5_ILP32_OFF32_LIBS,

    _CS_XBS5_ILP32_OFF32_LINTFLAGS,

    _CS_XBS5_ILP32_OFFBIG_CFLAGS,

    _CS_XBS5_ILP32_OFFBIG_LDFLAGS,

    _CS_XBS5_ILP32_OFFBIG_LIBS,

    _CS_XBS5_ILP32_OFFBIG_LINTFLAGS,

    _CS_XBS5_LP64_OFF64_CFLAGS,

    _CS_XBS5_LP64_OFF64_LDFLAGS,

    _CS_XBS5_LP64_OFF64_LIBS,

    _CS_XBS5_LP64_OFF64_LINTFLAGS,

    _CS_XBS5_LPBIG_OFFBIG_CFLAGS,

    _CS_XBS5_LPBIG_OFFBIG_LDFLAGS,

    _CS_XBS5_LPBIG_OFFBIG_LIBS,

    _CS_XBS5_LPBIG_OFFBIG_LINTFLAGS,


    _CS_POSIX_V6_ILP32_OFF32_CFLAGS,

    _CS_POSIX_V6_ILP32_OFF32_LDFLAGS,

    _CS_POSIX_V6_ILP32_OFF32_LIBS,

    _CS_POSIX_V6_ILP32_OFF32_LINTFLAGS,

    _CS_POSIX_V6_ILP32_OFFBIG_CFLAGS,

    _CS_POSIX_V6_ILP32_OFFBIG_LDFLAGS,

    _CS_POSIX_V6_ILP32_OFFBIG_LIBS,

    _CS_POSIX_V6_ILP32_OFFBIG_LINTFLAGS,

    _CS_POSIX_V6_LP64_OFF64_CFLAGS,

    _CS_POSIX_V6_LP64_OFF64_LDFLAGS,

    _CS_POSIX_V6_LP64_OFF64_LIBS,

    _CS_POSIX_V6_LP64_OFF64_LINTFLAGS,

    _CS_POSIX_V6_LPBIG_OFFBIG_CFLAGS,

    _CS_POSIX_V6_LPBIG_OFFBIG_LDFLAGS,

    _CS_POSIX_V6_LPBIG_OFFBIG_LIBS,

    _CS_POSIX_V6_LPBIG_OFFBIG_LINTFLAGS,


    _CS_POSIX_V7_ILP32_OFF32_CFLAGS,

    _CS_POSIX_V7_ILP32_OFF32_LDFLAGS,

    _CS_POSIX_V7_ILP32_OFF32_LIBS,

    _CS_POSIX_V7_ILP32_OFF32_LINTFLAGS,

    _CS_POSIX_V7_ILP32_OFFBIG_CFLAGS,

    _CS_POSIX_V7_ILP32_OFFBIG_LDFLAGS,

    _CS_POSIX_V7_ILP32_OFFBIG_LIBS,

    _CS_POSIX_V7_ILP32_OFFBIG_LINTFLAGS,

    _CS_POSIX_V7_LP64_OFF64_CFLAGS,

    _CS_POSIX_V7_LP64_OFF64_LDFLAGS,

    _CS_POSIX_V7_LP64_OFF64_LIBS,

    _CS_POSIX_V7_LP64_OFF64_LINTFLAGS,

    _CS_POSIX_V7_LPBIG_OFFBIG_CFLAGS,

    _CS_POSIX_V7_LPBIG_OFFBIG_LDFLAGS,

    _CS_POSIX_V7_LPBIG_OFFBIG_LIBS,

    _CS_POSIX_V7_LPBIG_OFFBIG_LINTFLAGS,


    _CS_V6_ENV,

    _CS_V7_ENV

  };



/*extern*/ long int pathconf (const char *__path, int __name)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


/*extern*/ long int fpathconf (int __fd, int __name) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ long int sysconf (int __name) __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ size_t confstr (int __name, char *__buf, size_t __len) __attribute__ ((__nothrow__ , __leaf__));




/*extern*/ __pid_t getpid (void) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ __pid_t getppid (void) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ __pid_t getpgrp (void) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ __pid_t __getpgid (__pid_t __pid) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ __pid_t getpgid (__pid_t __pid) __attribute__ ((__nothrow__ , __leaf__));






/*extern*/ int setpgid (__pid_t __pid, __pid_t __pgid) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ int setpgrp (void) __attribute__ ((__nothrow__ , __leaf__));






/*extern*/ __pid_t setsid (void) __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ __pid_t getsid (__pid_t __pid) __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ __uid_t getuid (void) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ __uid_t geteuid (void) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ __gid_t getgid (void) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ __gid_t getegid (void) __attribute__ ((__nothrow__ , __leaf__));




/*extern*/ int getgroups (int __size, __gid_t __list[]) __attribute__ ((__nothrow__ , __leaf__)) ;

/*extern*/ int setuid (__uid_t __uid) __attribute__ ((__nothrow__ , __leaf__)) ;




/*extern*/ int setreuid (__uid_t __ruid, __uid_t __euid) __attribute__ ((__nothrow__ , __leaf__)) ;




/*extern*/ int seteuid (__uid_t __uid) __attribute__ ((__nothrow__ , __leaf__)) ;






/*extern*/ int setgid (__gid_t __gid) __attribute__ ((__nothrow__ , __leaf__)) ;




/*extern*/ int setregid (__gid_t __rgid, __gid_t __egid) __attribute__ ((__nothrow__ , __leaf__)) ;




/*extern*/ int setegid (__gid_t __gid) __attribute__ ((__nothrow__ , __leaf__)) ;

/*extern*/ __pid_t fork (void) __attribute__ ((__nothrow__));







/*extern*/ __pid_t vfork (void) __attribute__ ((__nothrow__ , __leaf__));





/*extern*/ char *ttyname (int __fd) __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ int ttyname_r (int __fd, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) ;



/*extern*/ int isatty (int __fd) __attribute__ ((__nothrow__ , __leaf__));





/*extern*/ int ttyslot (void) __attribute__ ((__nothrow__ , __leaf__));




/*extern*/ int link (const char *__from, const char *__to)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) ;




/*extern*/ int linkat (int __fromfd, const char *__from, int __tofd,
     const char *__to, int __flags)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4))) ;




/*extern*/ int symlink (const char *__from, const char *__to)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) ;




/*extern*/ ssize_t readlink (const char *__restrict __path,
    char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) ;




/*extern*/ int symlinkat (const char *__from, int __tofd,
        const char *__to) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3))) ;


/*extern*/ ssize_t readlinkat (int __fd, const char *__restrict __path,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3))) ;



/*extern*/ int unlink (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



/*extern*/ int unlinkat (int __fd, const char *__name, int __flag)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



/*extern*/ int rmdir (const char *__path) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



/*extern*/ __pid_t tcgetpgrp (int __fd) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ int tcsetpgrp (int __fd, __pid_t __pgrp_id) __attribute__ ((__nothrow__ , __leaf__));






/*extern*/ char *getlogin ();







/*extern*/ int getlogin_r (char *__name, size_t __name_len) __attribute__ ((__nonnull__ (1)));




/*extern*/ int setlogin (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



/*extern*/ char *optarg;

/*extern*/ int optind;




/*extern*/ int opterr;



/*extern*/ int optopt;

/*extern*/ int getopt (int ___argc, char *const *___argv, const char *__shortopts)
       __attribute__ ((__nothrow__ , __leaf__));








/*extern*/ int gethostname (char *__name, size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






/*extern*/ int sethostname (const char *__name, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;



/*extern*/ int sethostid (long int __id) __attribute__ ((__nothrow__ , __leaf__)) ;





/*extern*/ int getdomainname (char *__name, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
/*extern*/ int setdomainname (const char *__name, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;





/*extern*/ int vhangup (void) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ int revoke (const char *__file) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;







/*extern*/ int profil (unsigned short int *__sample_buffer, size_t __size,
     size_t __offset, unsigned int __scale)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





/*extern*/ int acct (const char *__name) __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ char *getusershell (void) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ void endusershell (void) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ void setusershell (void) __attribute__ ((__nothrow__ , __leaf__));





/*extern*/ int daemon (int __nochdir, int __noclose) __attribute__ ((__nothrow__ , __leaf__)) ;






/*extern*/ int chroot (const char *__path) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;



/*extern*/ char *getpass (const char *__prompt) __attribute__ ((__nonnull__ (1)));







/*extern*/ int fsync (int __fd);

/*extern*/ long int gethostid ();


/*extern*/ void sync (void) __attribute__ ((__nothrow__ , __leaf__));





/*extern*/ int getpagesize (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));




/*extern*/ int getdtablesize (void) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ int truncate (const char *__file, __off_t __length)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;

/*extern*/ int ftruncate (int __fd, __off_t __length) __attribute__ ((__nothrow__ , __leaf__)) ;

/*extern*/ int brk (void *__addr) __attribute__ ((__nothrow__ , __leaf__)) ;





/*extern*/ void *sbrk (intptr_t __delta) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ long int syscall (long int __sysno, ...) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ int fdatasync (int __fildes);





















struct timezone
  {
    int tz_minuteswest;
    int tz_dsttime;
  };

typedef struct timezone *__restrict __timezone_ptr_t;

/*extern*/ int gettimeofday (struct timeval *__restrict __tv,
    __timezone_ptr_t __tz) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));




/*extern*/ int settimeofday (const struct timeval *__tv,
    const struct timezone *__tz)
     __attribute__ ((__nothrow__ , __leaf__));





/*extern*/ int adjtime (const struct timeval *__delta,
      struct timeval *__olddelta) __attribute__ ((__nothrow__ , __leaf__));




enum __itimer_which
  {

    ITIMER_REAL = 0,


    ITIMER_VIRTUAL = 1,



    ITIMER_PROF = 2

  };



struct itimerval
  {

    struct timeval it_interval;

    struct timeval it_value;
  };






typedef int __itimer_which_t;




/*extern*/ int getitimer (__itimer_which_t __which,
        struct itimerval *__value) __attribute__ ((__nothrow__ , __leaf__));




/*extern*/ int setitimer (__itimer_which_t __which,
        const struct itimerval *__restrict __new,
        struct itimerval *__restrict __old) __attribute__ ((__nothrow__ , __leaf__));




/*extern*/ int utimes (const char *__file, const struct timeval __tvp[2])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



/*extern*/ int lutimes (const char *__file, const struct timeval __tvp[2])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


/*extern*/ int futimes (int __fd, const struct timeval __tvp[2]) __attribute__ ((__nothrow__ , __leaf__));










enum __rlimit_resource
{

  RLIMIT_CPU = 0,



  RLIMIT_FSIZE = 1,



  RLIMIT_DATA = 2,



  RLIMIT_STACK = 3,



  RLIMIT_CORE = 4,






  __RLIMIT_RSS = 5,



  RLIMIT_NOFILE = 7,
  __RLIMIT_OFILE = RLIMIT_NOFILE,




  RLIMIT_AS = 9,



  __RLIMIT_NPROC = 6,



  __RLIMIT_MEMLOCK = 8,



  __RLIMIT_LOCKS = 10,



  __RLIMIT_SIGPENDING = 11,



  __RLIMIT_MSGQUEUE = 12,





  __RLIMIT_NICE = 13,




  __RLIMIT_RTPRIO = 14,





  __RLIMIT_RTTIME = 15,


  __RLIMIT_NLIMITS = 16,
  __RLIM_NLIMITS = __RLIMIT_NLIMITS


};

typedef __rlim_t rlim_t;







struct rlimit
  {

    rlim_t rlim_cur;

    rlim_t rlim_max;
  };

enum __rusage_who
{

  RUSAGE_SELF = 0,



  RUSAGE_CHILDREN = -1

};











struct rusage
  {

    struct timeval ru_utime;

    struct timeval ru_stime;

    __extension__ union
      {
 long int ru_maxrss;
 __syscall_slong_t __ru_maxrss_word;
      };



    __extension__ union
      {
 long int ru_ixrss;
 __syscall_slong_t __ru_ixrss_word;
      };

    __extension__ union
      {
 long int ru_idrss;
 __syscall_slong_t __ru_idrss_word;
      };

    __extension__ union
      {
 long int ru_isrss;
  __syscall_slong_t __ru_isrss_word;
      };


    __extension__ union
      {
 long int ru_minflt;
 __syscall_slong_t __ru_minflt_word;
      };

    __extension__ union
      {
 long int ru_majflt;
 __syscall_slong_t __ru_majflt_word;
      };

    __extension__ union
      {
 long int ru_nswap;
 __syscall_slong_t __ru_nswap_word;
      };


    __extension__ union
      {
 long int ru_inblock;
 __syscall_slong_t __ru_inblock_word;
      };

    __extension__ union
      {
 long int ru_oublock;
 __syscall_slong_t __ru_oublock_word;
      };

    __extension__ union
      {
 long int ru_msgsnd;
 __syscall_slong_t __ru_msgsnd_word;
      };

    __extension__ union
      {
 long int ru_msgrcv;
 __syscall_slong_t __ru_msgrcv_word;
      };

    __extension__ union
      {
 long int ru_nsignals;
 __syscall_slong_t __ru_nsignals_word;
      };



    __extension__ union
      {
 long int ru_nvcsw;
 __syscall_slong_t __ru_nvcsw_word;
      };


    __extension__ union
      {
 long int ru_nivcsw;
 __syscall_slong_t __ru_nivcsw_word;
      };
  };







enum __priority_which
{
  PRIO_PROCESS = 0,

  PRIO_PGRP = 1,

  PRIO_USER = 2

};














typedef int __rlimit_resource_t;
typedef int __rusage_who_t;
typedef int __priority_which_t;





/*extern*/ int getrlimit (__rlimit_resource_t __resource,
        struct rlimit *__rlimits) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ int setrlimit (__rlimit_resource_t __resource,
        const struct rlimit *__rlimits) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ int getrusage (__rusage_who_t __who, struct rusage *__usage) __attribute__ ((__nothrow__ , __leaf__));





/*extern*/ int getpriority (__priority_which_t __which, id_t __who) __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ int setpriority (__priority_which_t __which, id_t __who, int __prio)
     __attribute__ ((__nothrow__ , __leaf__));















struct tms
  {
    clock_t tms_utime;
    clock_t tms_stime;

    clock_t tms_cutime;
    clock_t tms_cstime;
  };






/*extern*/ clock_t __sym_times (struct tms *__buffer){
    return 0;
}

























/*extern*/ int *__errno_location (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));























/*extern*/ void *memcpy (void *__restrict __dest, const void *__restrict __src,
       size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


/*extern*/ void *memmove (void *__dest, const void *__src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));






/*extern*/ void *memccpy (void *__restrict __dest, const void *__restrict __src,
        int __c, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));





/*extern*/ void *memset (void *__s, int __c, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


/*extern*/ int memcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ void *memchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));





/*extern*/ char *strcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ char *strncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


/*extern*/ char *strcat (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ char *strncat (char *__restrict __dest, const char *__restrict __src,
        size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


/*extern*/ int strcmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ int strncmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


/*extern*/ int strcoll (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ size_t strxfrm (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));


/*extern*/ int strcoll_l (const char *__s1, const char *__s2, __locale_t __l)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));

/*extern*/ size_t strxfrm_l (char *__dest, const char *__src, size_t __n,
    __locale_t __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)));





/*extern*/ char *strdup (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));






/*extern*/ char *strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));



/*extern*/ char *strchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));

/*extern*/ char *strrchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));






/*extern*/ size_t strcspn (const char *__s, const char *__reject)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


/*extern*/ size_t strspn (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ char *strpbrk (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ char *strstr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));




/*extern*/ char *strtok (char *__restrict __s, const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));




/*extern*/ char *__strtok_r (char *__restrict __s,
    const char *__restrict __delim,
    char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));

/*extern*/ char *strtok_r (char *__restrict __s, const char *__restrict __delim,
         char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));



/*extern*/ size_t strlen (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));





/*extern*/ size_t strnlen (const char *__string, size_t __maxlen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));





/*extern*/ char *strerror (int __errnum) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ int strerror_r (int __errnum, char *__buf, size_t __buflen) __asm__ ("" "__xpg_strerror_r") __attribute__ ((__nothrow__ , __leaf__))

                        __attribute__ ((__nonnull__ (2)));

/*extern*/ char *strerror_l (int __errnum, __locale_t __l) __attribute__ ((__nothrow__ , __leaf__));





/*extern*/ void __bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



/*extern*/ void bcopy (const void *__src, void *__dest, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


/*extern*/ void bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


/*extern*/ int bcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ char *index (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));

/*extern*/ char *rindex (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




/*extern*/ int ffs (int __i) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));

/*extern*/ int strcasecmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


/*extern*/ int strncasecmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ char *strsep (char **__restrict __stringp,
       const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




/*extern*/ char *strsignal (int __sig) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ char *__stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
/*extern*/ char *stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



/*extern*/ char *__stpncpy (char *__restrict __dest,
   const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
/*extern*/ char *stpncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));







/*extern*/ void *__rawmemchr (const void *__s, int __c);

/*extern*/ __inline __attribute__ ((__gnu_inline__)) size_t __strcspn_c1 (const char *__s, int __reject);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) size_t
__strcspn_c1 (const char *__s, int __reject)
{
  size_t __result = 0;
  while (__s[__result] != '\0' && __s[__result] != __reject)
    ++__result;
  return __result;
}

/*extern*/ __inline __attribute__ ((__gnu_inline__)) size_t __strcspn_c2 (const char *__s, int __reject1,
         int __reject2);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) size_t
__strcspn_c2 (const char *__s, int __reject1, int __reject2)
{
  size_t __result = 0;
  while (__s[__result] != '\0' && __s[__result] != __reject1
  && __s[__result] != __reject2)
    ++__result;
  return __result;
}

/*extern*/ __inline __attribute__ ((__gnu_inline__)) size_t __strcspn_c3 (const char *__s, int __reject1,
         int __reject2, int __reject3);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) size_t
__strcspn_c3 (const char *__s, int __reject1, int __reject2,
       int __reject3)
{
  size_t __result = 0;
  while (__s[__result] != '\0' && __s[__result] != __reject1
  && __s[__result] != __reject2 && __s[__result] != __reject3)
    ++__result;
  return __result;
}

/*extern*/ __inline __attribute__ ((__gnu_inline__)) size_t __strspn_c1 (const char *__s, int __accept);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) size_t
__strspn_c1 (const char *__s, int __accept)
{
  size_t __result = 0;

  while (__s[__result] == __accept)
    ++__result;
  return __result;
}

/*extern*/ __inline __attribute__ ((__gnu_inline__)) size_t __strspn_c2 (const char *__s, int __accept1,
        int __accept2);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) size_t
__strspn_c2 (const char *__s, int __accept1, int __accept2)
{
  size_t __result = 0;

  while (__s[__result] == __accept1 || __s[__result] == __accept2)
    ++__result;
  return __result;
}

/*extern*/ __inline __attribute__ ((__gnu_inline__)) size_t __strspn_c3 (const char *__s, int __accept1,
        int __accept2, int __accept3);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) size_t
__strspn_c3 (const char *__s, int __accept1, int __accept2, int __accept3)
{
  size_t __result = 0;

  while (__s[__result] == __accept1 || __s[__result] == __accept2
  || __s[__result] == __accept3)
    ++__result;
  return __result;
}

/*extern*/ __inline __attribute__ ((__gnu_inline__)) char *__strpbrk_c2 (const char *__s, int __accept1,
        int __accept2);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) char *
__strpbrk_c2 (const char *__s, int __accept1, int __accept2)
{

  while (*__s != '\0' && *__s != __accept1 && *__s != __accept2)
    ++__s;
  return *__s == '\0' ? ((void *)0) : (char *) (size_t) __s;
}

/*extern*/ __inline __attribute__ ((__gnu_inline__)) char *__strpbrk_c3 (const char *__s, int __accept1,
        int __accept2, int __accept3);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) char *
__strpbrk_c3 (const char *__s, int __accept1, int __accept2, int __accept3)
{

  while (*__s != '\0' && *__s != __accept1 && *__s != __accept2
  && *__s != __accept3)
    ++__s;
  return *__s == '\0' ? ((void *)0) : (char *) (size_t) __s;
}

/*extern*/ __inline __attribute__ ((__gnu_inline__)) char *__strtok_r_1c (char *__s, char __sep, char **__nextp);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) char *
__strtok_r_1c (char *__s, char __sep, char **__nextp)
{
  char *__result;
  if (__s == ((void *)0))
    __s = *__nextp;
  while (*__s == __sep)
    ++__s;
  __result = ((void *)0);
  if (*__s != '\0')
    {
      __result = __s++;
      while (*__s != '\0')
 if (*__s++ == __sep)
   {
     __s[-1] = '\0';
     break;
   }
    }
  *__nextp = __s;
  return __result;
}

/*extern*/ char *__strsep_g (char **__stringp, const char *__delim);

/*extern*/ __inline __attribute__ ((__gnu_inline__)) char *__strsep_1c (char **__s, char __reject);
static void * __sym___rawmemchr(const void * param0, int param1, ...);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) char *
__strsep_1c (char **__s, char __reject)
{
  char *__retval = *__s;
  if (__retval != ((void *)0) && (*__s = (__extension__ (__builtin_constant_p (__reject) && !__builtin_constant_p (__retval) && (__reject) == '\0' ? (char *) __sym___rawmemchr (__retval, __reject) : __builtin_strchr (__retval, __reject)))) != ((void *)0))
    *(*__s)++ = '\0';
  return __retval;
}

/*extern*/ __inline __attribute__ ((__gnu_inline__)) char *__strsep_2c (char **__s, char __reject1, char __reject2);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) char *
__strsep_2c (char **__s, char __reject1, char __reject2)
{
  char *__retval = *__s;
  if (__retval != ((void *)0))
    {
      char *__cp = __retval;
      while (1)
 {
   if (*__cp == '\0')
     {
       __cp = ((void *)0);
   break;
     }
   if (*__cp == __reject1 || *__cp == __reject2)
     {
       *__cp++ = '\0';
       break;
     }
   ++__cp;
 }
      *__s = __cp;
    }
  return __retval;
}

/*extern*/ __inline __attribute__ ((__gnu_inline__)) char *__strsep_3c (char **__s, char __reject1, char __reject2,
       char __reject3);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) char *
__strsep_3c (char **__s, char __reject1, char __reject2, char __reject3)
{
  char *__retval = *__s;
  if (__retval != ((void *)0))
    {
      char *__cp = __retval;
      while (1)
 {
   if (*__cp == '\0')
     {
       __cp = ((void *)0);
   break;
     }
   if (*__cp == __reject1 || *__cp == __reject2 || *__cp == __reject3)
     {
       *__cp++ = '\0';
       break;
     }
   ++__cp;
 }
      *__s = __cp;
    }
  return __retval;
}










/*extern*/ void *malloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) ;

/*extern*/ void *calloc (size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) ;








/*extern*/ char *__strdup (const char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__));

/*extern*/ char *__strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__));













typedef int wchar_t;











typedef enum
{
  P_ALL,
  P_PID,
  P_PGID
} idtype_t;



union wait
  {
    int w_status;
    struct
      {

 unsigned int __w_termsig:7;
 unsigned int __w_coredump:1;
 unsigned int __w_retcode:8;
 unsigned int:16;







      } __wait_terminated;
    struct
      {

 unsigned int __w_stopval:8;
 unsigned int __w_stopsig:8;
 unsigned int:16;






      } __wait_stopped;
  };


typedef union
  {
    union wait *__uptr;
    int *__iptr;
  } __WAIT_STATUS __attribute__ ((__transparent_union__));



typedef struct
  {
    int quot;
    int rem;
  } div_t;



typedef struct
  {
    long int quot;
    long int rem;
  } ldiv_t;







__extension__ typedef struct
  {
    long long int quot;
    long long int rem;
  } lldiv_t;



/*extern*/ size_t __ctype_get_mb_cur_max (void) __attribute__ ((__nothrow__ , __leaf__)) ;




/*extern*/ double atof (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

/*extern*/ int atoi (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

/*extern*/ long int atol (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;





__extension__ /*extern*/ long long int atoll (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;





/*extern*/ double strtod (const char *__restrict __nptr,
        char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





/*extern*/ float strtof (const char *__restrict __nptr,
       char **__restrict __endptr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

/*extern*/ long double strtold (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





/*extern*/ long int strtol (const char *__restrict __nptr,
   char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

/*extern*/ unsigned long int strtoul (const char *__restrict __nptr,
      char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));




__extension__
/*extern*/ long long int strtoq (const char *__restrict __nptr,
        char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
/*extern*/ unsigned long long int strtouq (const char *__restrict __nptr,
           char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





__extension__
/*extern*/ long long int strtoll (const char *__restrict __nptr,
         char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
/*extern*/ unsigned long long int strtoull (const char *__restrict __nptr,
     char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



static long __sym_strtol(const char * param0, char ** param1, int param2, ...);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) atoi (const char *__nptr)
{
  return (int) __sym_strtol (__nptr, (char **) ((void *)0), 10);
}
/*extern*/ __inline __attribute__ ((__gnu_inline__)) long int
__attribute__ ((__nothrow__ , __leaf__)) atol (const char *__nptr)
{
  return __sym_strtol (__nptr, (char **) ((void *)0), 10);
}




__extension__ static long long __sym_strtoll(const char * param0, char ** param1, int param2, ...);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) long long int
__attribute__ ((__nothrow__ , __leaf__)) atoll (const char *__nptr)
{
  return __sym_strtoll (__nptr, (char **) ((void *)0), 10);
}


/*extern*/ char *l64a (long int __n) __attribute__ ((__nothrow__ , __leaf__)) ;


/*extern*/ long int a64l (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

/*extern*/ long int random (void) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ void srandom (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));





/*extern*/ char *initstate (unsigned int __seed, char *__statebuf,
   size_t __statelen) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



/*extern*/ char *setstate (char *__statebuf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







struct random_data
  {
    int32_t *fptr;
    int32_t *rptr;
    int32_t *state;
    int rand_type;
    int rand_deg;
    int rand_sep;
    int32_t *end_ptr;
  };

/*extern*/ int random_r (struct random_data *__restrict __buf,
       int32_t *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ int srandom_r (unsigned int __seed, struct random_data *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

/*extern*/ int initstate_r (unsigned int __seed, char *__restrict __statebuf,
   size_t __statelen,
   struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)));

/*extern*/ int setstate_r (char *__restrict __statebuf,
         struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));






/*extern*/ int rand (void) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ void srand (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));




/*extern*/ int rand_r (unsigned int *__seed) __attribute__ ((__nothrow__ , __leaf__));







/*extern*/ double drand48 (void) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ double erand48 (unsigned short int __xsubi[3]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


/*extern*/ long int lrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ long int nrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


/*extern*/ long int mrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ long int jrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


/*extern*/ void srand48 (long int __seedval) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ unsigned short int *seed48 (unsigned short int __seed16v[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
/*extern*/ void lcong48 (unsigned short int __param[7]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





struct drand48_data
  {
    unsigned short int __x[3];
    unsigned short int __old_x[3];
    unsigned short int __c;
    unsigned short int __init;
    __extension__ unsigned long long int __a;

  };


/*extern*/ int drand48_r (struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
/*extern*/ int erand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


/*extern*/ int lrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
/*extern*/ int nrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


/*extern*/ int mrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
/*extern*/ int jrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


/*extern*/ int srand48_r (long int __seedval, struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

/*extern*/ int seed48_r (unsigned short int __seed16v[3],
       struct drand48_data *__buffer) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ int lcong48_r (unsigned short int __param[7],
        struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));







/*extern*/ void *realloc (void *__ptr, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));

/*extern*/ void free (void *__ptr) __attribute__ ((__nothrow__ , __leaf__));




/*extern*/ void cfree (void *__ptr) __attribute__ ((__nothrow__ , __leaf__));














/*extern*/ void *alloca (size_t __size) __attribute__ ((__nothrow__ , __leaf__));












/*extern*/ void *valloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) ;




/*extern*/ int posix_memalign (void **__memptr, size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;



/*extern*/ void abort (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));



/*extern*/ int atexit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






/*extern*/ int on_exit (void (*__func) (int __status, void *__arg), void *__arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






/*extern*/ void exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));













/*extern*/ void _Exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));






/*extern*/ char *getenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;


/*extern*/ int putenv (char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





/*extern*/ int setenv (const char *__name, const char *__value, int __replace)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));


/*extern*/ int unsetenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






/*extern*/ int clearenv (void) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ char *mktemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

/*extern*/ int mkstemp (char *__template) __attribute__ ((__nonnull__ (1))) ;

/*extern*/ int mkstemps (char *__template, int __suffixlen) __attribute__ ((__nonnull__ (1))) ;

/*extern*/ char *mkdtemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;






/*extern*/ int system (const char *__command) ;


/*extern*/ char *realpath (const char *__restrict __name,
         char *__restrict __resolved) __attribute__ ((__nothrow__ , __leaf__)) ;






typedef int (*__compar_fn_t) (const void *, const void *);




/*extern*/ void *bsearch (const void *__key, const void *__base,
        size_t __nmemb, size_t __size, __compar_fn_t __compar)
     __attribute__ ((__nonnull__ (1, 2, 5))) ;




/*extern*/ __inline __attribute__ ((__gnu_inline__)) void *
bsearch (const void *__key, const void *__base, size_t __nmemb, size_t __size,
  __compar_fn_t __compar)
{
  size_t __l, __u, __idx;
  const void *__p;
  int __comparison;

  __l = 0;
  __u = __nmemb;
  while (__l < __u)
    {
      __idx = (__l + __u) / 2;
      __p = (void *) (((const char *) __base) + (__idx * __size));
      __comparison = (*__compar) (__key, __p);
      if (__comparison < 0)
 __u = __idx;
      else if (__comparison > 0)
 __l = __idx + 1;
      else
 return (void *) __p;
    }

  return ((void *)0);
}





/*extern*/ void qsort (void *__base, size_t __nmemb, size_t __size,
     __compar_fn_t __compar) __attribute__ ((__nonnull__ (1, 4)));

/*extern*/ int abs (int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
/*extern*/ long int labs (long int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;



__extension__ /*extern*/ long long int llabs (long long int __x)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;







/*extern*/ div_t div (int __numer, int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
/*extern*/ ldiv_t ldiv (long int __numer, long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;




__extension__ /*extern*/ lldiv_t lldiv (long long int __numer,
        long long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;


/*extern*/ char *ecvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;




/*extern*/ char *fcvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;




/*extern*/ char *gcvt (double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3))) ;




/*extern*/ char *qecvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;
/*extern*/ char *qfcvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;
/*extern*/ char *qgcvt (long double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3))) ;




/*extern*/ int ecvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
/*extern*/ int fcvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));

/*extern*/ int qecvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
/*extern*/ int qfcvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));






/*extern*/ int mblen (const char *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ int mbtowc (wchar_t *__restrict __pwc,
     const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ int wctomb (char *__s, wchar_t __wchar) __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ size_t mbstowcs (wchar_t *__restrict __pwcs,
   const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ size_t wcstombs (char *__restrict __s,
   const wchar_t *__restrict __pwcs, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__));








/*extern*/ int rpmatch (const char *__response) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;

/*extern*/ int getsubopt (char **__restrict __optionp,
        char *const *__restrict __tokens,
        char **__restrict __valuep)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2, 3))) ;

/*extern*/ int getloadavg (double __loadavg[], int __nelem)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





static double __sym_strtod(const char * param0, char ** param1, ...);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) double
__attribute__ ((__nothrow__ , __leaf__)) atof (const char *__nptr)
{
  return __sym_strtod (__nptr, (char **) ((void *)0));
}





























typedef long int __jmp_buf[8];






struct __jmp_buf_tag
  {




    __jmp_buf __jmpbuf;
    int __mask_was_saved;
    __sigset_t __saved_mask;
  };




typedef struct __jmp_buf_tag jmp_buf[1];



/*extern*/ int setjmp (jmp_buf __env) __attribute__ ((__nothrow__));






/*extern*/ int __sigsetjmp (struct __jmp_buf_tag __env[1], int __savemask) __attribute__ ((__nothrow__));



/*extern*/ int _setjmp (struct __jmp_buf_tag __env[1]) __attribute__ ((__nothrow__));










/*extern*/ void longjmp (struct __jmp_buf_tag __env[1], int __val)
     __attribute__ ((__nothrow__)) __attribute__ ((__noreturn__));







/*extern*/ void _longjmp (struct __jmp_buf_tag __env[1], int __val)
     __attribute__ ((__nothrow__)) __attribute__ ((__noreturn__));







typedef struct __jmp_buf_tag sigjmp_buf[1];

/*extern*/ void siglongjmp (sigjmp_buf __env, int __val)
     __attribute__ ((__nothrow__)) __attribute__ ((__noreturn__));




/*extern*/ sigjmp_buf top_level;
/*extern*/ sigjmp_buf subshell_top_level;
/*extern*/ sigjmp_buf return_catch;








enum r_instruction {
  r_output_direction, r_input_direction, r_inputa_direction,
  r_appending_to, r_reading_until, r_duplicating_input,
  r_duplicating_output, r_deblank_reading_until, r_close_this,
  r_err_and_out, r_input_output, r_output_force,
  r_duplicating_input_word, r_duplicating_output_word
};

enum command_type { cm_for, cm_case, cm_while, cm_if, cm_simple, cm_select,
      cm_connection, cm_function_def, cm_until, cm_group };

typedef struct word_desc {
  char *word;
  int flags;
} WORD_DESC;


typedef struct word_list {
  struct word_list *next;
  WORD_DESC *word;
} WORD_LIST;

typedef union {
  long dest;
  WORD_DESC *filename;
} REDIRECTEE;

typedef struct redirect {
  struct redirect *next;
  int redirector;
  int flags;
  enum r_instruction instruction;
  REDIRECTEE redirectee;
  char *here_doc_eof;
} REDIRECT;



typedef struct element {
  WORD_DESC *word;
  REDIRECT *redirect;
} ELEMENT;

typedef struct command {
  enum command_type type;
  int flags;
  int line;
  REDIRECT *redirects;
  union {
    struct for_com *For;
    struct case_com *Case;
    struct while_com *While;
    struct if_com *If;
    struct connection *Connection;
    struct simple_com *Simple;
    struct function_def *Function_def;
    struct group_com *Group;

    struct select_com *Select;

  } value;
} COMMAND;


typedef struct connection {
  int ignore;
  COMMAND *first;
  COMMAND *second;
  int connector;
} CONNECTION;




typedef struct pattern_list {
  struct pattern_list *next;
  WORD_LIST *patterns;
  COMMAND *action;
} PATTERN_LIST;


typedef struct case_com {
  int flags;
  WORD_DESC *word;
  PATTERN_LIST *clauses;
} CASE_COM;


typedef struct for_com {
  int flags;
  WORD_DESC *name;
  WORD_LIST *map_list;
  COMMAND *action;


} FOR_COM;



typedef struct select_com {
  int flags;
  WORD_DESC *name;
  WORD_LIST *map_list;
  COMMAND *action;


} SELECT_COM;



typedef struct if_com {
  int flags;
  COMMAND *test;
  COMMAND *true_case;
  COMMAND *false_case;
} IF_COM;


typedef struct while_com {
  int flags;
  COMMAND *test;
  COMMAND *action;
} WHILE_COM;


typedef struct simple_com {
  int flags;
  WORD_LIST *words;

  REDIRECT *redirects;
  int line;
} SIMPLE_COM;


typedef struct function_def {
  int ignore;
  WORD_DESC *name;
  COMMAND *command;
  int line;
} FUNCTION_DEF;



typedef struct group_com {
  int ignore;
  COMMAND *command;
} GROUP_COM;

/*extern*/ COMMAND *global_command;



/*extern*/ WORD_DESC *copy_word (WORD_DESC *);
/*extern*/ WORD_LIST *copy_word_list (WORD_LIST *);
/*extern*/ REDIRECT *copy_redirect (REDIRECT *);
/*extern*/ REDIRECT *copy_redirects (REDIRECT *);
/*extern*/ COMMAND *copy_command (COMMAND *);



/*extern*/ char *xmalloc (), *xrealloc ();






/*extern*/ char *strcpy ();

typedef struct g_list {
  struct g_list *next;
} GENERIC_LIST;



typedef struct {
  char *word;
  int token;
} STRING_INT_ALIST;

typedef int Function ();
typedef void VFunction ();
typedef char *CPFunction ();
typedef char **CPPFunction ();

/*extern*/ char *xmalloc (size_t);
/*extern*/ char *xrealloc (void *, size_t);
/*extern*/ void xfree (char *);


/*extern*/ void posix_initialize (int);

/*extern*/ char *itos (int);
/*extern*/ long string_to_long (char *);


/*extern*/ quad_t string_to_rlimtype (char *);
/*extern*/ void print_rlimtype (quad_t, int);


/*extern*/ void timeval_to_secs ();
/*extern*/ void print_timeval ();
/*extern*/ void clock_t_to_secs ();
/*extern*/ void print_time_in_hz ();

/*extern*/ int all_digits (char *);
/*extern*/ int legal_number (char *, long *);
/*extern*/ int legal_identifier (char *);
/*extern*/ int check_identifier (WORD_DESC *, int);

/*extern*/ void unset_nodelay_mode (int);
/*extern*/ void check_dev_tty ();
/*extern*/ int same_file ();
/*extern*/ int move_to_high_fd (int, int);
/*extern*/ int check_binary_file (unsigned char *, int);

/*extern*/ char *canonicalize_pathname (char *);
/*extern*/ char *make_absolute (char *, char *);
/*extern*/ int absolute_pathname (char *);
/*extern*/ int absolute_program (char *);
/*extern*/ char *base_pathname (char *);
/*extern*/ char *full_pathname (char *);
/*extern*/ char *polite_directory_format (char *);

/*extern*/ char *extract_colon_unit (char *, int *);

/*extern*/ void tilde_initialize ();
/*extern*/ char *bash_tilde_expand (char *);



/*extern*/ char *get_name_for_error ();


/*extern*/ void file_error (char *);


/*extern*/ void programming_error (const char *, ...);


/*extern*/ void report_error (const char *, ...);


/*extern*/ void parser_error (int, const char *, ...);


/*extern*/ void fatal_error (const char *, ...);


/*extern*/ void sys_error (const char *, ...);


/*extern*/ void internal_error (const char *, ...);
















typedef int arrayind_t;

enum atype {array_indexed, array_assoc};

typedef struct array {
 enum atype type;
 arrayind_t max_index, num_elements, max_size;
 struct array_element *head;
} ARRAY;

typedef struct array_element {
 arrayind_t ind;
 char *value;
 struct array_element *next, *prev;
} ARRAY_ELEMENT;

char *array_reference (ARRAY *, arrayind_t);

/*extern*/ int array_add_element (ARRAY *, arrayind_t, char *);
/*extern*/ ARRAY_ELEMENT *array_delete_element (ARRAY *, arrayind_t);

/*extern*/ ARRAY_ELEMENT *new_array_element (arrayind_t, char *);
/*extern*/ void destroy_array_element (ARRAY_ELEMENT *);

/*extern*/ ARRAY *new_array ();
/*extern*/ void empty_array (ARRAY *);
/*extern*/ void dispose_array (ARRAY *);
/*extern*/ ARRAY *dup_array (ARRAY *);
/*extern*/ ARRAY *dup_array_subrange (ARRAY *, ARRAY_ELEMENT *, ARRAY_ELEMENT *);
/*extern*/ ARRAY_ELEMENT *new_array_element (arrayind_t, char *);
/*extern*/ ARRAY_ELEMENT *copy_array_element (ARRAY_ELEMENT *);

/*extern*/ WORD_LIST *array_to_word_list (ARRAY *);
/*extern*/ ARRAY *word_list_to_array (WORD_LIST *);
/*extern*/ ARRAY *assign_word_list (ARRAY *, WORD_LIST *);

/*extern*/ char *array_to_assignment_string (ARRAY *);
/*extern*/ char *quoted_array_assignment_string (ARRAY *);
/*extern*/ char *array_to_string (ARRAY *, char *, int);
/*extern*/ ARRAY *string_to_array (char *, char *);

/*extern*/ char *array_subrange (ARRAY *, int, int, int);
/*extern*/ char *array_pat_subst (ARRAY *, char *, char *, int);

/*extern*/ ARRAY *array_quote (ARRAY *);





typedef struct bucket_contents {
  struct bucket_contents *next;
  char *key;
  char *data;
  int times_found;
} BUCKET_CONTENTS;

typedef struct hash_table {
  BUCKET_CONTENTS **bucket_array;
  int nbuckets;
  int nentries;
} HASH_TABLE;

/*extern*/ int hash_string ();
/*extern*/ HASH_TABLE *make_hash_table ();
/*extern*/ BUCKET_CONTENTS *find_hash_item ();
/*extern*/ BUCKET_CONTENTS *remove_hash_item ();
/*extern*/ BUCKET_CONTENTS *add_hash_item ();
/*extern*/ BUCKET_CONTENTS *get_hash_bucket ();
/*extern*/ void flush_hash_table ();




typedef struct variable *DYNAMIC_FUNC ();

typedef struct variable {
  char *name;
  char *value;
  DYNAMIC_FUNC *dynamic_value;


  DYNAMIC_FUNC *assign_func;


  int attributes;
  int context;
  struct variable *prev_context;
} SHELL_VAR;

/*extern*/ int variable_context;
/*extern*/ HASH_TABLE *shell_variables, *shell_functions;
/*extern*/ char *dollar_vars[];
/*extern*/ char **export_env;
/*extern*/ char **non_unsettable_vars;

/*extern*/ void initialize_shell_variables (char **, int);
/*extern*/ SHELL_VAR *set_if_not (char *, char *);
/*extern*/ void set_lines_and_columns (int, int);

/*extern*/ SHELL_VAR *find_function (char *);
/*extern*/ SHELL_VAR *find_variable (char *);
/*extern*/ SHELL_VAR *find_variable_internal (char *, int);
/*extern*/ SHELL_VAR *find_tempenv_variable (char *);
/*extern*/ SHELL_VAR *copy_variable (SHELL_VAR *);
/*extern*/ SHELL_VAR *make_local_variable (char *);
/*extern*/ SHELL_VAR *bind_variable (char *, char *);
/*extern*/ SHELL_VAR *bind_function (char *, COMMAND *);
/*extern*/ SHELL_VAR **map_over (Function *, HASH_TABLE *);
/*extern*/ SHELL_VAR **all_shell_variables ();
/*extern*/ SHELL_VAR **all_shell_functions ();
/*extern*/ SHELL_VAR **all_visible_variables ();
/*extern*/ SHELL_VAR **all_visible_functions ();

/*extern*/ char **make_var_array (HASH_TABLE *);
/*extern*/ char **add_or_supercede (char *, char **);

/*extern*/ char *get_string_value (char *);
/*extern*/ char *make_variable_value (SHELL_VAR *, char *);

/*extern*/ int assignment (char *);
/*extern*/ int variable_in_context (SHELL_VAR *);
/*extern*/ int assign_in_env (char *);
/*extern*/ int unbind_variable (char *);
/*extern*/ int makunbound (char *, HASH_TABLE *);
/*extern*/ int kill_local_variable (char *);
/*extern*/ void delete_all_variables (HASH_TABLE *);

/*extern*/ void adjust_shell_level (int);
/*extern*/ void non_unsettable (char *);
/*extern*/ void dispose_variable (SHELL_VAR *);
/*extern*/ void dispose_used_env_vars ();
/*extern*/ void dispose_function_env ();
/*extern*/ void dispose_builtin_env ();
/*extern*/ void merge_temporary_env ();
/*extern*/ void merge_builtin_env ();
/*extern*/ void kill_all_local_variables ();
/*extern*/ void set_var_read_only (char *);
/*extern*/ void set_func_read_only (char *);
/*extern*/ void set_var_auto_export (char *);
/*extern*/ void set_func_auto_export (char *);
/*extern*/ void sort_variables (SHELL_VAR **);
/*extern*/ void maybe_make_export_env ();
/*extern*/ void put_command_name_into_env (char *);
/*extern*/ void put_gnu_argv_flags_into_env (int, char *);
/*extern*/ void print_var_list (SHELL_VAR **);
/*extern*/ void print_assignment (SHELL_VAR *);
/*extern*/ void print_var_value (SHELL_VAR *, int);
/*extern*/ void print_var_function (SHELL_VAR *);

/*extern*/ char *indirection_level_string ();


/*extern*/ SHELL_VAR *make_new_array_variable (char *);
/*extern*/ SHELL_VAR *make_local_array_variable (char *);
/*extern*/ SHELL_VAR *convert_var_to_array (SHELL_VAR *);
/*extern*/ SHELL_VAR *bind_array_variable (char *, int, char *);
/*extern*/ SHELL_VAR *assign_array_from_string (char *, char *);
/*extern*/ SHELL_VAR *assign_array_var_from_word_list (SHELL_VAR *, WORD_LIST *);
/*extern*/ SHELL_VAR *assign_array_var_from_string (SHELL_VAR *, char *);
/*extern*/ int unbind_array_element (SHELL_VAR *, char *);
/*extern*/ int skipsubscript (char *, int);
/*extern*/ void print_array_assignment (SHELL_VAR *, int);



/*extern*/ int interrupt_state;

/*extern*/ void throw_to_top_level ();








/*extern*/ void begin_unwind_frame ();
/*extern*/ void discard_unwind_frame ();
/*extern*/ void run_unwind_frame ();
/*extern*/ void add_unwind_protect ();
/*extern*/ void remove_unwind_protect ();
/*extern*/ void run_unwind_protects ();
/*extern*/ void unwind_protect_var ();



typedef union {
  char *s;
  int i;
} UWP;



/*extern*/ void dispose_command (COMMAND *);
/*extern*/ void dispose_word (WORD_DESC *);
/*extern*/ void dispose_words (WORD_LIST *);
/*extern*/ void dispose_word_array (char **);
/*extern*/ void dispose_redirects (REDIRECT *);



/*extern*/ WORD_LIST *make_word_list (WORD_DESC *, WORD_LIST *);
/*extern*/ WORD_LIST *add_string_to_list (char *, WORD_LIST *);

/*extern*/ WORD_DESC *make_bare_word (char *);
/*extern*/ WORD_DESC *make_word (char *);
/*extern*/ WORD_DESC *make_word_from_token (int);

/*extern*/ COMMAND *make_command (enum command_type, SIMPLE_COM *);
/*extern*/ COMMAND *command_connect (COMMAND *, COMMAND *, int);
/*extern*/ COMMAND *make_for_command (WORD_DESC *, WORD_LIST *, COMMAND *);
/*extern*/ COMMAND *make_group_command (COMMAND *);
/*extern*/ COMMAND *make_case_command (WORD_DESC *, PATTERN_LIST *);
/*extern*/ PATTERN_LIST *make_pattern_list (WORD_LIST *, COMMAND *);
/*extern*/ COMMAND *make_if_command (COMMAND *, COMMAND *, COMMAND *);
/*extern*/ COMMAND *make_while_command (COMMAND *, COMMAND *);
/*extern*/ COMMAND *make_until_command (COMMAND *, COMMAND *);
/*extern*/ COMMAND *make_bare_simple_command ();
/*extern*/ COMMAND *make_simple_command (ELEMENT, COMMAND *);
/*extern*/ void make_here_document (REDIRECT *);
/*extern*/ REDIRECT *make_redirection (int, enum r_instruction, REDIRECTEE);
/*extern*/ COMMAND *make_function_def (WORD_DESC *, COMMAND *, int, int);
/*extern*/ COMMAND *clean_simple_command (COMMAND *);

/*extern*/ COMMAND *make_select_command (WORD_DESC *, WORD_LIST *, COMMAND *);

/*extern*/ COMMAND *connect_async_list (COMMAND *, COMMAND *, int);



/*extern*/ char *substring (char *, int, int);



/*extern*/ char * de_backslash (char *);


/*extern*/ void unquote_bang (char *);




/*extern*/ char *extract_command_subst (char *, int *);




/*extern*/ char *extract_arithmetic_subst (char *, int *);





/*extern*/ char *extract_process_subst (char *, char *, int *);



/*extern*/ char *assignment_name (char *);



/*extern*/ char *string_list (WORD_LIST *);






/*extern*/ char *string_list_dollar_star (WORD_LIST *);



/*extern*/ void word_list_remove_quoted_nulls (WORD_LIST *);



/*extern*/ WORD_LIST *list_string (char *, char *, int);

/*extern*/ char *get_word_from_string (char **, char *, char **);
/*extern*/ char *strip_trailing_ifs_whitespace (char *, char *, int);






/*extern*/ int do_assignment (char *);
/*extern*/ int do_assignment_no_expand (char *);


/*extern*/ SHELL_VAR *do_array_element_assignment (char *, char *);






/*extern*/ char *sub_append_string (char *, char *, int *, int *);



/*extern*/ char *sub_append_number (int, char *, int *, int *);


/*extern*/ WORD_LIST *list_rest_of_args ();




/*extern*/ char *string_rest_of_args (int);

/*extern*/ int number_of_args ();






/*extern*/ WORD_LIST *expand_string_unsplit (char *, int);






/*extern*/ WORD_LIST *expand_string (char *, int);


/*extern*/ char *dequote_string (char *);




/*extern*/ WORD_LIST *expand_word (WORD_DESC *, int);




/*extern*/ WORD_LIST *expand_word_no_split (WORD_DESC *, int);
/*extern*/ WORD_LIST *expand_word_leave_quoted (WORD_DESC *, int);


/*extern*/ char *get_dollar_var_value (int);


/*extern*/ char *quote_string (char *);



/*extern*/ char *string_quote_removal (char *, int);



/*extern*/ WORD_DESC *word_quote_removal (WORD_DESC *, int);




/*extern*/ WORD_LIST *word_list_quote_removal (WORD_LIST *, int);




/*extern*/ WORD_LIST *word_split (WORD_DESC *);




/*extern*/ WORD_LIST *expand_words (WORD_LIST *);



/*extern*/ WORD_LIST *expand_words_no_vars (WORD_LIST *);



/*extern*/ void stupidly_hack_special_variables (char *);

/*extern*/ char *pat_subst (char *, char *, char *, int);

/*extern*/ void unlink_fifo_list ();


/*extern*/ int array_expand_index (char *, int);
/*extern*/ int valid_array_reference (char *);
/*extern*/ char *get_array_value (char *, int);
/*extern*/ SHELL_VAR *array_variable_part (char *, char **, int *);
/*extern*/ WORD_LIST *list_string_with_quotes (char *);
/*extern*/ char *extract_array_assignment_list (char *, int *);




void sv_path (), sv_mail (), sv_ignoreeof (), sv_strict_posix ();
void sv_optind (), sv_opterr (), sv_globignore (), sv_locale ();


void sv_terminal (), sv_hostfile ();



void sv_tz ();



void sv_histsize (), sv_histignore (), sv_history_control ();

void sv_histchars ();



typedef void SigHandler ();

/*extern*/ SigHandler *set_signal_handler ();

/*extern*/ void termination_unwind_protect (int);
/*extern*/ void sigint_sighandler (int);
/*extern*/ void initialize_signals ();
/*extern*/ void reinitialize_signals ();
/*extern*/ void reset_terminating_signals ();
/*extern*/ void throw_to_top_level ();
/*extern*/ void jump_to_top_level (int);


/*extern*/ SigHandler *set_sigint_handler ();





/*extern*/ long evalexp (char *);







/*extern*/ char *make_command_string (COMMAND *);
/*extern*/ void print_command (COMMAND *);
/*extern*/ void print_simple_command (SIMPLE_COM *);
/*extern*/ char *named_function_string (char *, COMMAND *, int);
/*extern*/ void print_word_list (WORD_LIST *, char *);
/*extern*/ void xtrace_print_word_list (WORD_LIST *);


/*extern*/ int exit_shell (int);
/*extern*/ void disable_priv_mode ();


/*extern*/ int maybe_make_restricted (char *);



/*extern*/ int reader_loop ();
/*extern*/ int parse_command ();
/*extern*/ int read_command ();


/*extern*/ int group_member ();
/*extern*/ int test_command ();



/*extern*/ char **brace_expand (char *);



/*extern*/ int yyparse ();
/*extern*/ void reset_parser ();


/*extern*/ char *shell_version_string ();
/*extern*/ void show_shell_version (int);


/*extern*/ void set_default_locale ();
/*extern*/ void set_default_locale_vars ();
/*extern*/ int set_locale_var (char *, char *);
/*extern*/ int set_lang (char *, char *);
/*extern*/ char *get_locale_var (char *);
/*extern*/ char *localetrans (char *, int, int *);


/*extern*/ void map_over_list (GENERIC_LIST *, Function *);
/*extern*/ void map_over_words (WORD_LIST *, Function *);
/*extern*/ GENERIC_LIST *reverse_list ();
/*extern*/ int list_length ();
/*extern*/ GENERIC_LIST *list_append ();
/*extern*/ GENERIC_LIST *delete_element ();


/*extern*/ long get_clk_tck ();


/*extern*/ char *strerror (int);







/*extern*/ int dup2 (int, int);

/*extern*/ char *ansicstr (char *, int, int *);
/*extern*/ int find_name_in_array (char *, char **);
/*extern*/ int array_len (char **);
/*extern*/ void free_array_members (char **);
/*extern*/ void free_array (char **);
/*extern*/ char **copy_array (char **);
/*extern*/ int qsort_string_compare ();
/*extern*/ void sort_char_array (char **);
/*extern*/ char **word_list_to_argv (WORD_LIST *, int, int, int *);
/*extern*/ WORD_LIST *argv_to_word_list (char **, int, int);

/*extern*/ char *strsub (char *, char *, char *, int);
/*extern*/ void strip_leading (char *);
/*extern*/ void strip_trailing (char *, int);
/*extern*/ char *strindex (char *, char *);
/*extern*/ void xbcopy (char *, char *, int);


/*extern*/ int EOF_Reached;

/*extern*/ char **shell_environment;
/*extern*/ WORD_LIST *rest_of_args;


/*extern*/ int executing, login_shell;



struct fd_bitmap {
  long size;
  char *bitmap;
};







struct user_info {
  int uid, euid;
  int gid, egid;
  char *user_name;
  char *shell;
  char *home_dir;
};

/*extern*/ struct user_info current_user;


typedef union {
  WORD_DESC *word;
  int number;
  WORD_LIST *word_list;
  COMMAND *command;
  REDIRECT *redirect;
  ELEMENT element;
  PATTERN_LIST *pattern;
} YYSTYPE;

/*extern*/ YYSTYPE yylval;



struct flags_alist {
  char name;
  int *value;
};

/*extern*/ struct flags_alist shell_flags[];

/*extern*/ int
  mark_modified_vars, exit_immediately_on_error, disallow_filename_globbing,
  place_keywords_in_env, read_but_dont_execute,
  just_one_command, unbound_vars_is_error, echo_input_at_read,
  echo_command_at_execute, no_invisible_vars, noclobber,
  hashing_enabled, forced_interactive, privileged_mode,
  asynchronous_notification, interactive_comments, no_symbolic_links;






/*extern*/ int brace_expansion;



/*extern*/ int history_expansion;



/*extern*/ int restricted;


/*extern*/ int *find_flag (int);
/*extern*/ int change_flag (int, int);
/*extern*/ char *which_set_flags ();









/*extern*/ char *xmalloc ();

typedef struct alias {
  char *name;
  char *value;
  char flags;
} alias_t;






/*extern*/ HASH_TABLE *aliases;

/*extern*/ void initialize_aliases ();



/*extern*/ alias_t *find_alias ();


/*extern*/ char *get_alias_value ();



/*extern*/ void add_alias ();



/*extern*/ int remove_alias ();


/*extern*/ void delete_all_aliases ();


/*extern*/ char *alias_expand ();


/*extern*/ alias_t **all_aliases ();


/*extern*/ char *alias_expand_word ();


struct builtin {
  char *name;
  Function *function;
  int flags;
  char **long_doc;
  char *short_doc;
  char *handle;
};


/*extern*/ int num_shell_builtins;
/*extern*/ struct builtin static_shell_builtins[];
/*extern*/ struct builtin *shell_builtins;
/*extern*/ struct builtin *current_builtin;











/*extern*/ __pid_t wait (__WAIT_STATUS __stat_loc);

/*extern*/ __pid_t waitpid (__pid_t __pid, int *__stat_loc, int __options);







/*extern*/ int waitid (idtype_t __idtype, __id_t __id, siginfo_t *__infop,
     int __options);





struct rusage;






/*extern*/ __pid_t wait3 (__WAIT_STATUS __stat_loc, int __options,
        struct rusage * __usage) __attribute__ ((__nothrow__));




/*extern*/ __pid_t wait4 (__pid_t __pid, __WAIT_STATUS __stat_loc, int __options,
        struct rusage *__usage) __attribute__ ((__nothrow__));






typedef int WAIT;

typedef struct process {
  struct process *next;
  pid_t pid;
  WAIT status;
  int running;
  char *command;
} PROCESS;


typedef enum { JRUNNING, JSTOPPED, JDEAD, JMIXED } JOB_STATE;

typedef struct job {
  char *wd;
  PROCESS *pipe;
  pid_t pgrp;
  JOB_STATE state;
  int flags;

  COMMAND *deferred;
  VFunction *j_cleanup;
  void * cleanarg;

} JOB;

/*extern*/ pid_t original_pgrp, shell_pgrp, pipeline_pgrp;
/*extern*/ pid_t last_made_pid, last_asynchronous_pid;
/*extern*/ int current_job, previous_job;
/*extern*/ int asynchronous_notification;
/*extern*/ JOB **jobs;
/*extern*/ int job_slots;

/*extern*/ void making_children ();
/*extern*/ void stop_making_children ();
/*extern*/ void cleanup_the_pipeline ();
/*extern*/ void save_pipeline (int);
/*extern*/ void restore_pipeline (int);
/*extern*/ void start_pipeline ();
/*extern*/ int stop_pipeline (int, COMMAND *);
/*extern*/ void delete_job (int);
/*extern*/ void nohup_job (int);

/*extern*/ void terminate_current_pipeline ();
/*extern*/ void terminate_stopped_jobs ();
/*extern*/ void hangup_all_jobs ();
/*extern*/ void kill_current_pipeline ();




/*extern*/ void describe_pid (pid_t);


/*extern*/ void list_one_job (JOB *, int, int, int);
/*extern*/ void list_all_jobs (int);
/*extern*/ void list_stopped_jobs (int);
/*extern*/ void list_running_jobs (int);

/*extern*/ pid_t make_child (char *, int);
/*extern*/ int get_tty_state ();
/*extern*/ int set_tty_state ();

/*extern*/ int wait_for_single_pid (pid_t);
/*extern*/ void wait_for_background_pids ();
/*extern*/ int wait_for (pid_t);
/*extern*/ int wait_for_job (int);

/*extern*/ void notify_and_cleanup ();
/*extern*/ void reap_dead_jobs ();
/*extern*/ int start_job (int, int);
/*extern*/ int kill_pid (pid_t, int, int);
/*extern*/ int initialize_jobs ();
/*extern*/ void initialize_job_signals ();
/*extern*/ int give_terminal_to (pid_t);

/*extern*/ void set_sigwinch_handler ();
/*extern*/ void unset_sigwinch_handler ();

/*extern*/ void unfreeze_jobs_list ();
/*extern*/ int set_job_control (int);
/*extern*/ void without_job_control ();
/*extern*/ void end_job_control ();
/*extern*/ void restart_job_control ();
/*extern*/ void set_sigchld_handler ();
/*extern*/ void ignore_tty_job_signals ();
/*extern*/ void default_tty_job_signals ();


/*extern*/ int job_control;



/*extern*/ struct fd_bitmap *new_fd_bitmap (long);
/*extern*/ void dispose_fd_bitmap (struct fd_bitmap *);
/*extern*/ void close_fd_bitmap (struct fd_bitmap *);
/*extern*/ int executing_line_number ();
/*extern*/ int execute_command (COMMAND *);
/*extern*/ int execute_command_internal (COMMAND *, int, int, int, struct fd_bitmap *);
/*extern*/ int shell_execve (char *, char **, char **);
/*extern*/ char *redirection_expand (WORD_DESC *);
/*extern*/ int file_status (char *);
/*extern*/ int executable_file (char *);
/*extern*/ int is_directory (char *);
/*extern*/ char *search_for_command (char *);
/*extern*/ char *find_user_command (char *);
/*extern*/ char *find_path_file (char *);
/*extern*/ char *user_command_matches (char *, int, int);
/*extern*/ void setup_async_signals ();


/*extern*/ void close_all_files ();



/*extern*/ char *trap_list[];


/*extern*/ void initialize_traps ();
/*extern*/ void run_pending_traps ();
/*extern*/ void maybe_set_sigchld_trap (char *);
/*extern*/ void set_sigchld_trap (char *);
/*extern*/ void set_debug_trap (char *);
/*extern*/ void set_sigint_trap (char *);
/*extern*/ void set_signal (int, char *);
/*extern*/ void restore_default_signal (int);
/*extern*/ void ignore_signal (int);
/*extern*/ int run_exit_trap ();
/*extern*/ void run_trap_cleanup (int);
/*extern*/ void run_debug_trap ();
/*extern*/ void free_trap_strings ();
/*extern*/ void reset_signal_handlers ();
/*extern*/ void restore_original_signals ();

/*extern*/ char *signal_name (int);

/*extern*/ int decode_signal (char *);
/*extern*/ void run_interrupt_trap ();
/*extern*/ int maybe_call_trap_handler (int);
/*extern*/ int signal_is_trapped (int);
/*extern*/ int signal_is_ignored (int);
/*extern*/ int signal_is_special (int);
/*extern*/ void set_signal_ignored (int);



/*extern*/ int noglob_dot_filenames;
/*extern*/ char *glob_error_return;


/*extern*/ int glob_dot_filenames;

/*extern*/ int unquoted_glob_pattern_p (char *);

/*extern*/ char *quote_string_for_globbing (char *, int);

/*extern*/ char *quote_globbing_chars (char *);


/*extern*/ char **shell_glob_filename (char *);

struct ign {
  char *val;
  int len, flags;
};

struct ignorevar {
  char *varname;
  struct ign *ignores;
  int num_ignores;
  char *last_ignoreval;
  Function *item_func;
};

/*extern*/ void setup_ignore_patterns (struct ignorevar *);

/*extern*/ void setup_glob_ignore (char *);
/*extern*/ int should_ignore_glob_matches ();
/*extern*/ void ignore_glob_matches (char **);









/*extern*/ void builtin_error (const char *, ...);
/*extern*/ void builtin_usage ();
/*extern*/ void bad_option ();

/*extern*/ char **make_builtin_argv ();

/*extern*/ int get_numeric_arg ();
/*extern*/ void remember_args ();
/*extern*/ void no_args ();
/*extern*/ int no_options ();

/*extern*/ int read_octal ();

/*extern*/ void push_context (), pop_context ();
/*extern*/ void push_dollar_vars (), pop_dollar_vars ();
/*extern*/ void dispose_saved_dollar_vars ();
/*extern*/ int dollar_vars_changed ();
/*extern*/ void set_dollar_vars_unchanged (), set_dollar_vars_changed ();


/*extern*/ char *the_current_working_directory;
/*extern*/ char *get_working_directory ();
/*extern*/ void set_working_directory ();


/*extern*/ int get_job_spec ();


/*extern*/ int display_signal_list ();



/*extern*/ struct builtin *builtin_address_internal ();
/*extern*/ Function *find_shell_builtin ();
/*extern*/ Function *builtin_address ();
/*extern*/ Function *find_special_builtin ();

/*extern*/ void initialize_shell_builtins ();

/*extern*/ char *single_quote ();
/*extern*/ char *double_quote ();
/*extern*/ char *backslash_quote ();
/*extern*/ int contains_shell_metas ();


/*extern*/ void initialize_filename_hashing ();
/*extern*/ void flush_hashed_filenames ();
/*extern*/ char *find_hashed_filename ();
/*extern*/ void remove_hashed_filename ();
/*extern*/ void remember_filename ();


/*extern*/ void initialize_shell_options ();
/*extern*/ void list_minus_o_opts ();
/*extern*/ int set_minus_o_option ();
/*extern*/ int minus_o_option_value ();


/*extern*/ int describe_command ();


/*extern*/ int set_or_show_attributes ();
/*extern*/ int show_var_attributes ();
/*extern*/ int show_name_attributes ();
/*extern*/ void set_var_attribute ();


/*extern*/ char *get_dirstack_element ();
/*extern*/ void set_dirstack_element ();
/*extern*/ WORD_LIST *get_directory_stack ();


/*extern*/ int parse_and_execute ();
/*extern*/ void parse_and_execute_cleanup ();


/*extern*/ int maybe_execute_file (char *, int);
/*extern*/ int source_file (char *);




/*extern*/ int alias_builtin ();
/*extern*/ char *alias_doc[];


/*extern*/ int unalias_builtin ();
/*extern*/ char *unalias_doc[];


/*extern*/ int bind_builtin ();
/*extern*/ char *bind_doc[];

/*extern*/ int break_builtin ();
/*extern*/ char *break_doc[];
/*extern*/ int continue_builtin ();
/*extern*/ char *continue_doc[];
/*extern*/ int builtin_builtin ();
/*extern*/ char *builtin_doc[];
/*extern*/ int cd_builtin ();
/*extern*/ char *cd_doc[];
/*extern*/ int pwd_builtin ();
/*extern*/ char *pwd_doc[];
/*extern*/ int colon_builtin ();
/*extern*/ char *colon_builtin_doc[];
/*extern*/ int colon_builtin ();
/*extern*/ char *true_builtin_doc[];
/*extern*/ int false_builtin ();
/*extern*/ char *false_builtin_doc[];
/*extern*/ int command_builtin ();
/*extern*/ char *command_doc[];
/*extern*/ int declare_builtin ();
/*extern*/ char *declare_doc[];
/*extern*/ int declare_builtin ();
/*extern*/ char *typeset_doc[];
/*extern*/ int local_builtin ();
/*extern*/ char *local_doc[];

/*extern*/ int echo_builtin ();
/*extern*/ char *echo_doc[];





/*extern*/ int enable_builtin ();
/*extern*/ char *enable_doc[];
/*extern*/ int eval_builtin ();
/*extern*/ char *eval_doc[];
/*extern*/ int getopts_builtin ();
/*extern*/ char *getopts_doc[];
/*extern*/ int exec_builtin ();
/*extern*/ char *exec_doc[];
/*extern*/ int exit_builtin ();
/*extern*/ char *exit_doc[];
/*extern*/ int logout_builtin ();
/*extern*/ char *logout_doc[];

/*extern*/ int fc_builtin ();
/*extern*/ char *fc_doc[];


/*extern*/ int fg_builtin ();
/*extern*/ char *fg_doc[];


/*extern*/ int bg_builtin ();
/*extern*/ char *bg_doc[];

/*extern*/ int hash_builtin ();
/*extern*/ char *hash_doc[];

/*extern*/ int help_builtin ();
/*extern*/ char *help_doc[];


/*extern*/ int history_builtin ();
/*extern*/ char *history_doc[];


/*extern*/ int jobs_builtin ();
/*extern*/ char *jobs_doc[];


/*extern*/ int disown_builtin ();
/*extern*/ char *disown_doc[];


/*extern*/ int kill_builtin ();
/*extern*/ char *kill_doc[];

/*extern*/ int let_builtin ();
/*extern*/ char *let_doc[];
/*extern*/ int read_builtin ();
/*extern*/ char *read_doc[];
/*extern*/ int return_builtin ();
/*extern*/ char *return_doc[];
/*extern*/ int set_builtin ();
/*extern*/ char *set_doc[];
/*extern*/ int unset_builtin ();
/*extern*/ char *unset_doc[];
/*extern*/ int export_builtin ();
/*extern*/ char *export_doc[];
/*extern*/ int readonly_builtin ();
/*extern*/ char *readonly_doc[];
/*extern*/ int shift_builtin ();
/*extern*/ char *shift_doc[];
/*extern*/ int source_builtin ();
/*extern*/ char *source_doc[];
/*extern*/ int source_builtin ();
/*extern*/ char *dot_doc[];

/*extern*/ int suspend_builtin ();
/*extern*/ char *suspend_doc[];

/*extern*/ int test_builtin ();
/*extern*/ char *test_doc[];
/*extern*/ int test_builtin ();
/*extern*/ char *test_bracket_doc[];
/*extern*/ int times_builtin ();
/*extern*/ char *times_doc[];
/*extern*/ int trap_builtin ();
/*extern*/ char *trap_doc[];
/*extern*/ int type_builtin ();
/*extern*/ char *type_doc[];

/*extern*/ int ulimit_builtin ();
/*extern*/ char *ulimit_doc[];

/*extern*/ int umask_builtin ();
/*extern*/ char *umask_doc[];

/*extern*/ int wait_builtin ();
/*extern*/ char *wait_doc[];





/*extern*/ char *for_doc[];
/*extern*/ char *select_doc[];
/*extern*/ char *time_doc[];
/*extern*/ char *case_doc[];
/*extern*/ char *if_doc[];
/*extern*/ char *while_doc[];
/*extern*/ char *until_doc[];
/*extern*/ char *function_doc[];
/*extern*/ char *grouping_braces_doc[];
/*extern*/ char *fg_percent_doc[];
/*extern*/ char *variable_help_doc[];

/*extern*/ int pushd_builtin ();
/*extern*/ char *pushd_doc[];


/*extern*/ int popd_builtin ();
/*extern*/ char *popd_doc[];


/*extern*/ int dirs_builtin ();
/*extern*/ char *dirs_doc[];

/*extern*/ int shopt_builtin ();
/*extern*/ char *shopt_builtin_doc[];




/*extern*/ int fnmatch();



/*extern*/ CPFunction *tilde_expansion_failure_hook;




/*extern*/ char **tilde_additional_prefixes;




/*extern*/ char **tilde_additional_suffixes;


/*extern*/ char *tilde_expand ();



/*extern*/ char *tilde_expand_word ();





enum stream_type {st_none, st_stdin, st_stream, st_string, st_bstream};

typedef struct BSTREAM
{
  int b_fd;
  char *b_buffer;
  int b_size;
  int b_used;
  int b_flag;
  int b_inputp;
} BUFFERED_STREAM;

/*extern*/ BUFFERED_STREAM **buffers;

/*extern*/ BUFFERED_STREAM *fd_to_buffered_stream ();

/*extern*/ int default_buffered_input;



typedef union {
  FILE *file;
  char *string;

  int buffered_fd;

} INPUT_STREAM;

typedef struct {
  enum stream_type type;
  char *name;
  INPUT_STREAM location;
  Function *getter;
  Function *ungetter;
} BASH_INPUT;

/*extern*/ BASH_INPUT bash_input;


/*extern*/ void initialize_bash_input ();
/*extern*/ void init_yy_io (Function *, Function *, int, char *, INPUT_STREAM);
/*extern*/ void with_input_from_stdin ();
/*extern*/ void with_input_from_string (char *, char *);
/*extern*/ void with_input_from_stream (FILE *, char *);
/*extern*/ void push_stream (int);
/*extern*/ void pop_stream ();
/*extern*/ int stream_on_stack (enum stream_type);
/*extern*/ char *read_secondary_line (int);
/*extern*/ int find_reserved_word (char *);
/*extern*/ char *decode_prompt_string (char *);
/*extern*/ void gather_here_documents ();
/*extern*/ void execute_prompt_command (char *);


/*extern*/ int getc_with_restart ();
/*extern*/ int ungetc_with_restart ();



/*extern*/ int check_bash_input (int);
/*extern*/ int duplicate_buffered_stream (int, int);
/*extern*/ BUFFERED_STREAM *fd_to_buffered_stream (int);
/*extern*/ BUFFERED_STREAM *open_buffered_stream (char *);
/*extern*/ void free_buffered_stream (BUFFERED_STREAM *);
/*extern*/ int close_buffered_stream (BUFFERED_STREAM *);
/*extern*/ int close_buffered_fd (int);
/*extern*/ int sync_buffered_stream (int);
/*extern*/ int buffered_getchar ();
/*extern*/ int buffered_ungetchar (int);
/*extern*/ void with_input_from_buffered_stream (int, char *);










/*extern*/ int remember_on_history;
/*extern*/ int history_lines_this_session;
/*extern*/ int history_lines_in_file;
/*extern*/ int history_expansion;
/*extern*/ int history_control;
/*extern*/ int command_oriented_history;


/*extern*/ int history_expansion_inhibited;


/*extern*/ void bash_initialize_history ();
/*extern*/ void bash_history_reinit ();
/*extern*/ void bash_history_disable ();
/*extern*/ void bash_history_enable ();
/*extern*/ void load_history ();
/*extern*/ void save_history ();
/*extern*/ int maybe_append_history ();
/*extern*/ int maybe_save_shell_history ();
/*extern*/ char *pre_process_line ();
/*extern*/ int history_number ();
/*extern*/ void maybe_add_history ();

/*extern*/ void setup_history_ignore ();

/*extern*/ char *last_history_line ();



/*extern*/ int posixly_correct;
/*extern*/ int executing, breaking, continuing, loop_level;
/*extern*/ int interactive, interactive_shell, login_shell, expand_aliases;
/*extern*/ int parse_and_execute_level, running_trap;
/*extern*/ int command_string_index, variable_context, line_number;
/*extern*/ int dot_found_in_search;
/*extern*/ int already_making_children;
/*extern*/ char **temporary_env, **function_env, **builtin_env;
/*extern*/ char *the_printed_command, *shell_name;
/*extern*/ pid_t last_command_subst_pid;
/*extern*/ Function *last_shell_builtin, *this_shell_builtin;
/*extern*/ char **subshell_argv, **subshell_envp;
/*extern*/ int subshell_argc;
/*extern*/ char *glob_argv_flags;

/*extern*/ int getdtablesize ();
/*extern*/ int close ();


static void close_pipes (), do_piping (), bind_lastarg ();
static void cleanup_redirects ();
static void add_undo_close_redirect (), add_exec_redirect ();
static int add_undo_redirect ();
static int do_redirection_internal (), do_redirections ();
static int expandable_redirection_filename ();
static char *find_user_command_internal (), *find_user_command_in_path ();
static char *find_in_path_element (), *find_absolute_program ();

static int execute_for_command ();

static int execute_select_command ();

static int time_command ();
static int execute_case_command ();
static int execute_while_command (), execute_until_command ();
static int execute_while_or_until ();
static int execute_if_command ();
static int execute_simple_command ();
static int execute_builtin (), execute_function ();
static int execute_builtin_or_function ();
static int builtin_status ();
static void execute_subshell_builtin_or_function ();
static void execute_disk_command ();
static int execute_connection ();
static int execute_intern_function ();


static int function_line_number;


static int stdin_redir;



char *this_command_name;

static COMMAND *currently_executing_command;

struct stat SB;

static int special_builtin_failed;
static REDIRECTEE rd;






static char *file_to_lose_on;


int return_catch_flag;
int return_catch_value;
sigjmp_buf return_catch;


int last_command_exit_value;



REDIRECT *redirection_undo_list = (REDIRECT *)((void *)0);




REDIRECT *exec_redirection_undo_list = (REDIRECT *)((void *)0);



int subshell_environment;



int check_hashed_filenames;

struct fd_bitmap *current_fds_to_close = (struct fd_bitmap *)((void *)0);





static char * __sym_xmalloc(unsigned long param0, ...);
static void __sym_bzero(void * param0, size_t param1, ...);
struct fd_bitmap *
new_fd_bitmap (size)
     long size;
{
  struct fd_bitmap *ret;

  ret = (struct fd_bitmap *)__sym_xmalloc (sizeof (struct fd_bitmap));

  ret->size = size;

  if (size)
    {
      ret->bitmap = __sym_xmalloc (size);
      __sym_bzero (ret->bitmap, size);
    }
  else
    ret->bitmap = (char *)((void *)0);
  return (ret);
}

static void __sym_free(void * param0, ...);
void
dispose_fd_bitmap (fdbp)
     struct fd_bitmap *fdbp;
{
  do { if (fdbp->bitmap) __sym_free (fdbp->bitmap); } while (0);
  __sym_free (fdbp);
}

static int __sym_close(int param0, ...);
void
close_fd_bitmap (fdbp)
     struct fd_bitmap *fdbp;
{
  register int i;

  if (fdbp)
    {
      for (i = 0; i < fdbp->size; i++)
 if (fdbp->bitmap[i])
   {
     __sym_close (i);
     fdbp->bitmap[i] = 0;
   }
    }
}


int
executing_line_number ()
{
  if (executing && variable_context == 0 && currently_executing_command &&
       currently_executing_command->type == cm_simple)
    return currently_executing_command->value.Simple->line;
  return line_number;
}

static struct fd_bitmap * __sym_new_fd_bitmap(long param0, ...);
static void __sym_begin_unwind_frame();
static void __sym_add_unwind_protect();
static int __sym_execute_command_internal(COMMAND * param0, int param1, int param2, int param3, struct fd_bitmap * param4, ...);
static void __sym_dispose_fd_bitmap(struct fd_bitmap * param0, ...);
static void __sym_discard_unwind_frame();
static void __sym_unlink_fifo_list();
int
execute_command (command)
     COMMAND *command;
{
  struct fd_bitmap *bitmap;
  int result;

  current_fds_to_close = (struct fd_bitmap *)((void *)0);
  bitmap = __sym_new_fd_bitmap (32);
  __sym_begin_unwind_frame ("execute-command");
  __sym_add_unwind_protect (dispose_fd_bitmap, (char *)bitmap);


  result = __sym_execute_command_internal (command, 0, -1, -1, bitmap);

  __sym_dispose_fd_bitmap (bitmap);
  __sym_discard_unwind_frame ("execute-command");


  __sym_unlink_fifo_list ();


  return (result);
}


static int
shell_control_structure (type)
     enum command_type type;
{
  switch (type)
    {
    case cm_for:

    case cm_select:

    case cm_case:
    case cm_while:
    case cm_until:
    case cm_if:
    case cm_group:
      return (1);

    default:
      return (0);
    }
}



static int __sym_do_redirections();
static void __sym_dispose_redirects(REDIRECT * param0, ...);
static void
cleanup_redirects (list)
     REDIRECT *list;
{
  __sym_do_redirections (list, 1, 0, 0);
  __sym_dispose_redirects (list);
}

static void
dispose_exec_redirects ()
{
  if (exec_redirection_undo_list)
    {
      __sym_dispose_redirects (exec_redirection_undo_list);
      exec_redirection_undo_list = (REDIRECT *)((void *)0);
    }
}




static int __sym_sigprocmask(int param0, const sigset_t * param1, sigset_t * param2, ...);
static int
restore_signal_mask (set)
     sigset_t set;
{
  return (__sym_sigprocmask (2, &set, (sigset_t *)((void *)0)));
}



static int __sym_getdtablesize();
static int __sym_fprintf(FILE * param0, const char * param1, ...);
static int __sym_getpid();
static int __sym_fcntl(int param0, int param1, ...);
void
open_files ()
{
  register int i;
  int f, fd_table_size;

  fd_table_size = __sym_getdtablesize ();

  __sym_fprintf (stderr, "pid %d open files:", (int)__sym_getpid ());
  for (i = 3; i < fd_table_size; i++)
    {
      if ((f = __sym_fcntl (i, 1, 0)) != -1)
 __sym_fprintf (stderr, " %d (%s)", i, f ? "close" : "open");
    }
  __sym_fprintf (stderr, "\n");
}

static void __sym_run_pending_traps();
static int __sym_time_command();
static int __sym_shell_control_structure(enum command_type param0, ...);
static int __sym_make_child(char * param0, int param1, ...);
static char * __sym_strcpy(char * param0, const char * param1, ...);
static unsigned long __sym_strlen(const char * param0, ...);
static char * __sym_make_command_string(COMMAND * param0, ...);
static void __sym_reset_terminating_signals();
static void __sym_restore_original_signals();
static void __sym_setup_async_signals();
static void __sym_set_sigchld_handler();
static void * __sym_set_sigint_handler();
static void __sym_without_job_control();
static void __sym_do_piping();
static void __sym_restore_default_signal(int param0, ...);
static void __sym_close_fd_bitmap(struct fd_bitmap * param0, ...);
static void __sym_exit(int param0, ...);
static int __sym___sigsetjmp(struct __jmp_buf_tag param0[], int param1, ...);
static int __sym_signal_is_trapped(int param0, ...);
static int __sym_run_exit_trap();
static void __sym_close_pipes();
static int __sym_stop_pipeline(int param0, COMMAND * param1, ...);
static int __sym_wait_for(pid_t param0, ...);
static void __sym_describe_pid(pid_t param0, ...);
static void __sym_cleanup_redirects(REDIRECT * param0, ...);
static void __sym_dispose_exec_redirects();
static struct redirect * __sym_copy_redirects(REDIRECT * param0, ...);
static void __sym_throw_to_top_level();
static int __sym_signal_is_ignored(int param0, ...);
static int __sym_execute_simple_command();
static void __sym_dispose_used_env_vars();
static void __sym_run_debug_trap();
static void __sym_jump_to_top_level(int param0, ...);
static int __sym_execute_for_command();
static int __sym_execute_select_command();
static int __sym_execute_case_command();
static int __sym_execute_while_command();
static int __sym_execute_until_command();
static int __sym_execute_if_command();
static int __sym_execute_connection();
static int __sym_execute_intern_function();
static void __sym_programming_error(const char * param0, ...);
int
execute_command_internal (command, asynchronous, pipe_in, pipe_out,
     fds_to_close)
     COMMAND *command;
     int asynchronous;
     int pipe_in, pipe_out;
     struct fd_bitmap *fds_to_close;
{
  int exec_result, invert, ignore_return, was_debug_trap;
  REDIRECT *my_undo_list, *exec_undo_list, *rp;
  pid_t last_pid;

  if (command == 0 || breaking || continuing || read_but_dont_execute)
    return (0);

  __sym_run_pending_traps ();

  if (running_trap == 0)
    currently_executing_command = command;


  if (command->flags & 0x80)
    {
      exec_result = __sym_time_command (command, asynchronous, pipe_in, pipe_out, fds_to_close);
      if (running_trap == 0)
 currently_executing_command = (COMMAND *)((void *)0);
      return (exec_result);
    }


  invert = (command->flags & 0x04) != 0;
  exec_result = 0;





  if ((command->flags & (0x01|0x02)) ||
      (__sym_shell_control_structure (command->type) &&
       (pipe_out != -1 || pipe_in != -1 || asynchronous)))
    {
      pid_t paren_pid;



      paren_pid = __sym_make_child ((char *)__sym_strcpy (__sym_xmalloc (1 + __sym_strlen (__sym_make_command_string (command))), (__sym_make_command_string (command))),
         asynchronous);
      if (paren_pid == 0)
 {
   int user_subshell, return_code, function_value;

   user_subshell = (command->flags & 0x01) != 0;
   command->flags &= ~(0x02 | 0x01 | 0x04);

   if (asynchronous)
     {





       original_pgrp = -1;

       interactive_shell = 0;
       expand_aliases = 0;
       asynchronous = 0;
     }


   login_shell = interactive = 0;

   subshell_environment = user_subshell ? 0x02 : 0x01;

   __sym_reset_terminating_signals ();

   __sym_restore_original_signals ();
   if (asynchronous)
     __sym_setup_async_signals ();


   __sym_set_sigchld_handler ();


   __sym_set_sigint_handler ();




   __sym_without_job_control ();

   __sym_do_piping (pipe_in, pipe_out);





   if (user_subshell)
     {
       for (rp = command->redirects; rp; rp = rp->next)
  switch (rp->instruction)
    {
    case r_input_direction:
    case r_inputa_direction:
    case r_input_output:
    case r_reading_until:
    case r_deblank_reading_until:
      stdin_redir++;
      break;
    case r_duplicating_input:
    case r_duplicating_input_word:
    case r_close_this:
      stdin_redir += (rp->redirector == 0);
      break;
    }

       __sym_restore_default_signal (0);
     }

   if (fds_to_close)
     __sym_close_fd_bitmap (fds_to_close);


   if (command->redirects)
     {
       if (__sym_do_redirections (command->redirects, 1, 0, 0) != 0)
  __sym_exit (1);

       __sym_dispose_redirects (command->redirects);
       command->redirects = (REDIRECT *)((void *)0);
     }




   if (user_subshell && command->type == cm_simple)
     {
       command->flags |= 0x40;
       command->value.Simple->flags |= 0x40;
     }



   function_value = 0;
   if (return_catch_flag)
     function_value = __sym___sigsetjmp ((return_catch), 1);

   if (function_value)
     return_code = return_catch_value;
   else
     return_code = __sym_execute_command_internal
       (command, asynchronous, -1, -1, fds_to_close);



   if (user_subshell && __sym_signal_is_trapped (0))
     {
       last_command_exit_value = return_code;
       return_code = __sym_run_exit_trap ();
     }

   __sym_exit (return_code);
 }
      else
 {
   __sym_close_pipes (pipe_in, pipe_out);


   __sym_unlink_fifo_list ();






   if (pipe_out != -1)
     return (0);

   __sym_stop_pipeline (asynchronous, (COMMAND *)((void *)0));

   if (asynchronous == 0)
     {
       last_command_exit_value = __sym_wait_for (paren_pid);


       if (invert)
  return ((last_command_exit_value == 0)
     ? 1
     : 0);
       else
  return (last_command_exit_value);
     }
   else
     {
       do { if (interactive) __sym_describe_pid (paren_pid); } while (0);

       __sym_run_pending_traps ();

       return (0);
     }
 }
    }



  if (__sym_do_redirections (command->redirects, 1, 1, 0) != 0)
    {
      __sym_cleanup_redirects (redirection_undo_list);
      redirection_undo_list = (REDIRECT *)((void *)0);
      __sym_dispose_exec_redirects ();
      return (1);
    }

  if (redirection_undo_list)
    {
      my_undo_list = (REDIRECT *)__sym_copy_redirects (redirection_undo_list);
      __sym_dispose_redirects (redirection_undo_list);
      redirection_undo_list = (REDIRECT *)((void *)0);
    }
  else
    my_undo_list = (REDIRECT *)((void *)0);

  if (exec_redirection_undo_list)
    {
      exec_undo_list = (REDIRECT *)__sym_copy_redirects (exec_redirection_undo_list);
      __sym_dispose_redirects (exec_redirection_undo_list);
      exec_redirection_undo_list = (REDIRECT *)((void *)0);
    }
  else
    exec_undo_list = (REDIRECT *)((void *)0);

  if (my_undo_list || exec_undo_list)
    __sym_begin_unwind_frame ("loop_redirections");

  if (my_undo_list)
    __sym_add_unwind_protect ((Function *)cleanup_redirects, my_undo_list);

  if (exec_undo_list)
    __sym_add_unwind_protect ((Function *)__sym_dispose_redirects, exec_undo_list);

  ignore_return = (command->flags & 0x08) != 0;

  if (interrupt_state) __sym_throw_to_top_level ();

  switch (command->type)
    {
    case cm_simple:
      {



 last_pid = last_made_pid;
 was_debug_trap = __sym_signal_is_trapped (65) && __sym_signal_is_ignored (65) == 0;

 if (ignore_return && command->value.Simple)
   command->value.Simple->flags |= 0x08;
 exec_result =
   __sym_execute_simple_command (command->value.Simple, pipe_in, pipe_out,
      asynchronous, fds_to_close);



 __sym_dispose_used_env_vars ();

 if (already_making_children && pipe_out == -1 &&
     last_pid != last_made_pid)
   {
     __sym_stop_pipeline (asynchronous, (COMMAND *)((void *)0));

     if (asynchronous)
       {
  do { if (interactive) __sym_describe_pid (last_made_pid); } while (0);
       }
     else

       exec_result = __sym_wait_for (last_made_pid);
   }
      }

      if (was_debug_trap)
 __sym_run_debug_trap ();

      if (ignore_return == 0 && invert == 0 &&
          ((posixly_correct && interactive == 0 && special_builtin_failed) ||
    (exit_immediately_on_error && (exec_result != 0))))
 {
   last_command_exit_value = exec_result;
   __sym_run_pending_traps ();
   __sym_jump_to_top_level (3);
 }

      break;

    case cm_for:
      if (ignore_return)
 command->value.For->flags |= 0x08;
      exec_result = __sym_execute_for_command (command->value.For);
      break;


    case cm_select:
      if (ignore_return)
 command->value.Select->flags |= 0x08;
      exec_result = __sym_execute_select_command (command->value.Select);
      break;


    case cm_case:
      if (ignore_return)
 command->value.Case->flags |= 0x08;
      exec_result = __sym_execute_case_command (command->value.Case);
      break;

    case cm_while:
      if (ignore_return)
 command->value.While->flags |= 0x08;
      exec_result = __sym_execute_while_command (command->value.While);
      break;

    case cm_until:
      if (ignore_return)
 command->value.While->flags |= 0x08;
      exec_result = __sym_execute_until_command (command->value.While);
      break;

    case cm_if:
      if (ignore_return)
 command->value.If->flags |= 0x08;
      exec_result = __sym_execute_if_command (command->value.If);
      break;

    case cm_group:

      if (asynchronous)
 {
   command->flags |= 0x02;
   exec_result =
     __sym_execute_command_internal (command, 1, pipe_in, pipe_out,
          fds_to_close);
 }
      else
 {
   if (ignore_return && command->value.Group->command)
     command->value.Group->command->flags |= 0x08;
   exec_result =
     __sym_execute_command_internal (command->value.Group->command,
          asynchronous, pipe_in, pipe_out,
          fds_to_close);
 }
      break;

    case cm_connection:
      exec_result = __sym_execute_connection (command, asynchronous,
     pipe_in, pipe_out, fds_to_close);
      break;

    case cm_function_def:
      exec_result = __sym_execute_intern_function (command->value.Function_def->name,
          command->value.Function_def->command);
      break;

    default:
      __sym_programming_error
 ("execute_command: bad command type `%d'", command->type);
    }

  if (my_undo_list)
    {
      __sym_do_redirections (my_undo_list, 1, 0, 0);
      __sym_dispose_redirects (my_undo_list);
    }

  if (exec_undo_list)
    __sym_dispose_redirects (exec_undo_list);

  if (my_undo_list || exec_undo_list)
    __sym_discard_unwind_frame ("loop_redirections");


  if (invert)
    exec_result = (exec_result == 0)
      ? 1
      : 0;

  last_command_exit_value = exec_result;
  __sym_run_pending_traps ();
  if (running_trap == 0)
    currently_executing_command = (COMMAND *)((void *)0);
  return (last_command_exit_value);
}



static struct timeval *
difftimeval (d, t1, t2)
     struct timeval *d, *t1, *t2;
{
  d->tv_sec = t2->tv_sec - t1->tv_sec;
  d->tv_usec = t2->tv_usec - t1->tv_usec;
  if (d->tv_usec < 0)
    {
      d->tv_usec += 1000000;
      d->tv_sec -= 1;
      if (d->tv_sec < 0)
 d->tv_sec = 0;
    }
  return d;
}

static struct timeval *
addtimeval (d, t1, t2)
     struct timeval *d, *t1, *t2;
{
  d->tv_sec = t1->tv_sec + t2->tv_sec;
  d->tv_usec = t1->tv_usec + t2->tv_usec;
  if (d->tv_usec > 1000000)
    {
      d->tv_usec -= 1000000;
      d->tv_sec += 1;
    }
  return d;
}



static struct timeval * __sym_addtimeval(struct timeval * param0, struct timeval * param1, struct timeval * param2, ...);
static int
timeval_to_cpu (rt, ut, st)
     struct timeval *rt, *ut, *st;
{
  struct timeval t1, t2;
  register int i;

  __sym_addtimeval (&t1, ut, st);
  t2.tv_sec = rt->tv_sec;
  t2.tv_usec = rt->tv_usec;

  for (i = 0; i < 6; i++)
    {
      if ((t1.tv_sec > 99999999) || (t2.tv_sec > 99999999))
 break;
      t1.tv_sec *= 10;
      t1.tv_sec += t1.tv_usec / 100000;
      t1.tv_usec *= 10;
      t1.tv_usec %= 1000000;
      t2.tv_sec *= 10;
      t2.tv_sec += t2.tv_usec / 100000;
      t2.tv_usec *= 10;
      t2.tv_usec %= 1000000;
    }
  for (i = 0; i < 4; i++)
    {
      if (t1.tv_sec < 100000000)
 t1.tv_sec *= 10;
      else
        t2.tv_sec /= 10;
    }

  return (t1.tv_sec / t2.tv_sec);
}





static int precs[] = { 0, 100, 10, 1 };


static int
mkfmt (buf, prec, lng, sec, sec_fraction)
     char *buf;
     int prec, lng;
     long sec;
     int sec_fraction;
{
  long min;
  char abuf[16];
  int ind, aind;

  ind = 0;
  abuf[15] = '\0';


  if (lng)
    {
      min = sec / 60;
      sec %= 60;
      aind = 14;
      do
 abuf[aind--] = (min % 10) + '0';
      while (min /= 10);
      aind++;
      while (abuf[aind])
        buf[ind++] = abuf[aind++];
      buf[ind++] = 'm';
    }


  aind = 14;
  do
    abuf[aind--] = (sec % 10) + '0';
  while (sec /= 10);
  aind++;
  while (abuf[aind])
    buf[ind++] = abuf[aind++];




  if (prec != 0)
    {
      buf[ind++] = '.';
      for (aind = 1; aind <= prec; aind++)
 {
   buf[ind++] = (sec_fraction / precs[aind]) + '0';
   sec_fraction %= precs[aind];
 }
    }

  if (lng)
    buf[ind++] = 's';
  buf[ind] = '\0';

  return (ind);
}

static char * __sym_xrealloc(void * param0, size_t param1, ...);
static int __sym_mkfmt(char * param0, int param1, int param2, long param3, int param4, ...);
static const unsigned short ** __sym___ctype_b_loc();
static void __sym_internal_error(const char * param0, ...);
static int __sym_fflush(FILE * param0, ...);
static void
print_formatted_time (fp, format, rs, rsf, us, usf, ss, ssf, cpu)
     FILE *fp;
     char *format;
     long rs, us, ss;
     int rsf, usf, ssf, cpu;
{
  int prec, lng, len;
  char *str, *s, ts[32];
  int sum, sum_frac;
  int sindex, ssize;

  len = __sym_strlen (format);
  ssize = (len + 64) - (len % 64);
  str = __sym_xmalloc (ssize);
  sindex = 0;

  for (s = format; *s; s++)
    {
      if (*s != '%' || s[1] == '\0')
        {
          do { if ((sindex) + (1) >= ssize) { while ((sindex) + (1) >= ssize) ssize += (64); str = __sym_xrealloc (str, ssize); } } while (0);
          str[sindex++] = *s;
        }
      else if (s[1] == '%')
        {
          s++;
          do { if ((sindex) + (1) >= ssize) { while ((sindex) + (1) >= ssize) ssize += (64); str = __sym_xrealloc (str, ssize); } } while (0);
          str[sindex++] = *s;
        }
      else if (s[1] == 'P')
 {
   s++;
   if (cpu > 10000)
     cpu = 10000;
   sum = cpu / 100;
   sum_frac = (cpu % 100) * 10;
   len = __sym_mkfmt (ts, 2, 0, sum, sum_frac);
   do { if ((sindex) + (len) >= ssize) { while ((sindex) + (len) >= ssize) ssize += (64); str = __sym_xrealloc (str, ssize); } } while (0);
   __sym_strcpy (str + sindex, ts);
   sindex += len;
 }
      else
 {
   prec = 3;
   lng = 0;
   s++;
   if (((*__sym___ctype_b_loc ())[(int) ((*s))] & (unsigned short int) _ISdigit))
     {
       prec = *s++ - '0';
       if (prec > 3) prec = 3;
     }
   if (*s == 'l')
     {
       lng = 1;
       s++;
     }
   if (*s == 'R' || *s == 'E')
     len = __sym_mkfmt (ts, prec, lng, rs, rsf);
   else if (*s == 'U')
     len = __sym_mkfmt (ts, prec, lng, us, usf);
   else if (*s == 'S')
     len = __sym_mkfmt (ts, prec, lng, ss, ssf);
   else
     {
       __sym_internal_error ("bad format character in time format: %c", *s);
       __sym_free (str);
       return;
     }
   do { if ((sindex) + (len) >= ssize) { while ((sindex) + (len) >= ssize) ssize += (64); str = __sym_xrealloc (str, ssize); } } while (0);
   __sym_strcpy (str + sindex, ts);
   sindex += len;
 }
    }

  str[sindex] = '\0';
  __sym_fprintf (fp, "%s\n", str);
  __sym_fflush (fp);

  __sym_free (str);
}
long
get_clk_tck ()
{
  static long retval = 0;

  if (retval != 0)
    return (retval);


  retval = sysconf (_SC_CLK_TCK);




  return (retval);
}

void
clock_t_to_secs (t, sp, sfp)
     clock_t t;
     long *sp;
     int *sfp;
{
  static long clk_tck = 0;

  if (clk_tck == 0)
    clk_tck = get_clk_tck ();

  *sfp = t % clk_tck;
  *sfp = (*sfp * 1000) / clk_tck;

  *sp = t / clk_tck;
}

static int __sym_gettimeofday(struct timeval * param0, struct timezone * param1, ...);
static int __sym_getrusage(__rusage_who_t param0, struct rusage * param1, ...);
static struct timeval * __sym_difftimeval(struct timeval * param0, struct timeval * param1, struct timeval * param2, ...);
static void __sym_timeval_to_secs();
static int __sym_timeval_to_cpu(struct timeval * param0, struct timeval * param1, struct timeval * param2, ...);
static char * __sym_get_string_value(char * param0, ...);
static void __sym_print_formatted_time(FILE * param0, char * param1, long param2, int param3, long param4, int param5, long param6, int param7, int param8, ...);
static int
time_command (command, asynchronous, pipe_in, pipe_out, fds_to_close)
     COMMAND *command;
     int asynchronous, pipe_in, pipe_out;
     struct fd_bitmap *fds_to_close;
{
  int rv, posix_time;
  long rs, us, ss;
  int rsf, usf, ssf;
  int cpu;
  char *time_format;

/*
  struct timeval real, user, sys;
  struct timeval before, after;
  struct timezone dtz;
  struct rusage selfb, selfa, kidsb, kidsa;
*/
  clock_t tbefore, tafter, real, user, sys;
  struct tms before, after;
/*
  gettimeofday (&before, &dtz);
  getrusage (RUSAGE_SELF, &selfb);
  getrusage (RUSAGE_CHILDREN, &kidsb);
*/



tbefore = __sym_times (&before);
assert(command != 0);
  posix_time = (command->flags & 0x100);
assert(command != 0);
  command->flags &= ~(0x80|0x100);
  rv = __sym_execute_command_internal (command, asynchronous, pipe_in, pipe_out, fds_to_close);


    tafter = __sym_times (&after);

    real = tafter - tbefore;
    clock_t_to_secs (real, &rs, &rsf);

    user = (after.tms_utime - before.tms_utime) + (after.tms_cutime - before.tms_cutime);
    clock_t_to_secs (user, &us, &usf);

    sys = (after.tms_stime - before.tms_stime) + (after.tms_cstime - before.tms_cstime);
    clock_t_to_secs (sys, &ss, &ssf);
    assert(real != 0);
    cpu = ((user + sys) * 10000) / real;

  if (posix_time)
    time_format = "real %2R\nuser %2U\nsys %2S";
  else if ((time_format = __sym_get_string_value ("TIMEFORMAT")) == 0)
    time_format = "\nreal\t%3lR\nuser\t%3lU\nsys\t%3lS";
assert(time_format != 0);
  if (time_format && *time_format)
    print_formatted_time (stderr, time_format, rs, rsf, us, usf, ss, ssf, cpu);

  return rv;
}


static int __sym_sigemptyset(sigset_t * param0, ...);
static int __sym_sigaddset(sigset_t * param0, int param1, ...);
static int __sym_pipe(int param0[], ...);
static void __sym_sys_error(const char * param0, ...);
static void __sym_terminate_current_pipeline();
static void __sym_kill_current_pipeline();
static void __sym_xbcopy(char * param0, char * param1, int param2, ...);
static int
execute_pipeline (command, asynchronous, pipe_in, pipe_out, fds_to_close)
     COMMAND *command;
     int asynchronous, pipe_in, pipe_out;
     struct fd_bitmap *fds_to_close;
{
  int prev, fildes[2], new_bitmap_size, dummyfd, ignore_return, exec_result;
  COMMAND *cmd;
  struct fd_bitmap *fd_bitmap;


  sigset_t set, oset;
  __sym_sigemptyset (&set); __sym_sigaddset (&set, 17); __sym_sigemptyset (&oset); __sym_sigprocmask (0, &set, &oset);


  ignore_return = (command->flags & 0x08) != 0;

  prev = pipe_in;
  cmd = command;

  while (cmd && cmd->type == cm_connection &&
  cmd->value.Connection && cmd->value.Connection->connector == '|')
    {

      if (__sym_pipe (fildes) < 0)
 {
   __sym_sys_error ("pipe error");

   __sym_terminate_current_pipeline ();
   __sym_kill_current_pipeline ();

   last_command_exit_value = 1;


   __sym_throw_to_top_level ();
   return (1);
 }

      new_bitmap_size = (fildes[0] < fds_to_close->size)
    ? fds_to_close->size
    : fildes[0] + 8;

      fd_bitmap = __sym_new_fd_bitmap (new_bitmap_size);


      __sym_xbcopy ((char *)fds_to_close->bitmap, (char *)fd_bitmap->bitmap, fds_to_close->size);


      fd_bitmap->bitmap[fildes[0]] = 1;





      __sym_begin_unwind_frame ("pipe-file-descriptors");
      __sym_add_unwind_protect (dispose_fd_bitmap, fd_bitmap);
      __sym_add_unwind_protect (close_fd_bitmap, fd_bitmap);
      if (prev >= 0)
 __sym_add_unwind_protect (close, prev);
      dummyfd = fildes[1];
      __sym_add_unwind_protect (close, dummyfd);


      __sym_add_unwind_protect (restore_signal_mask, oset);


      if (ignore_return && cmd->value.Connection->first)
 cmd->value.Connection->first->flags |= 0x08;
      __sym_execute_command_internal (cmd->value.Connection->first, asynchronous,
    prev, fildes[1], fd_bitmap);

      if (prev >= 0)
 __sym_close (prev);

      prev = fildes[0];
      __sym_close (fildes[1]);

      __sym_dispose_fd_bitmap (fd_bitmap);
      __sym_discard_unwind_frame ("pipe-file-descriptors");

      cmd = cmd->value.Connection->second;
    }


  if (ignore_return && cmd)
    cmd->flags |= 0x08;
  exec_result = __sym_execute_command_internal (cmd, asynchronous, prev, pipe_out, fds_to_close);

  if (prev >= 0)
    __sym_close (prev);


  __sym_sigprocmask (2, &oset, (sigset_t *) ((void *)0));


  return (exec_result);
}

static struct word_desc * __sym_make_bare_word(char * param0, ...);
static struct redirect * __sym_make_redirection(int param0, enum r_instruction param1, REDIRECTEE param2, ...);
static int __sym_execute_command(COMMAND * param0, ...);
static int __sym_execute_pipeline(COMMAND * param0, int param1, int param2, int param3, struct fd_bitmap * param4, ...);
static int
execute_connection (command, asynchronous, pipe_in, pipe_out, fds_to_close)
     COMMAND *command;
     int asynchronous, pipe_in, pipe_out;
     struct fd_bitmap *fds_to_close;
{
  REDIRECT *tr, *tl, *rp;
  COMMAND *tc, *second;
  int ignore_return, exec_result;

  ignore_return = (command->flags & 0x08) != 0;

  switch (command->value.Connection->connector)
    {

    case '&':
      tc = command->value.Connection->first;
      if (tc == 0)
 return (0);

      rp = tc->redirects;

      if (ignore_return && tc)
 tc->flags |= 0x08;







      if ((!interactive_shell || subshell_environment || !job_control) && !stdin_redir)



 {
   rd.filename = __sym_make_bare_word ("/dev/null");
   tr = __sym_make_redirection (0, r_inputa_direction, rd);
   tr->next = tc->redirects;
   tc->redirects = tr;
 }

      exec_result = __sym_execute_command_internal (tc, 1, pipe_in, pipe_out, fds_to_close);


      if ((!interactive_shell || subshell_environment || !job_control) && !stdin_redir)



 {



   tr = tc->redirects;
   do
     {
       tl = tc->redirects;
       tc->redirects = tc->redirects->next;
     }
   while (tc->redirects && tc->redirects != rp);

   tl->next = (REDIRECT *)((void *)0);
   __sym_dispose_redirects (tr);
 }

      second = command->value.Connection->second;
      if (second)
 {
   if (ignore_return)
     second->flags |= 0x08;

   exec_result = __sym_execute_command_internal (second, asynchronous, pipe_in, pipe_out, fds_to_close);
 }

      break;


    case ';':
      if (ignore_return)
 {
   if (command->value.Connection->first)
     command->value.Connection->first->flags |= 0x08;
   if (command->value.Connection->second)
     command->value.Connection->second->flags |= 0x08;
 }
      if (interrupt_state) __sym_throw_to_top_level ();
      __sym_execute_command (command->value.Connection->first);
      if (interrupt_state) __sym_throw_to_top_level ();
      exec_result = __sym_execute_command_internal (command->value.Connection->second,
          asynchronous, pipe_in, pipe_out,
          fds_to_close);
      break;

    case '|':
      exec_result = __sym_execute_pipeline (command, asynchronous, pipe_in, pipe_out, fds_to_close);
      break;

    case 279:
    case 280:
      if (asynchronous)
 {





   command->flags |= 0x02;
   exec_result = __sym_execute_command_internal (command, 1, pipe_in, pipe_out, fds_to_close);
   break;
 }






      if (command->value.Connection->first)
 command->value.Connection->first->flags |= 0x08;

      exec_result = __sym_execute_command (command->value.Connection->first);
      if (interrupt_state) __sym_throw_to_top_level ();
      if (((command->value.Connection->connector == 279) &&
    (exec_result == 0)) ||
   ((command->value.Connection->connector == 280) &&
    (exec_result != 0)))
 {
   if (ignore_return && command->value.Connection->second)
     command->value.Connection->second->flags |= 0x08;

   exec_result = __sym_execute_command (command->value.Connection->second);
 }
      break;

    default:
      __sym_programming_error ("execute_connection: bad connector `%d'", command->value.Connection->connector);
      __sym_jump_to_top_level (2);
      exec_result = 1;
    }

  return exec_result;
}

static int __sym_check_identifier(WORD_DESC * param0, int param1, ...);
static struct word_list * __sym_expand_words_no_vars(WORD_LIST * param0, ...);
static struct variable * __sym_bind_variable(char * param0, char * param1, ...);
static void __sym_run_unwind_frame();
static void __sym_reap_dead_jobs();
static void __sym_dispose_words(WORD_LIST * param0, ...);
static int
execute_for_command (for_command)
     FOR_COM *for_command;
{
  register WORD_LIST *releaser, *list;
  SHELL_VAR *v;
  char *identifier;
  int retval;




  if (__sym_check_identifier (for_command->name, 1) == 0)
    {
      if (posixly_correct && interactive_shell == 0)
        {
          last_command_exit_value = 258;
          __sym_jump_to_top_level (3);
        }
      return (1);
    }

  loop_level++;
  identifier = for_command->name->word;

  list = releaser = __sym_expand_words_no_vars (for_command->map_list);

  __sym_begin_unwind_frame ("for");
  __sym_add_unwind_protect (__sym_dispose_words, releaser);

  if (for_command->flags & 0x08)
    for_command->action->flags |= 0x08;

  for (retval = 0; list; list = list->next)
    {
      if (interrupt_state) __sym_throw_to_top_level ();
      this_command_name = (char *)((void *)0);
      v = __sym_bind_variable (identifier, list->word->word);
      if (((((v)->attributes) & (0x02))))
 {
   if (interactive_shell == 0 && posixly_correct)
     {
       last_command_exit_value = 1;
       __sym_jump_to_top_level (1);
     }
   else
     {
       __sym_run_unwind_frame ("for");
       return (1);
     }
 }
      retval = __sym_execute_command (for_command->action);
      do { if (!interactive_shell) __sym_reap_dead_jobs (); } while (0);
      if (interrupt_state) __sym_throw_to_top_level ();

      if (breaking)
 {
   breaking--;
   break;
 }

      if (continuing)
 {
   continuing--;
   if (continuing)
     break;
 }
    }

  loop_level--;

  __sym_dispose_words (releaser);
  __sym_discard_unwind_frame ("for");
  return (retval);
}


static int LINES, COLS, tabsize;

static int
print_index_and_element (len, ind, list)
      int len, ind;
      WORD_LIST *list;
{
  register WORD_LIST *l;
  register int i;

  if (list == 0)
    return (0);
  for (i = ind, l = list; l && --i; l = l->next)
    ;
  __sym_fprintf (stderr, "%*d%s%s", len, ind, ") ", l->word->word);
  return ((((l->word->word) && (l->word->word)[0]) ? ((l->word->word)[1] ? ((l->word->word)[2] ? __sym_strlen(l->word->word) : 2) : 1) : 0));
}

static void
indent (from, to)
     int from, to;
{
  while (from < to)
    {
      if ((to / tabsize) > (from / tabsize))
 {
   __sym__IO_putc ('\t', stderr);
   from += tabsize - from % tabsize;
 }
      else
 {
   __sym__IO_putc (' ', stderr);
   from++;
 }
    }
}

static int __sym_print_index_and_element(int param0, int param1, WORD_LIST * param2, ...);
static void __sym_indent(int param0, int param1, ...);
static void
print_select_list (list, list_len, max_elem_len, indices_len)
     WORD_LIST *list;
     int list_len, max_elem_len, indices_len;
{
  int ind, row, elem_len, pos, cols, rows;
  int first_column_indices_len, other_indices_len;

  if (list == 0)
    {
      __sym__IO_putc ('\n', stderr);
      return;
    }

  cols = max_elem_len ? COLS / max_elem_len : 1;
  if (cols == 0)
    cols = 1;
  rows = list_len ? list_len / cols + (list_len % cols != 0) : 1;
  cols = list_len ? list_len / rows + (list_len % rows != 0) : 1;

  if (rows == 1)
    {
      rows = cols;
      cols = 1;
    }

  first_column_indices_len = ((rows < 10) ? 1 : ((rows < 100) ? 2 : ((rows < 1000) ? 3 : ((rows < 10000) ? 4 : ((rows < 100000) ? 5 : 6)))));
  other_indices_len = indices_len;

  for (row = 0; row < rows; row++)
    {
      ind = row;
      pos = 0;
      while (1)
 {
   indices_len = (pos == 0) ? first_column_indices_len : other_indices_len;
   elem_len = __sym_print_index_and_element (indices_len, ind + 1, list);
   elem_len += indices_len + 2;
   ind += rows;
   if (ind >= list_len)
     break;
   __sym_indent (pos + elem_len, pos + max_elem_len);
   pos += max_elem_len;
 }
      __sym__IO_putc ('\n', stderr);
    }
}






static int __sym_atoi(const char * param0, ...);
static void __sym_print_select_list(WORD_LIST * param0, int param1, int param2, int param3, ...);
static int __sym_read_builtin();
static int __sym_putchar(int param0, ...);
static char *
select_query (list, list_len, prompt)
     WORD_LIST *list;
     int list_len;
     char *prompt;
{
  int max_elem_len, indices_len, len, reply;
  WORD_LIST *l;
  char *repl_string, *t;

  t = __sym_get_string_value ("LINES");
  LINES = (t && *t) ? __sym_atoi (t) : 24;
  t = __sym_get_string_value ("COLUMNS");
  COLS = (t && *t) ? __sym_atoi (t) : 80;







  tabsize = 8;


  max_elem_len = 0;
  for (l = list; l; l = l->next)
    {
      len = (((l->word->word) && (l->word->word)[0]) ? ((l->word->word)[1] ? ((l->word->word)[2] ? __sym_strlen(l->word->word) : 2) : 1) : 0);
      if (len > max_elem_len)
        max_elem_len = len;
    }
  indices_len = ((list_len < 10) ? 1 : ((list_len < 100) ? 2 : ((list_len < 1000) ? 3 : ((list_len < 10000) ? 4 : ((list_len < 100000) ? 5 : 6)))));
  max_elem_len += indices_len + 2 + 2;

  while (1)
    {
      __sym_print_select_list (list, list_len, max_elem_len, indices_len);
      __sym_fprintf (stderr, "%s", prompt);
      __sym_fflush (stderr);
      if (interrupt_state) __sym_throw_to_top_level ();

      if (__sym_read_builtin ((WORD_LIST *)((void *)0)) == 1)
 {
   __sym_putchar ('\n');
   return ((char *)((void *)0));
 }
      repl_string = __sym_get_string_value ("REPLY");
      if (*repl_string == 0)
 continue;
      reply = __sym_atoi (repl_string);
      if (reply < 1 || reply > list_len)
 return "";

      for (l = list; l && --reply; l = l->next)
 ;
      return (l->word->word);
    }
}





static int __sym_list_length();
static void __sym_unwind_protect_var();
static char * __sym_select_query(WORD_LIST * param0, int param1, char * param2, ...);
static int
execute_select_command (select_command)
     SELECT_COM *select_command;
{
  WORD_LIST *releaser, *list;
  SHELL_VAR *v;
  char *identifier, *ps3_prompt, *selection;
  int retval, list_len, return_val;

  if (__sym_check_identifier (select_command->name, 1) == 0)
    return (1);

  loop_level++;
  identifier = select_command->name->word;



  list = releaser = __sym_expand_words_no_vars (select_command->map_list);
  list_len = __sym_list_length (list);
  if (list == 0 || list_len == 0)
    {
      if (list)
 __sym_dispose_words (list);
      return (0);
    }

  __sym_begin_unwind_frame ("select");
  __sym_add_unwind_protect (__sym_dispose_words, releaser);

  if (select_command->flags & 0x08)
    select_command->action->flags |= 0x08;

  retval = 0;

  do { UWP u; u.i = (return_catch_flag); __sym_unwind_protect_var (&(return_catch_flag), u.s, sizeof (int)); } while (0);
  __sym_unwind_protect_var ((int *)(return_catch), (char *)(return_catch), sizeof (sigjmp_buf));
  return_catch_flag++;

  while (1)
    {
      ps3_prompt = __sym_get_string_value ("PS3");
      if (ps3_prompt == 0)
 ps3_prompt = "#? ";

      if (interrupt_state) __sym_throw_to_top_level ();
      selection = __sym_select_query (list, list_len, ps3_prompt);
      if (interrupt_state) __sym_throw_to_top_level ();
      if (selection == 0)
 break;

      v = __sym_bind_variable (identifier, selection);
      if (((((v)->attributes) & (0x02))))
 {
   if (interactive_shell == 0 && posixly_correct)
     {
       last_command_exit_value = 1;
       __sym_jump_to_top_level (1);
     }
   else
     {
       __sym_run_unwind_frame ("select");
       return (1);
     }
 }

      return_val = __sym___sigsetjmp ((return_catch), 1);

      if (return_val)
        {
   retval = return_catch_value;
   break;
        }
      else
        retval = __sym_execute_command (select_command->action);

      do { if (!interactive_shell) __sym_reap_dead_jobs (); } while (0);
      if (interrupt_state) __sym_throw_to_top_level ();

      if (breaking)
 {
   breaking--;
   break;
 }
    }

  loop_level--;

  __sym_run_unwind_frame ("select");
  return (retval);
}






static char * __sym_bash_tilde_expand(char * param0, ...);
static struct word_list * __sym_expand_word_no_split(WORD_DESC * param0, int param1, ...);
static char * __sym_string_list(WORD_LIST * param0, ...);
static struct word_list * __sym_expand_word_leave_quoted(WORD_DESC * param0, int param1, ...);
static char * __sym_quote_string_for_globbing(char * param0, int param1, ...);
static int __sym_fnmatch();
static int
execute_case_command (case_command)
     CASE_COM *case_command;
{
  register WORD_LIST *list;
  WORD_LIST *wlist, *es;
  PATTERN_LIST *clauses;
  char *word, *pattern;
  int retval, match, ignore_return;


  if ((('~') ? ((char *)(__extension__ (__builtin_constant_p (('~')) && !__builtin_constant_p ((case_command->word->word)) && (('~')) == '\0' ? (char *) __sym___rawmemchr ((case_command->word->word), ('~')) : __builtin_strchr ((case_command->word->word), ('~')))) != (char *)((void *)0)) : 0))
    {
      word = __sym_bash_tilde_expand (case_command->word->word);
      __sym_free (case_command->word->word);
      case_command->word->word = word;
    }

  wlist = __sym_expand_word_no_split (case_command->word, 0);
  word = wlist ? __sym_string_list (wlist) : (char *)__sym_strcpy (__sym_xmalloc (1 + __sym_strlen ("")), (""));
  __sym_dispose_words (wlist);

  retval = 0;
  ignore_return = case_command->flags & 0x08;

  __sym_begin_unwind_frame ("case");



  for (clauses = case_command->clauses; clauses; clauses = clauses->next)
    {
      if (interrupt_state) __sym_throw_to_top_level ();
      for (list = clauses->patterns; list; list = list->next)
 {


   if ((('~') ? ((char *)(__extension__ (__builtin_constant_p (('~')) && !__builtin_constant_p ((list->word->word)) && (('~')) == '\0' ? (char *) __sym___rawmemchr ((list->word->word), ('~')) : __builtin_strchr ((list->word->word), ('~')))) != (char *)((void *)0)) : 0))
     {
       pattern = __sym_bash_tilde_expand (list->word->word);
       __sym_free (list->word->word);
       list->word->word = pattern;
     }

   es = __sym_expand_word_leave_quoted (list->word, 0);

   if (es && es->word && es->word->word && *(es->word->word))
     pattern = __sym_quote_string_for_globbing (es->word->word, 1);
   else
     {
       pattern = __sym_xmalloc (1);
       pattern[0] = '\0';
     }




   match = __sym_fnmatch (pattern, word, 0) != 1;
   __sym_free (pattern);

   __sym_dispose_words (es);

   if (match)
     {
       if (clauses->action && ignore_return)
  clauses->action->flags |= 0x08;
       retval = __sym_execute_command (clauses->action);
       goto exit_case_command;
     }

   if (interrupt_state) __sym_throw_to_top_level ();
 }
    }

exit_case_command:
  __sym_free (word);
  __sym_discard_unwind_frame ("case");
  return (retval);
}







static int __sym_execute_while_or_until();
static int
execute_while_command (while_command)
     WHILE_COM *while_command;
{
  return (__sym_execute_while_or_until (while_command, 0));
}


static int
execute_until_command (while_command)
     WHILE_COM *while_command;
{
  return (__sym_execute_while_or_until (while_command, 1));
}






static int
execute_while_or_until (while_command, type)
     WHILE_COM *while_command;
     int type;
{
  int return_value, body_status;

  body_status = 0;
  loop_level++;

  while_command->test->flags |= 0x08;
  if (while_command->flags & 0x08)
    while_command->action->flags |= 0x08;

  while (1)
    {
      return_value = __sym_execute_command (while_command->test);
      do { if (!interactive_shell) __sym_reap_dead_jobs (); } while (0);

      if (type == 0 && return_value != 0)
 break;
      if (type == 1 && return_value == 0)
 break;

      if (interrupt_state) __sym_throw_to_top_level ();
      body_status = __sym_execute_command (while_command->action);
      if (interrupt_state) __sym_throw_to_top_level ();

      if (breaking)
 {
   breaking--;
   break;
 }

      if (continuing)
 {
   continuing--;
   if (continuing)
     break;
 }
    }
  loop_level--;

  return (body_status);
}




static int
execute_if_command (if_command)
     IF_COM *if_command;
{
  int return_value;

  if_command->test->flags |= 0x08;
  return_value = __sym_execute_command (if_command->test);

  if (return_value == 0)
    {
      if (interrupt_state) __sym_throw_to_top_level ();

      if (if_command->true_case && (if_command->flags & 0x08))
 if_command->true_case->flags |= 0x08;

      return (__sym_execute_command (if_command->true_case));
    }
  else
    {
      if (interrupt_state) __sym_throw_to_top_level ();

      if (if_command->false_case && (if_command->flags & 0x08))
 if_command->false_case->flags |= 0x08;

      return (__sym_execute_command (if_command->false_case));
    }
}

static void
bind_lastarg (arg)
     char *arg;
{
  SHELL_VAR *var;

  if (arg == 0)
    arg = "";
  var = __sym_bind_variable ("_", arg);
  var->attributes &= ~0x01;
}




static int
execute_null_command (redirects, pipe_in, pipe_out, async, old_last_command_subst_pid)
     REDIRECT *redirects;
     int pipe_in, pipe_out, async, old_last_command_subst_pid;
{
  if (pipe_in != -1 || pipe_out != -1 || async)
    {


      if (__sym_make_child ((char *)((void *)0), async) == 0)
 {

   __sym_restore_original_signals ();

   __sym_do_piping (pipe_in, pipe_out);

   subshell_environment = 0x01;

   if (__sym_do_redirections (redirects, 1, 0, 0) == 0)
     __sym_exit (0);
   else
     __sym_exit (1);
 }
      else
 {
   __sym_close_pipes (pipe_in, pipe_out);

   __sym_unlink_fifo_list ();

   return (0);
 }
    }
  else
    {







      if (__sym_do_redirections (redirects, 0, 0, 0) != 0)
 return (1);
      else if (old_last_command_subst_pid != last_command_subst_pid)
 return (last_command_exit_value);
      else
 return (0);
    }
}



static struct builtin * __sym_builtin_address_internal();
static void
fix_assignment_words (words)
     WORD_LIST *words;
{
  WORD_LIST *w;
  struct builtin *b;

  if (words == 0)
    return;

  b = __sym_builtin_address_internal (words->word->word);
  if (b == 0 || (b->flags & 0x10) == 0)
    return;

  for (w = words; w; w = w->next)
    if (w->word->flags & 0x04)
      w->word->flags |= 0x10;
}




static void __sym_print_simple_command(SIMPLE_COM * param0, ...);
static void __sym_fix_assignment_words(WORD_LIST * param0, ...);
static struct word_list * __sym_expand_words(WORD_LIST * param0, ...);
static struct word_list * __sym_copy_word_list(WORD_LIST * param0, ...);
static int __sym_execute_null_command(REDIRECT * param0, int param1, int param2, int param3, int param4, ...);
static void __sym_bind_lastarg(char * param0, ...);
static void __sym_xtrace_print_word_list(WORD_LIST * param0, ...);
static void * __sym_find_special_builtin();
static struct variable * __sym_find_function(char * param0, ...);
static void * __sym_builtin_address();
static int __sym_strncmp(const char * param0, const char * param1, size_t param2, ...);
static char * __sym_strindex(char * param0, char * param1, ...);
static int __sym_start_job(int param0, int param1, ...);
static void * __sym_find_shell_builtin();
static void __sym_execute_subshell_builtin_or_function();
static int __sym_execute_builtin_or_function();
static int __sym_builtin_status();
static void __sym_merge_temporary_env();
static void __sym_execute_disk_command();
static int
execute_simple_command (simple_command, pipe_in, pipe_out, async, fds_to_close)
     SIMPLE_COM *simple_command;
     int pipe_in, pipe_out, async;
     struct fd_bitmap *fds_to_close;
{
  WORD_LIST *words, *lastword;
  char *command_line, *lastarg, *temp;
  int first_word_quoted, result, builtin_is_special;
  pid_t old_last_command_subst_pid;
  Function *builtin;
  SHELL_VAR *func;

  result = 0;
  special_builtin_failed = builtin_is_special = 0;


  if (variable_context)
    line_number = simple_command->line - function_line_number;


  command_string_index = 0;
  __sym_print_simple_command (simple_command);
  command_line = __sym_xmalloc (1 + __sym_strlen (the_printed_command));
  __sym_strcpy (command_line, the_printed_command);

  first_word_quoted =
    simple_command->words ? (simple_command->words->word->flags & 0x02): 0;

  old_last_command_subst_pid = last_command_subst_pid;



  if ((simple_command->flags & 0x20) == 0)
    {
      current_fds_to_close = fds_to_close;
      __sym_fix_assignment_words (simple_command->words);
      words = __sym_expand_words (simple_command->words);
      current_fds_to_close = (struct fd_bitmap *)((void *)0);
    }
  else
    words = __sym_copy_word_list (simple_command->words);




  if (words == 0)
    {
      result = __sym_execute_null_command (simple_command->redirects,
         pipe_in, pipe_out, async,
         old_last_command_subst_pid);
      do { if (command_line) __sym_free (command_line); } while (0);
      __sym_bind_lastarg ((char *)((void *)0));
      return (result);
    }

  lastarg = (char *)((void *)0);

  __sym_begin_unwind_frame ("simple-command");

  if (echo_command_at_execute)
    __sym_xtrace_print_word_list (words);

  builtin = (Function *)((void *)0);
  func = (SHELL_VAR *)((void *)0);
  if ((simple_command->flags & 0x10) == 0)
    {






      if (posixly_correct)
 {
   builtin = __sym_find_special_builtin (words->word->word);
   if (builtin)
     builtin_is_special = 1;
 }
      if (builtin == 0)
 func = __sym_find_function (words->word->word);
    }

  __sym_add_unwind_protect (__sym_dispose_words, words);
  if (interrupt_state) __sym_throw_to_top_level ();


  for (lastword = words; lastword->next; lastword = lastword->next)
    ;
  lastarg = lastword->word->word;



  if (words->word->word[0] == '%')
    {
      this_command_name = async ? "bg" : "fg";
      last_shell_builtin = this_shell_builtin;
      this_shell_builtin = __sym_builtin_address (this_command_name);
      result = (*this_shell_builtin) (words);
      goto return_result;
    }




  if (job_control && async == 0 &&
 !first_word_quoted &&
 !words->next &&
 words->word->word[0] &&
 !simple_command->redirects &&
 pipe_in == -1 &&
 pipe_out == -1 &&
 (temp = __sym_get_string_value ("auto_resume")))
    {
      char *word;
      register int i;
      int wl, cl, exact, substring, match, started_status;
      register PROCESS *p;

      word = words->word->word;
      exact = ((temp)[0] == ("exact")[0] && __extension__ ({ size_t __s1_len, __s2_len; (__builtin_constant_p (temp) && __builtin_constant_p ("exact") && (__s1_len = __builtin_strlen (temp), __s2_len = __builtin_strlen ("exact"), (!((size_t)(const void *)((temp) + 1) - (size_t)(const void *)(temp) == 1) || __s1_len >= 4) && (!((size_t)(const void *)(("exact") + 1) - (size_t)(const void *)("exact") == 1) || __s2_len >= 4)) ? __builtin_strcmp (temp, "exact") : (__builtin_constant_p (temp) && ((size_t)(const void *)((temp) + 1) - (size_t)(const void *)(temp) == 1) && (__s1_len = __builtin_strlen (temp), __s1_len < 4) ? (__builtin_constant_p ("exact") && ((size_t)(const void *)(("exact") + 1) - (size_t)(const void *)("exact") == 1) ? __builtin_strcmp (temp, "exact") : (__extension__ ({ const unsigned char *__s2 = (const unsigned char *) (const char *) ("exact"); int __result = (((const unsigned char *) (const char *) (temp))[0] - __s2[0]); if (__s1_len > 0 && __result == 0) { __result = (((const unsigned char *) (const char *) (temp))[1] - __s2[1]); if (__s1_len > 1 && __result == 0) { __result = (((const unsigned char *) (const char *) (temp))[2] - __s2[2]); if (__s1_len > 2 && __result == 0) __result = (((const unsigned char *) (const char *) (temp))[3] - __s2[3]); } } __result; }))) : (__builtin_constant_p ("exact") && ((size_t)(const void *)(("exact") + 1) - (size_t)(const void *)("exact") == 1) && (__s2_len = __builtin_strlen ("exact"), __s2_len < 4) ? (__builtin_constant_p (temp) && ((size_t)(const void *)((temp) + 1) - (size_t)(const void *)(temp) == 1) ? __builtin_strcmp (temp, "exact") : (- (__extension__ ({ const unsigned char *__s2 = (const unsigned char *) (const char *) (temp); int __result = (((const unsigned char *) (const char *) ("exact"))[0] - __s2[0]); if (__s2_len > 0 && __result == 0) { __result = (((const unsigned char *) (const char *) ("exact"))[1] - __s2[1]); if (__s2_len > 1 && __result == 0) { __result = (((const unsigned char *) (const char *) ("exact"))[2] - __s2[2]); if (__s2_len > 2 && __result == 0) __result = (((const unsigned char *) (const char *) ("exact"))[3] - __s2[3]); } } __result; })))) : __builtin_strcmp (temp, "exact")))); }) == 0);
      substring = ((temp)[0] == ("substring")[0] && __extension__ ({ size_t __s1_len, __s2_len; (__builtin_constant_p (temp) && __builtin_constant_p ("substring") && (__s1_len = __builtin_strlen (temp), __s2_len = __builtin_strlen ("substring"), (!((size_t)(const void *)((temp) + 1) - (size_t)(const void *)(temp) == 1) || __s1_len >= 4) && (!((size_t)(const void *)(("substring") + 1) - (size_t)(const void *)("substring") == 1) || __s2_len >= 4)) ? __builtin_strcmp (temp, "substring") : (__builtin_constant_p (temp) && ((size_t)(const void *)((temp) + 1) - (size_t)(const void *)(temp) == 1) && (__s1_len = __builtin_strlen (temp), __s1_len < 4) ? (__builtin_constant_p ("substring") && ((size_t)(const void *)(("substring") + 1) - (size_t)(const void *)("substring") == 1) ? __builtin_strcmp (temp, "substring") : (__extension__ ({ const unsigned char *__s2 = (const unsigned char *) (const char *) ("substring"); int __result = (((const unsigned char *) (const char *) (temp))[0] - __s2[0]); if (__s1_len > 0 && __result == 0) { __result = (((const unsigned char *) (const char *) (temp))[1] - __s2[1]); if (__s1_len > 1 && __result == 0) { __result = (((const unsigned char *) (const char *) (temp))[2] - __s2[2]); if (__s1_len > 2 && __result == 0) __result = (((const unsigned char *) (const char *) (temp))[3] - __s2[3]); } } __result; }))) : (__builtin_constant_p ("substring") && ((size_t)(const void *)(("substring") + 1) - (size_t)(const void *)("substring") == 1) && (__s2_len = __builtin_strlen ("substring"), __s2_len < 4) ? (__builtin_constant_p (temp) && ((size_t)(const void *)((temp) + 1) - (size_t)(const void *)(temp) == 1) ? __builtin_strcmp (temp, "substring") : (- (__extension__ ({ const unsigned char *__s2 = (const unsigned char *) (const char *) (temp); int __result = (((const unsigned char *) (const char *) ("substring"))[0] - __s2[0]); if (__s2_len > 0 && __result == 0) { __result = (((const unsigned char *) (const char *) ("substring"))[1] - __s2[1]); if (__s2_len > 1 && __result == 0) { __result = (((const unsigned char *) (const char *) ("substring"))[2] - __s2[2]); if (__s2_len > 2 && __result == 0) __result = (((const unsigned char *) (const char *) ("substring"))[3] - __s2[3]); } } __result; })))) : __builtin_strcmp (temp, "substring")))); }) == 0);
      wl = __sym_strlen (word);
      for (i = job_slots - 1; i > -1; i--)
 {
   if (jobs[i] == 0 || ((jobs[(i)]->state) != JSTOPPED))
     continue;

   p = jobs[i]->pipe;
   do
     {
       if (exact)
  {
    cl = __sym_strlen (p->command);
    match = ((p->command)[0] == (word)[0] && (__extension__ (__builtin_constant_p (cl) && ((__builtin_constant_p (p->command) && __sym_strlen (p->command) < ((size_t) (cl))) || (__builtin_constant_p (word) && __sym_strlen (word) < ((size_t) (cl)))) ? __extension__ ({ size_t __s1_len, __s2_len; (__builtin_constant_p (p->command) && __builtin_constant_p (word) && (__s1_len = __builtin_strlen (p->command), __s2_len = __builtin_strlen (word), (!((size_t)(const void *)((p->command) + 1) - (size_t)(const void *)(p->command) == 1) || __s1_len >= 4) && (!((size_t)(const void *)((word) + 1) - (size_t)(const void *)(word) == 1) || __s2_len >= 4)) ? __builtin_strcmp (p->command, word) : (__builtin_constant_p (p->command) && ((size_t)(const void *)((p->command) + 1) - (size_t)(const void *)(p->command) == 1) && (__s1_len = __builtin_strlen (p->command), __s1_len < 4) ? (__builtin_constant_p (word) && ((size_t)(const void *)((word) + 1) - (size_t)(const void *)(word) == 1) ? __builtin_strcmp (p->command, word) : (__extension__ ({ const unsigned char *__s2 = (const unsigned char *) (const char *) (word); int __result = (((const unsigned char *) (const char *) (p->command))[0] - __s2[0]); if (__s1_len > 0 && __result == 0) { __result = (((const unsigned char *) (const char *) (p->command))[1] - __s2[1]); if (__s1_len > 1 && __result == 0) { __result = (((const unsigned char *) (const char *) (p->command))[2] - __s2[2]); if (__s1_len > 2 && __result == 0) __result = (((const unsigned char *) (const char *) (p->command))[3] - __s2[3]); } } __result; }))) : (__builtin_constant_p (word) && ((size_t)(const void *)((word) + 1) - (size_t)(const void *)(word) == 1) && (__s2_len = __builtin_strlen (word), __s2_len < 4) ? (__builtin_constant_p (p->command) && ((size_t)(const void *)((p->command) + 1) - (size_t)(const void *)(p->command) == 1) ? __builtin_strcmp (p->command, word) : (- (__extension__ ({ const unsigned char *__s2 = (const unsigned char *) (const char *) (p->command); int __result = (((const unsigned char *) (const char *) (word))[0] - __s2[0]); if (__s2_len > 0 && __result == 0) { __result = (((const unsigned char *) (const char *) (word))[1] - __s2[1]); if (__s2_len > 1 && __result == 0) { __result = (((const unsigned char *) (const char *) (word))[2] - __s2[2]); if (__s2_len > 2 && __result == 0) __result = (((const unsigned char *) (const char *) (word))[3] - __s2[3]); } } __result; })))) : __builtin_strcmp (p->command, word)))); }) : __sym_strncmp (p->command, word, cl))) == 0);
  }
       else if (substring)
  match = __sym_strindex (p->command, word) != (char *)0;
       else
  match = ((p->command)[0] == (word)[0] && (__extension__ (__builtin_constant_p (wl) && ((__builtin_constant_p (p->command) && __sym_strlen (p->command) < ((size_t) (wl))) || (__builtin_constant_p (word) && __sym_strlen (word) < ((size_t) (wl)))) ? __extension__ ({ size_t __s1_len, __s2_len; (__builtin_constant_p (p->command) && __builtin_constant_p (word) && (__s1_len = __builtin_strlen (p->command), __s2_len = __builtin_strlen (word), (!((size_t)(const void *)((p->command) + 1) - (size_t)(const void *)(p->command) == 1) || __s1_len >= 4) && (!((size_t)(const void *)((word) + 1) - (size_t)(const void *)(word) == 1) || __s2_len >= 4)) ? __builtin_strcmp (p->command, word) : (__builtin_constant_p (p->command) && ((size_t)(const void *)((p->command) + 1) - (size_t)(const void *)(p->command) == 1) && (__s1_len = __builtin_strlen (p->command), __s1_len < 4) ? (__builtin_constant_p (word) && ((size_t)(const void *)((word) + 1) - (size_t)(const void *)(word) == 1) ? __builtin_strcmp (p->command, word) : (__extension__ ({ const unsigned char *__s2 = (const unsigned char *) (const char *) (word); int __result = (((const unsigned char *) (const char *) (p->command))[0] - __s2[0]); if (__s1_len > 0 && __result == 0) { __result = (((const unsigned char *) (const char *) (p->command))[1] - __s2[1]); if (__s1_len > 1 && __result == 0) { __result = (((const unsigned char *) (const char *) (p->command))[2] - __s2[2]); if (__s1_len > 2 && __result == 0) __result = (((const unsigned char *) (const char *) (p->command))[3] - __s2[3]); } } __result; }))) : (__builtin_constant_p (word) && ((size_t)(const void *)((word) + 1) - (size_t)(const void *)(word) == 1) && (__s2_len = __builtin_strlen (word), __s2_len < 4) ? (__builtin_constant_p (p->command) && ((size_t)(const void *)((p->command) + 1) - (size_t)(const void *)(p->command) == 1) ? __builtin_strcmp (p->command, word) : (- (__extension__ ({ const unsigned char *__s2 = (const unsigned char *) (const char *) (p->command); int __result = (((const unsigned char *) (const char *) (word))[0] - __s2[0]); if (__s2_len > 0 && __result == 0) { __result = (((const unsigned char *) (const char *) (word))[1] - __s2[1]); if (__s2_len > 1 && __result == 0) { __result = (((const unsigned char *) (const char *) (word))[2] - __s2[2]); if (__s2_len > 2 && __result == 0) __result = (((const unsigned char *) (const char *) (word))[3] - __s2[3]); } } __result; })))) : __builtin_strcmp (p->command, word)))); }) : __sym_strncmp (p->command, word, wl))) == 0);

       if (match == 0)
  {
    p = p->next;
    continue;
  }

       __sym_run_unwind_frame ("simple-command");
       this_command_name = "fg";
       last_shell_builtin = this_shell_builtin;
       this_shell_builtin = __sym_builtin_address ("fg");

       started_status = __sym_start_job (i, 1);
       return ((started_status < 0) ? 1 : started_status);
     }
   while (p != jobs[i]->pipe);
 }
    }



  this_command_name = words->word->word;

  if (interrupt_state) __sym_throw_to_top_level ();






  if (func == 0 && builtin == 0)
    builtin = __sym_find_shell_builtin (this_command_name);

  last_shell_builtin = this_shell_builtin;
  this_shell_builtin = builtin;

  if (builtin || func)
    {
      if ((pipe_in != -1) || (pipe_out != -1) || async)
 {
   if (__sym_make_child (command_line, async) == 0)
     {


       __sym_restore_original_signals ();

       if (async)
  __sym_setup_async_signals ();

       __sym_execute_subshell_builtin_or_function
  (words, simple_command->redirects, builtin, func,
   pipe_in, pipe_out, async, fds_to_close,
   simple_command->flags);
     }
   else
     {
       __sym_close_pipes (pipe_in, pipe_out);

       __sym_unlink_fifo_list ();

       command_line = (char *)((void *)0);
       goto return_result;
     }
 }
      else
 {
   result = __sym_execute_builtin_or_function
     (words, builtin, func, simple_command->redirects, fds_to_close,
      simple_command->flags);
   if (builtin)
     {
       if (result > 256)
  {
           result = __sym_builtin_status (result);
           if (builtin_is_special)
             special_builtin_failed = 1;
  }



       if (posixly_correct && builtin_is_special && temporary_env)
  __sym_merge_temporary_env ();
     }
   else
     {
       if (result == 258)
  result = 2;
       else if (result > 256)
         result = 1;
     }

   goto return_result;
 }
    }

  __sym_execute_disk_command (words, simple_command->redirects, command_line,
   pipe_in, pipe_out, async, fds_to_close,
   (simple_command->flags & 0x40));

 return_result:
  __sym_bind_lastarg (lastarg);
  do { if (command_line) __sym_free (command_line); } while (0);
  __sym_run_unwind_frame ("simple-command");
  return (result);
}



static int
builtin_status (result)
     int result;
{
  int r;

  switch (result)
    {
    case 258:
      r = 2;
      break;
    case 259:
    case 257:
    case 260:
    case 261:
      r = 1;
      break;
    default:
      r = 0;
      break;
    }
  return (r);
}

static char ** __sym_copy_array(char ** param0, ...);
static void __sym_merge_builtin_env();
static void __sym_dispose_builtin_env();
/*
static int
execute_builtin (builtin, words, flags, subshell)
     Function *builtin;
     WORD_LIST *words;
     int flags, subshell;
{
  int old_e_flag, result;

  old_e_flag = exit_immediately_on_error;






  if (subshell == 0 && builtin == eval_builtin && (flags & 0x08))
    {
      __sym_begin_unwind_frame ("eval_builtin");
      do { UWP u; u.i = (exit_immediately_on_error); __sym_unwind_protect_var (&(exit_immediately_on_error), u.s, sizeof (int)); } while (0);
      exit_immediately_on_error = 0;
    }




  if (builtin == source_builtin)
    {
      if (subshell == 0)
 __sym_begin_unwind_frame ("builtin_env");

      if (temporary_env)
 {
   builtin_env = __sym_copy_array (temporary_env);
   if (subshell == 0)
     __sym_add_unwind_protect (dispose_builtin_env, (char *)((void *)0));
   __sym_dispose_used_env_vars ();
 }




    }

  result = ((*builtin) (words->next));

  if (subshell == 0 && builtin == source_builtin)
    {



      if (posixly_correct && builtin_env)
 __sym_merge_builtin_env ();
      __sym_dispose_builtin_env ();
      __sym_discard_unwind_frame ("builtin_env");
    }

  if (subshell == 0 && builtin == eval_builtin && (flags & 0x08))
    {
      exit_immediately_on_error += old_e_flag;
      __sym_discard_unwind_frame ("eval_builtin");
    }

  return (result);
}
*/
static struct command * __sym_copy_command(COMMAND * param0, ...);
static void __sym_push_context();
static void __sym_remember_args();
/*
static int
execute_function (var, words, flags, fds_to_close, async, subshell)
     SHELL_VAR *var;
     WORD_LIST *words;
     int flags, subshell, async;
     struct fd_bitmap *fds_to_close;
{
  int return_val, result;
  COMMAND *tc, *fc;
  char *debug_trap;

  tc = (COMMAND *)__sym_copy_command ((COMMAND *)((var)->value));
  if (tc && (flags & 0x08))
    tc->flags |= 0x08;

  if (subshell == 0)
    {
      __sym_begin_unwind_frame ("function_calling");
      __sym_push_context ();
      __sym_add_unwind_protect (pop_context, (char *)((void *)0));
      do { UWP u; u.i = (line_number); __sym_unwind_protect_var (&(line_number), u.s, sizeof (int)); } while (0);
      do { UWP u; u.i = (return_catch_flag); __sym_unwind_protect_var (&(return_catch_flag), u.s, sizeof (int)); } while (0);
      __sym_unwind_protect_var ((int *)(return_catch), (char *)(return_catch), sizeof (sigjmp_buf));
      __sym_add_unwind_protect (dispose_command, (char *)tc);
      do { UWP u; u.i = (loop_level); __sym_unwind_protect_var (&(loop_level), u.s, sizeof (int)); } while (0);
    }

  debug_trap = (__sym_signal_is_trapped (65) && __sym_signal_is_ignored (65) == 0)
   ? trap_list[65]
   : (char *)((void *)0);
  if (debug_trap)
    {
      if (subshell == 0)
 {
   debug_trap = (char *)__sym_strcpy (__sym_xmalloc (1 + __sym_strlen (debug_trap)), (debug_trap));
   __sym_add_unwind_protect (set_debug_trap, debug_trap);
 }
      __sym_restore_default_signal (65);
    }



  if (temporary_env)
    {
      function_env = __sym_copy_array (temporary_env);
      if (subshell == 0)
 __sym_add_unwind_protect (dispose_function_env, (char *)((void *)0));
      __sym_dispose_used_env_vars ();
    }





  __sym_remember_args (words->next, 1);


  line_number = function_line_number = tc->line;

  if (subshell)
    {

      __sym_stop_pipeline (async, (COMMAND *)((void *)0));

      fc = (tc->type == cm_group) ? tc->value.Group->command : tc;

      if (fc && (flags & 0x08))
 fc->flags |= 0x08;

      variable_context++;
    }
  else
    fc = tc;

  return_catch_flag++;
  return_val = __sym___sigsetjmp ((return_catch), 1);

  if (return_val)
    result = return_catch_value;
  else
    result = __sym_execute_command_internal (fc, 0, -1, -1, fds_to_close);

  if (subshell == 0)
    __sym_run_unwind_frame ("function_calling");

  return (result);
}
*/







static void __sym_maybe_make_export_env();
static int __sym_execute_builtin(void * param0, WORD_LIST * param1, int param2, int param3, ...);
static int __sym_execute_function(SHELL_VAR * param0, WORD_LIST * param1, int param2, struct fd_bitmap * param3, int param4, int param5, ...);
/*
static void
execute_subshell_builtin_or_function (words, redirects, builtin, var,
          pipe_in, pipe_out, async, fds_to_close,
          flags)
     WORD_LIST *words;
     REDIRECT *redirects;
     Function *builtin;
     SHELL_VAR *var;
     int pipe_in, pipe_out, async;
     struct fd_bitmap *fds_to_close;
     int flags;
{
  int result, r;


  login_shell = interactive = 0;

  subshell_environment = 0x01;

  __sym_maybe_make_export_env ();







  if (builtin == jobs_builtin && !async &&
      (pipe_out != -1 || pipe_in != -1))
    __sym_kill_current_pipeline ();
  else
    __sym_without_job_control ();

  __sym_set_sigchld_handler ();


  __sym_set_sigint_handler ();

  __sym_do_piping (pipe_in, pipe_out);

  if (fds_to_close)
    __sym_close_fd_bitmap (fds_to_close);

  if (__sym_do_redirections (redirects, 1, 0, 0) != 0)
    __sym_exit (1);

  if (builtin)
    {


      result = __sym___sigsetjmp ((top_level), 1);

      if (result == 3)
 __sym_exit (last_command_exit_value);
      else if (result)
 __sym_exit (1);
      else
        {
          r = __sym_execute_builtin (builtin, words, flags, 1);
          if (r == 258)
            r = 2;
          __sym_exit (r);
        }
    }
  else
    __sym_exit (__sym_execute_function (var, words, flags, fds_to_close, async, 1));
}

static int
execute_builtin_or_function (words, builtin, var, redirects,
        fds_to_close, flags)
     WORD_LIST *words;
     Function *builtin;
     SHELL_VAR *var;
     REDIRECT *redirects;
     struct fd_bitmap *fds_to_close;
     int flags;
{
  int result;
  REDIRECT *saved_undo_list;

  if (__sym_do_redirections (redirects, 1, 1, 0) != 0)
    {
      __sym_cleanup_redirects (redirection_undo_list);
      redirection_undo_list = (REDIRECT *)((void *)0);
      __sym_dispose_exec_redirects ();
      return (259);
    }

  saved_undo_list = redirection_undo_list;


  if (builtin == exec_builtin)
    {
      __sym_dispose_redirects (saved_undo_list);
      saved_undo_list = exec_redirection_undo_list;
      exec_redirection_undo_list = (REDIRECT *)((void *)0);
    }
  else
    __sym_dispose_exec_redirects ();

  if (saved_undo_list)
    {
      __sym_begin_unwind_frame ("saved redirects");
      __sym_add_unwind_protect (cleanup_redirects, (char *)saved_undo_list);
    }

  redirection_undo_list = (REDIRECT *)((void *)0);

  if (builtin)
    result = __sym_execute_builtin (builtin, words, flags, 0);
  else
    result = __sym_execute_function (var, words, flags, fds_to_close, 0, 0);

  if (saved_undo_list)
    {
      redirection_undo_list = saved_undo_list;
      __sym_discard_unwind_frame ("saved redirects");
    }

  if (redirection_undo_list)
    {
      __sym_cleanup_redirects (redirection_undo_list);
      redirection_undo_list = (REDIRECT *)((void *)0);
    }

  return (result);
}
*/
static void * __sym_set_signal_handler();
static void __sym_set_signal_ignored(int param0, ...);
void
setup_async_signals ()
{

  if (job_control == 0)

    {
      __sym_set_signal_handler (2, ((__sighandler_t) 1));
      __sym_set_signal_ignored (2);
      __sym_set_signal_handler (3, ((__sighandler_t) 1));
      __sym_set_signal_ignored (3);
    }
}

static char * __sym_search_for_command(char * param0, ...);
static void __sym_put_command_name_into_env(char * param0, ...);
static void __sym_put_gnu_argv_flags_into_env(int param0, char * param1, ...);
static char ** __sym_word_list_to_argv(WORD_LIST * param0, int param1, int param2, int * param3, ...);
static int __sym_shell_execve(char * param0, char ** param1, char ** param2, ...);
static void
execute_disk_command (words, redirects, command_line, pipe_in, pipe_out,
        async, fds_to_close, nofork)
     WORD_LIST *words;
     REDIRECT *redirects;
     char *command_line;
     int pipe_in, pipe_out, async;
     struct fd_bitmap *fds_to_close;
     int nofork;
{
  char *pathname, *command, **args;
  int pid;

  pathname = words->word->word;


  if (restricted && (__extension__ (__builtin_constant_p ('/') && !__builtin_constant_p (pathname) && ('/') == '\0' ? (char *) __sym___rawmemchr (pathname, '/') : __builtin_strchr (pathname, '/'))))
    {
      __sym_internal_error ("%s: restricted: cannot specify `/' in command names",
      pathname);
      last_command_exit_value = 1;
      return;
    }


  command = __sym_search_for_command (pathname);

  if (command)
    {
      __sym_maybe_make_export_env ();
      __sym_put_command_name_into_env (command);
    }





  if (nofork && pipe_in == -1 && pipe_out == -1)
    pid = 0;
  else
    pid = __sym_make_child ((char *)__sym_strcpy (__sym_xmalloc (1 + __sym_strlen (command_line)), (command_line)), async);

  if (pid == 0)
    {
      int old_interactive;


      if (posixly_correct == 0)
 __sym_put_gnu_argv_flags_into_env ((int)__sym_getpid (), glob_argv_flags);



      __sym_restore_original_signals ();




      if (async)
 __sym_setup_async_signals ();

      __sym_do_piping (pipe_in, pipe_out);

      if (async)
 {
   old_interactive = interactive;
   interactive = 0;
 }

      subshell_environment = 0x08;






      if (fds_to_close)
 __sym_close_fd_bitmap (fds_to_close);

      if (redirects && (__sym_do_redirections (redirects, 1, 0, 0) != 0))
 {



   __sym_unlink_fifo_list ();

   __sym_exit (1);
 }

      if (async)
 interactive = old_interactive;

      if (command == 0)
 {
   __sym_internal_error ("%s: command not found", pathname);
   __sym_exit (127);
 }




      args = __sym_word_list_to_argv (words, 0, 0, (int *)((void *)0));
      __sym_exit (__sym_shell_execve (command, args, export_env));
    }
  else
    {

      __sym_close_pipes (pipe_in, pipe_out);

      __sym_unlink_fifo_list ();

      do { if (command) __sym_free (command); } while (0);
    }
}

static int __sym_execve(const char * param0, char * param1[], char * param2[], ...);
static int * __sym___errno_location();
static int __sym_stat(const char * param0, struct stat * param1, ...);
static void __sym_file_error(char * param0, ...);
static int __sym_open(const char * param0, int param1, ...);
static long __sym_read(int param0, void * param1, size_t param2, ...);
static int __sym_check_binary_file(unsigned char * param0, int param1, ...);
static int __sym_array_len(char ** param0, ...);
static void __sym_delete_all_aliases();
static int __sym_close_buffered_fd(int param0, ...);
static int __sym_change_flag(int param0, int param1, ...);
static void __sym_dispose_command(COMMAND * param0, ...);
static int __sym_unbind_args();
static void __sym_siglongjmp(sigjmp_buf param0[], int param1, ...);
int
shell_execve (command, args, env)
     char *command;
     char **args, **env;
{
  struct stat finfo;
  int larray, i, fd;

  ;
  __sym_execve (command, args, env);
  ;



  if ((*__sym___errno_location ()) != 8)
    {
      i = (*__sym___errno_location ());
      if ((__sym_stat (command, &finfo) == 0) && (((((finfo.st_mode)) & 0170000) == (0040000))))
 __sym_internal_error ("%s: is a directory", command);
      else
 {
   (*__sym___errno_location ()) = i;
   __sym_file_error (command);
 }
      return (126);
    }






  fd = __sym_open (command, 00);
  if (fd >= 0)
    {
      unsigned char sample[80];
      int sample_len;

      sample_len = __sym_read (fd, (char *)sample, 80);
      __sym_close (fd);

      if (sample_len == 0)
 return (0);







      if (sample_len > 0)
 {





   if (__sym_check_binary_file (sample, sample_len))
     {
       __sym_internal_error ("%s: cannot execute binary file", command);
       return (126);
     }
 }
    }

  larray = __sym_array_len (args) + 1;



  __sym_delete_all_aliases ();





  history_lines_this_session = 0;




  __sym_without_job_control ();
  __sym_set_sigchld_handler ();





  if (interactive_shell == 0 && default_buffered_input >= 0)
    {
      __sym_close_buffered_fd (default_buffered_input);
      default_buffered_input = bash_input.location.buffered_fd = -1;
    }

  __sym_set_sigint_handler ();


  args = (char **)__sym_xrealloc ((char *)args, (1 + larray) * sizeof (char *));

  for (i = larray - 1; i; i--)
    args[i] = args[i - 1];

  args[0] = shell_name;
  args[1] = command;
  args[larray] = (char *)((void *)0);

  if (args[0][0] == '-')
    args[0]++;


  if (restricted)
    __sym_change_flag ('r', '+');


  if (subshell_argv)
    {

      for (i = 1; i < subshell_argc; i++)
 __sym_free (subshell_argv[i]);
      __sym_free (subshell_argv);
    }

  __sym_dispose_command (currently_executing_command);
  currently_executing_command = (COMMAND *)((void *)0);

  subshell_argc = larray;
  subshell_argv = args;
  subshell_envp = env;

  __sym_unbind_args ();

  __sym_siglongjmp((subshell_top_level), (1));
}

static struct variable * __sym_bind_function(char * param0, COMMAND * param1, ...);
static int
execute_intern_function (name, function)
     WORD_DESC *name;
     COMMAND *function;
{
  SHELL_VAR *var;

  if (__sym_check_identifier (name, posixly_correct) == 0)
    {
      if (posixly_correct && interactive_shell == 0)
 {
   last_command_exit_value = 258;
   __sym_jump_to_top_level (3);
 }
      return (1);
    }

  var = __sym_find_function (name->word);
  if (var && ((((var)->attributes) & (0x02))))
    {
      __sym_internal_error ("%s: readonly function", var->name);
      return (1);
    }

  __sym_bind_function (name->word, function);
  return (0);
}


void
close_all_files ()
{
  register int i, fd_table_size;

  fd_table_size = __sym_getdtablesize ();
  if (fd_table_size > 256)
   fd_table_size = 256;

  for (i = 3; i < fd_table_size; i++)
    __sym_close (i);
}


static void
close_pipes (in, out)
     int in, out;
{
  if (in >= 0)
    __sym_close (in);
  if (out >= 0)
    __sym_close (out);
}



static int __sym_dup2(int param0, int param1, ...);
static void
do_piping (pipe_in, pipe_out)
     int pipe_in, pipe_out;
{
  if (pipe_in != -1)
    {
      if (__sym_dup2 (pipe_in, 0) < 0)
 __sym_sys_error ("cannot duplicate fd %d to fd 0", pipe_in);
      if (pipe_in > 0)
        __sym_close (pipe_in);
    }
  if (pipe_out != -1)
    {
      if (pipe_out != -2)
 {
   if (__sym_dup2 (pipe_out, 1) < 0)
     __sym_sys_error ("cannot duplicate fd %d to fd 1", pipe_out);
   if (pipe_out == 0 || pipe_out > 1)
     __sym_close (pipe_out);
 }
      else
 if (__sym_dup2 (1, 2) < 0)
   __sym_sys_error ("cannot duplicate fd 1 to fd 2");
    }
}

static int __sym_expandable_redirection_filename();
static char * __sym_redirection_expand(WORD_DESC * param0, ...);
static char * __sym_itos(int param0, ...);
static char * __sym_strerror(int param0, ...);
static void
redirection_error (temp, error)
     REDIRECT *temp;
     int error;
{
  char *filename;

  if (__sym_expandable_redirection_filename (temp))
    {
      if (posixly_correct && !interactive_shell)
        disallow_filename_globbing++;
      filename = __sym_redirection_expand (temp->redirectee.filename);
      if (posixly_correct && !interactive_shell)
        disallow_filename_globbing--;
      if (filename == 0)
 filename = (char *)__sym_strcpy (__sym_xmalloc (1 + __sym_strlen (temp->redirectee.filename->word)), (temp->redirectee.filename->word));
      if (filename == 0)
 {
   filename = __sym_xmalloc (1);
   filename[0] = '\0';
 }
    }
  else
    filename = __sym_itos (temp->redirectee.dest);

  switch (error)
    {
    case -1:
      __sym_internal_error ("%s: ambiguous redirect", filename);
      break;

    case -2:
      __sym_internal_error ("%s: cannot overwrite existing file", filename);
      break;


    case -3:
      __sym_internal_error ("%s: restricted: cannot redirect output", filename);
      break;


    default:
      __sym_internal_error ("%s: %s", filename, __sym_strerror (error));
      break;
    }

  do { if (filename) __sym_free (filename); } while (0);
}







static int __sym_do_redirection_internal();
static void __sym_redirection_error(REDIRECT * param0, int param1, ...);
static int
do_redirections (list, for_real, internal, set_clexec)
     REDIRECT *list;
     int for_real, internal, set_clexec;
{
  int error;
  REDIRECT *temp;

  if (internal)
    {
      if (redirection_undo_list)
 {
   __sym_dispose_redirects (redirection_undo_list);
   redirection_undo_list = (REDIRECT *)((void *)0);
 }
      if (exec_redirection_undo_list)
 __sym_dispose_exec_redirects ();
    }

  for (temp = list; temp; temp = temp->next)
    {
      error = __sym_do_redirection_internal (temp, for_real, internal, set_clexec);
      if (error)
 {
   __sym_redirection_error (temp, error);
   return (error);
 }
    }
  return (0);
}



static int
expandable_redirection_filename (redirect)
     REDIRECT *redirect;
{
  switch (redirect->instruction)
    {
    case r_output_direction:
    case r_appending_to:
    case r_input_direction:
    case r_inputa_direction:
    case r_err_and_out:
    case r_input_output:
    case r_output_force:
    case r_duplicating_input_word:
    case r_duplicating_output_word:
      return 1;

    default:
      return 0;
    }
}



static struct word_list * __sym_make_word_list(WORD_DESC * param0, WORD_LIST * param1, ...);
static struct word_desc * __sym_copy_word(WORD_DESC * param0, ...);
char *
redirection_expand (word)
     WORD_DESC *word;
{
  char *result;
  WORD_LIST *tlist1, *tlist2;

  tlist1 = __sym_make_word_list (__sym_copy_word (word), (WORD_LIST *)((void *)0));
  tlist2 = __sym_expand_words_no_vars (tlist1);
  __sym_dispose_words (tlist1);

  if (!tlist2 || tlist2->next)
    {


      if (tlist2)
 __sym_dispose_words (tlist2);
      return ((char *)((void *)0));
    }
  result = __sym_string_list (tlist2);
  __sym_dispose_words (tlist2);
  return (result);
}

static long __sym_write(int param0, const void * param1, size_t param2, ...);
static struct word_list * __sym_expand_string(char * param0, int param1, ...);
static int __sym_dup(int param0, ...);
static struct _IO_FILE * __sym_fdopen(int param0, const char * param1, ...);
static unsigned long __sym_fwrite(const void * param0, size_t param1, size_t param2, FILE * param3, ...);
static int __sym_ferror(FILE * param0, ...);
static int __sym_fclose(FILE * param0, ...);
static int
write_here_document (fd, redirectee)
     int fd;
     WORD_DESC *redirectee;
{
  char *document;
  int document_len, fd2;
  FILE *fp;
  register WORD_LIST *t, *tlist;





  if (redirectee->flags & 0x02)
    {
      document = redirectee->word;
      document_len = __sym_strlen (document);

      if (__sym_write (fd, document, document_len) < document_len)
 {
   if ((*__sym___errno_location ()) == 0)
     (*__sym___errno_location ()) = 28;
   return ((*__sym___errno_location ()));
 }
      else
        return 0;
    }

  tlist = __sym_expand_string (redirectee->word, 0x2);
  if (tlist)
    {





      if ((fd2 = __sym_dup (fd)) < 0 || (fp = __sym_fdopen (fd2, "w")) == ((void *)0))
 {
   if (fd2 >= 0)
     __sym_close (fd2);
   return ((*__sym___errno_location ()));
 }
      (*__sym___errno_location ()) = 0;
      for (t = tlist; t; t = t->next)
 {


   document = t->word->word;
   document_len = __sym_strlen (document);
   if (t != tlist)
     __sym__IO_putc (' ', fp);
   __sym_fwrite (document, document_len, 1, fp);
   if (__sym_ferror (fp))
     {
       if ((*__sym___errno_location ()) == 0)
  (*__sym___errno_location ()) = 28;
       fd2 = (*__sym___errno_location ());
       __sym_fclose(fp);
       __sym_dispose_words (tlist);
       return (fd2);
     }
 }
      __sym_fclose (fp);
      __sym_dispose_words (tlist);
    }
  return 0;
}






static int __sym_all_digits(char * param0, ...);
static long __sym_atol(const char * param0, ...);
static struct redirect * __sym_copy_redirect(REDIRECT * param0, ...);
static int __sym_add_undo_redirect();
static void __sym_add_undo_close_redirect();
static int __sym_check_bash_input(int param0, ...);
static int __sym_duplicate_buffered_stream(int param0, int param1, ...);
static int __sym_sprintf(char * param0, const char * param1, ...);
static int __sym_write_here_document(int param0, WORD_DESC * param1, ...);
static int __sym_unlink(const char * param0, ...);
static int
do_redirection_internal (redirect, for_real, remembering, set_clexec)
     REDIRECT *redirect;
     int for_real, remembering, set_clexec;
{
  WORD_DESC *redirectee;
  int redir_fd, fd, redirector, r;
  char *redirectee_word;
  enum r_instruction ri;
  REDIRECT *new_redirect;
  struct stat finfo;

  redirectee = redirect->redirectee.filename;
  redir_fd = redirect->redirectee.dest;
  redirector = redirect->redirector;
  ri = redirect->instruction;

  if (ri == r_duplicating_input_word || ri == r_duplicating_output_word)
    {


      redirectee_word = __sym_redirection_expand (redirectee);

      if (redirectee_word == 0)
 return (-1);
      else if (redirectee_word[0] == '-' && redirectee_word[1] == '\0')
 {
   rd.dest = 0L;
   new_redirect = __sym_make_redirection (redirector, r_close_this, rd);
 }
      else if (__sym_all_digits (redirectee_word))
 {
   if (ri == r_duplicating_input_word)
     {
       rd.dest = __sym_atol (redirectee_word);
       new_redirect = __sym_make_redirection (redirector, r_duplicating_input, rd);
     }
   else
     {
       rd.dest = __sym_atol (redirectee_word);
       new_redirect = __sym_make_redirection (redirector, r_duplicating_output, rd);
     }
 }
      else if (ri == r_duplicating_output_word && redirector == 1)
 {
   if (posixly_correct == 0)
     {
       rd.filename = __sym_make_bare_word (redirectee_word);
       new_redirect = __sym_make_redirection (1, r_err_and_out, rd);
     }
   else
     new_redirect = __sym_copy_redirect (redirect);
 }
      else
 {
   __sym_free (redirectee_word);
   return (-1);
 }

      __sym_free (redirectee_word);



      if (new_redirect->instruction == r_err_and_out)
 {
   char *alloca_hack;



   redirectee = (WORD_DESC *)__builtin_alloca (sizeof (WORD_DESC));
   __sym_xbcopy ((char *)new_redirect->redirectee.filename,
   (char *)redirectee, sizeof (WORD_DESC));

   alloca_hack = (char *)
     __builtin_alloca (1 + __sym_strlen (new_redirect->redirectee.filename->word));
   redirectee->word = alloca_hack;
   __sym_strcpy (redirectee->word, new_redirect->redirectee.filename->word);
 }
      else

 redirectee = new_redirect->redirectee.filename;

      redir_fd = new_redirect->redirectee.dest;
      redirector = new_redirect->redirector;
      ri = new_redirect->instruction;


      redirect->flags = new_redirect->flags;
      __sym_dispose_redirects (new_redirect);
    }

  switch (ri)
    {
    case r_output_direction:
    case r_appending_to:
    case r_input_direction:
    case r_inputa_direction:
    case r_err_and_out:
    case r_input_output:
    case r_output_force:
      if (posixly_correct && !interactive_shell)
 disallow_filename_globbing++;
      redirectee_word = __sym_redirection_expand (redirectee);
      if (posixly_correct && !interactive_shell)
 disallow_filename_globbing--;

      if (redirectee_word == 0)
 return (-1);


      if (restricted && ((ri == r_output_direction || ri == r_input_output || ri == r_err_and_out || ri == r_appending_to || ri == r_output_force)))
 {
   __sym_free (redirectee_word);
   return (-3);
 }




      if (noclobber && (ri == r_output_direction || ri == r_input_output || ri == r_err_and_out))
 {
   r = __sym_stat (redirectee_word, &finfo);

   if (r == 0 && (((((finfo.st_mode)) & 0170000) == (0100000))))
     {
       __sym_free (redirectee_word);
       return (-2);
     }



   if (r != 0)
     redirect->flags |= 0200;

   fd = __sym_open (redirectee_word, redirect->flags, 0666);

   if (fd < 0 && (*__sym___errno_location ()) == 17)
     {
       __sym_free (redirectee_word);
       return (-2);
     }
 }
      else
 {
   fd = __sym_open (redirectee_word, redirect->flags, 0666);




 }
      __sym_free (redirectee_word);

      if (fd < 0)
 return ((*__sym___errno_location ()));

      if (for_real)
 {
   if (remembering)

     if ((fd != redirector) && (__sym_fcntl (redirector, 1, 0) != -1))
       __sym_add_undo_redirect (redirector);
     else
       __sym_add_undo_close_redirect (redirector);


   __sym_check_bash_input (redirector);


   if ((fd != redirector) && (__sym_dup2 (fd, redirector) < 0))
     return ((*__sym___errno_location ()));





   if (ri == r_input_direction || ri == r_input_output)
     __sym_duplicate_buffered_stream (fd, redirector);

   if (set_clexec && (redirector > 2))
     (__sym_fcntl ((redirector), 2, 1));
 }

      if (fd != redirector)
 {

   if ((ri == r_input_direction || ri == r_inputa_direction || ri == r_input_output))
     __sym_close_buffered_fd (fd);
   else

     __sym_close (fd);
 }



      if (ri == r_err_and_out)
 {
   if (for_real)
     {
       if (remembering)
  __sym_add_undo_redirect (2);
       if (__sym_dup2 (1, 2) < 0)
  return ((*__sym___errno_location ()));
     }
 }
      break;

    case r_reading_until:
    case r_deblank_reading_until:


      if (redirectee)
 {
   char filename[24];


   __sym_sprintf (filename, "/tmp/t%d-sh", (int)__sym_getpid ());

   fd = __sym_open (filename, 01000 | 01 | 0100, 0666);
   if (fd < 0)
     return ((*__sym___errno_location ()));

   (*__sym___errno_location ()) = r = 0;
   if (redirectee->word)
     r = __sym_write_here_document (fd, redirectee);

   __sym_close (fd);
   if (r)
     return (r);


   fd = __sym_open (filename, 00, 0666);

   if (fd < 0)
     return ((*__sym___errno_location ()));

   if (__sym_unlink (filename) < 0)
     {
       r = (*__sym___errno_location ());
       __sym_close (fd);
       return (r);
     }

   if (for_real)
     {
       if (remembering)

  if ((fd != redirector) && (__sym_fcntl (redirector, 1, 0) != -1))
    __sym_add_undo_redirect (redirector);
  else
    __sym_add_undo_close_redirect (redirector);


       __sym_check_bash_input (redirector);

       if (fd != redirector && __sym_dup2 (fd, redirector) < 0)
  {
    r = (*__sym___errno_location ());
    __sym_close (fd);
    return (r);
  }


       __sym_duplicate_buffered_stream (fd, redirector);


       if (set_clexec && (redirector > 2))
  (__sym_fcntl ((redirector), 2, 1));
     }


   __sym_close_buffered_fd (fd);



 }
      break;

    case r_duplicating_input:
    case r_duplicating_output:
      if (for_real && (redir_fd != redirector))
 {
   if (remembering)

     if (__sym_fcntl (redirector, 1, 0) != -1)
       __sym_add_undo_redirect (redirector);
     else
       __sym_add_undo_close_redirect (redirector);


   __sym_check_bash_input (redirector);


   if (__sym_dup2 (redir_fd, redirector) < 0)
     return ((*__sym___errno_location ()));


   if (ri == r_duplicating_input)
     __sym_duplicate_buffered_stream (redir_fd, redirector);

   if (((__sym_fcntl (redir_fd, 1, 0) == 1) || set_clexec) &&
        (redirector > 2))
     (__sym_fcntl ((redirector), 2, 1));
 }
      break;

    case r_close_this:
      if (for_real)
 {
   if (remembering && (__sym_fcntl (redirector, 1, 0) != -1))
     __sym_add_undo_redirect (redirector);


   __sym_check_bash_input (redirector);
   __sym_close_buffered_fd (redirector);



 }
      break;
    }
  return (0);
}

static void __sym_add_exec_redirect();
static int
add_undo_redirect (fd)
     int fd;
{
  int new_fd, clexec_flag;
  REDIRECT *new_redirect, *closer, *dummy_redirect;

  new_fd = __sym_fcntl (fd, 0, 10);

  if (new_fd < 0)
    {
      __sym_sys_error ("redirection error");
      return (-1);
    }

  clexec_flag = __sym_fcntl (fd, 1, 0);

  rd.dest = 0L;
  closer = __sym_make_redirection (new_fd, r_close_this, rd);
  dummy_redirect = __sym_copy_redirects (closer);

  rd.dest = (long)new_fd;
  new_redirect = __sym_make_redirection (fd, r_duplicating_output, rd);
  new_redirect->next = closer;

  closer->next = redirection_undo_list;
  redirection_undo_list = new_redirect;



  __sym_add_exec_redirect (dummy_redirect);

  if (clexec_flag || fd < 3)
    (__sym_fcntl ((new_fd), 2, 1));

  return (0);
}



static void
add_undo_close_redirect (fd)
     int fd;
{
  REDIRECT *closer;

  rd.dest = 0L;
  closer = __sym_make_redirection (fd, r_close_this, rd);
  closer->next = redirection_undo_list;
  redirection_undo_list = closer;
}

static void
add_exec_redirect (dummy_redirect)
     REDIRECT *dummy_redirect;
{
  dummy_redirect->next = exec_redirection_undo_list;
  exec_redirection_undo_list = dummy_redirect;
}

static int __sym_group_member();
int
file_status (name)
     char *name;
{
  struct stat finfo;
  static int user_id = -1;


  if (__sym_stat (name, &finfo) < 0)
    return (0);



  if (((((finfo.st_mode)) & 0170000) == (0040000)))
    return (0x1|0x10);

  if (user_id == -1)
    user_id = current_user.euid;



  if (user_id == 0)
    {
      int bits;

      bits = ((((finfo.st_mode) & 0000700) >> 6) |
       (((finfo.st_mode) & 0000070) >> 3) |
       (((finfo.st_mode) & 0000007) >> 0));

      if (((bits) & 1))
 return (0x1 | 0x2);
    }


  if (user_id == finfo.st_uid && (((((finfo.st_mode) & 0000700) >> 6)) & 1))
    return (0x1 | 0x2);


  if (__sym_group_member (finfo.st_gid) && (((((finfo.st_mode) & 0000070) >> 3)) & 1))
    return (0x1 | 0x2);



  if ((((((finfo.st_mode) & 0000007) >> 0)) & 1))
    return (0x1 | 0x2);

  return (0x1);

}





static int __sym_file_status(char * param0, ...);
int
executable_file (file)
     char *file;
{
  int s;

  s = __sym_file_status (file);
  return ((s & 0x2) && ((s & 0x10) == 0));
}

int
is_directory (file)
     char *file;
{
  return (__sym_file_status (file) & 0x10);
}





int dot_found_in_search = 0;






static char * __sym_find_user_command_internal();
char *
find_user_command (name)
     char *name;
{
  return (__sym_find_user_command_internal (name, 0x4|0x20));
}





char *
find_path_file (name)
     char *name;
{
  return (__sym_find_user_command_internal (name, 0x1));
}

static struct variable * __sym_find_variable_internal(char * param0, int param1, ...);
static char * __sym_find_user_command_in_path();
static char *
_find_user_command_internal (name, flags)
     char *name;
     int flags;
{
  char *path_list;
  SHELL_VAR *var;



  if (var = __sym_find_variable_internal ("PATH", 1))
    path_list = ((var)->value);
  else
    path_list = (char *)((void *)0);

  if (path_list == 0 || *path_list == '\0')
    return ((char *)__sym_strcpy (__sym_xmalloc (1 + __sym_strlen (name)), (name)));

  return (__sym_find_user_command_in_path (name, path_list, flags));
}

static char * __sym__find_user_command_internal(char * param0, int param1, ...);
static char *
find_user_command_internal (name, flags)
     char *name;
     int flags;
{

  return (__sym__find_user_command_internal (name, flags));

}





static char * __sym_extract_colon_unit(char * param0, int * param1, ...);
static char *
get_next_path_element (path_list, path_index_pointer)
     char *path_list;
     int *path_index_pointer;
{
  char *path;

  path = __sym_extract_colon_unit (path_list, path_index_pointer);

  if (!path)
    return (path);

  if (!*path)
    {
      __sym_free (path);
      path = (char *)__sym_strcpy (__sym_xmalloc (1 + __sym_strlen (".")), ("."));
    }

  return (path);
}

static struct variable * __sym_find_tempenv_variable(char * param0, ...);
static int __sym_absolute_program(char * param0, ...);
static char * __sym_find_hashed_filename();
static void __sym_remove_hashed_filename();
static char * __sym_find_user_command(char * param0, ...);
static void __sym_remember_filename();
char *
search_for_command (pathname)
     char *pathname;
{
  char *hashed_file, *command;
  int temp_path, st;
  SHELL_VAR *path;

  hashed_file = command = (char *)((void *)0);



  path = __sym_find_tempenv_variable ("PATH");
  temp_path = path != 0;




  if (path == 0 && __sym_absolute_program (pathname) == 0)
    hashed_file = __sym_find_hashed_filename (pathname);





  if (hashed_file && (posixly_correct || check_hashed_filenames))
    {
      st = __sym_file_status (hashed_file);
      if ((st ^ (0x1 | 0x2)) != 0)
 {
   __sym_remove_hashed_filename (pathname);
   hashed_file = (char *)((void *)0);
 }
    }

  if (hashed_file)
    command = (char *)__sym_strcpy (__sym_xmalloc (1 + __sym_strlen (hashed_file)), (hashed_file));
  else if (__sym_absolute_program (pathname))


    command = (char *)__sym_strcpy (__sym_xmalloc (1 + __sym_strlen (pathname)), (pathname));
  else
    {


      if (temp_path)
 command = __sym_find_user_command_in_path (pathname, ((path)->value),
          0x4|0x20);
      else
 command = __sym_find_user_command (pathname);
      if (command && hashing_enabled && temp_path == 0)
 __sym_remember_filename (pathname, command, dot_found_in_search, 1);
    }
  return (command);
}

static char * __sym_find_absolute_program();
static char * __sym_get_next_path_element(char * param0, int * param1, ...);
static char * __sym_find_in_path_element();
char *
user_command_matches (name, flags, state)
     char *name;
     int flags, state;
{
  register int i;
  int path_index, name_len;
  char *path_list, *path_element, *match;
  struct stat dotinfo;
  static char **match_list = ((void *)0);
  static int match_list_size = 0;
  static int match_index = 0;

  if (state == 0)
    {

      if (match_list == 0)
 {
   match_list_size = 5;
   match_list = (char **)__sym_xmalloc (match_list_size * sizeof(char *));
 }


      for (i = 0; i < match_list_size; i++)
 match_list[i] = 0;


      match_index = 0;

      if (__sym_absolute_program (name))
 {
   match_list[0] = __sym_find_absolute_program (name, flags);
   match_list[1] = (char *)((void *)0);
   path_list = (char *)((void *)0);
 }
      else
 {
   name_len = __sym_strlen (name);
   file_to_lose_on = (char *)((void *)0);
   dot_found_in_search = 0;
         __sym_stat (".", &dotinfo);
   path_list = __sym_get_string_value ("PATH");
         path_index = 0;
 }

      while (path_list && path_list[path_index])
 {
   path_element = __sym_get_next_path_element (path_list, &path_index);

   if (path_element == 0)
     break;

   match = __sym_find_in_path_element (name, path_element, flags, name_len, &dotinfo);

   __sym_free (path_element);

   if (match == 0)
     continue;

   if (match_index + 1 == match_list_size)
     {
       match_list_size += 10;
       match_list = (char **)__sym_xrealloc (match_list, (match_list_size + 1) * sizeof (char *));
     }

   match_list[match_index++] = match;
   match_list[match_index] = (char *)((void *)0);
   do { if (file_to_lose_on) __sym_free (file_to_lose_on); } while (0);
   file_to_lose_on = (char *)((void *)0);
 }


      match_index = 0;
    }

  match = match_list[match_index];

  if (match)
    match_index++;

  return (match);
}



static char *
make_full_pathname (path, name, name_len)
     char *path, *name;
     int name_len;
{
  char *full_path;
  int path_len;

  path_len = __sym_strlen (path);
  full_path = __sym_xmalloc (2 + path_len + name_len);
  __sym_strcpy (full_path, path);
  full_path[path_len] = '/';
  __sym_strcpy (full_path + path_len + 1, name);
  return (full_path);
}

static char *
find_absolute_program (name, flags)
     char *name;
     int flags;
{
  int st;

  st = __sym_file_status (name);


  if ((st & 0x1) == 0)
    return ((char *)((void *)0));




  if ((flags & 0x1) || ((flags & 0x8) && (st & 0x2)))
    return ((char *)__sym_strcpy (__sym_xmalloc (1 + __sym_strlen (name)), (name)));

  return ((char *)((void *)0));
}

static int __sym_same_file();
static char * __sym_make_full_pathname(char * param0, char * param1, int param2, ...);
static char *
find_in_path_element (name, path, flags, name_len, dotinfop)
     char *name, *path;
     int flags, name_len;
     struct stat *dotinfop;
{
  int status;
  char *full_path, *xpath;

  xpath = (*path == '~') ? __sym_bash_tilde_expand (path) : path;



  if (dot_found_in_search == 0 && *xpath == '.')
    dot_found_in_search = __sym_same_file (".", xpath, dotinfop, (struct stat *)((void *)0));

  full_path = __sym_make_full_pathname (xpath, name, name_len);

  status = __sym_file_status (full_path);

  if (xpath != path)
    __sym_free (xpath);

  if ((status & 0x1) == 0)
    {
      __sym_free (full_path);
      return ((char *)((void *)0));
    }


  if (flags & 0x1)
    return (full_path);



  if ((status & 0x2) &&
      (((flags & 0x20) == 0) || ((status & 0x10) == 0)))
    {
      do { if (file_to_lose_on) __sym_free (file_to_lose_on); } while (0);
      file_to_lose_on = (char *)((void *)0);
      return (full_path);
    }




  if ((flags & 0x4) && file_to_lose_on == 0)
    file_to_lose_on = (char *)__sym_strcpy (__sym_xmalloc (1 + __sym_strlen (full_path)), (full_path));



  if ((flags & 0x8) || (flags & 0x4) ||
      ((flags & 0x20) && (status & 0x10)))
    {
      __sym_free (full_path);
      return ((char *)((void *)0));
    }
  else
    return (full_path);
}

static int __sym_is_directory(char * param0, ...);
static char *
find_user_command_in_path (name, path_list, flags)
     char *name;
     char *path_list;
     int flags;
{
  char *full_path, *path;
  int path_index, name_len;
  struct stat dotinfo;



  dot_found_in_search = 0;

  if (__sym_absolute_program (name))
    {
      full_path = __sym_find_absolute_program (name, flags);
      return (full_path);
    }

  if (path_list == 0 || *path_list == '\0')
    return ((char *)__sym_strcpy (__sym_xmalloc (1 + __sym_strlen (name)), (name)));

  file_to_lose_on = (char *)((void *)0);
  name_len = __sym_strlen (name);
  __sym_stat (".", &dotinfo);
  path_index = 0;

  while (path_list[path_index])
    {

      if (interrupt_state) __sym_throw_to_top_level ();

      path = __sym_get_next_path_element (path_list, &path_index);
      if (path == 0)
 break;



      full_path = __sym_find_in_path_element (name, path, flags, name_len, &dotinfo);
      __sym_free (path);



      if (full_path && __sym_is_directory (full_path))
 {
   __sym_free (full_path);
   continue;
 }

      if (full_path)
 {
   do { if (file_to_lose_on) __sym_free (file_to_lose_on); } while (0);
   return (full_path);
 }
    }





  return (file_to_lose_on);
}

// Test driver for function time_command returning int
int time_command_driver()
{
struct command * param1;
int param2;
int param3;
int param4;
struct fd_bitmap * param5;
param1 = malloc(1*sizeof(struct command));
__CrestInt(&param1[0].type);
__CrestInt(&param1[0].flags);
__CrestInt(&param1[0].line);
param1[0].redirects = malloc(1*sizeof(struct redirect));
param1[0].redirects[0].next = malloc(1*sizeof(struct redirect));
// Pointer Type: struct redirect * of param1[0].redirects[0].next[0].next is set as NULL
param1[0].redirects[0].next[0].next = 0;
__CrestInt(&param1[0].redirects[0].next[0].redirector);
__CrestInt(&param1[0].redirects[0].next[0].flags);
__CrestInt(&param1[0].redirects[0].next[0].instruction);
// Type: REDIRECTEE of param1[0].redirects[0].next[0].redirectee is not supported
// Pointer Type: char * of param1[0].redirects[0].next[0].here_doc_eof is set as NULL
param1[0].redirects[0].next[0].here_doc_eof = 0;
__CrestInt(&param1[0].redirects[0].redirector);
__CrestInt(&param1[0].redirects[0].flags);
__CrestInt(&param1[0].redirects[0].instruction);
// Type: REDIRECTEE of param1[0].redirects[0].redirectee is not supported
param1[0].redirects[0].here_doc_eof = malloc(3*sizeof(char));
__CrestChar(&param1[0].redirects[0].here_doc_eof[0]);
__CrestChar(&param1[0].redirects[0].here_doc_eof[1]);
__CrestChar(&param1[0].redirects[0].here_doc_eof[2]);
// Type: union command::<anonymous at command.h:131:3> of param1[0].value is not supported
__CrestInt(&param2);
__CrestInt(&param3);
__CrestInt(&param4);
param5 = malloc(1*sizeof(struct fd_bitmap));
__CrestLong(&param5[0].size);
param5[0].bitmap = malloc(3*sizeof(char));
__CrestChar(&param5[0].bitmap[0]);
__CrestChar(&param5[0].bitmap[1]);
__CrestChar(&param5[0].bitmap[2]);
__CrestInt(&COLS);
__CrestInt(&LINES);
__CrestInt(&already_making_children);
__CrestInt(&bash_input.type);
bash_input.name = malloc(3*sizeof(char));
__CrestChar(&bash_input.name[0]);
__CrestChar(&bash_input.name[1]);
__CrestChar(&bash_input.name[2]);
// Type: INPUT_STREAM of bash_input.location is not supported
// Function pointer type: int (*)() of bash_input.getter is not supported
bash_input.getter = 0;
// Function pointer type: int (*)() of bash_input.ungetter is not supported
bash_input.ungetter = 0;
__CrestInt(&breaking);
builtin_env = malloc(1*sizeof(char *));
builtin_env[0] = malloc(3*sizeof(char));
__CrestChar(&builtin_env[0][0]);
__CrestChar(&builtin_env[0][1]);
__CrestChar(&builtin_env[0][2]);
__CrestInt(&check_hashed_filenames);
__CrestInt(&command_string_index);
__CrestInt(&continuing);
current_fds_to_close = malloc(1*sizeof(struct fd_bitmap));
__CrestLong(&current_fds_to_close[0].size);
current_fds_to_close[0].bitmap = malloc(3*sizeof(char));
__CrestChar(&current_fds_to_close[0].bitmap[0]);
__CrestChar(&current_fds_to_close[0].bitmap[1]);
__CrestChar(&current_fds_to_close[0].bitmap[2]);
__CrestInt(&current_user.uid);
__CrestInt(&current_user.euid);
__CrestInt(&current_user.gid);
__CrestInt(&current_user.egid);
current_user.user_name = malloc(3*sizeof(char));
__CrestChar(&current_user.user_name[0]);
__CrestChar(&current_user.user_name[1]);
__CrestChar(&current_user.user_name[2]);
current_user.shell = malloc(3*sizeof(char));
__CrestChar(&current_user.shell[0]);
__CrestChar(&current_user.shell[1]);
__CrestChar(&current_user.shell[2]);
current_user.home_dir = malloc(3*sizeof(char));
__CrestChar(&current_user.home_dir[0]);
__CrestChar(&current_user.home_dir[1]);
__CrestChar(&current_user.home_dir[2]);
currently_executing_command = malloc(1*sizeof(struct command));
__CrestInt(&currently_executing_command[0].type);
__CrestInt(&currently_executing_command[0].flags);
__CrestInt(&currently_executing_command[0].line);
currently_executing_command[0].redirects = malloc(1*sizeof(struct redirect));
currently_executing_command[0].redirects[0].next = malloc(1*sizeof(struct redirect));
// Pointer Type: struct redirect * of currently_executing_command[0].redirects[0].next[0].next is set as NULL
currently_executing_command[0].redirects[0].next[0].next = 0;
__CrestInt(&currently_executing_command[0].redirects[0].next[0].redirector);
__CrestInt(&currently_executing_command[0].redirects[0].next[0].flags);
__CrestInt(&currently_executing_command[0].redirects[0].next[0].instruction);
// Type: REDIRECTEE of currently_executing_command[0].redirects[0].next[0].redirectee is not supported
// Pointer Type: char * of currently_executing_command[0].redirects[0].next[0].here_doc_eof is set as NULL
currently_executing_command[0].redirects[0].next[0].here_doc_eof = 0;
__CrestInt(&currently_executing_command[0].redirects[0].redirector);
__CrestInt(&currently_executing_command[0].redirects[0].flags);
__CrestInt(&currently_executing_command[0].redirects[0].instruction);
// Type: REDIRECTEE of currently_executing_command[0].redirects[0].redirectee is not supported
currently_executing_command[0].redirects[0].here_doc_eof = malloc(3*sizeof(char));
__CrestChar(&currently_executing_command[0].redirects[0].here_doc_eof[0]);
__CrestChar(&currently_executing_command[0].redirects[0].here_doc_eof[1]);
__CrestChar(&currently_executing_command[0].redirects[0].here_doc_eof[2]);
// Type: union command::<anonymous at command.h:131:3> of currently_executing_command[0].value is not supported
__CrestInt(&default_buffered_input);
__CrestInt(&disallow_filename_globbing);
__CrestInt(&dot_found_in_search);
__CrestInt(&echo_command_at_execute);
exec_redirection_undo_list = malloc(1*sizeof(struct redirect));
exec_redirection_undo_list[0].next = malloc(1*sizeof(struct redirect));
exec_redirection_undo_list[0].next[0].next = malloc(1*sizeof(struct redirect));
// Pointer Type: struct redirect * of exec_redirection_undo_list[0].next[0].next[0].next is set as NULL
exec_redirection_undo_list[0].next[0].next[0].next = 0;
__CrestInt(&exec_redirection_undo_list[0].next[0].next[0].redirector);
__CrestInt(&exec_redirection_undo_list[0].next[0].next[0].flags);
__CrestInt(&exec_redirection_undo_list[0].next[0].next[0].instruction);
// Type: REDIRECTEE of exec_redirection_undo_list[0].next[0].next[0].redirectee is not supported
// Pointer Type: char * of exec_redirection_undo_list[0].next[0].next[0].here_doc_eof is set as NULL
exec_redirection_undo_list[0].next[0].next[0].here_doc_eof = 0;
__CrestInt(&exec_redirection_undo_list[0].next[0].redirector);
__CrestInt(&exec_redirection_undo_list[0].next[0].flags);
__CrestInt(&exec_redirection_undo_list[0].next[0].instruction);
// Type: REDIRECTEE of exec_redirection_undo_list[0].next[0].redirectee is not supported
exec_redirection_undo_list[0].next[0].here_doc_eof = malloc(3*sizeof(char));
__CrestChar(&exec_redirection_undo_list[0].next[0].here_doc_eof[0]);
__CrestChar(&exec_redirection_undo_list[0].next[0].here_doc_eof[1]);
__CrestChar(&exec_redirection_undo_list[0].next[0].here_doc_eof[2]);
__CrestInt(&exec_redirection_undo_list[0].redirector);
__CrestInt(&exec_redirection_undo_list[0].flags);
__CrestInt(&exec_redirection_undo_list[0].instruction);
// Type: REDIRECTEE of exec_redirection_undo_list[0].redirectee is not supported
exec_redirection_undo_list[0].here_doc_eof = malloc(3*sizeof(char));
__CrestChar(&exec_redirection_undo_list[0].here_doc_eof[0]);
__CrestChar(&exec_redirection_undo_list[0].here_doc_eof[1]);
__CrestChar(&exec_redirection_undo_list[0].here_doc_eof[2]);
__CrestInt(&executing);
__CrestInt(&exit_immediately_on_error);
__CrestInt(&expand_aliases);
export_env = malloc(1*sizeof(char *));
export_env[0] = malloc(3*sizeof(char));
__CrestChar(&export_env[0][0]);
__CrestChar(&export_env[0][1]);
__CrestChar(&export_env[0][2]);
file_to_lose_on = malloc(3*sizeof(char));
__CrestChar(&file_to_lose_on[0]);
__CrestChar(&file_to_lose_on[1]);
__CrestChar(&file_to_lose_on[2]);
function_env = malloc(1*sizeof(char *));
function_env[0] = malloc(3*sizeof(char));
__CrestChar(&function_env[0][0]);
__CrestChar(&function_env[0][1]);
__CrestChar(&function_env[0][2]);
__CrestInt(&function_line_number);
glob_argv_flags = malloc(3*sizeof(char));
__CrestChar(&glob_argv_flags[0]);
__CrestChar(&glob_argv_flags[1]);
__CrestChar(&glob_argv_flags[2]);
__CrestInt(&hashing_enabled);
__CrestInt(&history_lines_this_session);
__CrestInt(&interactive);
__CrestInt(&interactive_shell);
__CrestInt(&interrupt_state);
__CrestInt(&job_control);
__CrestInt(&job_slots);
jobs = malloc(1*sizeof(struct job *));
jobs[0] = malloc(1*sizeof(struct job));
jobs[0][0].wd = malloc(3*sizeof(char));
__CrestChar(&jobs[0][0].wd[0]);
__CrestChar(&jobs[0][0].wd[1]);
__CrestChar(&jobs[0][0].wd[2]);
jobs[0][0].pipe = malloc(1*sizeof(struct process));
// Pointer Type: struct process * of jobs[0][0].pipe[0].next is set as NULL
jobs[0][0].pipe[0].next = 0;
__CrestInt(&jobs[0][0].pipe[0].pid);
__CrestInt(&jobs[0][0].pipe[0].status);
__CrestInt(&jobs[0][0].pipe[0].running);
// Pointer Type: char * of jobs[0][0].pipe[0].command is set as NULL
jobs[0][0].pipe[0].command = 0;
__CrestInt(&jobs[0][0].pgrp);
__CrestInt(&jobs[0][0].state);
__CrestInt(&jobs[0][0].flags);
jobs[0][0].deferred = malloc(1*sizeof(struct command));
__CrestInt(&jobs[0][0].deferred[0].type);
__CrestInt(&jobs[0][0].deferred[0].flags);
__CrestInt(&jobs[0][0].deferred[0].line);
// Pointer Type: struct redirect * of jobs[0][0].deferred[0].redirects is set as NULL
jobs[0][0].deferred[0].redirects = 0;
// Type: union command::<anonymous at command.h:131:3> of jobs[0][0].deferred[0].value is not supported
// Function pointer type: void (*)() of jobs[0][0].j_cleanup is not supported
jobs[0][0].j_cleanup = 0;
// Pointee type 'void' is an incomplete type
jobs[0][0].cleanarg = 0;
__CrestInt(&last_command_exit_value);
__CrestInt(&last_command_subst_pid);
__CrestInt(&last_made_pid);
// Function pointer type: int (*)() of last_shell_builtin is not supported
last_shell_builtin = 0;
__CrestInt(&line_number);
__CrestInt(&login_shell);
__CrestInt(&loop_level);
__CrestInt(&noclobber);
__CrestInt(&original_pgrp);
__CrestInt(&posixly_correct);
__CrestInt(&precs[0]);
__CrestInt(&precs[1]);
__CrestInt(&precs[2]);
__CrestInt(&precs[3]);
// Type: REDIRECTEE of rd is not supported
__CrestInt(&read_but_dont_execute);
redirection_undo_list = malloc(1*sizeof(struct redirect));
redirection_undo_list[0].next = malloc(1*sizeof(struct redirect));
redirection_undo_list[0].next[0].next = malloc(1*sizeof(struct redirect));
// Pointer Type: struct redirect * of redirection_undo_list[0].next[0].next[0].next is set as NULL
redirection_undo_list[0].next[0].next[0].next = 0;
__CrestInt(&redirection_undo_list[0].next[0].next[0].redirector);
__CrestInt(&redirection_undo_list[0].next[0].next[0].flags);
__CrestInt(&redirection_undo_list[0].next[0].next[0].instruction);
// Type: REDIRECTEE of redirection_undo_list[0].next[0].next[0].redirectee is not supported
// Pointer Type: char * of redirection_undo_list[0].next[0].next[0].here_doc_eof is set as NULL
redirection_undo_list[0].next[0].next[0].here_doc_eof = 0;
__CrestInt(&redirection_undo_list[0].next[0].redirector);
__CrestInt(&redirection_undo_list[0].next[0].flags);
__CrestInt(&redirection_undo_list[0].next[0].instruction);
// Type: REDIRECTEE of redirection_undo_list[0].next[0].redirectee is not supported
redirection_undo_list[0].next[0].here_doc_eof = malloc(3*sizeof(char));
__CrestChar(&redirection_undo_list[0].next[0].here_doc_eof[0]);
__CrestChar(&redirection_undo_list[0].next[0].here_doc_eof[1]);
__CrestChar(&redirection_undo_list[0].next[0].here_doc_eof[2]);
__CrestInt(&redirection_undo_list[0].redirector);
__CrestInt(&redirection_undo_list[0].flags);
__CrestInt(&redirection_undo_list[0].instruction);
// Type: REDIRECTEE of redirection_undo_list[0].redirectee is not supported
redirection_undo_list[0].here_doc_eof = malloc(3*sizeof(char));
__CrestChar(&redirection_undo_list[0].here_doc_eof[0]);
__CrestChar(&redirection_undo_list[0].here_doc_eof[1]);
__CrestChar(&redirection_undo_list[0].here_doc_eof[2]);
__CrestInt(&restricted);
__CrestLong(&return_catch[0].__jmpbuf[0]);
__CrestLong(&return_catch[0].__jmpbuf[1]);
__CrestLong(&return_catch[0].__jmpbuf[2]);
__CrestLong(&return_catch[0].__jmpbuf[3]);
__CrestLong(&return_catch[0].__jmpbuf[4]);
__CrestLong(&return_catch[0].__jmpbuf[5]);
__CrestLong(&return_catch[0].__jmpbuf[6]);
__CrestLong(&return_catch[0].__jmpbuf[7]);
__CrestInt(&return_catch[0].__mask_was_saved);
__CrestULong(&return_catch[0].__saved_mask.__val[0]);
__CrestULong(&return_catch[0].__saved_mask.__val[1]);
__CrestULong(&return_catch[0].__saved_mask.__val[2]);
__CrestULong(&return_catch[0].__saved_mask.__val[3]);
__CrestULong(&return_catch[0].__saved_mask.__val[4]);
__CrestULong(&return_catch[0].__saved_mask.__val[5]);
__CrestULong(&return_catch[0].__saved_mask.__val[6]);
__CrestULong(&return_catch[0].__saved_mask.__val[7]);
__CrestULong(&return_catch[0].__saved_mask.__val[8]);
__CrestULong(&return_catch[0].__saved_mask.__val[9]);
__CrestULong(&return_catch[0].__saved_mask.__val[10]);
__CrestULong(&return_catch[0].__saved_mask.__val[11]);
__CrestULong(&return_catch[0].__saved_mask.__val[12]);
__CrestULong(&return_catch[0].__saved_mask.__val[13]);
__CrestULong(&return_catch[0].__saved_mask.__val[14]);
__CrestULong(&return_catch[0].__saved_mask.__val[15]);
__CrestInt(&return_catch_flag);
__CrestInt(&return_catch_value);
__CrestInt(&running_trap);
shell_name = malloc(3*sizeof(char));
__CrestChar(&shell_name[0]);
__CrestChar(&shell_name[1]);
__CrestChar(&shell_name[2]);
__CrestInt(&special_builtin_failed);
// stderr will be set by C standard library
// stdin will be set by C standard library
__CrestInt(&stdin_redir);
// stdout will be set by C standard library
__CrestInt(&subshell_argc);
subshell_argv = malloc(1*sizeof(char *));
subshell_argv[0] = malloc(3*sizeof(char));
__CrestChar(&subshell_argv[0][0]);
__CrestChar(&subshell_argv[0][1]);
__CrestChar(&subshell_argv[0][2]);
__CrestInt(&subshell_environment);
subshell_envp = malloc(1*sizeof(char *));
subshell_envp[0] = malloc(3*sizeof(char));
__CrestChar(&subshell_envp[0][0]);
__CrestChar(&subshell_envp[0][1]);
__CrestChar(&subshell_envp[0][2]);
__CrestLong(&subshell_top_level[0].__jmpbuf[0]);
__CrestLong(&subshell_top_level[0].__jmpbuf[1]);
__CrestLong(&subshell_top_level[0].__jmpbuf[2]);
__CrestLong(&subshell_top_level[0].__jmpbuf[3]);
__CrestLong(&subshell_top_level[0].__jmpbuf[4]);
__CrestLong(&subshell_top_level[0].__jmpbuf[5]);
__CrestLong(&subshell_top_level[0].__jmpbuf[6]);
__CrestLong(&subshell_top_level[0].__jmpbuf[7]);
__CrestInt(&subshell_top_level[0].__mask_was_saved);
__CrestULong(&subshell_top_level[0].__saved_mask.__val[0]);
__CrestULong(&subshell_top_level[0].__saved_mask.__val[1]);
__CrestULong(&subshell_top_level[0].__saved_mask.__val[2]);
__CrestULong(&subshell_top_level[0].__saved_mask.__val[3]);
__CrestULong(&subshell_top_level[0].__saved_mask.__val[4]);
__CrestULong(&subshell_top_level[0].__saved_mask.__val[5]);
__CrestULong(&subshell_top_level[0].__saved_mask.__val[6]);
__CrestULong(&subshell_top_level[0].__saved_mask.__val[7]);
__CrestULong(&subshell_top_level[0].__saved_mask.__val[8]);
__CrestULong(&subshell_top_level[0].__saved_mask.__val[9]);
__CrestULong(&subshell_top_level[0].__saved_mask.__val[10]);
__CrestULong(&subshell_top_level[0].__saved_mask.__val[11]);
__CrestULong(&subshell_top_level[0].__saved_mask.__val[12]);
__CrestULong(&subshell_top_level[0].__saved_mask.__val[13]);
__CrestULong(&subshell_top_level[0].__saved_mask.__val[14]);
__CrestULong(&subshell_top_level[0].__saved_mask.__val[15]);
__CrestInt(&tabsize);
temporary_env = malloc(1*sizeof(char *));
temporary_env[0] = malloc(3*sizeof(char));
__CrestChar(&temporary_env[0][0]);
__CrestChar(&temporary_env[0][1]);
__CrestChar(&temporary_env[0][2]);
the_printed_command = malloc(3*sizeof(char));
__CrestChar(&the_printed_command[0]);
__CrestChar(&the_printed_command[1]);
__CrestChar(&the_printed_command[2]);
this_command_name = malloc(3*sizeof(char));
__CrestChar(&this_command_name[0]);
__CrestChar(&this_command_name[1]);
__CrestChar(&this_command_name[2]);
// Function pointer type: int (*)() of this_shell_builtin is not supported
this_shell_builtin = 0;
__CrestLong(&top_level[0].__jmpbuf[0]);
__CrestLong(&top_level[0].__jmpbuf[1]);
__CrestLong(&top_level[0].__jmpbuf[2]);
__CrestLong(&top_level[0].__jmpbuf[3]);
__CrestLong(&top_level[0].__jmpbuf[4]);
__CrestLong(&top_level[0].__jmpbuf[5]);
__CrestLong(&top_level[0].__jmpbuf[6]);
__CrestLong(&top_level[0].__jmpbuf[7]);
__CrestInt(&top_level[0].__mask_was_saved);
__CrestULong(&top_level[0].__saved_mask.__val[0]);
__CrestULong(&top_level[0].__saved_mask.__val[1]);
__CrestULong(&top_level[0].__saved_mask.__val[2]);
__CrestULong(&top_level[0].__saved_mask.__val[3]);
__CrestULong(&top_level[0].__saved_mask.__val[4]);
__CrestULong(&top_level[0].__saved_mask.__val[5]);
__CrestULong(&top_level[0].__saved_mask.__val[6]);
__CrestULong(&top_level[0].__saved_mask.__val[7]);
__CrestULong(&top_level[0].__saved_mask.__val[8]);
__CrestULong(&top_level[0].__saved_mask.__val[9]);
__CrestULong(&top_level[0].__saved_mask.__val[10]);
__CrestULong(&top_level[0].__saved_mask.__val[11]);
__CrestULong(&top_level[0].__saved_mask.__val[12]);
__CrestULong(&top_level[0].__saved_mask.__val[13]);
__CrestULong(&top_level[0].__saved_mask.__val[14]);
__CrestULong(&top_level[0].__saved_mask.__val[15]);
trap_list[0] = malloc(3*sizeof(char));
__CrestChar(&trap_list[0][0]);
__CrestChar(&trap_list[0][1]);
__CrestChar(&trap_list[0][2]);
__CrestInt(&variable_context);
return time_command(param1,param2,param3,param4,param5);
}
int test_main(){
time_command_driver();
 return 0;}

void init_execute_cmd_i(){
__CrestInt(&COLS);
__CrestInt(&LINES);
__CrestInt(&already_making_children);
__CrestInt(&bash_input.type);
bash_input.name = malloc(3*sizeof(char));
__CrestChar(&bash_input.name[0]);
__CrestChar(&bash_input.name[1]);
__CrestChar(&bash_input.name[2]);
// Type: INPUT_STREAM of bash_input.location is not supported
// Function pointer type: int (*)() of bash_input.getter is not supported
bash_input.getter = 0;
// Function pointer type: int (*)() of bash_input.ungetter is not supported
bash_input.ungetter = 0;
__CrestInt(&breaking);
builtin_env = malloc(1*sizeof(char *));
builtin_env[0] = malloc(3*sizeof(char));
__CrestChar(&builtin_env[0][0]);
__CrestChar(&builtin_env[0][1]);
__CrestChar(&builtin_env[0][2]);
__CrestInt(&check_hashed_filenames);
__CrestInt(&command_string_index);
__CrestInt(&continuing);
current_fds_to_close = malloc(1*sizeof(struct fd_bitmap));
__CrestLong(&current_fds_to_close[0].size);
current_fds_to_close[0].bitmap = malloc(3*sizeof(char));
__CrestChar(&current_fds_to_close[0].bitmap[0]);
__CrestChar(&current_fds_to_close[0].bitmap[1]);
__CrestChar(&current_fds_to_close[0].bitmap[2]);
__CrestInt(&current_user.uid);
__CrestInt(&current_user.euid);
__CrestInt(&current_user.gid);
__CrestInt(&current_user.egid);
current_user.user_name = malloc(3*sizeof(char));
__CrestChar(&current_user.user_name[0]);
__CrestChar(&current_user.user_name[1]);
__CrestChar(&current_user.user_name[2]);
current_user.shell = malloc(3*sizeof(char));
__CrestChar(&current_user.shell[0]);
__CrestChar(&current_user.shell[1]);
__CrestChar(&current_user.shell[2]);
current_user.home_dir = malloc(3*sizeof(char));
__CrestChar(&current_user.home_dir[0]);
__CrestChar(&current_user.home_dir[1]);
__CrestChar(&current_user.home_dir[2]);
currently_executing_command = malloc(1*sizeof(struct command));
__CrestInt(&currently_executing_command[0].type);
__CrestInt(&currently_executing_command[0].flags);
__CrestInt(&currently_executing_command[0].line);
currently_executing_command[0].redirects = malloc(1*sizeof(struct redirect));
currently_executing_command[0].redirects[0].next = malloc(1*sizeof(struct redirect));
// Pointer Type: struct redirect * of currently_executing_command[0].redirects[0].next[0].next is set as NULL
currently_executing_command[0].redirects[0].next[0].next = 0;
__CrestInt(&currently_executing_command[0].redirects[0].next[0].redirector);
__CrestInt(&currently_executing_command[0].redirects[0].next[0].flags);
__CrestInt(&currently_executing_command[0].redirects[0].next[0].instruction);
// Type: REDIRECTEE of currently_executing_command[0].redirects[0].next[0].redirectee is not supported
// Pointer Type: char * of currently_executing_command[0].redirects[0].next[0].here_doc_eof is set as NULL
currently_executing_command[0].redirects[0].next[0].here_doc_eof = 0;
__CrestInt(&currently_executing_command[0].redirects[0].redirector);
__CrestInt(&currently_executing_command[0].redirects[0].flags);
__CrestInt(&currently_executing_command[0].redirects[0].instruction);
// Type: REDIRECTEE of currently_executing_command[0].redirects[0].redirectee is not supported
currently_executing_command[0].redirects[0].here_doc_eof = malloc(3*sizeof(char));
__CrestChar(&currently_executing_command[0].redirects[0].here_doc_eof[0]);
__CrestChar(&currently_executing_command[0].redirects[0].here_doc_eof[1]);
__CrestChar(&currently_executing_command[0].redirects[0].here_doc_eof[2]);
// Type: union command::<anonymous at command.h:131:3> of currently_executing_command[0].value is not supported
__CrestInt(&default_buffered_input);
__CrestInt(&disallow_filename_globbing);
__CrestInt(&dot_found_in_search);
__CrestInt(&echo_command_at_execute);
exec_redirection_undo_list = malloc(1*sizeof(struct redirect));
exec_redirection_undo_list[0].next = malloc(1*sizeof(struct redirect));
exec_redirection_undo_list[0].next[0].next = malloc(1*sizeof(struct redirect));
// Pointer Type: struct redirect * of exec_redirection_undo_list[0].next[0].next[0].next is set as NULL
exec_redirection_undo_list[0].next[0].next[0].next = 0;
__CrestInt(&exec_redirection_undo_list[0].next[0].next[0].redirector);
__CrestInt(&exec_redirection_undo_list[0].next[0].next[0].flags);
__CrestInt(&exec_redirection_undo_list[0].next[0].next[0].instruction);
// Type: REDIRECTEE of exec_redirection_undo_list[0].next[0].next[0].redirectee is not supported
// Pointer Type: char * of exec_redirection_undo_list[0].next[0].next[0].here_doc_eof is set as NULL
exec_redirection_undo_list[0].next[0].next[0].here_doc_eof = 0;
__CrestInt(&exec_redirection_undo_list[0].next[0].redirector);
__CrestInt(&exec_redirection_undo_list[0].next[0].flags);
__CrestInt(&exec_redirection_undo_list[0].next[0].instruction);
// Type: REDIRECTEE of exec_redirection_undo_list[0].next[0].redirectee is not supported
exec_redirection_undo_list[0].next[0].here_doc_eof = malloc(3*sizeof(char));
__CrestChar(&exec_redirection_undo_list[0].next[0].here_doc_eof[0]);
__CrestChar(&exec_redirection_undo_list[0].next[0].here_doc_eof[1]);
__CrestChar(&exec_redirection_undo_list[0].next[0].here_doc_eof[2]);
__CrestInt(&exec_redirection_undo_list[0].redirector);
__CrestInt(&exec_redirection_undo_list[0].flags);
__CrestInt(&exec_redirection_undo_list[0].instruction);
// Type: REDIRECTEE of exec_redirection_undo_list[0].redirectee is not supported
exec_redirection_undo_list[0].here_doc_eof = malloc(3*sizeof(char));
__CrestChar(&exec_redirection_undo_list[0].here_doc_eof[0]);
__CrestChar(&exec_redirection_undo_list[0].here_doc_eof[1]);
__CrestChar(&exec_redirection_undo_list[0].here_doc_eof[2]);
__CrestInt(&executing);
__CrestInt(&exit_immediately_on_error);
__CrestInt(&expand_aliases);
export_env = malloc(1*sizeof(char *));
export_env[0] = malloc(3*sizeof(char));
__CrestChar(&export_env[0][0]);
__CrestChar(&export_env[0][1]);
__CrestChar(&export_env[0][2]);
file_to_lose_on = malloc(3*sizeof(char));
__CrestChar(&file_to_lose_on[0]);
__CrestChar(&file_to_lose_on[1]);
__CrestChar(&file_to_lose_on[2]);
function_env = malloc(1*sizeof(char *));
function_env[0] = malloc(3*sizeof(char));
__CrestChar(&function_env[0][0]);
__CrestChar(&function_env[0][1]);
__CrestChar(&function_env[0][2]);
__CrestInt(&function_line_number);
glob_argv_flags = malloc(3*sizeof(char));
__CrestChar(&glob_argv_flags[0]);
__CrestChar(&glob_argv_flags[1]);
__CrestChar(&glob_argv_flags[2]);
__CrestInt(&hashing_enabled);
__CrestInt(&history_lines_this_session);
__CrestInt(&interactive);
__CrestInt(&interactive_shell);
__CrestInt(&interrupt_state);
__CrestInt(&job_control);
__CrestInt(&job_slots);
jobs = malloc(1*sizeof(struct job *));
jobs[0] = malloc(1*sizeof(struct job));
jobs[0][0].wd = malloc(3*sizeof(char));
__CrestChar(&jobs[0][0].wd[0]);
__CrestChar(&jobs[0][0].wd[1]);
__CrestChar(&jobs[0][0].wd[2]);
jobs[0][0].pipe = malloc(1*sizeof(struct process));
// Pointer Type: struct process * of jobs[0][0].pipe[0].next is set as NULL
jobs[0][0].pipe[0].next = 0;
__CrestInt(&jobs[0][0].pipe[0].pid);
__CrestInt(&jobs[0][0].pipe[0].status);
__CrestInt(&jobs[0][0].pipe[0].running);
// Pointer Type: char * of jobs[0][0].pipe[0].command is set as NULL
jobs[0][0].pipe[0].command = 0;
__CrestInt(&jobs[0][0].pgrp);
__CrestInt(&jobs[0][0].state);
__CrestInt(&jobs[0][0].flags);
jobs[0][0].deferred = malloc(1*sizeof(struct command));
__CrestInt(&jobs[0][0].deferred[0].type);
__CrestInt(&jobs[0][0].deferred[0].flags);
__CrestInt(&jobs[0][0].deferred[0].line);
// Pointer Type: struct redirect * of jobs[0][0].deferred[0].redirects is set as NULL
jobs[0][0].deferred[0].redirects = 0;
// Type: union command::<anonymous at command.h:131:3> of jobs[0][0].deferred[0].value is not supported
// Function pointer type: void (*)() of jobs[0][0].j_cleanup is not supported
jobs[0][0].j_cleanup = 0;
// Pointee type 'void' is an incomplete type
jobs[0][0].cleanarg = 0;
__CrestInt(&last_command_exit_value);
__CrestInt(&last_command_subst_pid);
__CrestInt(&last_made_pid);
// Function pointer type: int (*)() of last_shell_builtin is not supported
last_shell_builtin = 0;
__CrestInt(&line_number);
__CrestInt(&login_shell);
__CrestInt(&loop_level);
__CrestInt(&noclobber);
__CrestInt(&original_pgrp);
__CrestInt(&posixly_correct);
__CrestInt(&precs[0]);
__CrestInt(&precs[1]);
__CrestInt(&precs[2]);
__CrestInt(&precs[3]);
// Type: REDIRECTEE of rd is not supported
__CrestInt(&read_but_dont_execute);
redirection_undo_list = malloc(1*sizeof(struct redirect));
redirection_undo_list[0].next = malloc(1*sizeof(struct redirect));
redirection_undo_list[0].next[0].next = malloc(1*sizeof(struct redirect));
// Pointer Type: struct redirect * of redirection_undo_list[0].next[0].next[0].next is set as NULL
redirection_undo_list[0].next[0].next[0].next = 0;
__CrestInt(&redirection_undo_list[0].next[0].next[0].redirector);
__CrestInt(&redirection_undo_list[0].next[0].next[0].flags);
__CrestInt(&redirection_undo_list[0].next[0].next[0].instruction);
// Type: REDIRECTEE of redirection_undo_list[0].next[0].next[0].redirectee is not supported
// Pointer Type: char * of redirection_undo_list[0].next[0].next[0].here_doc_eof is set as NULL
redirection_undo_list[0].next[0].next[0].here_doc_eof = 0;
__CrestInt(&redirection_undo_list[0].next[0].redirector);
__CrestInt(&redirection_undo_list[0].next[0].flags);
__CrestInt(&redirection_undo_list[0].next[0].instruction);
// Type: REDIRECTEE of redirection_undo_list[0].next[0].redirectee is not supported
redirection_undo_list[0].next[0].here_doc_eof = malloc(3*sizeof(char));
__CrestChar(&redirection_undo_list[0].next[0].here_doc_eof[0]);
__CrestChar(&redirection_undo_list[0].next[0].here_doc_eof[1]);
__CrestChar(&redirection_undo_list[0].next[0].here_doc_eof[2]);
__CrestInt(&redirection_undo_list[0].redirector);
__CrestInt(&redirection_undo_list[0].flags);
__CrestInt(&redirection_undo_list[0].instruction);
// Type: REDIRECTEE of redirection_undo_list[0].redirectee is not supported
redirection_undo_list[0].here_doc_eof = malloc(3*sizeof(char));
__CrestChar(&redirection_undo_list[0].here_doc_eof[0]);
__CrestChar(&redirection_undo_list[0].here_doc_eof[1]);
__CrestChar(&redirection_undo_list[0].here_doc_eof[2]);
__CrestInt(&restricted);
__CrestLong(&return_catch[0].__jmpbuf[0]);
__CrestLong(&return_catch[0].__jmpbuf[1]);
__CrestLong(&return_catch[0].__jmpbuf[2]);
__CrestLong(&return_catch[0].__jmpbuf[3]);
__CrestLong(&return_catch[0].__jmpbuf[4]);
__CrestLong(&return_catch[0].__jmpbuf[5]);
__CrestLong(&return_catch[0].__jmpbuf[6]);
__CrestLong(&return_catch[0].__jmpbuf[7]);
__CrestInt(&return_catch[0].__mask_was_saved);
__CrestULong(&return_catch[0].__saved_mask.__val[0]);
__CrestULong(&return_catch[0].__saved_mask.__val[1]);
__CrestULong(&return_catch[0].__saved_mask.__val[2]);
__CrestULong(&return_catch[0].__saved_mask.__val[3]);
__CrestULong(&return_catch[0].__saved_mask.__val[4]);
__CrestULong(&return_catch[0].__saved_mask.__val[5]);
__CrestULong(&return_catch[0].__saved_mask.__val[6]);
__CrestULong(&return_catch[0].__saved_mask.__val[7]);
__CrestULong(&return_catch[0].__saved_mask.__val[8]);
__CrestULong(&return_catch[0].__saved_mask.__val[9]);
__CrestULong(&return_catch[0].__saved_mask.__val[10]);
__CrestULong(&return_catch[0].__saved_mask.__val[11]);
__CrestULong(&return_catch[0].__saved_mask.__val[12]);
__CrestULong(&return_catch[0].__saved_mask.__val[13]);
__CrestULong(&return_catch[0].__saved_mask.__val[14]);
__CrestULong(&return_catch[0].__saved_mask.__val[15]);
__CrestInt(&return_catch_flag);
__CrestInt(&return_catch_value);
__CrestInt(&running_trap);
shell_name = malloc(3*sizeof(char));
__CrestChar(&shell_name[0]);
__CrestChar(&shell_name[1]);
__CrestChar(&shell_name[2]);
__CrestInt(&special_builtin_failed);
// stderr will be set by C standard library
// stdin will be set by C standard library
__CrestInt(&stdin_redir);
// stdout will be set by C standard library
__CrestInt(&subshell_argc);
subshell_argv = malloc(1*sizeof(char *));
subshell_argv[0] = malloc(3*sizeof(char));
__CrestChar(&subshell_argv[0][0]);
__CrestChar(&subshell_argv[0][1]);
__CrestChar(&subshell_argv[0][2]);
__CrestInt(&subshell_environment);
subshell_envp = malloc(1*sizeof(char *));
subshell_envp[0] = malloc(3*sizeof(char));
__CrestChar(&subshell_envp[0][0]);
__CrestChar(&subshell_envp[0][1]);
__CrestChar(&subshell_envp[0][2]);
__CrestLong(&subshell_top_level[0].__jmpbuf[0]);
__CrestLong(&subshell_top_level[0].__jmpbuf[1]);
__CrestLong(&subshell_top_level[0].__jmpbuf[2]);
__CrestLong(&subshell_top_level[0].__jmpbuf[3]);
__CrestLong(&subshell_top_level[0].__jmpbuf[4]);
__CrestLong(&subshell_top_level[0].__jmpbuf[5]);
__CrestLong(&subshell_top_level[0].__jmpbuf[6]);
__CrestLong(&subshell_top_level[0].__jmpbuf[7]);
__CrestInt(&subshell_top_level[0].__mask_was_saved);
__CrestULong(&subshell_top_level[0].__saved_mask.__val[0]);
__CrestULong(&subshell_top_level[0].__saved_mask.__val[1]);
__CrestULong(&subshell_top_level[0].__saved_mask.__val[2]);
__CrestULong(&subshell_top_level[0].__saved_mask.__val[3]);
__CrestULong(&subshell_top_level[0].__saved_mask.__val[4]);
__CrestULong(&subshell_top_level[0].__saved_mask.__val[5]);
__CrestULong(&subshell_top_level[0].__saved_mask.__val[6]);
__CrestULong(&subshell_top_level[0].__saved_mask.__val[7]);
__CrestULong(&subshell_top_level[0].__saved_mask.__val[8]);
__CrestULong(&subshell_top_level[0].__saved_mask.__val[9]);
__CrestULong(&subshell_top_level[0].__saved_mask.__val[10]);
__CrestULong(&subshell_top_level[0].__saved_mask.__val[11]);
__CrestULong(&subshell_top_level[0].__saved_mask.__val[12]);
__CrestULong(&subshell_top_level[0].__saved_mask.__val[13]);
__CrestULong(&subshell_top_level[0].__saved_mask.__val[14]);
__CrestULong(&subshell_top_level[0].__saved_mask.__val[15]);
__CrestInt(&tabsize);
temporary_env = malloc(1*sizeof(char *));
temporary_env[0] = malloc(3*sizeof(char));
__CrestChar(&temporary_env[0][0]);
__CrestChar(&temporary_env[0][1]);
__CrestChar(&temporary_env[0][2]);
the_printed_command = malloc(3*sizeof(char));
__CrestChar(&the_printed_command[0]);
__CrestChar(&the_printed_command[1]);
__CrestChar(&the_printed_command[2]);
this_command_name = malloc(3*sizeof(char));
__CrestChar(&this_command_name[0]);
__CrestChar(&this_command_name[1]);
__CrestChar(&this_command_name[2]);
// Function pointer type: int (*)() of this_shell_builtin is not supported
this_shell_builtin = 0;
__CrestLong(&top_level[0].__jmpbuf[0]);
__CrestLong(&top_level[0].__jmpbuf[1]);
__CrestLong(&top_level[0].__jmpbuf[2]);
__CrestLong(&top_level[0].__jmpbuf[3]);
__CrestLong(&top_level[0].__jmpbuf[4]);
__CrestLong(&top_level[0].__jmpbuf[5]);
__CrestLong(&top_level[0].__jmpbuf[6]);
__CrestLong(&top_level[0].__jmpbuf[7]);
__CrestInt(&top_level[0].__mask_was_saved);
__CrestULong(&top_level[0].__saved_mask.__val[0]);
__CrestULong(&top_level[0].__saved_mask.__val[1]);
__CrestULong(&top_level[0].__saved_mask.__val[2]);
__CrestULong(&top_level[0].__saved_mask.__val[3]);
__CrestULong(&top_level[0].__saved_mask.__val[4]);
__CrestULong(&top_level[0].__saved_mask.__val[5]);
__CrestULong(&top_level[0].__saved_mask.__val[6]);
__CrestULong(&top_level[0].__saved_mask.__val[7]);
__CrestULong(&top_level[0].__saved_mask.__val[8]);
__CrestULong(&top_level[0].__saved_mask.__val[9]);
__CrestULong(&top_level[0].__saved_mask.__val[10]);
__CrestULong(&top_level[0].__saved_mask.__val[11]);
__CrestULong(&top_level[0].__saved_mask.__val[12]);
__CrestULong(&top_level[0].__saved_mask.__val[13]);
__CrestULong(&top_level[0].__saved_mask.__val[14]);
__CrestULong(&top_level[0].__saved_mask.__val[15]);
trap_list[0] = malloc(3*sizeof(char));
__CrestChar(&trap_list[0][0]);
__CrestChar(&trap_list[0][1]);
__CrestChar(&trap_list[0][2]);
__CrestInt(&variable_context);
}
static int __sym__IO_getc(_IO_FILE * param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym__IO_putc(int param0, _IO_FILE * param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static const unsigned short ** __sym___ctype_b_loc(void){
  const unsigned short ** ret;
ret = malloc(1*sizeof(const unsigned short *));
// Pointee type 'unsigned short' is a constant
{
unsigned short *__tmp__1;
__tmp__1 = malloc(3*sizeof(unsigned short));
__CrestUShort(&__tmp__1[0]);
__CrestUShort(&__tmp__1[1]);
__CrestUShort(&__tmp__1[2]);
ret[0] = __tmp__1;
}
  return ret;
}
static const int ** __sym___ctype_tolower_loc(void){
  const int ** ret;
ret = malloc(1*sizeof(const int *));
// Pointee type 'int' is a constant
{
int *__tmp__1;
__tmp__1 = malloc(3*sizeof(int));
__CrestInt(&__tmp__1[0]);
__CrestInt(&__tmp__1[1]);
__CrestInt(&__tmp__1[2]);
ret[0] = __tmp__1;
}
  return ret;
}
static const int ** __sym___ctype_toupper_loc(void){
  const int ** ret;
ret = malloc(1*sizeof(const int *));
// Pointee type 'int' is a constant
{
int *__tmp__1;
__tmp__1 = malloc(3*sizeof(int));
__CrestInt(&__tmp__1[0]);
__CrestInt(&__tmp__1[1]);
__CrestInt(&__tmp__1[2]);
ret[0] = __tmp__1;
}
  return ret;
}
static int * __sym___errno_location(void){
  int * ret;
ret = malloc(3*sizeof(int));
__CrestInt(&ret[0]);
__CrestInt(&ret[1]);
__CrestInt(&ret[2]);
  return ret;
}
static int __sym___fxstat(int param0, int param1, struct stat * param2, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym___fxstatat(int param0, int param1, const char * param2, struct stat * param3, int param4, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym___lxstat(int param0, const char * param1, struct stat * param2, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym___overflow(_IO_FILE * param0, int param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void * __sym___rawmemchr(const void * param0, int param1, ...){
  void * ret;
// Pointee type 'void' is an incomplete type
ret = 0;
  return ret;
}
static int __sym___sigsetjmp(struct __jmp_buf_tag param0[], int param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym___uflow(_IO_FILE * param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym___xmknod(int param0, const char * param1, __mode_t param2, __dev_t * param3, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym___xmknodat(int param0, int param1, const char * param2, __mode_t param3, __dev_t * param4, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym___xstat(int param0, const char * param1, struct stat * param2, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static char * __sym__find_user_command_internal(char * param0, int param1, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static int __sym_absolute_program(char * param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym_add_exec_redirect(void){
}
static void __sym_add_undo_close_redirect(void){
}
static int __sym_add_undo_redirect(void){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym_add_unwind_protect(void){
}
static struct timeval * __sym_addtimeval(struct timeval * param0, struct timeval * param1, struct timeval * param2, ...){
  struct timeval * ret;
ret = malloc(1*sizeof(struct timeval));
__CrestLong(&ret[0].tv_sec);
__CrestLong(&ret[0].tv_usec);
  return ret;
}
static int __sym_all_digits(char * param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_array_len(char ** param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_atoi(const char * param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static long __sym_atol(const char * param0, ...){
  long ret;
__CrestLong(&ret);
  return ret;
}
static char * __sym_bash_tilde_expand(char * param0, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static void __sym_begin_unwind_frame(void){
}
static struct variable * __sym_bind_function(char * param0, COMMAND * param1, ...){
  struct variable * ret;
ret = malloc(1*sizeof(struct variable));
ret[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].name[0]);
__CrestChar(&ret[0].name[1]);
__CrestChar(&ret[0].name[2]);
ret[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].value[0]);
__CrestChar(&ret[0].value[1]);
__CrestChar(&ret[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].dynamic_value is not supported
ret[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].assign_func is not supported
ret[0].assign_func = 0;
__CrestInt(&ret[0].attributes);
__CrestInt(&ret[0].context);
ret[0].prev_context = malloc(1*sizeof(struct variable));
ret[0].prev_context[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].name[0]);
__CrestChar(&ret[0].prev_context[0].name[1]);
__CrestChar(&ret[0].prev_context[0].name[2]);
ret[0].prev_context[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].value[0]);
__CrestChar(&ret[0].prev_context[0].value[1]);
__CrestChar(&ret[0].prev_context[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].context);
ret[0].prev_context[0].prev_context = malloc(1*sizeof(struct variable));
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].name is set as NULL
ret[0].prev_context[0].prev_context[0].name = 0;
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].value is set as NULL
ret[0].prev_context[0].prev_context[0].value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].prev_context[0].context);
// Pointer Type: struct variable * of ret[0].prev_context[0].prev_context[0].prev_context is set as NULL
ret[0].prev_context[0].prev_context[0].prev_context = 0;
  return ret;
}
static void __sym_bind_lastarg(char * param0, ...){
}
static struct variable * __sym_bind_variable(char * param0, char * param1, ...){
  struct variable * ret;
ret = malloc(1*sizeof(struct variable));
ret[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].name[0]);
__CrestChar(&ret[0].name[1]);
__CrestChar(&ret[0].name[2]);
ret[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].value[0]);
__CrestChar(&ret[0].value[1]);
__CrestChar(&ret[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].dynamic_value is not supported
ret[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].assign_func is not supported
ret[0].assign_func = 0;
__CrestInt(&ret[0].attributes);
__CrestInt(&ret[0].context);
ret[0].prev_context = malloc(1*sizeof(struct variable));
ret[0].prev_context[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].name[0]);
__CrestChar(&ret[0].prev_context[0].name[1]);
__CrestChar(&ret[0].prev_context[0].name[2]);
ret[0].prev_context[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].value[0]);
__CrestChar(&ret[0].prev_context[0].value[1]);
__CrestChar(&ret[0].prev_context[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].context);
ret[0].prev_context[0].prev_context = malloc(1*sizeof(struct variable));
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].name is set as NULL
ret[0].prev_context[0].prev_context[0].name = 0;
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].value is set as NULL
ret[0].prev_context[0].prev_context[0].value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].prev_context[0].context);
// Pointer Type: struct variable * of ret[0].prev_context[0].prev_context[0].prev_context is set as NULL
ret[0].prev_context[0].prev_context[0].prev_context = 0;
  return ret;
}
static void * __sym_builtin_address(void){
  void * ret;
// Function pointer type: void * of ret is not supported
ret = 0;
  return ret;
}
static struct builtin * __sym_builtin_address_internal(void){
  struct builtin * ret;
ret = malloc(1*sizeof(struct builtin));
ret[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].name[0]);
__CrestChar(&ret[0].name[1]);
__CrestChar(&ret[0].name[2]);
// Function pointer type: int (*)() of ret[0].function is not supported
ret[0].function = 0;
__CrestInt(&ret[0].flags);
ret[0].long_doc = malloc(1*sizeof(char *));
ret[0].long_doc[0] = malloc(3*sizeof(char));
__CrestChar(&ret[0].long_doc[0][0]);
__CrestChar(&ret[0].long_doc[0][1]);
__CrestChar(&ret[0].long_doc[0][2]);
ret[0].short_doc = malloc(3*sizeof(char));
__CrestChar(&ret[0].short_doc[0]);
__CrestChar(&ret[0].short_doc[1]);
__CrestChar(&ret[0].short_doc[2]);
ret[0].handle = malloc(3*sizeof(char));
__CrestChar(&ret[0].handle[0]);
__CrestChar(&ret[0].handle[1]);
__CrestChar(&ret[0].handle[2]);
  return ret;
}
static int __sym_builtin_status(void){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym_bzero(void * param0, size_t param1, ...){
}
static int __sym_change_flag(int param0, int param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_check_bash_input(int param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_check_binary_file(unsigned char * param0, int param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_check_identifier(WORD_DESC * param0, int param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym_cleanup_redirects(REDIRECT * param0, ...){
}
static int __sym_close(int param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_close_buffered_fd(int param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym_close_fd_bitmap(struct fd_bitmap * param0, ...){
}
static void __sym_close_pipes(void){
}
static char ** __sym_copy_array(char ** param0, ...){
  char ** ret;
ret = malloc(1*sizeof(char *));
ret[0] = malloc(3*sizeof(char));
__CrestChar(&ret[0][0]);
__CrestChar(&ret[0][1]);
__CrestChar(&ret[0][2]);
  return ret;
}
static struct command * __sym_copy_command(COMMAND * param0, ...){
  struct command * ret;
ret = malloc(1*sizeof(struct command));
__CrestInt(&ret[0].type);
__CrestInt(&ret[0].flags);
__CrestInt(&ret[0].line);
ret[0].redirects = malloc(1*sizeof(struct redirect));
ret[0].redirects[0].next = malloc(1*sizeof(struct redirect));
// Pointer Type: struct redirect * of ret[0].redirects[0].next[0].next is set as NULL
ret[0].redirects[0].next[0].next = 0;
__CrestInt(&ret[0].redirects[0].next[0].redirector);
__CrestInt(&ret[0].redirects[0].next[0].flags);
__CrestInt(&ret[0].redirects[0].next[0].instruction);
// Type: REDIRECTEE of ret[0].redirects[0].next[0].redirectee is not supported
// Pointer Type: char * of ret[0].redirects[0].next[0].here_doc_eof is set as NULL
ret[0].redirects[0].next[0].here_doc_eof = 0;
__CrestInt(&ret[0].redirects[0].redirector);
__CrestInt(&ret[0].redirects[0].flags);
__CrestInt(&ret[0].redirects[0].instruction);
// Type: REDIRECTEE of ret[0].redirects[0].redirectee is not supported
ret[0].redirects[0].here_doc_eof = malloc(3*sizeof(char));
__CrestChar(&ret[0].redirects[0].here_doc_eof[0]);
__CrestChar(&ret[0].redirects[0].here_doc_eof[1]);
__CrestChar(&ret[0].redirects[0].here_doc_eof[2]);
// Type: union command::<anonymous at command.h:131:3> of ret[0].value is not supported
  return ret;
}
static struct redirect * __sym_copy_redirect(REDIRECT * param0, ...){
  struct redirect * ret;
ret = malloc(1*sizeof(struct redirect));
ret[0].next = malloc(1*sizeof(struct redirect));
ret[0].next[0].next = malloc(1*sizeof(struct redirect));
// Pointer Type: struct redirect * of ret[0].next[0].next[0].next is set as NULL
ret[0].next[0].next[0].next = 0;
__CrestInt(&ret[0].next[0].next[0].redirector);
__CrestInt(&ret[0].next[0].next[0].flags);
__CrestInt(&ret[0].next[0].next[0].instruction);
// Type: REDIRECTEE of ret[0].next[0].next[0].redirectee is not supported
// Pointer Type: char * of ret[0].next[0].next[0].here_doc_eof is set as NULL
ret[0].next[0].next[0].here_doc_eof = 0;
__CrestInt(&ret[0].next[0].redirector);
__CrestInt(&ret[0].next[0].flags);
__CrestInt(&ret[0].next[0].instruction);
// Type: REDIRECTEE of ret[0].next[0].redirectee is not supported
ret[0].next[0].here_doc_eof = malloc(3*sizeof(char));
__CrestChar(&ret[0].next[0].here_doc_eof[0]);
__CrestChar(&ret[0].next[0].here_doc_eof[1]);
__CrestChar(&ret[0].next[0].here_doc_eof[2]);
__CrestInt(&ret[0].redirector);
__CrestInt(&ret[0].flags);
__CrestInt(&ret[0].instruction);
// Type: REDIRECTEE of ret[0].redirectee is not supported
ret[0].here_doc_eof = malloc(3*sizeof(char));
__CrestChar(&ret[0].here_doc_eof[0]);
__CrestChar(&ret[0].here_doc_eof[1]);
__CrestChar(&ret[0].here_doc_eof[2]);
  return ret;
}
static struct redirect * __sym_copy_redirects(REDIRECT * param0, ...){
  struct redirect * ret;
ret = malloc(1*sizeof(struct redirect));
ret[0].next = malloc(1*sizeof(struct redirect));
ret[0].next[0].next = malloc(1*sizeof(struct redirect));
// Pointer Type: struct redirect * of ret[0].next[0].next[0].next is set as NULL
ret[0].next[0].next[0].next = 0;
__CrestInt(&ret[0].next[0].next[0].redirector);
__CrestInt(&ret[0].next[0].next[0].flags);
__CrestInt(&ret[0].next[0].next[0].instruction);
// Type: REDIRECTEE of ret[0].next[0].next[0].redirectee is not supported
// Pointer Type: char * of ret[0].next[0].next[0].here_doc_eof is set as NULL
ret[0].next[0].next[0].here_doc_eof = 0;
__CrestInt(&ret[0].next[0].redirector);
__CrestInt(&ret[0].next[0].flags);
__CrestInt(&ret[0].next[0].instruction);
// Type: REDIRECTEE of ret[0].next[0].redirectee is not supported
ret[0].next[0].here_doc_eof = malloc(3*sizeof(char));
__CrestChar(&ret[0].next[0].here_doc_eof[0]);
__CrestChar(&ret[0].next[0].here_doc_eof[1]);
__CrestChar(&ret[0].next[0].here_doc_eof[2]);
__CrestInt(&ret[0].redirector);
__CrestInt(&ret[0].flags);
__CrestInt(&ret[0].instruction);
// Type: REDIRECTEE of ret[0].redirectee is not supported
ret[0].here_doc_eof = malloc(3*sizeof(char));
__CrestChar(&ret[0].here_doc_eof[0]);
__CrestChar(&ret[0].here_doc_eof[1]);
__CrestChar(&ret[0].here_doc_eof[2]);
  return ret;
}
static struct word_desc * __sym_copy_word(WORD_DESC * param0, ...){
  struct word_desc * ret;
ret = malloc(1*sizeof(struct word_desc));
ret[0].word = malloc(3*sizeof(char));
__CrestChar(&ret[0].word[0]);
__CrestChar(&ret[0].word[1]);
__CrestChar(&ret[0].word[2]);
__CrestInt(&ret[0].flags);
  return ret;
}
static struct word_list * __sym_copy_word_list(WORD_LIST * param0, ...){
  struct word_list * ret;
ret = malloc(1*sizeof(struct word_list));
ret[0].next = malloc(1*sizeof(struct word_list));
ret[0].next[0].next = malloc(1*sizeof(struct word_list));
// Pointer Type: struct word_list * of ret[0].next[0].next[0].next is set as NULL
ret[0].next[0].next[0].next = 0;
// Pointer Type: struct word_desc * of ret[0].next[0].next[0].word is set as NULL
ret[0].next[0].next[0].word = 0;
ret[0].next[0].word = malloc(1*sizeof(struct word_desc));
// Pointer Type: char * of ret[0].next[0].word[0].word is set as NULL
ret[0].next[0].word[0].word = 0;
__CrestInt(&ret[0].next[0].word[0].flags);
ret[0].word = malloc(1*sizeof(struct word_desc));
ret[0].word[0].word = malloc(3*sizeof(char));
__CrestChar(&ret[0].word[0].word[0]);
__CrestChar(&ret[0].word[0].word[1]);
__CrestChar(&ret[0].word[0].word[2]);
__CrestInt(&ret[0].word[0].flags);
  return ret;
}
static void __sym_delete_all_aliases(void){
}
static void __sym_describe_pid(pid_t param0, ...){
}
static struct timeval * __sym_difftimeval(struct timeval * param0, struct timeval * param1, struct timeval * param2, ...){
  struct timeval * ret;
ret = malloc(1*sizeof(struct timeval));
__CrestLong(&ret[0].tv_sec);
__CrestLong(&ret[0].tv_usec);
  return ret;
}
static void __sym_discard_unwind_frame(void){
}
static void __sym_dispose_builtin_env(void){
}
static void __sym_dispose_command(COMMAND * param0, ...){
}
static void __sym_dispose_exec_redirects(void){
}
static void __sym_dispose_fd_bitmap(struct fd_bitmap * param0, ...){
}
static void __sym_dispose_redirects(REDIRECT * param0, ...){
}
static void __sym_dispose_used_env_vars(void){
}
static void __sym_dispose_words(WORD_LIST * param0, ...){
}
static void __sym_do_piping(void){
}
static int __sym_do_redirection_internal(void){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_do_redirections(void){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_dup(int param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_dup2(int param0, int param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_duplicate_buffered_stream(int param0, int param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_execute_builtin(void * param0, WORD_LIST * param1, int param2, int param3, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_execute_builtin_or_function(void){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_execute_case_command(void){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_execute_command(COMMAND * param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_execute_command_internal(COMMAND * param0, int param1, int param2, int param3, struct fd_bitmap * param4, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_execute_connection(void){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym_execute_disk_command(void){
}
static int __sym_execute_for_command(void){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_execute_function(SHELL_VAR * param0, WORD_LIST * param1, int param2, struct fd_bitmap * param3, int param4, int param5, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_execute_if_command(void){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_execute_intern_function(void){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_execute_null_command(REDIRECT * param0, int param1, int param2, int param3, int param4, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_execute_pipeline(COMMAND * param0, int param1, int param2, int param3, struct fd_bitmap * param4, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_execute_select_command(void){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_execute_simple_command(void){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym_execute_subshell_builtin_or_function(void){
}
static int __sym_execute_until_command(void){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_execute_while_command(void){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_execute_while_or_until(void){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_execve(const char * param0, char * param1[], char * param2[], ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym_exit(int param0, ...){
}
static struct word_list * __sym_expand_string(char * param0, int param1, ...){
  struct word_list * ret;
ret = malloc(1*sizeof(struct word_list));
ret[0].next = malloc(1*sizeof(struct word_list));
ret[0].next[0].next = malloc(1*sizeof(struct word_list));
// Pointer Type: struct word_list * of ret[0].next[0].next[0].next is set as NULL
ret[0].next[0].next[0].next = 0;
// Pointer Type: struct word_desc * of ret[0].next[0].next[0].word is set as NULL
ret[0].next[0].next[0].word = 0;
ret[0].next[0].word = malloc(1*sizeof(struct word_desc));
// Pointer Type: char * of ret[0].next[0].word[0].word is set as NULL
ret[0].next[0].word[0].word = 0;
__CrestInt(&ret[0].next[0].word[0].flags);
ret[0].word = malloc(1*sizeof(struct word_desc));
ret[0].word[0].word = malloc(3*sizeof(char));
__CrestChar(&ret[0].word[0].word[0]);
__CrestChar(&ret[0].word[0].word[1]);
__CrestChar(&ret[0].word[0].word[2]);
__CrestInt(&ret[0].word[0].flags);
  return ret;
}
static struct word_list * __sym_expand_word_leave_quoted(WORD_DESC * param0, int param1, ...){
  struct word_list * ret;
ret = malloc(1*sizeof(struct word_list));
ret[0].next = malloc(1*sizeof(struct word_list));
ret[0].next[0].next = malloc(1*sizeof(struct word_list));
// Pointer Type: struct word_list * of ret[0].next[0].next[0].next is set as NULL
ret[0].next[0].next[0].next = 0;
// Pointer Type: struct word_desc * of ret[0].next[0].next[0].word is set as NULL
ret[0].next[0].next[0].word = 0;
ret[0].next[0].word = malloc(1*sizeof(struct word_desc));
// Pointer Type: char * of ret[0].next[0].word[0].word is set as NULL
ret[0].next[0].word[0].word = 0;
__CrestInt(&ret[0].next[0].word[0].flags);
ret[0].word = malloc(1*sizeof(struct word_desc));
ret[0].word[0].word = malloc(3*sizeof(char));
__CrestChar(&ret[0].word[0].word[0]);
__CrestChar(&ret[0].word[0].word[1]);
__CrestChar(&ret[0].word[0].word[2]);
__CrestInt(&ret[0].word[0].flags);
  return ret;
}
static struct word_list * __sym_expand_word_no_split(WORD_DESC * param0, int param1, ...){
  struct word_list * ret;
ret = malloc(1*sizeof(struct word_list));
ret[0].next = malloc(1*sizeof(struct word_list));
ret[0].next[0].next = malloc(1*sizeof(struct word_list));
// Pointer Type: struct word_list * of ret[0].next[0].next[0].next is set as NULL
ret[0].next[0].next[0].next = 0;
// Pointer Type: struct word_desc * of ret[0].next[0].next[0].word is set as NULL
ret[0].next[0].next[0].word = 0;
ret[0].next[0].word = malloc(1*sizeof(struct word_desc));
// Pointer Type: char * of ret[0].next[0].word[0].word is set as NULL
ret[0].next[0].word[0].word = 0;
__CrestInt(&ret[0].next[0].word[0].flags);
ret[0].word = malloc(1*sizeof(struct word_desc));
ret[0].word[0].word = malloc(3*sizeof(char));
__CrestChar(&ret[0].word[0].word[0]);
__CrestChar(&ret[0].word[0].word[1]);
__CrestChar(&ret[0].word[0].word[2]);
__CrestInt(&ret[0].word[0].flags);
  return ret;
}
static struct word_list * __sym_expand_words(WORD_LIST * param0, ...){
  struct word_list * ret;
ret = malloc(1*sizeof(struct word_list));
ret[0].next = malloc(1*sizeof(struct word_list));
ret[0].next[0].next = malloc(1*sizeof(struct word_list));
// Pointer Type: struct word_list * of ret[0].next[0].next[0].next is set as NULL
ret[0].next[0].next[0].next = 0;
// Pointer Type: struct word_desc * of ret[0].next[0].next[0].word is set as NULL
ret[0].next[0].next[0].word = 0;
ret[0].next[0].word = malloc(1*sizeof(struct word_desc));
// Pointer Type: char * of ret[0].next[0].word[0].word is set as NULL
ret[0].next[0].word[0].word = 0;
__CrestInt(&ret[0].next[0].word[0].flags);
ret[0].word = malloc(1*sizeof(struct word_desc));
ret[0].word[0].word = malloc(3*sizeof(char));
__CrestChar(&ret[0].word[0].word[0]);
__CrestChar(&ret[0].word[0].word[1]);
__CrestChar(&ret[0].word[0].word[2]);
__CrestInt(&ret[0].word[0].flags);
  return ret;
}
static struct word_list * __sym_expand_words_no_vars(WORD_LIST * param0, ...){
  struct word_list * ret;
ret = malloc(1*sizeof(struct word_list));
ret[0].next = malloc(1*sizeof(struct word_list));
ret[0].next[0].next = malloc(1*sizeof(struct word_list));
// Pointer Type: struct word_list * of ret[0].next[0].next[0].next is set as NULL
ret[0].next[0].next[0].next = 0;
// Pointer Type: struct word_desc * of ret[0].next[0].next[0].word is set as NULL
ret[0].next[0].next[0].word = 0;
ret[0].next[0].word = malloc(1*sizeof(struct word_desc));
// Pointer Type: char * of ret[0].next[0].word[0].word is set as NULL
ret[0].next[0].word[0].word = 0;
__CrestInt(&ret[0].next[0].word[0].flags);
ret[0].word = malloc(1*sizeof(struct word_desc));
ret[0].word[0].word = malloc(3*sizeof(char));
__CrestChar(&ret[0].word[0].word[0]);
__CrestChar(&ret[0].word[0].word[1]);
__CrestChar(&ret[0].word[0].word[2]);
__CrestInt(&ret[0].word[0].flags);
  return ret;
}
static int __sym_expandable_redirection_filename(void){
  int ret;
__CrestInt(&ret);
  return ret;
}
static char * __sym_extract_colon_unit(char * param0, int * param1, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static int __sym_fclose(FILE * param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_fcntl(int param0, int param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static struct _IO_FILE * __sym_fdopen(int param0, const char * param1, ...){
  struct _IO_FILE * ret;
ret = malloc(1*sizeof(struct _IO_FILE));
__CrestInt(&ret[0]._flags);
ret[0]._IO_read_ptr = malloc(3*sizeof(char));
__CrestChar(&ret[0]._IO_read_ptr[0]);
__CrestChar(&ret[0]._IO_read_ptr[1]);
__CrestChar(&ret[0]._IO_read_ptr[2]);
ret[0]._IO_read_end = malloc(3*sizeof(char));
__CrestChar(&ret[0]._IO_read_end[0]);
__CrestChar(&ret[0]._IO_read_end[1]);
__CrestChar(&ret[0]._IO_read_end[2]);
ret[0]._IO_read_base = malloc(3*sizeof(char));
__CrestChar(&ret[0]._IO_read_base[0]);
__CrestChar(&ret[0]._IO_read_base[1]);
__CrestChar(&ret[0]._IO_read_base[2]);
ret[0]._IO_write_base = malloc(3*sizeof(char));
__CrestChar(&ret[0]._IO_write_base[0]);
__CrestChar(&ret[0]._IO_write_base[1]);
__CrestChar(&ret[0]._IO_write_base[2]);
ret[0]._IO_write_ptr = malloc(3*sizeof(char));
__CrestChar(&ret[0]._IO_write_ptr[0]);
__CrestChar(&ret[0]._IO_write_ptr[1]);
__CrestChar(&ret[0]._IO_write_ptr[2]);
ret[0]._IO_write_end = malloc(3*sizeof(char));
__CrestChar(&ret[0]._IO_write_end[0]);
__CrestChar(&ret[0]._IO_write_end[1]);
__CrestChar(&ret[0]._IO_write_end[2]);
ret[0]._IO_buf_base = malloc(3*sizeof(char));
__CrestChar(&ret[0]._IO_buf_base[0]);
__CrestChar(&ret[0]._IO_buf_base[1]);
__CrestChar(&ret[0]._IO_buf_base[2]);
ret[0]._IO_buf_end = malloc(3*sizeof(char));
__CrestChar(&ret[0]._IO_buf_end[0]);
__CrestChar(&ret[0]._IO_buf_end[1]);
__CrestChar(&ret[0]._IO_buf_end[2]);
ret[0]._IO_save_base = malloc(3*sizeof(char));
__CrestChar(&ret[0]._IO_save_base[0]);
__CrestChar(&ret[0]._IO_save_base[1]);
__CrestChar(&ret[0]._IO_save_base[2]);
ret[0]._IO_backup_base = malloc(3*sizeof(char));
__CrestChar(&ret[0]._IO_backup_base[0]);
__CrestChar(&ret[0]._IO_backup_base[1]);
__CrestChar(&ret[0]._IO_backup_base[2]);
ret[0]._IO_save_end = malloc(3*sizeof(char));
__CrestChar(&ret[0]._IO_save_end[0]);
__CrestChar(&ret[0]._IO_save_end[1]);
__CrestChar(&ret[0]._IO_save_end[2]);
ret[0]._markers = malloc(1*sizeof(struct _IO_marker));
ret[0]._markers[0]._next = malloc(1*sizeof(struct _IO_marker));
// Pointer Type: struct _IO_marker * of ret[0]._markers[0]._next[0]._next is set as NULL
ret[0]._markers[0]._next[0]._next = 0;
// Pointer Type: struct _IO_FILE * of ret[0]._markers[0]._next[0]._sbuf is set as NULL
ret[0]._markers[0]._next[0]._sbuf = 0;
__CrestInt(&ret[0]._markers[0]._next[0]._pos);
ret[0]._markers[0]._sbuf = malloc(1*sizeof(struct _IO_FILE));
__CrestInt(&ret[0]._markers[0]._sbuf[0]._flags);
// Pointer Type: char * of ret[0]._markers[0]._sbuf[0]._IO_read_ptr is set as NULL
ret[0]._markers[0]._sbuf[0]._IO_read_ptr = 0;
// Pointer Type: char * of ret[0]._markers[0]._sbuf[0]._IO_read_end is set as NULL
ret[0]._markers[0]._sbuf[0]._IO_read_end = 0;
// Pointer Type: char * of ret[0]._markers[0]._sbuf[0]._IO_read_base is set as NULL
ret[0]._markers[0]._sbuf[0]._IO_read_base = 0;
// Pointer Type: char * of ret[0]._markers[0]._sbuf[0]._IO_write_base is set as NULL
ret[0]._markers[0]._sbuf[0]._IO_write_base = 0;
// Pointer Type: char * of ret[0]._markers[0]._sbuf[0]._IO_write_ptr is set as NULL
ret[0]._markers[0]._sbuf[0]._IO_write_ptr = 0;
// Pointer Type: char * of ret[0]._markers[0]._sbuf[0]._IO_write_end is set as NULL
ret[0]._markers[0]._sbuf[0]._IO_write_end = 0;
// Pointer Type: char * of ret[0]._markers[0]._sbuf[0]._IO_buf_base is set as NULL
ret[0]._markers[0]._sbuf[0]._IO_buf_base = 0;
// Pointer Type: char * of ret[0]._markers[0]._sbuf[0]._IO_buf_end is set as NULL
ret[0]._markers[0]._sbuf[0]._IO_buf_end = 0;
// Pointer Type: char * of ret[0]._markers[0]._sbuf[0]._IO_save_base is set as NULL
ret[0]._markers[0]._sbuf[0]._IO_save_base = 0;
// Pointer Type: char * of ret[0]._markers[0]._sbuf[0]._IO_backup_base is set as NULL
ret[0]._markers[0]._sbuf[0]._IO_backup_base = 0;
// Pointer Type: char * of ret[0]._markers[0]._sbuf[0]._IO_save_end is set as NULL
ret[0]._markers[0]._sbuf[0]._IO_save_end = 0;
// Pointer Type: struct _IO_marker * of ret[0]._markers[0]._sbuf[0]._markers is set as NULL
ret[0]._markers[0]._sbuf[0]._markers = 0;
// Pointer Type: struct _IO_FILE * of ret[0]._markers[0]._sbuf[0]._chain is set as NULL
ret[0]._markers[0]._sbuf[0]._chain = 0;
__CrestInt(&ret[0]._markers[0]._sbuf[0]._fileno);
__CrestInt(&ret[0]._markers[0]._sbuf[0]._flags2);
__CrestLong(&ret[0]._markers[0]._sbuf[0]._old_offset);
__CrestUShort(&ret[0]._markers[0]._sbuf[0]._cur_column);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._vtable_offset);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._shortbuf[0]);
// Pointer Type: void * of ret[0]._markers[0]._sbuf[0]._lock is set as NULL
ret[0]._markers[0]._sbuf[0]._lock = 0;
__CrestLong(&ret[0]._markers[0]._sbuf[0]._offset);
// Pointer Type: void * of ret[0]._markers[0]._sbuf[0].__pad1 is set as NULL
ret[0]._markers[0]._sbuf[0].__pad1 = 0;
// Pointer Type: void * of ret[0]._markers[0]._sbuf[0].__pad2 is set as NULL
ret[0]._markers[0]._sbuf[0].__pad2 = 0;
// Pointer Type: void * of ret[0]._markers[0]._sbuf[0].__pad3 is set as NULL
ret[0]._markers[0]._sbuf[0].__pad3 = 0;
// Pointer Type: void * of ret[0]._markers[0]._sbuf[0].__pad4 is set as NULL
ret[0]._markers[0]._sbuf[0].__pad4 = 0;
__CrestULong(&ret[0]._markers[0]._sbuf[0].__pad5);
__CrestInt(&ret[0]._markers[0]._sbuf[0]._mode);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[0]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[1]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[2]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[3]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[4]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[5]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[6]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[7]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[8]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[9]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[10]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[11]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[12]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[13]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[14]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[15]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[16]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[17]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[18]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[19]);
__CrestInt(&ret[0]._markers[0]._pos);
ret[0]._chain = malloc(1*sizeof(struct _IO_FILE));
__CrestInt(&ret[0]._chain[0]._flags);
ret[0]._chain[0]._IO_read_ptr = malloc(3*sizeof(char));
__CrestChar(&ret[0]._chain[0]._IO_read_ptr[0]);
__CrestChar(&ret[0]._chain[0]._IO_read_ptr[1]);
__CrestChar(&ret[0]._chain[0]._IO_read_ptr[2]);
ret[0]._chain[0]._IO_read_end = malloc(3*sizeof(char));
__CrestChar(&ret[0]._chain[0]._IO_read_end[0]);
__CrestChar(&ret[0]._chain[0]._IO_read_end[1]);
__CrestChar(&ret[0]._chain[0]._IO_read_end[2]);
ret[0]._chain[0]._IO_read_base = malloc(3*sizeof(char));
__CrestChar(&ret[0]._chain[0]._IO_read_base[0]);
__CrestChar(&ret[0]._chain[0]._IO_read_base[1]);
__CrestChar(&ret[0]._chain[0]._IO_read_base[2]);
ret[0]._chain[0]._IO_write_base = malloc(3*sizeof(char));
__CrestChar(&ret[0]._chain[0]._IO_write_base[0]);
__CrestChar(&ret[0]._chain[0]._IO_write_base[1]);
__CrestChar(&ret[0]._chain[0]._IO_write_base[2]);
ret[0]._chain[0]._IO_write_ptr = malloc(3*sizeof(char));
__CrestChar(&ret[0]._chain[0]._IO_write_ptr[0]);
__CrestChar(&ret[0]._chain[0]._IO_write_ptr[1]);
__CrestChar(&ret[0]._chain[0]._IO_write_ptr[2]);
ret[0]._chain[0]._IO_write_end = malloc(3*sizeof(char));
__CrestChar(&ret[0]._chain[0]._IO_write_end[0]);
__CrestChar(&ret[0]._chain[0]._IO_write_end[1]);
__CrestChar(&ret[0]._chain[0]._IO_write_end[2]);
ret[0]._chain[0]._IO_buf_base = malloc(3*sizeof(char));
__CrestChar(&ret[0]._chain[0]._IO_buf_base[0]);
__CrestChar(&ret[0]._chain[0]._IO_buf_base[1]);
__CrestChar(&ret[0]._chain[0]._IO_buf_base[2]);
ret[0]._chain[0]._IO_buf_end = malloc(3*sizeof(char));
__CrestChar(&ret[0]._chain[0]._IO_buf_end[0]);
__CrestChar(&ret[0]._chain[0]._IO_buf_end[1]);
__CrestChar(&ret[0]._chain[0]._IO_buf_end[2]);
ret[0]._chain[0]._IO_save_base = malloc(3*sizeof(char));
__CrestChar(&ret[0]._chain[0]._IO_save_base[0]);
__CrestChar(&ret[0]._chain[0]._IO_save_base[1]);
__CrestChar(&ret[0]._chain[0]._IO_save_base[2]);
ret[0]._chain[0]._IO_backup_base = malloc(3*sizeof(char));
__CrestChar(&ret[0]._chain[0]._IO_backup_base[0]);
__CrestChar(&ret[0]._chain[0]._IO_backup_base[1]);
__CrestChar(&ret[0]._chain[0]._IO_backup_base[2]);
ret[0]._chain[0]._IO_save_end = malloc(3*sizeof(char));
__CrestChar(&ret[0]._chain[0]._IO_save_end[0]);
__CrestChar(&ret[0]._chain[0]._IO_save_end[1]);
__CrestChar(&ret[0]._chain[0]._IO_save_end[2]);
ret[0]._chain[0]._markers = malloc(1*sizeof(struct _IO_marker));
// Pointer Type: struct _IO_marker * of ret[0]._chain[0]._markers[0]._next is set as NULL
ret[0]._chain[0]._markers[0]._next = 0;
// Pointer Type: struct _IO_FILE * of ret[0]._chain[0]._markers[0]._sbuf is set as NULL
ret[0]._chain[0]._markers[0]._sbuf = 0;
__CrestInt(&ret[0]._chain[0]._markers[0]._pos);
ret[0]._chain[0]._chain = malloc(1*sizeof(struct _IO_FILE));
__CrestInt(&ret[0]._chain[0]._chain[0]._flags);
// Pointer Type: char * of ret[0]._chain[0]._chain[0]._IO_read_ptr is set as NULL
ret[0]._chain[0]._chain[0]._IO_read_ptr = 0;
// Pointer Type: char * of ret[0]._chain[0]._chain[0]._IO_read_end is set as NULL
ret[0]._chain[0]._chain[0]._IO_read_end = 0;
// Pointer Type: char * of ret[0]._chain[0]._chain[0]._IO_read_base is set as NULL
ret[0]._chain[0]._chain[0]._IO_read_base = 0;
// Pointer Type: char * of ret[0]._chain[0]._chain[0]._IO_write_base is set as NULL
ret[0]._chain[0]._chain[0]._IO_write_base = 0;
// Pointer Type: char * of ret[0]._chain[0]._chain[0]._IO_write_ptr is set as NULL
ret[0]._chain[0]._chain[0]._IO_write_ptr = 0;
// Pointer Type: char * of ret[0]._chain[0]._chain[0]._IO_write_end is set as NULL
ret[0]._chain[0]._chain[0]._IO_write_end = 0;
// Pointer Type: char * of ret[0]._chain[0]._chain[0]._IO_buf_base is set as NULL
ret[0]._chain[0]._chain[0]._IO_buf_base = 0;
// Pointer Type: char * of ret[0]._chain[0]._chain[0]._IO_buf_end is set as NULL
ret[0]._chain[0]._chain[0]._IO_buf_end = 0;
// Pointer Type: char * of ret[0]._chain[0]._chain[0]._IO_save_base is set as NULL
ret[0]._chain[0]._chain[0]._IO_save_base = 0;
// Pointer Type: char * of ret[0]._chain[0]._chain[0]._IO_backup_base is set as NULL
ret[0]._chain[0]._chain[0]._IO_backup_base = 0;
// Pointer Type: char * of ret[0]._chain[0]._chain[0]._IO_save_end is set as NULL
ret[0]._chain[0]._chain[0]._IO_save_end = 0;
// Pointer Type: struct _IO_marker * of ret[0]._chain[0]._chain[0]._markers is set as NULL
ret[0]._chain[0]._chain[0]._markers = 0;
// Pointer Type: struct _IO_FILE * of ret[0]._chain[0]._chain[0]._chain is set as NULL
ret[0]._chain[0]._chain[0]._chain = 0;
__CrestInt(&ret[0]._chain[0]._chain[0]._fileno);
__CrestInt(&ret[0]._chain[0]._chain[0]._flags2);
__CrestLong(&ret[0]._chain[0]._chain[0]._old_offset);
__CrestUShort(&ret[0]._chain[0]._chain[0]._cur_column);
__CrestChar(&ret[0]._chain[0]._chain[0]._vtable_offset);
__CrestChar(&ret[0]._chain[0]._chain[0]._shortbuf[0]);
// Pointer Type: void * of ret[0]._chain[0]._chain[0]._lock is set as NULL
ret[0]._chain[0]._chain[0]._lock = 0;
__CrestLong(&ret[0]._chain[0]._chain[0]._offset);
// Pointer Type: void * of ret[0]._chain[0]._chain[0].__pad1 is set as NULL
ret[0]._chain[0]._chain[0].__pad1 = 0;
// Pointer Type: void * of ret[0]._chain[0]._chain[0].__pad2 is set as NULL
ret[0]._chain[0]._chain[0].__pad2 = 0;
// Pointer Type: void * of ret[0]._chain[0]._chain[0].__pad3 is set as NULL
ret[0]._chain[0]._chain[0].__pad3 = 0;
// Pointer Type: void * of ret[0]._chain[0]._chain[0].__pad4 is set as NULL
ret[0]._chain[0]._chain[0].__pad4 = 0;
__CrestULong(&ret[0]._chain[0]._chain[0].__pad5);
__CrestInt(&ret[0]._chain[0]._chain[0]._mode);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[0]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[1]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[2]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[3]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[4]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[5]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[6]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[7]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[8]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[9]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[10]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[11]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[12]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[13]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[14]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[15]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[16]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[17]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[18]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[19]);
__CrestInt(&ret[0]._chain[0]._fileno);
__CrestInt(&ret[0]._chain[0]._flags2);
__CrestLong(&ret[0]._chain[0]._old_offset);
__CrestUShort(&ret[0]._chain[0]._cur_column);
__CrestChar(&ret[0]._chain[0]._vtable_offset);
__CrestChar(&ret[0]._chain[0]._shortbuf[0]);
// Pointee type 'void' is an incomplete type
ret[0]._chain[0]._lock = 0;
__CrestLong(&ret[0]._chain[0]._offset);
// Pointee type 'void' is an incomplete type
ret[0]._chain[0].__pad1 = 0;
// Pointee type 'void' is an incomplete type
ret[0]._chain[0].__pad2 = 0;
// Pointee type 'void' is an incomplete type
ret[0]._chain[0].__pad3 = 0;
// Pointee type 'void' is an incomplete type
ret[0]._chain[0].__pad4 = 0;
__CrestULong(&ret[0]._chain[0].__pad5);
__CrestInt(&ret[0]._chain[0]._mode);
__CrestChar(&ret[0]._chain[0]._unused2[0]);
__CrestChar(&ret[0]._chain[0]._unused2[1]);
__CrestChar(&ret[0]._chain[0]._unused2[2]);
__CrestChar(&ret[0]._chain[0]._unused2[3]);
__CrestChar(&ret[0]._chain[0]._unused2[4]);
__CrestChar(&ret[0]._chain[0]._unused2[5]);
__CrestChar(&ret[0]._chain[0]._unused2[6]);
__CrestChar(&ret[0]._chain[0]._unused2[7]);
__CrestChar(&ret[0]._chain[0]._unused2[8]);
__CrestChar(&ret[0]._chain[0]._unused2[9]);
__CrestChar(&ret[0]._chain[0]._unused2[10]);
__CrestChar(&ret[0]._chain[0]._unused2[11]);
__CrestChar(&ret[0]._chain[0]._unused2[12]);
__CrestChar(&ret[0]._chain[0]._unused2[13]);
__CrestChar(&ret[0]._chain[0]._unused2[14]);
__CrestChar(&ret[0]._chain[0]._unused2[15]);
__CrestChar(&ret[0]._chain[0]._unused2[16]);
__CrestChar(&ret[0]._chain[0]._unused2[17]);
__CrestChar(&ret[0]._chain[0]._unused2[18]);
__CrestChar(&ret[0]._chain[0]._unused2[19]);
__CrestInt(&ret[0]._fileno);
__CrestInt(&ret[0]._flags2);
__CrestLong(&ret[0]._old_offset);
__CrestUShort(&ret[0]._cur_column);
__CrestChar(&ret[0]._vtable_offset);
__CrestChar(&ret[0]._shortbuf[0]);
// Pointee type 'void' is an incomplete type
ret[0]._lock = 0;
__CrestLong(&ret[0]._offset);
// Pointee type 'void' is an incomplete type
ret[0].__pad1 = 0;
// Pointee type 'void' is an incomplete type
ret[0].__pad2 = 0;
// Pointee type 'void' is an incomplete type
ret[0].__pad3 = 0;
// Pointee type 'void' is an incomplete type
ret[0].__pad4 = 0;
__CrestULong(&ret[0].__pad5);
__CrestInt(&ret[0]._mode);
__CrestChar(&ret[0]._unused2[0]);
__CrestChar(&ret[0]._unused2[1]);
__CrestChar(&ret[0]._unused2[2]);
__CrestChar(&ret[0]._unused2[3]);
__CrestChar(&ret[0]._unused2[4]);
__CrestChar(&ret[0]._unused2[5]);
__CrestChar(&ret[0]._unused2[6]);
__CrestChar(&ret[0]._unused2[7]);
__CrestChar(&ret[0]._unused2[8]);
__CrestChar(&ret[0]._unused2[9]);
__CrestChar(&ret[0]._unused2[10]);
__CrestChar(&ret[0]._unused2[11]);
__CrestChar(&ret[0]._unused2[12]);
__CrestChar(&ret[0]._unused2[13]);
__CrestChar(&ret[0]._unused2[14]);
__CrestChar(&ret[0]._unused2[15]);
__CrestChar(&ret[0]._unused2[16]);
__CrestChar(&ret[0]._unused2[17]);
__CrestChar(&ret[0]._unused2[18]);
__CrestChar(&ret[0]._unused2[19]);
  return ret;
}
static int __sym_ferror(FILE * param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_fflush(FILE * param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym_file_error(char * param0, ...){
}
static int __sym_file_status(char * param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static char * __sym_find_absolute_program(void){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static struct variable * __sym_find_function(char * param0, ...){
  struct variable * ret;
ret = malloc(1*sizeof(struct variable));
ret[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].name[0]);
__CrestChar(&ret[0].name[1]);
__CrestChar(&ret[0].name[2]);
ret[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].value[0]);
__CrestChar(&ret[0].value[1]);
__CrestChar(&ret[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].dynamic_value is not supported
ret[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].assign_func is not supported
ret[0].assign_func = 0;
__CrestInt(&ret[0].attributes);
__CrestInt(&ret[0].context);
ret[0].prev_context = malloc(1*sizeof(struct variable));
ret[0].prev_context[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].name[0]);
__CrestChar(&ret[0].prev_context[0].name[1]);
__CrestChar(&ret[0].prev_context[0].name[2]);
ret[0].prev_context[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].value[0]);
__CrestChar(&ret[0].prev_context[0].value[1]);
__CrestChar(&ret[0].prev_context[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].context);
ret[0].prev_context[0].prev_context = malloc(1*sizeof(struct variable));
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].name is set as NULL
ret[0].prev_context[0].prev_context[0].name = 0;
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].value is set as NULL
ret[0].prev_context[0].prev_context[0].value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].prev_context[0].context);
// Pointer Type: struct variable * of ret[0].prev_context[0].prev_context[0].prev_context is set as NULL
ret[0].prev_context[0].prev_context[0].prev_context = 0;
  return ret;
}
static char * __sym_find_hashed_filename(void){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static char * __sym_find_in_path_element(void){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static void * __sym_find_shell_builtin(void){
  void * ret;
// Function pointer type: void * of ret is not supported
ret = 0;
  return ret;
}
static void * __sym_find_special_builtin(void){
  void * ret;
// Function pointer type: void * of ret is not supported
ret = 0;
  return ret;
}
static struct variable * __sym_find_tempenv_variable(char * param0, ...){
  struct variable * ret;
ret = malloc(1*sizeof(struct variable));
ret[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].name[0]);
__CrestChar(&ret[0].name[1]);
__CrestChar(&ret[0].name[2]);
ret[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].value[0]);
__CrestChar(&ret[0].value[1]);
__CrestChar(&ret[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].dynamic_value is not supported
ret[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].assign_func is not supported
ret[0].assign_func = 0;
__CrestInt(&ret[0].attributes);
__CrestInt(&ret[0].context);
ret[0].prev_context = malloc(1*sizeof(struct variable));
ret[0].prev_context[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].name[0]);
__CrestChar(&ret[0].prev_context[0].name[1]);
__CrestChar(&ret[0].prev_context[0].name[2]);
ret[0].prev_context[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].value[0]);
__CrestChar(&ret[0].prev_context[0].value[1]);
__CrestChar(&ret[0].prev_context[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].context);
ret[0].prev_context[0].prev_context = malloc(1*sizeof(struct variable));
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].name is set as NULL
ret[0].prev_context[0].prev_context[0].name = 0;
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].value is set as NULL
ret[0].prev_context[0].prev_context[0].value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].prev_context[0].context);
// Pointer Type: struct variable * of ret[0].prev_context[0].prev_context[0].prev_context is set as NULL
ret[0].prev_context[0].prev_context[0].prev_context = 0;
  return ret;
}
static char * __sym_find_user_command(char * param0, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static char * __sym_find_user_command_in_path(void){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static char * __sym_find_user_command_internal(void){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static struct variable * __sym_find_variable_internal(char * param0, int param1, ...){
  struct variable * ret;
ret = malloc(1*sizeof(struct variable));
ret[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].name[0]);
__CrestChar(&ret[0].name[1]);
__CrestChar(&ret[0].name[2]);
ret[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].value[0]);
__CrestChar(&ret[0].value[1]);
__CrestChar(&ret[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].dynamic_value is not supported
ret[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].assign_func is not supported
ret[0].assign_func = 0;
__CrestInt(&ret[0].attributes);
__CrestInt(&ret[0].context);
ret[0].prev_context = malloc(1*sizeof(struct variable));
ret[0].prev_context[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].name[0]);
__CrestChar(&ret[0].prev_context[0].name[1]);
__CrestChar(&ret[0].prev_context[0].name[2]);
ret[0].prev_context[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].value[0]);
__CrestChar(&ret[0].prev_context[0].value[1]);
__CrestChar(&ret[0].prev_context[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].context);
ret[0].prev_context[0].prev_context = malloc(1*sizeof(struct variable));
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].name is set as NULL
ret[0].prev_context[0].prev_context[0].name = 0;
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].value is set as NULL
ret[0].prev_context[0].prev_context[0].value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].prev_context[0].context);
// Pointer Type: struct variable * of ret[0].prev_context[0].prev_context[0].prev_context is set as NULL
ret[0].prev_context[0].prev_context[0].prev_context = 0;
  return ret;
}
static void __sym_fix_assignment_words(WORD_LIST * param0, ...){
}
static int __sym_fnmatch(void){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_fprintf(FILE * param0, const char * param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym_free(void * param0, ...){
}
static unsigned long __sym_fwrite(const void * param0, size_t param1, size_t param2, FILE * param3, ...){
  unsigned long ret;
__CrestULong(&ret);
  return ret;
}
static char * __sym_get_next_path_element(char * param0, int * param1, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static char * __sym_get_string_value(char * param0, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static int __sym_getdtablesize(void){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_getpid(void){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_getrusage(__rusage_who_t param0, struct rusage * param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_gettimeofday(struct timeval * param0, struct timezone * param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_group_member(void){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym_indent(int param0, int param1, ...){
}
static void __sym_internal_error(const char * param0, ...){
}
static int __sym_is_directory(char * param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static char * __sym_itos(int param0, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static void __sym_jump_to_top_level(int param0, ...){
}
static void __sym_kill_current_pipeline(void){
}
static int __sym_list_length(void){
  int ret;
__CrestInt(&ret);
  return ret;
}
static struct word_desc * __sym_make_bare_word(char * param0, ...){
  struct word_desc * ret;
ret = malloc(1*sizeof(struct word_desc));
ret[0].word = malloc(3*sizeof(char));
__CrestChar(&ret[0].word[0]);
__CrestChar(&ret[0].word[1]);
__CrestChar(&ret[0].word[2]);
__CrestInt(&ret[0].flags);
  return ret;
}
static int __sym_make_child(char * param0, int param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static char * __sym_make_command_string(COMMAND * param0, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static char * __sym_make_full_pathname(char * param0, char * param1, int param2, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static struct redirect * __sym_make_redirection(int param0, enum r_instruction param1, REDIRECTEE param2, ...){
  struct redirect * ret;
ret = malloc(1*sizeof(struct redirect));
ret[0].next = malloc(1*sizeof(struct redirect));
ret[0].next[0].next = malloc(1*sizeof(struct redirect));
// Pointer Type: struct redirect * of ret[0].next[0].next[0].next is set as NULL
ret[0].next[0].next[0].next = 0;
__CrestInt(&ret[0].next[0].next[0].redirector);
__CrestInt(&ret[0].next[0].next[0].flags);
__CrestInt(&ret[0].next[0].next[0].instruction);
// Type: REDIRECTEE of ret[0].next[0].next[0].redirectee is not supported
// Pointer Type: char * of ret[0].next[0].next[0].here_doc_eof is set as NULL
ret[0].next[0].next[0].here_doc_eof = 0;
__CrestInt(&ret[0].next[0].redirector);
__CrestInt(&ret[0].next[0].flags);
__CrestInt(&ret[0].next[0].instruction);
// Type: REDIRECTEE of ret[0].next[0].redirectee is not supported
ret[0].next[0].here_doc_eof = malloc(3*sizeof(char));
__CrestChar(&ret[0].next[0].here_doc_eof[0]);
__CrestChar(&ret[0].next[0].here_doc_eof[1]);
__CrestChar(&ret[0].next[0].here_doc_eof[2]);
__CrestInt(&ret[0].redirector);
__CrestInt(&ret[0].flags);
__CrestInt(&ret[0].instruction);
// Type: REDIRECTEE of ret[0].redirectee is not supported
ret[0].here_doc_eof = malloc(3*sizeof(char));
__CrestChar(&ret[0].here_doc_eof[0]);
__CrestChar(&ret[0].here_doc_eof[1]);
__CrestChar(&ret[0].here_doc_eof[2]);
  return ret;
}
static struct word_list * __sym_make_word_list(WORD_DESC * param0, WORD_LIST * param1, ...){
  struct word_list * ret;
ret = malloc(1*sizeof(struct word_list));
ret[0].next = malloc(1*sizeof(struct word_list));
ret[0].next[0].next = malloc(1*sizeof(struct word_list));
// Pointer Type: struct word_list * of ret[0].next[0].next[0].next is set as NULL
ret[0].next[0].next[0].next = 0;
// Pointer Type: struct word_desc * of ret[0].next[0].next[0].word is set as NULL
ret[0].next[0].next[0].word = 0;
ret[0].next[0].word = malloc(1*sizeof(struct word_desc));
// Pointer Type: char * of ret[0].next[0].word[0].word is set as NULL
ret[0].next[0].word[0].word = 0;
__CrestInt(&ret[0].next[0].word[0].flags);
ret[0].word = malloc(1*sizeof(struct word_desc));
ret[0].word[0].word = malloc(3*sizeof(char));
__CrestChar(&ret[0].word[0].word[0]);
__CrestChar(&ret[0].word[0].word[1]);
__CrestChar(&ret[0].word[0].word[2]);
__CrestInt(&ret[0].word[0].flags);
  return ret;
}
static void __sym_maybe_make_export_env(void){
}
static void __sym_merge_builtin_env(void){
}
static void __sym_merge_temporary_env(void){
}
static int __sym_mkfmt(char * param0, int param1, int param2, long param3, int param4, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static struct fd_bitmap * __sym_new_fd_bitmap(long param0, ...){
  struct fd_bitmap * ret;
ret = malloc(1*sizeof(struct fd_bitmap));
__CrestLong(&ret[0].size);
ret[0].bitmap = malloc(3*sizeof(char));
__CrestChar(&ret[0].bitmap[0]);
__CrestChar(&ret[0].bitmap[1]);
__CrestChar(&ret[0].bitmap[2]);
  return ret;
}
static int __sym_open(const char * param0, int param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_pipe(int param0[], ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym_print_formatted_time(FILE * param0, char * param1, long param2, int param3, long param4, int param5, long param6, int param7, int param8, ...){
}
static int __sym_print_index_and_element(int param0, int param1, WORD_LIST * param2, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym_print_select_list(WORD_LIST * param0, int param1, int param2, int param3, ...){
}
static void __sym_print_simple_command(SIMPLE_COM * param0, ...){
}
static void __sym_programming_error(const char * param0, ...){
}
static void __sym_push_context(void){
}
static void __sym_put_command_name_into_env(char * param0, ...){
}
static void __sym_put_gnu_argv_flags_into_env(int param0, char * param1, ...){
}
static int __sym_putchar(int param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static char * __sym_quote_string_for_globbing(char * param0, int param1, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static long __sym_read(int param0, void * param1, size_t param2, ...){
  long ret;
__CrestLong(&ret);
  return ret;
}
static int __sym_read_builtin(void){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym_reap_dead_jobs(void){
}
static void __sym_redirection_error(REDIRECT * param0, int param1, ...){
}
static char * __sym_redirection_expand(WORD_DESC * param0, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static void __sym_remember_args(void){
}
static void __sym_remember_filename(void){
}
static void __sym_remove_hashed_filename(void){
}
static void __sym_reset_terminating_signals(void){
}
static void __sym_restore_default_signal(int param0, ...){
}
static void __sym_restore_original_signals(void){
}
static void __sym_run_debug_trap(void){
}
static int __sym_run_exit_trap(void){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym_run_pending_traps(void){
}
static void __sym_run_unwind_frame(void){
}
static int __sym_same_file(void){
  int ret;
__CrestInt(&ret);
  return ret;
}
static char * __sym_search_for_command(char * param0, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static char * __sym_select_query(WORD_LIST * param0, int param1, char * param2, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static void __sym_set_sigchld_handler(void){
}
static void * __sym_set_sigint_handler(void){
  void * ret;
// Function pointer type: void * of ret is not supported
ret = 0;
  return ret;
}
static void * __sym_set_signal_handler(void){
  void * ret;
// Function pointer type: void * of ret is not supported
ret = 0;
  return ret;
}
static void __sym_set_signal_ignored(int param0, ...){
}
static void __sym_setup_async_signals(void){
}
static int __sym_shell_control_structure(enum command_type param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_shell_execve(char * param0, char ** param1, char ** param2, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_sigaddset(sigset_t * param0, int param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_sigemptyset(sigset_t * param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym_siglongjmp(sigjmp_buf param0[], int param1, ...){
}
static int __sym_signal_is_ignored(int param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_signal_is_trapped(int param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_sigprocmask(int param0, const sigset_t * param1, sigset_t * param2, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_sprintf(char * param0, const char * param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_start_job(int param0, int param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_stat(const char * param0, struct stat * param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_stop_pipeline(int param0, COMMAND * param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static char * __sym_strcpy(char * param0, const char * param1, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static char * __sym_strerror(int param0, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static char * __sym_strindex(char * param0, char * param1, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static char * __sym_string_list(WORD_LIST * param0, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static unsigned long __sym_strlen(const char * param0, ...){
  unsigned long ret;
__CrestULong(&ret);
  return ret;
}
static int __sym_strncmp(const char * param0, const char * param1, size_t param2, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static double __sym_strtod(const char * param0, char ** param1, ...){
  double ret;
// Floting Type: double of ret is not supported
ret = 0;
  return ret;
}
static long __sym_strtol(const char * param0, char ** param1, int param2, ...){
  long ret;
__CrestLong(&ret);
  return ret;
}
static long long __sym_strtoll(const char * param0, char ** param1, int param2, ...){
  long long ret;
__CrestLongLong(&ret);
  return ret;
}
static void __sym_sys_error(const char * param0, ...){
}
static void __sym_terminate_current_pipeline(void){
}
static void __sym_throw_to_top_level(void){
}
static int __sym_time_command(void){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_timeval_to_cpu(struct timeval * param0, struct timeval * param1, struct timeval * param2, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym_timeval_to_secs(void){
}
static int __sym_unbind_args(void){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_unlink(const char * param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym_unlink_fifo_list(void){
}
static void __sym_unwind_protect_var(void){
}
static int __sym_vfprintf(FILE * param0, const char * param1, __gnuc_va_list param2, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_wait_for(pid_t param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym_without_job_control(void){
}
static char ** __sym_word_list_to_argv(WORD_LIST * param0, int param1, int param2, int * param3, ...){
  char ** ret;
ret = malloc(1*sizeof(char *));
ret[0] = malloc(3*sizeof(char));
__CrestChar(&ret[0][0]);
__CrestChar(&ret[0][1]);
__CrestChar(&ret[0][2]);
  return ret;
}
static long __sym_write(int param0, const void * param1, size_t param2, ...){
  long ret;
__CrestLong(&ret);
  return ret;
}
static int __sym_write_here_document(int param0, WORD_DESC * param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym_xbcopy(char * param0, char * param1, int param2, ...){
}
static char * __sym_xmalloc(unsigned long param0, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static char * __sym_xrealloc(void * param0, size_t param1, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static void __sym_xtrace_print_word_list(WORD_LIST * param0, ...){
}
#endif
int main(){
    time_command_driver();
   return 0;
}
