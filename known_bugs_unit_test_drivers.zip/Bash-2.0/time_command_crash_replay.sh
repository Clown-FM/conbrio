#!/bin/bash
cp time_command_crash_input input
./time_command_driver
rm -f input
