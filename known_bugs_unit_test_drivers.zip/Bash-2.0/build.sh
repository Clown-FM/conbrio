#!/bin/bash

gcc -g -w -o set_shellopts_driver set_shellopts_driver.c -lcrestr -L../lib -D__H_
gcc -g -w -o time_command_driver time_command_driver.c -lcrestr -L../lib -D__H_
gcc -g -w -o disown_builtin1_driver disown_builtin1_driver.c -lcrestr -L../lib -D__H_
gcc -g -w -o disown_builtin2_driver disown_builtin2_driver.c -lcrestr -L../lib -D__H_
gcc -g -w -o initialize_shell_variables_driver initialize_shell_variables_driver.c -lcrestr -L../lib -D__H_


