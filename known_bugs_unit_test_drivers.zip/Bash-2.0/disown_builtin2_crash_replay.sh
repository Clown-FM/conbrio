#!/bin/bash
cp disown_builtin2_crash_input input
./disown_builtin2_driver
rm -f input
