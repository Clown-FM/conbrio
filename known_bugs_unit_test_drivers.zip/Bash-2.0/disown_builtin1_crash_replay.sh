#!/bin/bash
cp disown_builtin1_crash_input input
./disown_builtin1_driver
rm -f input
