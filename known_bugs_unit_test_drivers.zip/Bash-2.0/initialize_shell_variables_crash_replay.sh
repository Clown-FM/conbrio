#!/bin/bash
cp initialize_shell_variables_crash_input input
./initialize_shell_variables_driver
rm -f input
