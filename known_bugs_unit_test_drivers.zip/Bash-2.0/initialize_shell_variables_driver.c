#include <assert.h>











































typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;







typedef long int __quad_t;
typedef unsigned long int __u_quad_t;





typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned long int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef long int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef __quad_t *__qaddr_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;




typedef __loff_t loff_t;



typedef __ino_t ino_t;

typedef __dev_t dev_t;




typedef __gid_t gid_t;




typedef __mode_t mode_t;




typedef __nlink_t nlink_t;




typedef __uid_t uid_t;





typedef __off_t off_t;

typedef __pid_t pid_t;





typedef __id_t id_t;




typedef __ssize_t ssize_t;





typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;





typedef __key_t key_t;





typedef __clock_t clock_t;






typedef __time_t time_t;




typedef __clockid_t clockid_t;

typedef __timer_t timer_t;




typedef long unsigned int size_t;


#ifdef __H_

typedef unsigned long int ulong;
typedef unsigned short int ushort;
typedef unsigned int uint;

typedef int int8_t __attribute__ ((__mode__ (__QI__)));
typedef int int16_t __attribute__ ((__mode__ (__HI__)));
typedef int int32_t __attribute__ ((__mode__ (__SI__)));
typedef int int64_t __attribute__ ((__mode__ (__DI__)));


typedef unsigned int u_int8_t __attribute__ ((__mode__ (__QI__)));
typedef unsigned int u_int16_t __attribute__ ((__mode__ (__HI__)));
typedef unsigned int u_int32_t __attribute__ ((__mode__ (__SI__)));
typedef unsigned int u_int64_t __attribute__ ((__mode__ (__DI__)));

typedef int register_t __attribute__ ((__mode__ (__word__)));



















static __inline unsigned int
__bswap_32 (unsigned int __bsx)
{
  return __builtin_bswap32 (__bsx);
}

static __inline __uint64_t
__bswap_64 (__uint64_t __bsx)
{
  return __builtin_bswap64 (__bsx);
}















typedef int __sig_atomic_t;




typedef struct
  {
    unsigned long int __val[(1024 / (8 * sizeof (unsigned long int)))];
  } __sigset_t;




typedef __sigset_t sigset_t;







struct timespec
  {
    __time_t tv_sec;
    __syscall_slong_t tv_nsec;
  };




struct timeval
  {
    __time_t tv_sec;
    __suseconds_t tv_usec;
  };



typedef __suseconds_t suseconds_t;





typedef long int __fd_mask;

typedef struct
  {






    __fd_mask __fds_bits[1024 / (8 * (int) sizeof (__fd_mask))];


  } fd_set;






typedef __fd_mask fd_mask;



/*extern*/ int select (int __nfds, fd_set *__restrict __readfds,
     fd_set *__restrict __writefds,
     fd_set *__restrict __exceptfds,
     struct timeval *__restrict __timeout);

/*extern*/ int pselect (int __nfds, fd_set *__restrict __readfds,
      fd_set *__restrict __writefds,
      fd_set *__restrict __exceptfds,
      const struct timespec *__restrict __timeout,
      const __sigset_t *__restrict __sigmask);









__extension__
/*extern*/ unsigned int gnu_dev_major (unsigned long long int __dev)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
__extension__
/*extern*/ unsigned int gnu_dev_minor (unsigned long long int __dev)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
__extension__
/*extern*/ unsigned long long int gnu_dev_makedev (unsigned int __major,
            unsigned int __minor)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


__extension__ /*extern*/ __inline __attribute__ ((__gnu_inline__)) __attribute__ ((__const__)) unsigned int
__attribute__ ((__nothrow__ , __leaf__)) gnu_dev_major (unsigned long long int __dev)
{
  return ((__dev >> 8) & 0xfff) | ((unsigned int) (__dev >> 32) & ~0xfff);
}

__extension__ /*extern*/ __inline __attribute__ ((__gnu_inline__)) __attribute__ ((__const__)) unsigned int
__attribute__ ((__nothrow__ , __leaf__)) gnu_dev_minor (unsigned long long int __dev)
{
  return (__dev & 0xff) | ((unsigned int) (__dev >> 12) & ~0xff);
}

__extension__ /*extern*/ __inline __attribute__ ((__gnu_inline__)) __attribute__ ((__const__)) unsigned long long int
__attribute__ ((__nothrow__ , __leaf__)) gnu_dev_makedev (unsigned int __major, unsigned int __minor)
{
  return ((__minor & 0xff) | ((__major & 0xfff) << 8)
   | (((unsigned long long int) (__minor & ~0xff)) << 12)
   | (((unsigned long long int) (__major & ~0xfff)) << 32));
}








typedef __blksize_t blksize_t;






typedef __blkcnt_t blkcnt_t;



typedef __fsblkcnt_t fsblkcnt_t;



typedef __fsfilcnt_t fsfilcnt_t;






typedef unsigned long int pthread_t;


union pthread_attr_t
{
  char __size[56];
  long int __align;
};

typedef union pthread_attr_t pthread_attr_t;





typedef struct __pthread_internal_list
{
  struct __pthread_internal_list *__prev;
  struct __pthread_internal_list *__next;
} __pthread_list_t;

typedef union
{
  struct __pthread_mutex_s
  {
    int __lock;
    unsigned int __count;
    int __owner;

    unsigned int __nusers;



    int __kind;

    short __spins;
    short __elision;
    __pthread_list_t __list;

  } __data;
  char __size[40];
  long int __align;
} pthread_mutex_t;

typedef union
{
  char __size[4];
  int __align;
} pthread_mutexattr_t;




typedef union
{
  struct
  {
    int __lock;
    unsigned int __futex;
    __extension__ unsigned long long int __total_seq;
    __extension__ unsigned long long int __wakeup_seq;
    __extension__ unsigned long long int __woken_seq;
    void *__mutex;
    unsigned int __nwaiters;
    unsigned int __broadcast_seq;
  } __data;
  char __size[48];
  __extension__ long long int __align;
} pthread_cond_t;

typedef union
{
  char __size[4];
  int __align;
} pthread_condattr_t;



typedef unsigned int pthread_key_t;



typedef int pthread_once_t;





typedef union
{

  struct
  {
    int __lock;
    unsigned int __nr_readers;
    unsigned int __readers_wakeup;
    unsigned int __writer_wakeup;
    unsigned int __nr_readers_queued;
    unsigned int __nr_writers_queued;
    int __writer;
    int __shared;
    unsigned long int __pad1;
    unsigned long int __pad2;


    unsigned int __flags;

  } __data;

  char __size[56];
  long int __align;
} pthread_rwlock_t;

typedef union
{
  char __size[8];
  long int __align;
} pthread_rwlockattr_t;





typedef volatile int pthread_spinlock_t;




typedef union
{
  char __size[32];
  long int __align;
} pthread_barrier_t;

typedef union
{
  char __size[4];
  int __align;
} pthread_barrierattr_t;

















struct stat
  {
    __dev_t st_dev;




    __ino_t st_ino;







    __nlink_t st_nlink;
    __mode_t st_mode;

    __uid_t st_uid;
    __gid_t st_gid;

    int __pad0;

    __dev_t st_rdev;




    __off_t st_size;



    __blksize_t st_blksize;

    __blkcnt_t st_blocks;

    struct timespec st_atim;
    struct timespec st_mtim;
    struct timespec st_ctim;

    __syscall_slong_t __glibc_reserved[3];

  };


/*extern*/ int stat (const char *__restrict __file,
   struct stat *__restrict __buf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



/*extern*/ int fstat (int __fd, struct stat *__buf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

/*extern*/ int fstatat (int __fd, const char *__restrict __file,
      struct stat *__restrict __buf, int __flag)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));

/*extern*/ int lstat (const char *__restrict __file,
    struct stat *__restrict __buf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ int chmod (const char *__file, __mode_t __mode)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





/*extern*/ int lchmod (const char *__file, __mode_t __mode)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));




/*extern*/ int fchmod (int __fd, __mode_t __mode) __attribute__ ((__nothrow__ , __leaf__));





/*extern*/ int fchmodat (int __fd, const char *__file, __mode_t __mode,
       int __flag)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) ;






/*extern*/ __mode_t umask (__mode_t __mask) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ int mkdir (const char *__path, __mode_t __mode)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





/*extern*/ int mkdirat (int __fd, const char *__path, __mode_t __mode)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));






/*extern*/ int mknod (const char *__path, __mode_t __mode, __dev_t __dev)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





/*extern*/ int mknodat (int __fd, const char *__path, __mode_t __mode,
      __dev_t __dev) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));





/*extern*/ int mkfifo (const char *__path, __mode_t __mode)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





/*extern*/ int mkfifoat (int __fd, const char *__path, __mode_t __mode)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));





/*extern*/ int utimensat (int __fd, const char *__path,
        const struct timespec __times[2],
        int __flags)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));




/*extern*/ int futimens (int __fd, const struct timespec __times[2]) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ int __fxstat (int __ver, int __fildes, struct stat *__stat_buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
/*extern*/ int __xstat (int __ver, const char *__filename,
      struct stat *__stat_buf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));
/*extern*/ int __lxstat (int __ver, const char *__filename,
       struct stat *__stat_buf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));
/*extern*/ int __fxstatat (int __ver, int __fildes, const char *__filename,
         struct stat *__stat_buf, int __flag)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4)));

/*extern*/ int __xmknod (int __ver, const char *__path, __mode_t __mode,
       __dev_t *__dev) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)));

/*extern*/ int __xmknodat (int __ver, int __fd, const char *__path,
         __mode_t __mode, __dev_t *__dev)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 5)));




static int __sym___xstat(int param0, const char * param1, struct stat * param2, ...);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) stat (const char *__path, struct stat *__statbuf)
{
  return __sym___xstat (1, __path, __statbuf);
}


static int __sym___lxstat(int param0, const char * param1, struct stat * param2, ...);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) lstat (const char *__path, struct stat *__statbuf)
{
  return __sym___lxstat (1, __path, __statbuf);
}


static int __sym___fxstat(int param0, int param1, struct stat * param2, ...);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) fstat (int __fd, struct stat *__statbuf)
{
  return __sym___fxstat (1, __fd, __statbuf);
}


static int __sym___fxstatat(int param0, int param1, const char * param2, struct stat * param3, int param4, ...);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) fstatat (int __fd, const char *__filename, struct stat *__statbuf, int __flag)

{
  return __sym___fxstatat (1, __fd, __filename, __statbuf, __flag);
}



static int __sym___xmknod(int param0, const char * param1, __mode_t param2, __dev_t * param3, ...);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) mknod (const char *__path, __mode_t __mode, __dev_t __dev)
{
  return __sym___xmknod (0, __path, __mode, &__dev);
}



static int __sym___xmknodat(int param0, int param1, const char * param2, __mode_t param3, __dev_t * param4, ...);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) mknodat (int __fd, const char *__path, __mode_t __mode, __dev_t __dev)

{
  return __sym___xmknodat (0, __fd, __path, __mode, &__dev);
}
























typedef __useconds_t useconds_t;

typedef __intptr_t intptr_t;






typedef __socklen_t socklen_t;

/*extern*/ int access (const char *__name, int __type) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

/*extern*/ int faccessat (int __fd, const char *__file, int __type, int __flag)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) ;

/*extern*/ __off_t lseek (int __fd, __off_t __offset, int __whence) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ int close (int __fd);






/*extern*/ ssize_t read (int __fd, void *__buf, size_t __nbytes) ;





/*extern*/ ssize_t write (int __fd, const void *__buf, size_t __n) ;

/*extern*/ ssize_t pread (int __fd, void *__buf, size_t __nbytes,
        __off_t __offset) ;






/*extern*/ ssize_t pwrite (int __fd, const void *__buf, size_t __n,
         __off_t __offset) ;

/*extern*/ int pipe (int __pipedes[2]) __attribute__ ((__nothrow__ , __leaf__)) ;

/*extern*/ unsigned int alarm (unsigned int __seconds) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ unsigned int sleep (unsigned int __seconds);







/*extern*/ __useconds_t ualarm (__useconds_t __value, __useconds_t __interval)
     __attribute__ ((__nothrow__ , __leaf__));






/*extern*/ int usleep (__useconds_t __useconds);

/*extern*/ int pause ();



/*extern*/ int chown (const char *__file, __uid_t __owner, __gid_t __group)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;



/*extern*/ int fchown (int __fd, __uid_t __owner, __gid_t __group) __attribute__ ((__nothrow__ , __leaf__)) ;




/*extern*/ int lchown (const char *__file, __uid_t __owner, __gid_t __group)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;






/*extern*/ int fchownat (int __fd, const char *__file, __uid_t __owner,
       __gid_t __group, int __flag)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) ;



/*extern*/ int chdir (const char *__path) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;



/*extern*/ int fchdir (int __fd) __attribute__ ((__nothrow__ , __leaf__)) ;

/*extern*/ char *getcwd (char *__buf, size_t __size) __attribute__ ((__nothrow__ , __leaf__)) ;

/*extern*/ char *getwd (char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__deprecated__)) ;




/*extern*/ int dup (int __fd) __attribute__ ((__nothrow__ , __leaf__)) ;


/*extern*/ int dup2 (int __fd, int __fd2) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ char **__environ;







/*extern*/ int execve (const char *__path, char *const __argv[],
     char *const __envp[]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




/*extern*/ int fexecve (int __fd, char *const __argv[], char *const __envp[])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));




/*extern*/ int execv (const char *__path, char *const __argv[])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



/*extern*/ int execle (const char *__path, const char *__arg, ...)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



/*extern*/ int execl (const char *__path, const char *__arg, ...)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



/*extern*/ int execvp (const char *__file, char *const __argv[])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




/*extern*/ int execlp (const char *__file, const char *__arg, ...)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ int nice (int __inc) __attribute__ ((__nothrow__ , __leaf__)) ;




/*extern*/ void _exit (int __status) __attribute__ ((__noreturn__));







enum
  {
    _PC_LINK_MAX,

    _PC_MAX_CANON,

    _PC_MAX_INPUT,

    _PC_NAME_MAX,

    _PC_PATH_MAX,

    _PC_PIPE_BUF,

    _PC_CHOWN_RESTRICTED,

    _PC_NO_TRUNC,

    _PC_VDISABLE,

    _PC_SYNC_IO,

    _PC_ASYNC_IO,

    _PC_PRIO_IO,

    _PC_SOCK_MAXBUF,

    _PC_FILESIZEBITS,

    _PC_REC_INCR_XFER_SIZE,

    _PC_REC_MAX_XFER_SIZE,

    _PC_REC_MIN_XFER_SIZE,

    _PC_REC_XFER_ALIGN,

    _PC_ALLOC_SIZE_MIN,

    _PC_SYMLINK_MAX,

    _PC_2_SYMLINKS

  };


enum
  {
    _SC_ARG_MAX,

    _SC_CHILD_MAX,

    _SC_CLK_TCK,

    _SC_NGROUPS_MAX,

    _SC_OPEN_MAX,

    _SC_STREAM_MAX,

    _SC_TZNAME_MAX,

    _SC_JOB_CONTROL,

    _SC_SAVED_IDS,

    _SC_REALTIME_SIGNALS,

    _SC_PRIORITY_SCHEDULING,

    _SC_TIMERS,

    _SC_ASYNCHRONOUS_IO,

    _SC_PRIORITIZED_IO,

    _SC_SYNCHRONIZED_IO,

    _SC_FSYNC,

    _SC_MAPPED_FILES,

    _SC_MEMLOCK,

    _SC_MEMLOCK_RANGE,

    _SC_MEMORY_PROTECTION,

    _SC_MESSAGE_PASSING,

    _SC_SEMAPHORES,

    _SC_SHARED_MEMORY_OBJECTS,

    _SC_AIO_LISTIO_MAX,

    _SC_AIO_MAX,

    _SC_AIO_PRIO_DELTA_MAX,

    _SC_DELAYTIMER_MAX,

    _SC_MQ_OPEN_MAX,

    _SC_MQ_PRIO_MAX,

    _SC_VERSION,

    _SC_PAGESIZE,


    _SC_RTSIG_MAX,

    _SC_SEM_NSEMS_MAX,

    _SC_SEM_VALUE_MAX,

    _SC_SIGQUEUE_MAX,

    _SC_TIMER_MAX,




    _SC_BC_BASE_MAX,

    _SC_BC_DIM_MAX,

    _SC_BC_SCALE_MAX,

    _SC_BC_STRING_MAX,

    _SC_COLL_WEIGHTS_MAX,

    _SC_EQUIV_CLASS_MAX,

    _SC_EXPR_NEST_MAX,

    _SC_LINE_MAX,

    _SC_RE_DUP_MAX,

    _SC_CHARCLASS_NAME_MAX,


    _SC_2_VERSION,

    _SC_2_C_BIND,

    _SC_2_C_DEV,

    _SC_2_FORT_DEV,

    _SC_2_FORT_RUN,

    _SC_2_SW_DEV,

    _SC_2_LOCALEDEF,


    _SC_PII,

    _SC_PII_XTI,

    _SC_PII_SOCKET,

    _SC_PII_INTERNET,

    _SC_PII_OSI,

    _SC_POLL,

    _SC_SELECT,

    _SC_UIO_MAXIOV,

    _SC_IOV_MAX = _SC_UIO_MAXIOV,

    _SC_PII_INTERNET_STREAM,

    _SC_PII_INTERNET_DGRAM,

    _SC_PII_OSI_COTS,

    _SC_PII_OSI_CLTS,

    _SC_PII_OSI_M,

    _SC_T_IOV_MAX,



    _SC_THREADS,

    _SC_THREAD_SAFE_FUNCTIONS,

    _SC_GETGR_R_SIZE_MAX,

    _SC_GETPW_R_SIZE_MAX,

    _SC_LOGIN_NAME_MAX,

    _SC_TTY_NAME_MAX,

    _SC_THREAD_DESTRUCTOR_ITERATIONS,

    _SC_THREAD_KEYS_MAX,

    _SC_THREAD_STACK_MIN,

    _SC_THREAD_THREADS_MAX,

    _SC_THREAD_ATTR_STACKADDR,

    _SC_THREAD_ATTR_STACKSIZE,

    _SC_THREAD_PRIORITY_SCHEDULING,

    _SC_THREAD_PRIO_INHERIT,

    _SC_THREAD_PRIO_PROTECT,

    _SC_THREAD_PROCESS_SHARED,


    _SC_NPROCESSORS_CONF,

    _SC_NPROCESSORS_ONLN,

    _SC_PHYS_PAGES,

    _SC_AVPHYS_PAGES,

    _SC_ATEXIT_MAX,

    _SC_PASS_MAX,


    _SC_XOPEN_VERSION,

    _SC_XOPEN_XCU_VERSION,

    _SC_XOPEN_UNIX,

    _SC_XOPEN_CRYPT,

    _SC_XOPEN_ENH_I18N,

    _SC_XOPEN_SHM,


    _SC_2_CHAR_TERM,

    _SC_2_C_VERSION,

    _SC_2_UPE,


    _SC_XOPEN_XPG2,

    _SC_XOPEN_XPG3,

    _SC_XOPEN_XPG4,


    _SC_CHAR_BIT,

    _SC_CHAR_MAX,

    _SC_CHAR_MIN,

    _SC_INT_MAX,

    _SC_INT_MIN,

    _SC_LONG_BIT,

    _SC_WORD_BIT,

    _SC_MB_LEN_MAX,

    _SC_NZERO,

    _SC_SSIZE_MAX,

    _SC_SCHAR_MAX,

    _SC_SCHAR_MIN,

    _SC_SHRT_MAX,

    _SC_SHRT_MIN,

    _SC_UCHAR_MAX,

    _SC_UINT_MAX,

    _SC_ULONG_MAX,

    _SC_USHRT_MAX,


    _SC_NL_ARGMAX,

    _SC_NL_LANGMAX,

    _SC_NL_MSGMAX,

    _SC_NL_NMAX,

    _SC_NL_SETMAX,

    _SC_NL_TEXTMAX,


    _SC_XBS5_ILP32_OFF32,

    _SC_XBS5_ILP32_OFFBIG,

    _SC_XBS5_LP64_OFF64,

    _SC_XBS5_LPBIG_OFFBIG,


    _SC_XOPEN_LEGACY,

    _SC_XOPEN_REALTIME,

    _SC_XOPEN_REALTIME_THREADS,


    _SC_ADVISORY_INFO,

    _SC_BARRIERS,

    _SC_BASE,

    _SC_C_LANG_SUPPORT,

    _SC_C_LANG_SUPPORT_R,

    _SC_CLOCK_SELECTION,

    _SC_CPUTIME,

    _SC_THREAD_CPUTIME,

    _SC_DEVICE_IO,

    _SC_DEVICE_SPECIFIC,

    _SC_DEVICE_SPECIFIC_R,

    _SC_FD_MGMT,

    _SC_FIFO,

    _SC_PIPE,

    _SC_FILE_ATTRIBUTES,

    _SC_FILE_LOCKING,

    _SC_FILE_SYSTEM,

    _SC_MONOTONIC_CLOCK,

    _SC_MULTI_PROCESS,

    _SC_SINGLE_PROCESS,

    _SC_NETWORKING,

    _SC_READER_WRITER_LOCKS,

    _SC_SPIN_LOCKS,

    _SC_REGEXP,

    _SC_REGEX_VERSION,

    _SC_SHELL,

    _SC_SIGNALS,

    _SC_SPAWN,

    _SC_SPORADIC_SERVER,

    _SC_THREAD_SPORADIC_SERVER,

    _SC_SYSTEM_DATABASE,

    _SC_SYSTEM_DATABASE_R,

    _SC_TIMEOUTS,

    _SC_TYPED_MEMORY_OBJECTS,

    _SC_USER_GROUPS,

    _SC_USER_GROUPS_R,

    _SC_2_PBS,

    _SC_2_PBS_ACCOUNTING,

    _SC_2_PBS_LOCATE,

    _SC_2_PBS_MESSAGE,

    _SC_2_PBS_TRACK,

    _SC_SYMLOOP_MAX,

    _SC_STREAMS,

    _SC_2_PBS_CHECKPOINT,


    _SC_V6_ILP32_OFF32,

    _SC_V6_ILP32_OFFBIG,

    _SC_V6_LP64_OFF64,

    _SC_V6_LPBIG_OFFBIG,


    _SC_HOST_NAME_MAX,

    _SC_TRACE,

    _SC_TRACE_EVENT_FILTER,

    _SC_TRACE_INHERIT,

    _SC_TRACE_LOG,


    _SC_LEVEL1_ICACHE_SIZE,

    _SC_LEVEL1_ICACHE_ASSOC,

    _SC_LEVEL1_ICACHE_LINESIZE,

    _SC_LEVEL1_DCACHE_SIZE,

    _SC_LEVEL1_DCACHE_ASSOC,

    _SC_LEVEL1_DCACHE_LINESIZE,

    _SC_LEVEL2_CACHE_SIZE,

    _SC_LEVEL2_CACHE_ASSOC,

    _SC_LEVEL2_CACHE_LINESIZE,

    _SC_LEVEL3_CACHE_SIZE,

    _SC_LEVEL3_CACHE_ASSOC,

    _SC_LEVEL3_CACHE_LINESIZE,

    _SC_LEVEL4_CACHE_SIZE,

    _SC_LEVEL4_CACHE_ASSOC,

    _SC_LEVEL4_CACHE_LINESIZE,



    _SC_IPV6 = _SC_LEVEL1_ICACHE_SIZE + 50,

    _SC_RAW_SOCKETS,


    _SC_V7_ILP32_OFF32,

    _SC_V7_ILP32_OFFBIG,

    _SC_V7_LP64_OFF64,

    _SC_V7_LPBIG_OFFBIG,


    _SC_SS_REPL_MAX,


    _SC_TRACE_EVENT_NAME_MAX,

    _SC_TRACE_NAME_MAX,

    _SC_TRACE_SYS_MAX,

    _SC_TRACE_USER_EVENT_MAX,


    _SC_XOPEN_STREAMS,


    _SC_THREAD_ROBUST_PRIO_INHERIT,

    _SC_THREAD_ROBUST_PRIO_PROTECT

  };


enum
  {
    _CS_PATH,


    _CS_V6_WIDTH_RESTRICTED_ENVS,



    _CS_GNU_LIBC_VERSION,

    _CS_GNU_LIBPTHREAD_VERSION,


    _CS_V5_WIDTH_RESTRICTED_ENVS,



    _CS_V7_WIDTH_RESTRICTED_ENVS,



    _CS_LFS_CFLAGS = 1000,

    _CS_LFS_LDFLAGS,

    _CS_LFS_LIBS,

    _CS_LFS_LINTFLAGS,

    _CS_LFS64_CFLAGS,

    _CS_LFS64_LDFLAGS,

    _CS_LFS64_LIBS,

    _CS_LFS64_LINTFLAGS,


    _CS_XBS5_ILP32_OFF32_CFLAGS = 1100,

    _CS_XBS5_ILP32_OFF32_LDFLAGS,

    _CS_XBS5_ILP32_OFF32_LIBS,

    _CS_XBS5_ILP32_OFF32_LINTFLAGS,

    _CS_XBS5_ILP32_OFFBIG_CFLAGS,

    _CS_XBS5_ILP32_OFFBIG_LDFLAGS,

    _CS_XBS5_ILP32_OFFBIG_LIBS,

    _CS_XBS5_ILP32_OFFBIG_LINTFLAGS,

    _CS_XBS5_LP64_OFF64_CFLAGS,

    _CS_XBS5_LP64_OFF64_LDFLAGS,

    _CS_XBS5_LP64_OFF64_LIBS,

    _CS_XBS5_LP64_OFF64_LINTFLAGS,

    _CS_XBS5_LPBIG_OFFBIG_CFLAGS,

    _CS_XBS5_LPBIG_OFFBIG_LDFLAGS,

    _CS_XBS5_LPBIG_OFFBIG_LIBS,

    _CS_XBS5_LPBIG_OFFBIG_LINTFLAGS,


    _CS_POSIX_V6_ILP32_OFF32_CFLAGS,

    _CS_POSIX_V6_ILP32_OFF32_LDFLAGS,

    _CS_POSIX_V6_ILP32_OFF32_LIBS,

    _CS_POSIX_V6_ILP32_OFF32_LINTFLAGS,

    _CS_POSIX_V6_ILP32_OFFBIG_CFLAGS,

    _CS_POSIX_V6_ILP32_OFFBIG_LDFLAGS,

    _CS_POSIX_V6_ILP32_OFFBIG_LIBS,

    _CS_POSIX_V6_ILP32_OFFBIG_LINTFLAGS,

    _CS_POSIX_V6_LP64_OFF64_CFLAGS,

    _CS_POSIX_V6_LP64_OFF64_LDFLAGS,

    _CS_POSIX_V6_LP64_OFF64_LIBS,

    _CS_POSIX_V6_LP64_OFF64_LINTFLAGS,

    _CS_POSIX_V6_LPBIG_OFFBIG_CFLAGS,

    _CS_POSIX_V6_LPBIG_OFFBIG_LDFLAGS,

    _CS_POSIX_V6_LPBIG_OFFBIG_LIBS,

    _CS_POSIX_V6_LPBIG_OFFBIG_LINTFLAGS,


    _CS_POSIX_V7_ILP32_OFF32_CFLAGS,

    _CS_POSIX_V7_ILP32_OFF32_LDFLAGS,

    _CS_POSIX_V7_ILP32_OFF32_LIBS,

    _CS_POSIX_V7_ILP32_OFF32_LINTFLAGS,

    _CS_POSIX_V7_ILP32_OFFBIG_CFLAGS,

    _CS_POSIX_V7_ILP32_OFFBIG_LDFLAGS,

    _CS_POSIX_V7_ILP32_OFFBIG_LIBS,

    _CS_POSIX_V7_ILP32_OFFBIG_LINTFLAGS,

    _CS_POSIX_V7_LP64_OFF64_CFLAGS,

    _CS_POSIX_V7_LP64_OFF64_LDFLAGS,

    _CS_POSIX_V7_LP64_OFF64_LIBS,

    _CS_POSIX_V7_LP64_OFF64_LINTFLAGS,

    _CS_POSIX_V7_LPBIG_OFFBIG_CFLAGS,

    _CS_POSIX_V7_LPBIG_OFFBIG_LDFLAGS,

    _CS_POSIX_V7_LPBIG_OFFBIG_LIBS,

    _CS_POSIX_V7_LPBIG_OFFBIG_LINTFLAGS,


    _CS_V6_ENV,

    _CS_V7_ENV

  };



/*extern*/ long int pathconf (const char *__path, int __name)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


/*extern*/ long int fpathconf (int __fd, int __name) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ long int sysconf (int __name) __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ size_t confstr (int __name, char *__buf, size_t __len) __attribute__ ((__nothrow__ , __leaf__));




/*extern*/ __pid_t getpid (void) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ __pid_t getppid (void) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ __pid_t getpgrp (void) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ __pid_t __getpgid (__pid_t __pid) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ __pid_t getpgid (__pid_t __pid) __attribute__ ((__nothrow__ , __leaf__));






/*extern*/ int setpgid (__pid_t __pid, __pid_t __pgid) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ int setpgrp (void) __attribute__ ((__nothrow__ , __leaf__));






/*extern*/ __pid_t setsid (void) __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ __pid_t getsid (__pid_t __pid) __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ __uid_t getuid (void) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ __uid_t geteuid (void) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ __gid_t getgid (void) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ __gid_t getegid (void) __attribute__ ((__nothrow__ , __leaf__));




/*extern*/ int getgroups (int __size, __gid_t __list[]) __attribute__ ((__nothrow__ , __leaf__)) ;

/*extern*/ int setuid (__uid_t __uid) __attribute__ ((__nothrow__ , __leaf__)) ;




/*extern*/ int setreuid (__uid_t __ruid, __uid_t __euid) __attribute__ ((__nothrow__ , __leaf__)) ;




/*extern*/ int seteuid (__uid_t __uid) __attribute__ ((__nothrow__ , __leaf__)) ;






/*extern*/ int setgid (__gid_t __gid) __attribute__ ((__nothrow__ , __leaf__)) ;




/*extern*/ int setregid (__gid_t __rgid, __gid_t __egid) __attribute__ ((__nothrow__ , __leaf__)) ;




/*extern*/ int setegid (__gid_t __gid) __attribute__ ((__nothrow__ , __leaf__)) ;

/*extern*/ __pid_t fork (void) __attribute__ ((__nothrow__));







/*extern*/ __pid_t vfork (void) __attribute__ ((__nothrow__ , __leaf__));





/*extern*/ char *ttyname (int __fd) __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ int ttyname_r (int __fd, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) ;



/*extern*/ int isatty (int __fd) __attribute__ ((__nothrow__ , __leaf__));





/*extern*/ int ttyslot (void) __attribute__ ((__nothrow__ , __leaf__));




/*extern*/ int link (const char *__from, const char *__to)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) ;




/*extern*/ int linkat (int __fromfd, const char *__from, int __tofd,
     const char *__to, int __flags)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4))) ;




/*extern*/ int symlink (const char *__from, const char *__to)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) ;




/*extern*/ ssize_t readlink (const char *__restrict __path,
    char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) ;




/*extern*/ int symlinkat (const char *__from, int __tofd,
        const char *__to) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3))) ;


/*extern*/ ssize_t readlinkat (int __fd, const char *__restrict __path,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3))) ;



/*extern*/ int unlink (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



/*extern*/ int unlinkat (int __fd, const char *__name, int __flag)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



/*extern*/ int rmdir (const char *__path) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



/*extern*/ __pid_t tcgetpgrp (int __fd) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ int tcsetpgrp (int __fd, __pid_t __pgrp_id) __attribute__ ((__nothrow__ , __leaf__));






/*extern*/ char *getlogin ();

#endif
//void initialize_shell_variables_driver(){
//  vio("char_index < 1 + string_length", __FILE__, 5517, "initialize_shell_variables");
//}
#ifdef __H_

/*extern*/ int getlogin_r (char *__name, size_t __name_len) __attribute__ ((__nonnull__ (1)));




/*extern*/ int setlogin (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



/*extern*/ char *optarg;

/*extern*/ int optind;




/*extern*/ int opterr;



/*extern*/ int optopt;

/*extern*/ int getopt (int ___argc, char *const *___argv, const char *__shortopts)
       __attribute__ ((__nothrow__ , __leaf__));








/*extern*/ int gethostname (char *__name, size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






/*extern*/ int sethostname (const char *__name, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;



/*extern*/ int sethostid (long int __id) __attribute__ ((__nothrow__ , __leaf__)) ;





/*extern*/ int getdomainname (char *__name, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
/*extern*/ int setdomainname (const char *__name, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;





/*extern*/ int vhangup (void) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ int revoke (const char *__file) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;







/*extern*/ int profil (unsigned short int *__sample_buffer, size_t __size,
     size_t __offset, unsigned int __scale)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





/*extern*/ int acct (const char *__name) __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ char *getusershell (void) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ void endusershell (void) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ void setusershell (void) __attribute__ ((__nothrow__ , __leaf__));





/*extern*/ int daemon (int __nochdir, int __noclose) __attribute__ ((__nothrow__ , __leaf__)) ;






/*extern*/ int chroot (const char *__path) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;



/*extern*/ char *getpass (const char *__prompt) __attribute__ ((__nonnull__ (1)));







/*extern*/ int fsync (int __fd);

/*extern*/ long int gethostid ();


/*extern*/ void sync (void) __attribute__ ((__nothrow__ , __leaf__));





/*extern*/ int getpagesize (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));




/*extern*/ int getdtablesize (void) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ int truncate (const char *__file, __off_t __length)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;

/*extern*/ int ftruncate (int __fd, __off_t __length) __attribute__ ((__nothrow__ , __leaf__)) ;

/*extern*/ int brk (void *__addr) __attribute__ ((__nothrow__ , __leaf__)) ;





/*extern*/ void *sbrk (intptr_t __delta) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ long int syscall (long int __sysno, ...) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ int lockf (int __fd, int __cmd, __off_t __len) ;

/*extern*/ int fdatasync (int __fildes);














struct _IO_FILE;



typedef struct _IO_FILE FILE;






typedef struct _IO_FILE __FILE;













typedef struct
{
  int __count;
  union
  {

    unsigned int __wch;



    char __wchb[4];
  } __value;
} __mbstate_t;

typedef struct
{
  __off_t __pos;
  __mbstate_t __state;
} _G_fpos_t;
typedef struct
{
  __off64_t __pos;
  __mbstate_t __state;
} _G_fpos64_t;




typedef __builtin_va_list __gnuc_va_list;


struct _IO_jump_t; struct _IO_FILE;

typedef void _IO_lock_t;





struct _IO_marker {
  struct _IO_marker *_next;
  struct _IO_FILE *_sbuf;



  int _pos;

};


enum __codecvt_result
{
  __codecvt_ok,
  __codecvt_partial,
  __codecvt_error,
  __codecvt_noconv
};

struct _IO_FILE {
  int _flags;




  char* _IO_read_ptr;
  char* _IO_read_end;
  char* _IO_read_base;
  char* _IO_write_base;
  char* _IO_write_ptr;
  char* _IO_write_end;
  char* _IO_buf_base;
  char* _IO_buf_end;

  char *_IO_save_base;
  char *_IO_backup_base;
  char *_IO_save_end;

  struct _IO_marker *_markers;

  struct _IO_FILE *_chain;

  int _fileno;



  int _flags2;

  __off_t _old_offset;



  unsigned short _cur_column;
  signed char _vtable_offset;
  char _shortbuf[1];



  _IO_lock_t *_lock;

  __off64_t _offset;

  void *__pad1;
  void *__pad2;
  void *__pad3;
  void *__pad4;
  size_t __pad5;

  int _mode;

  char _unused2[15 * sizeof (int) - 4 * sizeof (void *) - sizeof (size_t)];

};


typedef struct _IO_FILE _IO_FILE;


struct _IO_FILE_plus;

extern struct _IO_FILE_plus _IO_2_1_stdin_;
extern struct _IO_FILE_plus _IO_2_1_stdout_;
extern struct _IO_FILE_plus _IO_2_1_stderr_;

typedef __ssize_t __io_read_fn (void *__cookie, char *__buf, size_t __nbytes);







typedef __ssize_t __io_write_fn (void *__cookie, const char *__buf,
     size_t __n);







typedef int __io_seek_fn (void *__cookie, __off64_t *__pos, int __w);


typedef int __io_close_fn (void *__cookie);

/*extern*/ int __underflow (_IO_FILE *);
/*extern*/ int __uflow (_IO_FILE *);
/*extern*/ int __overflow (_IO_FILE *, int);

/*extern*/ int _IO_getc (_IO_FILE *__fp);
/*extern*/ int _IO_putc (int __c, _IO_FILE *__fp);
/*extern*/ int _IO_feof (_IO_FILE *__fp) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int _IO_ferror (_IO_FILE *__fp) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ int _IO_peekc_locked (_IO_FILE *__fp);





/*extern*/ void _IO_flockfile (_IO_FILE *) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ void _IO_funlockfile (_IO_FILE *) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int _IO_ftrylockfile (_IO_FILE *) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ int _IO_vfscanf (_IO_FILE * __restrict, const char * __restrict,
   __gnuc_va_list, int *__restrict);
/*extern*/ int _IO_vfprintf (_IO_FILE *__restrict, const char *__restrict,
    __gnuc_va_list);
/*extern*/ __ssize_t _IO_padn (_IO_FILE *, int, __ssize_t);
/*extern*/ size_t _IO_sgetn (_IO_FILE *, void *, size_t);

/*extern*/ __off64_t _IO_seekoff (_IO_FILE *, __off64_t, int, int);
/*extern*/ __off64_t _IO_seekpos (_IO_FILE *, __off64_t, int);

/*extern*/ void _IO_free_backup_area (_IO_FILE *) __attribute__ ((__nothrow__ , __leaf__));





typedef __gnuc_va_list va_list;



typedef _G_fpos_t fpos_t;










/*extern*/ struct _IO_FILE *stdin;
/*extern*/ struct _IO_FILE *stdout;
/*extern*/ struct _IO_FILE *stderr;







/*extern*/ int remove (const char *__filename) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ int rename (const char *__old, const char *__new) __attribute__ ((__nothrow__ , __leaf__));




/*extern*/ int renameat (int __oldfd, const char *__old, int __newfd,
       const char *__new) __attribute__ ((__nothrow__ , __leaf__));








/*extern*/ FILE *tmpfile (void) ;

/*extern*/ char *tmpnam (char *__s) __attribute__ ((__nothrow__ , __leaf__)) ;





/*extern*/ char *tmpnam_r (char *__s) __attribute__ ((__nothrow__ , __leaf__)) ;

/*extern*/ char *tempnam (const char *__dir, const char *__pfx)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) ;








/*extern*/ int fclose (FILE *__stream);




/*extern*/ int fflush (FILE *__stream);


/*extern*/ int fflush_unlocked (FILE *__stream);







/*extern*/ FILE *fopen (const char *__restrict __filename,
      const char *__restrict __modes) ;




/*extern*/ FILE *freopen (const char *__restrict __filename,
        const char *__restrict __modes,
        FILE *__restrict __stream) ;



/*extern*/ FILE *fdopen (int __fd, const char *__modes) __attribute__ ((__nothrow__ , __leaf__)) ;

/*extern*/ FILE *fmemopen (void *__s, size_t __len, const char *__modes)
  __attribute__ ((__nothrow__ , __leaf__)) ;




/*extern*/ FILE *open_memstream (char **__bufloc, size_t *__sizeloc) __attribute__ ((__nothrow__ , __leaf__)) ;






/*extern*/ void setbuf (FILE *__restrict __stream, char *__restrict __buf) __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ int setvbuf (FILE *__restrict __stream, char *__restrict __buf,
      int __modes, size_t __n) __attribute__ ((__nothrow__ , __leaf__));





/*extern*/ void setbuffer (FILE *__restrict __stream, char *__restrict __buf,
         size_t __size) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ void setlinebuf (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__));








/*extern*/ int fprintf (FILE *__restrict __stream,
      const char *__restrict __format, ...);




/*extern*/ int printf (const char *__restrict __format, ...);

/*extern*/ int sprintf (char *__restrict __s,
      const char *__restrict __format, ...) __attribute__ ((__nothrow__));





/*extern*/ int vfprintf (FILE *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg);




/*extern*/ int vprintf (const char *__restrict __format, __gnuc_va_list __arg);

/*extern*/ int vsprintf (char *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg) __attribute__ ((__nothrow__));





/*extern*/ int snprintf (char *__restrict __s, size_t __maxlen,
       const char *__restrict __format, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 4)));

/*extern*/ int vsnprintf (char *__restrict __s, size_t __maxlen,
        const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 0)));


/*extern*/ int vdprintf (int __fd, const char *__restrict __fmt,
       __gnuc_va_list __arg)
     __attribute__ ((__format__ (__printf__, 2, 0)));
/*extern*/ int dprintf (int __fd, const char *__restrict __fmt, ...)
     __attribute__ ((__format__ (__printf__, 2, 3)));








/*extern*/ int fscanf (FILE *__restrict __stream,
     const char *__restrict __format, ...) ;




/*extern*/ int scanf (const char *__restrict __format, ...) ;

/*extern*/ int sscanf (const char *__restrict __s,
     const char *__restrict __format, ...) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ int fscanf (FILE *__restrict __stream, const char *__restrict __format, ...) __asm__ ("" "__isoc99_fscanf")

                               ;
/*extern*/ int scanf (const char *__restrict __format, ...) __asm__ ("" "__isoc99_scanf")
                              ;
/*extern*/ int sscanf (const char *__restrict __s, const char *__restrict __format, ...) __asm__ ("" "__isoc99_sscanf") __attribute__ ((__nothrow__ , __leaf__))

                      ;









/*extern*/ int vfscanf (FILE *__restrict __s, const char *__restrict __format,
      __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 2, 0))) ;





/*extern*/ int vscanf (const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 1, 0))) ;


/*extern*/ int vsscanf (const char *__restrict __s,
      const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__format__ (__scanf__, 2, 0)));

/*extern*/ int vfscanf (FILE *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc99_vfscanf")



     __attribute__ ((__format__ (__scanf__, 2, 0))) ;
/*extern*/ int vscanf (const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc99_vscanf")

     __attribute__ ((__format__ (__scanf__, 1, 0))) ;
/*extern*/ int vsscanf (const char *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc99_vsscanf") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__format__ (__scanf__, 2, 0)));










/*extern*/ int fgetc (FILE *__stream);
/*extern*/ int getc (FILE *__stream);





/*extern*/ int getchar ();


/*extern*/ int getc_unlocked (FILE *__stream);
/*extern*/ int getchar_unlocked ();

/*extern*/ int fgetc_unlocked (FILE *__stream);











/*extern*/ int fputc (int __c, FILE *__stream);
/*extern*/ int putc (int __c, FILE *__stream);





/*extern*/ int putchar (int __c);


/*extern*/ int fputc_unlocked (int __c, FILE *__stream);







/*extern*/ int putc_unlocked (int __c, FILE *__stream);
/*extern*/ int putchar_unlocked (int __c);






/*extern*/ int getw (FILE *__stream);


/*extern*/ int putw (int __w, FILE *__stream);








/*extern*/ char *fgets (char *__restrict __s, int __n, FILE *__restrict __stream)
     ;

/*extern*/ char *gets (char *__s) __attribute__ ((__deprecated__));



/*extern*/ __ssize_t __getdelim (char **__restrict __lineptr,
          size_t *__restrict __n, int __delimiter,
          FILE *__restrict __stream) ;
/*extern*/ __ssize_t getdelim (char **__restrict __lineptr,
        size_t *__restrict __n, int __delimiter,
        FILE *__restrict __stream) ;







/*extern*/ __ssize_t getline (char **__restrict __lineptr,
       size_t *__restrict __n,
       FILE *__restrict __stream) ;








/*extern*/ int fputs (const char *__restrict __s, FILE *__restrict __stream);





/*extern*/ int puts (const char *__s);






/*extern*/ int ungetc (int __c, FILE *__stream);






/*extern*/ size_t fread (void *__restrict __ptr, size_t __size,
       size_t __n, FILE *__restrict __stream) ;




/*extern*/ size_t fwrite (const void *__restrict __ptr, size_t __size,
        size_t __n, FILE *__restrict __s);


/*extern*/ size_t fread_unlocked (void *__restrict __ptr, size_t __size,
         size_t __n, FILE *__restrict __stream) ;
/*extern*/ size_t fwrite_unlocked (const void *__restrict __ptr, size_t __size,
          size_t __n, FILE *__restrict __stream);








/*extern*/ int fseek (FILE *__stream, long int __off, int __whence);




/*extern*/ long int ftell (FILE *__stream) ;




/*extern*/ void rewind (FILE *__stream);


/*extern*/ int fseeko (FILE *__stream, __off_t __off, int __whence);




/*extern*/ __off_t ftello (FILE *__stream) ;







/*extern*/ int fgetpos (FILE *__restrict __stream, fpos_t *__restrict __pos);




/*extern*/ int fsetpos (FILE *__stream, const fpos_t *__pos);





/*extern*/ void clearerr (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ int feof (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) ;

/*extern*/ int ferror (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) ;




/*extern*/ void clearerr_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int feof_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) ;
/*extern*/ int ferror_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) ;








/*extern*/ void perror (const char *__s);








/*extern*/ int sys_nerr;
/*extern*/ const char *const sys_errlist[];





/*extern*/ int fileno (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) ;




/*extern*/ int fileno_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) ;

/*extern*/ FILE *popen (const char *__command, const char *__modes) ;





/*extern*/ int pclose (FILE *__stream);





/*extern*/ char *ctermid (char *__s) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ void flockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ int ftrylockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) ;


/*extern*/ void funlockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__));



static int __sym_vfprintf(FILE * param0, const char * param1, __gnuc_va_list param2, ...);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
vprintf (const char *__restrict __fmt, __gnuc_va_list __arg)
{
  return __sym_vfprintf (stdout, __fmt, __arg);
}



static int __sym__IO_getc(_IO_FILE * param0, ...);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
getchar (void)
{
  return __sym__IO_getc (stdin);
}




static int __sym___uflow(_IO_FILE * param0, ...);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
fgetc_unlocked (FILE *__fp)
{
  return (__builtin_expect (((__fp)->_IO_read_ptr >= (__fp)->_IO_read_end), 0) ? __sym___uflow (__fp) : *(unsigned char *) (__fp)->_IO_read_ptr++);
}





/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
getc_unlocked (FILE *__fp)
{
  return (__builtin_expect (((__fp)->_IO_read_ptr >= (__fp)->_IO_read_end), 0) ? __sym___uflow (__fp) : *(unsigned char *) (__fp)->_IO_read_ptr++);
}


/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
getchar_unlocked (void)
{
  return (__builtin_expect (((stdin)->_IO_read_ptr >= (stdin)->_IO_read_end), 0) ? __sym___uflow (stdin) : *(unsigned char *) (stdin)->_IO_read_ptr++);
}




static int __sym__IO_putc(int param0, _IO_FILE * param1, ...);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
putchar (int __c)
{
  return __sym__IO_putc (__c, stdout);
}




static int __sym___overflow(_IO_FILE * param0, int param1, ...);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
fputc_unlocked (int __c, FILE *__stream)
{
  return (__builtin_expect (((__stream)->_IO_write_ptr >= (__stream)->_IO_write_end), 0) ? __sym___overflow (__stream, (unsigned char) (__c)) : (unsigned char) (*(__stream)->_IO_write_ptr++ = (__c)));
}





/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
putc_unlocked (int __c, FILE *__stream)
{
  return (__builtin_expect (((__stream)->_IO_write_ptr >= (__stream)->_IO_write_end), 0) ? __sym___overflow (__stream, (unsigned char) (__c)) : (unsigned char) (*(__stream)->_IO_write_ptr++ = (__c)));
}


/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
putchar_unlocked (int __c)
{
  return (__builtin_expect (((stdout)->_IO_write_ptr >= (stdout)->_IO_write_end), 0) ? __sym___overflow (stdout, (unsigned char) (__c)) : (unsigned char) (*(stdout)->_IO_write_ptr++ = (__c)));
}

/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) feof_unlocked (FILE *__stream)
{
  return (((__stream)->_flags & 0x10) != 0);
}


/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) ferror_unlocked (FILE *__stream)
{
  return (((__stream)->_flags & 0x20) != 0);
}








enum
{
  _ISupper = ((0) < 8 ? ((1 << (0)) << 8) : ((1 << (0)) >> 8)),
  _ISlower = ((1) < 8 ? ((1 << (1)) << 8) : ((1 << (1)) >> 8)),
  _ISalpha = ((2) < 8 ? ((1 << (2)) << 8) : ((1 << (2)) >> 8)),
  _ISdigit = ((3) < 8 ? ((1 << (3)) << 8) : ((1 << (3)) >> 8)),
  _ISxdigit = ((4) < 8 ? ((1 << (4)) << 8) : ((1 << (4)) >> 8)),
  _ISspace = ((5) < 8 ? ((1 << (5)) << 8) : ((1 << (5)) >> 8)),
  _ISprint = ((6) < 8 ? ((1 << (6)) << 8) : ((1 << (6)) >> 8)),
  _ISgraph = ((7) < 8 ? ((1 << (7)) << 8) : ((1 << (7)) >> 8)),
  _ISblank = ((8) < 8 ? ((1 << (8)) << 8) : ((1 << (8)) >> 8)),
  _IScntrl = ((9) < 8 ? ((1 << (9)) << 8) : ((1 << (9)) >> 8)),
  _ISpunct = ((10) < 8 ? ((1 << (10)) << 8) : ((1 << (10)) >> 8)),
  _ISalnum = ((11) < 8 ? ((1 << (11)) << 8) : ((1 << (11)) >> 8))
};

/*extern*/ const unsigned short int **__ctype_b_loc (void)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
/*extern*/ const __int32_t **__ctype_tolower_loc (void)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
/*extern*/ const __int32_t **__ctype_toupper_loc (void)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));







/*extern*/ int isalnum (int) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int isalpha (int) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int iscntrl (int) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int isdigit (int) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int islower (int) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int isgraph (int) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int isprint (int) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int ispunct (int) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int isspace (int) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int isupper (int) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int isxdigit (int) __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ int tolower (int __c) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ int toupper (int __c) __attribute__ ((__nothrow__ , __leaf__));








/*extern*/ int isblank (int) __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ int isascii (int __c) __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ int toascii (int __c) __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ int _toupper (int) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int _tolower (int) __attribute__ ((__nothrow__ , __leaf__));

static const int ** __sym___ctype_tolower_loc();
/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) tolower (int __c)
{
  return __c >= -128 && __c < 256 ? (*__sym___ctype_tolower_loc ())[__c] : __c;
}

static const int ** __sym___ctype_toupper_loc();
/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) toupper (int __c)
{
  return __c >= -128 && __c < 256 ? (*__sym___ctype_toupper_loc ())[__c] : __c;
}



typedef struct __locale_struct
{

  struct __locale_data *__locales[13];


  const unsigned short int *__ctype_b;
  const int *__ctype_tolower;
  const int *__ctype_toupper;


  const char *__names[13];
} *__locale_t;


typedef __locale_t locale_t;


/*extern*/ int isalnum_l (int, __locale_t) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int isalpha_l (int, __locale_t) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int iscntrl_l (int, __locale_t) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int isdigit_l (int, __locale_t) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int islower_l (int, __locale_t) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int isgraph_l (int, __locale_t) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int isprint_l (int, __locale_t) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int ispunct_l (int, __locale_t) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int isspace_l (int, __locale_t) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int isupper_l (int, __locale_t) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int isxdigit_l (int, __locale_t) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ int isblank_l (int, __locale_t) __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ int __tolower_l (int __c, __locale_t __l) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int tolower_l (int __c, __locale_t __l) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ int __toupper_l (int __c, __locale_t __l) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int toupper_l (int __c, __locale_t __l) __attribute__ ((__nothrow__ , __leaf__));













struct passwd
{
  char *pw_name;
  char *pw_passwd;
  __uid_t pw_uid;
  __gid_t pw_gid;
  char *pw_gecos;
  char *pw_dir;
  char *pw_shell;
};

/*extern*/ void setpwent ();





/*extern*/ void endpwent ();





/*extern*/ struct passwd *getpwent ();

/*extern*/ struct passwd *fgetpwent (FILE *__stream);







/*extern*/ int putpwent (const struct passwd *__restrict __p,
       FILE *__restrict __f);






/*extern*/ struct passwd *getpwuid (__uid_t __uid);





/*extern*/ struct passwd *getpwnam (const char *__name);

/*extern*/ int getpwent_r (struct passwd *__restrict __resultbuf,
         char *__restrict __buffer, size_t __buflen,
         struct passwd **__restrict __result);


/*extern*/ int getpwuid_r (__uid_t __uid,
         struct passwd *__restrict __resultbuf,
         char *__restrict __buffer, size_t __buflen,
         struct passwd **__restrict __result);

/*extern*/ int getpwnam_r (const char *__restrict __name,
         struct passwd *__restrict __resultbuf,
         char *__restrict __buffer, size_t __buflen,
         struct passwd **__restrict __result);

/*extern*/ int fgetpwent_r (FILE *__restrict __stream,
   struct passwd *__restrict __resultbuf,
   char *__restrict __buffer, size_t __buflen,
   struct passwd **__restrict __result);

















/*extern*/ void *memcpy (void *__restrict __dest, const void *__restrict __src,
       size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


/*extern*/ void *memmove (void *__dest, const void *__src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));






/*extern*/ void *memccpy (void *__restrict __dest, const void *__restrict __src,
        int __c, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));





/*extern*/ void *memset (void *__s, int __c, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


/*extern*/ int memcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ void *memchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));





/*extern*/ char *strcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ char *strncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


/*extern*/ char *strcat (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ char *strncat (char *__restrict __dest, const char *__restrict __src,
        size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


/*extern*/ int strcmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ int strncmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


/*extern*/ int strcoll (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ size_t strxfrm (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));


/*extern*/ int strcoll_l (const char *__s1, const char *__s2, __locale_t __l)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));

/*extern*/ size_t strxfrm_l (char *__dest, const char *__src, size_t __n,
    __locale_t __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)));





/*extern*/ char *strdup (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));






/*extern*/ char *strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));



/*extern*/ char *strchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));

/*extern*/ char *strrchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));






/*extern*/ size_t strcspn (const char *__s, const char *__reject)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


/*extern*/ size_t strspn (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ char *strpbrk (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ char *strstr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));




/*extern*/ char *strtok (char *__restrict __s, const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));




/*extern*/ char *__strtok_r (char *__restrict __s,
    const char *__restrict __delim,
    char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));

/*extern*/ char *strtok_r (char *__restrict __s, const char *__restrict __delim,
         char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));



/*extern*/ size_t strlen (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));





/*extern*/ size_t strnlen (const char *__string, size_t __maxlen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));





/*extern*/ char *strerror (int __errnum) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ int strerror_r (int __errnum, char *__buf, size_t __buflen) __asm__ ("" "__xpg_strerror_r") __attribute__ ((__nothrow__ , __leaf__))

                        __attribute__ ((__nonnull__ (2)));

/*extern*/ char *strerror_l (int __errnum, __locale_t __l) __attribute__ ((__nothrow__ , __leaf__));





/*extern*/ void __bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



/*extern*/ void bcopy (const void *__src, void *__dest, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


/*extern*/ void bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


/*extern*/ int bcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ char *index (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));

/*extern*/ char *rindex (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




/*extern*/ int ffs (int __i) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));

/*extern*/ int strcasecmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


/*extern*/ int strncasecmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ char *strsep (char **__restrict __stringp,
       const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




/*extern*/ char *strsignal (int __sig) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ char *__stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
/*extern*/ char *stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



/*extern*/ char *__stpncpy (char *__restrict __dest,
   const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
/*extern*/ char *stpncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));







/*extern*/ void *__rawmemchr (const void *__s, int __c);

/*extern*/ __inline __attribute__ ((__gnu_inline__)) size_t __strcspn_c1 (const char *__s, int __reject);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) size_t
__strcspn_c1 (const char *__s, int __reject)
{
  size_t __result = 0;
  while (__s[__result] != '\0' && __s[__result] != __reject)
    ++__result;
  return __result;
}

/*extern*/ __inline __attribute__ ((__gnu_inline__)) size_t __strcspn_c2 (const char *__s, int __reject1,
         int __reject2);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) size_t
__strcspn_c2 (const char *__s, int __reject1, int __reject2)
{
  size_t __result = 0;
  while (__s[__result] != '\0' && __s[__result] != __reject1
  && __s[__result] != __reject2)
    ++__result;
  return __result;
}

/*extern*/ __inline __attribute__ ((__gnu_inline__)) size_t __strcspn_c3 (const char *__s, int __reject1,
         int __reject2, int __reject3);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) size_t
__strcspn_c3 (const char *__s, int __reject1, int __reject2,
       int __reject3)
{
  size_t __result = 0;
  while (__s[__result] != '\0' && __s[__result] != __reject1
  && __s[__result] != __reject2 && __s[__result] != __reject3)
    ++__result;
  return __result;
}

/*extern*/ __inline __attribute__ ((__gnu_inline__)) size_t __strspn_c1 (const char *__s, int __accept);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) size_t
__strspn_c1 (const char *__s, int __accept)
{
  size_t __result = 0;

  while (__s[__result] == __accept)
    ++__result;
  return __result;
}

/*extern*/ __inline __attribute__ ((__gnu_inline__)) size_t __strspn_c2 (const char *__s, int __accept1,
        int __accept2);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) size_t
__strspn_c2 (const char *__s, int __accept1, int __accept2)
{
  size_t __result = 0;

  while (__s[__result] == __accept1 || __s[__result] == __accept2)
    ++__result;
  return __result;
}

/*extern*/ __inline __attribute__ ((__gnu_inline__)) size_t __strspn_c3 (const char *__s, int __accept1,
        int __accept2, int __accept3);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) size_t
__strspn_c3 (const char *__s, int __accept1, int __accept2, int __accept3)
{
  size_t __result = 0;

  while (__s[__result] == __accept1 || __s[__result] == __accept2
  || __s[__result] == __accept3)
    ++__result;
  return __result;
}

/*extern*/ __inline __attribute__ ((__gnu_inline__)) char *__strpbrk_c2 (const char *__s, int __accept1,
        int __accept2);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) char *
__strpbrk_c2 (const char *__s, int __accept1, int __accept2)
{

  while (*__s != '\0' && *__s != __accept1 && *__s != __accept2)
    ++__s;
  return *__s == '\0' ? ((void *)0) : (char *) (size_t) __s;
}

/*extern*/ __inline __attribute__ ((__gnu_inline__)) char *__strpbrk_c3 (const char *__s, int __accept1,
        int __accept2, int __accept3);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) char *
__strpbrk_c3 (const char *__s, int __accept1, int __accept2, int __accept3)
{

  while (*__s != '\0' && *__s != __accept1 && *__s != __accept2
  && *__s != __accept3)
    ++__s;
  return *__s == '\0' ? ((void *)0) : (char *) (size_t) __s;
}

/*extern*/ __inline __attribute__ ((__gnu_inline__)) char *__strtok_r_1c (char *__s, char __sep, char **__nextp);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) char *
__strtok_r_1c (char *__s, char __sep, char **__nextp)
{
  char *__result;
  if (__s == ((void *)0))
    __s = *__nextp;
  while (*__s == __sep)
    ++__s;
  __result = ((void *)0);
  if (*__s != '\0')
    {
      __result = __s++;
      while (*__s != '\0')
 if (*__s++ == __sep)
   {
     __s[-1] = '\0';
     break;
   }
    }
  *__nextp = __s;
  return __result;
}

/*extern*/ char *__strsep_g (char **__stringp, const char *__delim);

/*extern*/ __inline __attribute__ ((__gnu_inline__)) char *__strsep_1c (char **__s, char __reject);
static void * __sym___rawmemchr(const void * param0, int param1, ...);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) char *
__strsep_1c (char **__s, char __reject)
{
  char *__retval = *__s;
  if (__retval != ((void *)0) && (*__s = (__extension__ (__builtin_constant_p (__reject) && !__builtin_constant_p (__retval) && (__reject) == '\0' ? (char *) __sym___rawmemchr (__retval, __reject) : __builtin_strchr (__retval, __reject)))) != ((void *)0))
    *(*__s)++ = '\0';
  return __retval;
}

/*extern*/ __inline __attribute__ ((__gnu_inline__)) char *__strsep_2c (char **__s, char __reject1, char __reject2);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) char *
__strsep_2c (char **__s, char __reject1, char __reject2)
{
  char *__retval = *__s;
  if (__retval != ((void *)0))
    {
      char *__cp = __retval;
      while (1)
 {
   if (*__cp == '\0')
     {
       __cp = ((void *)0);
   break;
     }
   if (*__cp == __reject1 || *__cp == __reject2)
     {
       *__cp++ = '\0';
       break;
     }
   ++__cp;
 }
      *__s = __cp;
    }
  return __retval;
}

/*extern*/ __inline __attribute__ ((__gnu_inline__)) char *__strsep_3c (char **__s, char __reject1, char __reject2,
       char __reject3);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) char *
__strsep_3c (char **__s, char __reject1, char __reject2, char __reject3)
{
  char *__retval = *__s;
  if (__retval != ((void *)0))
    {
      char *__cp = __retval;
      while (1)
 {
   if (*__cp == '\0')
     {
       __cp = ((void *)0);
   break;
     }
   if (*__cp == __reject1 || *__cp == __reject2 || *__cp == __reject3)
     {
       *__cp++ = '\0';
       break;
     }
   ++__cp;
 }
      *__s = __cp;
    }
  return __retval;
}










/*extern*/ void *malloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) ;

/*extern*/ void *calloc (size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) ;








/*extern*/ char *__strdup (const char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__));

/*extern*/ char *__strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__));













typedef int wchar_t;











typedef enum
{
  P_ALL,
  P_PID,
  P_PGID
} idtype_t;



union wait
  {
    int w_status;
    struct
      {

 unsigned int __w_termsig:7;
 unsigned int __w_coredump:1;
 unsigned int __w_retcode:8;
 unsigned int:16;







      } __wait_terminated;
    struct
      {

 unsigned int __w_stopval:8;
 unsigned int __w_stopsig:8;
 unsigned int:16;






      } __wait_stopped;
  };


typedef union
  {
    union wait *__uptr;
    int *__iptr;
  } __WAIT_STATUS __attribute__ ((__transparent_union__));



typedef struct
  {
    int quot;
    int rem;
  } div_t;



typedef struct
  {
    long int quot;
    long int rem;
  } ldiv_t;







__extension__ typedef struct
  {
    long long int quot;
    long long int rem;
  } lldiv_t;



/*extern*/ size_t __ctype_get_mb_cur_max (void) __attribute__ ((__nothrow__ , __leaf__)) ;




/*extern*/ double atof (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

/*extern*/ int atoi (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

/*extern*/ long int atol (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;





__extension__ /*extern*/ long long int atoll (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;





/*extern*/ double strtod (const char *__restrict __nptr,
        char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





/*extern*/ float strtof (const char *__restrict __nptr,
       char **__restrict __endptr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

/*extern*/ long double strtold (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





/*extern*/ long int strtol (const char *__restrict __nptr,
   char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

/*extern*/ unsigned long int strtoul (const char *__restrict __nptr,
      char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));




__extension__
/*extern*/ long long int strtoq (const char *__restrict __nptr,
        char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
/*extern*/ unsigned long long int strtouq (const char *__restrict __nptr,
           char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





__extension__
/*extern*/ long long int strtoll (const char *__restrict __nptr,
         char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
/*extern*/ unsigned long long int strtoull (const char *__restrict __nptr,
     char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



static long __sym_strtol(const char * param0, char ** param1, int param2, ...);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) atoi (const char *__nptr)
{
  return (int) __sym_strtol (__nptr, (char **) ((void *)0), 10);
}
/*extern*/ __inline __attribute__ ((__gnu_inline__)) long int
__attribute__ ((__nothrow__ , __leaf__)) atol (const char *__nptr)
{
  return __sym_strtol (__nptr, (char **) ((void *)0), 10);
}




__extension__ static long long __sym_strtoll(const char * param0, char ** param1, int param2, ...);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) long long int
__attribute__ ((__nothrow__ , __leaf__)) atoll (const char *__nptr)
{
  return __sym_strtoll (__nptr, (char **) ((void *)0), 10);
}


/*extern*/ char *l64a (long int __n) __attribute__ ((__nothrow__ , __leaf__)) ;


/*extern*/ long int a64l (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

/*extern*/ long int random (void) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ void srandom (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));





/*extern*/ char *initstate (unsigned int __seed, char *__statebuf,
   size_t __statelen) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



/*extern*/ char *setstate (char *__statebuf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







struct random_data
  {
    int32_t *fptr;
    int32_t *rptr;
    int32_t *state;
    int rand_type;
    int rand_deg;
    int rand_sep;
    int32_t *end_ptr;
  };

/*extern*/ int random_r (struct random_data *__restrict __buf,
       int32_t *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ int srandom_r (unsigned int __seed, struct random_data *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

/*extern*/ int initstate_r (unsigned int __seed, char *__restrict __statebuf,
   size_t __statelen,
   struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)));

/*extern*/ int setstate_r (char *__restrict __statebuf,
         struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));






/*extern*/ int rand (void) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ void srand (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));




/*extern*/ int rand_r (unsigned int *__seed) __attribute__ ((__nothrow__ , __leaf__));







/*extern*/ double drand48 (void) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ double erand48 (unsigned short int __xsubi[3]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


/*extern*/ long int lrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ long int nrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


/*extern*/ long int mrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ long int jrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


/*extern*/ void srand48 (long int __seedval) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ unsigned short int *seed48 (unsigned short int __seed16v[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
/*extern*/ void lcong48 (unsigned short int __param[7]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





struct drand48_data
  {
    unsigned short int __x[3];
    unsigned short int __old_x[3];
    unsigned short int __c;
    unsigned short int __init;
    __extension__ unsigned long long int __a;

  };


/*extern*/ int drand48_r (struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
/*extern*/ int erand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


/*extern*/ int lrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
/*extern*/ int nrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


/*extern*/ int mrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
/*extern*/ int jrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


/*extern*/ int srand48_r (long int __seedval, struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

/*extern*/ int seed48_r (unsigned short int __seed16v[3],
       struct drand48_data *__buffer) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ int lcong48_r (unsigned short int __param[7],
        struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));







/*extern*/ void *realloc (void *__ptr, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));

/*extern*/ void free (void *__ptr) __attribute__ ((__nothrow__ , __leaf__));




/*extern*/ void cfree (void *__ptr) __attribute__ ((__nothrow__ , __leaf__));














/*extern*/ void *alloca (size_t __size) __attribute__ ((__nothrow__ , __leaf__));












/*extern*/ void *valloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) ;




/*extern*/ int posix_memalign (void **__memptr, size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;



/*extern*/ void abort (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));



/*extern*/ int atexit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






/*extern*/ int on_exit (void (*__func) (int __status, void *__arg), void *__arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






/*extern*/ void exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));













/*extern*/ void _Exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));






/*extern*/ char *getenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;


/*extern*/ int putenv (char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





/*extern*/ int setenv (const char *__name, const char *__value, int __replace)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));


/*extern*/ int unsetenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






/*extern*/ int clearenv (void) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ char *mktemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

/*extern*/ int mkstemp (char *__template) __attribute__ ((__nonnull__ (1))) ;

/*extern*/ int mkstemps (char *__template, int __suffixlen) __attribute__ ((__nonnull__ (1))) ;

/*extern*/ char *mkdtemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;






/*extern*/ int system (const char *__command) ;


/*extern*/ char *realpath (const char *__restrict __name,
         char *__restrict __resolved) __attribute__ ((__nothrow__ , __leaf__)) ;






typedef int (*__compar_fn_t) (const void *, const void *);




/*extern*/ void *bsearch (const void *__key, const void *__base,
        size_t __nmemb, size_t __size, __compar_fn_t __compar)
     __attribute__ ((__nonnull__ (1, 2, 5))) ;




/*extern*/ __inline __attribute__ ((__gnu_inline__)) void *
bsearch (const void *__key, const void *__base, size_t __nmemb, size_t __size,
  __compar_fn_t __compar)
{
  size_t __l, __u, __idx;
  const void *__p;
  int __comparison;

  __l = 0;
  __u = __nmemb;
  while (__l < __u)
    {
      __idx = (__l + __u) / 2;
      __p = (void *) (((const char *) __base) + (__idx * __size));
      __comparison = (*__compar) (__key, __p);
      if (__comparison < 0)
 __u = __idx;
      else if (__comparison > 0)
 __l = __idx + 1;
      else
 return (void *) __p;
    }

  return ((void *)0);
}





/*extern*/ void qsort (void *__base, size_t __nmemb, size_t __size,
     __compar_fn_t __compar) __attribute__ ((__nonnull__ (1, 4)));

/*extern*/ int abs (int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
/*extern*/ long int labs (long int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;



__extension__ /*extern*/ long long int llabs (long long int __x)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;







/*extern*/ div_t div (int __numer, int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
/*extern*/ ldiv_t ldiv (long int __numer, long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;




__extension__ /*extern*/ lldiv_t lldiv (long long int __numer,
        long long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;


/*extern*/ char *ecvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;




/*extern*/ char *fcvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;




/*extern*/ char *gcvt (double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3))) ;




/*extern*/ char *qecvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;
/*extern*/ char *qfcvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;
/*extern*/ char *qgcvt (long double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3))) ;




/*extern*/ int ecvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
/*extern*/ int fcvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));

/*extern*/ int qecvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
/*extern*/ int qfcvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));






/*extern*/ int mblen (const char *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ int mbtowc (wchar_t *__restrict __pwc,
     const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ int wctomb (char *__s, wchar_t __wchar) __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ size_t mbstowcs (wchar_t *__restrict __pwcs,
   const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ size_t wcstombs (char *__restrict __s,
   const wchar_t *__restrict __pwcs, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__));








/*extern*/ int rpmatch (const char *__response) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;

/*extern*/ int getsubopt (char **__restrict __optionp,
        char *const *__restrict __tokens,
        char **__restrict __valuep)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2, 3))) ;

/*extern*/ int getloadavg (double __loadavg[], int __nelem)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





static double __sym_strtod(const char * param0, char ** param1, ...);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) double
__attribute__ ((__nothrow__ , __leaf__)) atof (const char *__nptr)
{
  return __sym_strtod (__nptr, (char **) ((void *)0));
}



























typedef long int __jmp_buf[8];






struct __jmp_buf_tag
  {




    __jmp_buf __jmpbuf;
    int __mask_was_saved;
    __sigset_t __saved_mask;
  };




typedef struct __jmp_buf_tag jmp_buf[1];



/*extern*/ int setjmp (jmp_buf __env) __attribute__ ((__nothrow__));






/*extern*/ int __sigsetjmp (struct __jmp_buf_tag __env[1], int __savemask) __attribute__ ((__nothrow__));



/*extern*/ int _setjmp (struct __jmp_buf_tag __env[1]) __attribute__ ((__nothrow__));










/*extern*/ void longjmp (struct __jmp_buf_tag __env[1], int __val)
     __attribute__ ((__nothrow__)) __attribute__ ((__noreturn__));







/*extern*/ void _longjmp (struct __jmp_buf_tag __env[1], int __val)
     __attribute__ ((__nothrow__)) __attribute__ ((__noreturn__));







typedef struct __jmp_buf_tag sigjmp_buf[1];

/*extern*/ void siglongjmp (sigjmp_buf __env, int __val)
     __attribute__ ((__nothrow__)) __attribute__ ((__noreturn__));




/*extern*/ sigjmp_buf top_level;
/*extern*/ sigjmp_buf subshell_top_level;
/*extern*/ sigjmp_buf return_catch;








enum r_instruction {
  r_output_direction, r_input_direction, r_inputa_direction,
  r_appending_to, r_reading_until, r_duplicating_input,
  r_duplicating_output, r_deblank_reading_until, r_close_this,
  r_err_and_out, r_input_output, r_output_force,
  r_duplicating_input_word, r_duplicating_output_word
};

enum command_type { cm_for, cm_case, cm_while, cm_if, cm_simple, cm_select,
      cm_connection, cm_function_def, cm_until, cm_group };

typedef struct word_desc {
  char *word;
  int flags;
} WORD_DESC;


typedef struct word_list {
  struct word_list *next;
  WORD_DESC *word;
} WORD_LIST;

typedef union {
  long dest;
  WORD_DESC *filename;
} REDIRECTEE;

typedef struct redirect {
  struct redirect *next;
  int redirector;
  int flags;
  enum r_instruction instruction;
  REDIRECTEE redirectee;
  char *here_doc_eof;
} REDIRECT;



typedef struct element {
  WORD_DESC *word;
  REDIRECT *redirect;
} ELEMENT;

typedef struct command {
  enum command_type type;
  int flags;
  int line;
  REDIRECT *redirects;
  union {
    struct for_com *For;
    struct case_com *Case;
    struct while_com *While;
    struct if_com *If;
    struct connection *Connection;
    struct simple_com *Simple;
    struct function_def *Function_def;
    struct group_com *Group;

    struct select_com *Select;

  } value;
} COMMAND;


typedef struct connection {
  int ignore;
  COMMAND *first;
  COMMAND *second;
  int connector;
} CONNECTION;




typedef struct pattern_list {
  struct pattern_list *next;
  WORD_LIST *patterns;
  COMMAND *action;
} PATTERN_LIST;


typedef struct case_com {
  int flags;
  WORD_DESC *word;
  PATTERN_LIST *clauses;
} CASE_COM;


typedef struct for_com {
  int flags;
  WORD_DESC *name;
  WORD_LIST *map_list;
  COMMAND *action;


} FOR_COM;



typedef struct select_com {
  int flags;
  WORD_DESC *name;
  WORD_LIST *map_list;
  COMMAND *action;


} SELECT_COM;



typedef struct if_com {
  int flags;
  COMMAND *test;
  COMMAND *true_case;
  COMMAND *false_case;
} IF_COM;


typedef struct while_com {
  int flags;
  COMMAND *test;
  COMMAND *action;
} WHILE_COM;


typedef struct simple_com {
  int flags;
  WORD_LIST *words;

  REDIRECT *redirects;
  int line;
} SIMPLE_COM;


typedef struct function_def {
  int ignore;
  WORD_DESC *name;
  COMMAND *command;
  int line;
} FUNCTION_DEF;



typedef struct group_com {
  int ignore;
  COMMAND *command;
} GROUP_COM;

/*extern*/ COMMAND *global_command;



/*extern*/ WORD_DESC *copy_word (WORD_DESC *);
/*extern*/ WORD_LIST *copy_word_list (WORD_LIST *);
/*extern*/ REDIRECT *copy_redirect (REDIRECT *);
/*extern*/ REDIRECT *copy_redirects (REDIRECT *);
/*extern*/ COMMAND *copy_command (COMMAND *);



/*extern*/ char *xmalloc (), *xrealloc ();






/*extern*/ char *strcpy ();

typedef struct g_list {
  struct g_list *next;
} GENERIC_LIST;



typedef struct {
  char *word;
  int token;
} STRING_INT_ALIST;

typedef int Function ();
typedef void VFunction ();
typedef char *CPFunction ();
typedef char **CPPFunction ();

/*extern*/ char *xmalloc (size_t);
/*extern*/ char *xrealloc (void *, size_t);
/*extern*/ void xfree (char *);


/*extern*/ void posix_initialize (int);

/*extern*/ char *itos (int);
/*extern*/ long string_to_long (char *);


/*extern*/ quad_t string_to_rlimtype (char *);
/*extern*/ void print_rlimtype (quad_t, int);


/*extern*/ void timeval_to_secs ();
/*extern*/ void print_timeval ();
/*extern*/ void clock_t_to_secs ();
/*extern*/ void print_time_in_hz ();

/*extern*/ int all_digits (char *);
/*extern*/ int legal_number (char *, long *);
/*extern*/ int legal_identifier (char *);
/*extern*/ int check_identifier (WORD_DESC *, int);

/*extern*/ void unset_nodelay_mode (int);
/*extern*/ void check_dev_tty ();
/*extern*/ int same_file ();
/*extern*/ int move_to_high_fd (int, int);
/*extern*/ int check_binary_file (unsigned char *, int);

/*extern*/ char *canonicalize_pathname (char *);
/*extern*/ char *make_absolute (char *, char *);
/*extern*/ int absolute_pathname (char *);
/*extern*/ int absolute_program (char *);
/*extern*/ char *base_pathname (char *);
/*extern*/ char *full_pathname (char *);
/*extern*/ char *polite_directory_format (char *);

/*extern*/ char *extract_colon_unit (char *, int *);

/*extern*/ void tilde_initialize ();
/*extern*/ char *bash_tilde_expand (char *);



/*extern*/ char *get_name_for_error ();


/*extern*/ void file_error (char *);


/*extern*/ void programming_error (const char *, ...);


/*extern*/ void report_error (const char *, ...);


/*extern*/ void parser_error (int, const char *, ...);


/*extern*/ void fatal_error (const char *, ...);


/*extern*/ void sys_error (const char *, ...);


/*extern*/ void internal_error (const char *, ...);
















typedef int arrayind_t;

enum atype {array_indexed, array_assoc};

typedef struct array {
 enum atype type;
 arrayind_t max_index, num_elements, max_size;
 struct array_element *head;
} ARRAY;

typedef struct array_element {
 arrayind_t ind;
 char *value;
 struct array_element *next, *prev;
} ARRAY_ELEMENT;

char *array_reference (ARRAY *, arrayind_t);

/*extern*/ int array_add_element (ARRAY *, arrayind_t, char *);
/*extern*/ ARRAY_ELEMENT *array_delete_element (ARRAY *, arrayind_t);

/*extern*/ ARRAY_ELEMENT *new_array_element (arrayind_t, char *);
/*extern*/ void destroy_array_element (ARRAY_ELEMENT *);

/*extern*/ ARRAY *new_array ();
/*extern*/ void empty_array (ARRAY *);
/*extern*/ void dispose_array (ARRAY *);
/*extern*/ ARRAY *dup_array (ARRAY *);
/*extern*/ ARRAY *dup_array_subrange (ARRAY *, ARRAY_ELEMENT *, ARRAY_ELEMENT *);
/*extern*/ ARRAY_ELEMENT *new_array_element (arrayind_t, char *);
/*extern*/ ARRAY_ELEMENT *copy_array_element (ARRAY_ELEMENT *);

/*extern*/ WORD_LIST *array_to_word_list (ARRAY *);
/*extern*/ ARRAY *word_list_to_array (WORD_LIST *);
/*extern*/ ARRAY *assign_word_list (ARRAY *, WORD_LIST *);

/*extern*/ char *array_to_assignment_string (ARRAY *);
/*extern*/ char *quoted_array_assignment_string (ARRAY *);
/*extern*/ char *array_to_string (ARRAY *, char *, int);
/*extern*/ ARRAY *string_to_array (char *, char *);

/*extern*/ char *array_subrange (ARRAY *, int, int, int);
/*extern*/ char *array_pat_subst (ARRAY *, char *, char *, int);

/*extern*/ ARRAY *array_quote (ARRAY *);





typedef struct bucket_contents {
  struct bucket_contents *next;
  char *key;
  char *data;
  int times_found;
} BUCKET_CONTENTS;

typedef struct hash_table {
  BUCKET_CONTENTS **bucket_array;
  int nbuckets;
  int nentries;
} HASH_TABLE;

/*extern*/ int hash_string ();
/*extern*/ HASH_TABLE *make_hash_table ();
/*extern*/ BUCKET_CONTENTS *find_hash_item ();
/*extern*/ BUCKET_CONTENTS *remove_hash_item ();
/*extern*/ BUCKET_CONTENTS *add_hash_item ();
/*extern*/ BUCKET_CONTENTS *get_hash_bucket ();
/*extern*/ void flush_hash_table ();




typedef struct variable *DYNAMIC_FUNC ();

typedef struct variable {
  char *name;
  char *value;
  DYNAMIC_FUNC *dynamic_value;


  DYNAMIC_FUNC *assign_func;


  int attributes;
  int context;
  struct variable *prev_context;
} SHELL_VAR;

/*extern*/ int variable_context;
/*extern*/ HASH_TABLE *shell_variables, *shell_functions;
/*extern*/ char *dollar_vars[];
/*extern*/ char **export_env;
/*extern*/ char **non_unsettable_vars;

/*extern*/ void initialize_shell_variables (char **, int);
/*extern*/ SHELL_VAR *set_if_not (char *, char *);
/*extern*/ void set_lines_and_columns (int, int);

/*extern*/ SHELL_VAR *find_function (char *);
/*extern*/ SHELL_VAR *find_variable (char *);
/*extern*/ SHELL_VAR *find_variable_internal (char *, int);
/*extern*/ SHELL_VAR *find_tempenv_variable (char *);
/*extern*/ SHELL_VAR *copy_variable (SHELL_VAR *);
/*extern*/ SHELL_VAR *make_local_variable (char *);
/*extern*/ SHELL_VAR *bind_variable (char *, char *);
/*extern*/ SHELL_VAR *bind_function (char *, COMMAND *);
/*extern*/ SHELL_VAR **map_over (Function *, HASH_TABLE *);
/*extern*/ SHELL_VAR **all_shell_variables ();
/*extern*/ SHELL_VAR **all_shell_functions ();
/*extern*/ SHELL_VAR **all_visible_variables ();
/*extern*/ SHELL_VAR **all_visible_functions ();

/*extern*/ char **make_var_array (HASH_TABLE *);
/*extern*/ char **add_or_supercede (char *, char **);

/*extern*/ char *get_string_value (char *);
/*extern*/ char *make_variable_value (SHELL_VAR *, char *);

/*extern*/ int assignment (char *);
/*extern*/ int variable_in_context (SHELL_VAR *);
/*extern*/ int assign_in_env (char *);
/*extern*/ int unbind_variable (char *);
/*extern*/ int makunbound (char *, HASH_TABLE *);
/*extern*/ int kill_local_variable (char *);
/*extern*/ void delete_all_variables (HASH_TABLE *);

/*extern*/ void adjust_shell_level (int);
/*extern*/ void non_unsettable (char *);
/*extern*/ void dispose_variable (SHELL_VAR *);
/*extern*/ void dispose_used_env_vars ();
/*extern*/ void dispose_function_env ();
/*extern*/ void dispose_builtin_env ();
/*extern*/ void merge_temporary_env ();
/*extern*/ void merge_builtin_env ();
/*extern*/ void kill_all_local_variables ();
/*extern*/ void set_var_read_only (char *);
/*extern*/ void set_func_read_only (char *);
/*extern*/ void set_var_auto_export (char *);
/*extern*/ void set_func_auto_export (char *);
/*extern*/ void sort_variables (SHELL_VAR **);
/*extern*/ void maybe_make_export_env ();
/*extern*/ void put_command_name_into_env (char *);
/*extern*/ void put_gnu_argv_flags_into_env (int, char *);
/*extern*/ void print_var_list (SHELL_VAR **);
/*extern*/ void print_assignment (SHELL_VAR *);
/*extern*/ void print_var_value (SHELL_VAR *, int);
/*extern*/ void print_var_function (SHELL_VAR *);

/*extern*/ char *indirection_level_string ();


/*extern*/ SHELL_VAR *make_new_array_variable (char *);
/*extern*/ SHELL_VAR *make_local_array_variable (char *);
/*extern*/ SHELL_VAR *convert_var_to_array (SHELL_VAR *);
/*extern*/ SHELL_VAR *bind_array_variable (char *, int, char *);
/*extern*/ SHELL_VAR *assign_array_from_string (char *, char *);
/*extern*/ SHELL_VAR *assign_array_var_from_word_list (SHELL_VAR *, WORD_LIST *);
/*extern*/ SHELL_VAR *assign_array_var_from_string (SHELL_VAR *, char *);
/*extern*/ int unbind_array_element (SHELL_VAR *, char *);
/*extern*/ int skipsubscript (char *, int);
/*extern*/ void print_array_assignment (SHELL_VAR *, int);



/*extern*/ int interrupt_state;

/*extern*/ void throw_to_top_level ();




































/*extern*/ void begin_unwind_frame ();
/*extern*/ void discard_unwind_frame ();
/*extern*/ void run_unwind_frame ();
/*extern*/ void add_unwind_protect ();
/*extern*/ void remove_unwind_protect ();
/*extern*/ void run_unwind_protects ();
/*extern*/ void unwind_protect_var ();



typedef union {
  char *s;
  int i;
} UWP;



/*extern*/ void dispose_command (COMMAND *);
/*extern*/ void dispose_word (WORD_DESC *);
/*extern*/ void dispose_words (WORD_LIST *);
/*extern*/ void dispose_word_array (char **);
/*extern*/ void dispose_redirects (REDIRECT *);



/*extern*/ WORD_LIST *make_word_list (WORD_DESC *, WORD_LIST *);
/*extern*/ WORD_LIST *add_string_to_list (char *, WORD_LIST *);

/*extern*/ WORD_DESC *make_bare_word (char *);
/*extern*/ WORD_DESC *make_word (char *);
/*extern*/ WORD_DESC *make_word_from_token (int);

/*extern*/ COMMAND *make_command (enum command_type, SIMPLE_COM *);
/*extern*/ COMMAND *command_connect (COMMAND *, COMMAND *, int);
/*extern*/ COMMAND *make_for_command (WORD_DESC *, WORD_LIST *, COMMAND *);
/*extern*/ COMMAND *make_group_command (COMMAND *);
/*extern*/ COMMAND *make_case_command (WORD_DESC *, PATTERN_LIST *);
/*extern*/ PATTERN_LIST *make_pattern_list (WORD_LIST *, COMMAND *);
/*extern*/ COMMAND *make_if_command (COMMAND *, COMMAND *, COMMAND *);
/*extern*/ COMMAND *make_while_command (COMMAND *, COMMAND *);
/*extern*/ COMMAND *make_until_command (COMMAND *, COMMAND *);
/*extern*/ COMMAND *make_bare_simple_command ();
/*extern*/ COMMAND *make_simple_command (ELEMENT, COMMAND *);
/*extern*/ void make_here_document (REDIRECT *);
/*extern*/ REDIRECT *make_redirection (int, enum r_instruction, REDIRECTEE);
/*extern*/ COMMAND *make_function_def (WORD_DESC *, COMMAND *, int, int);
/*extern*/ COMMAND *clean_simple_command (COMMAND *);

/*extern*/ COMMAND *make_select_command (WORD_DESC *, WORD_LIST *, COMMAND *);

/*extern*/ COMMAND *connect_async_list (COMMAND *, COMMAND *, int);



/*extern*/ char *substring (char *, int, int);



/*extern*/ char * de_backslash (char *);


/*extern*/ void unquote_bang (char *);




/*extern*/ char *extract_command_subst (char *, int *);




/*extern*/ char *extract_arithmetic_subst (char *, int *);





/*extern*/ char *extract_process_subst (char *, char *, int *);



/*extern*/ char *assignment_name (char *);



/*extern*/ char *string_list (WORD_LIST *);






/*extern*/ char *string_list_dollar_star (WORD_LIST *);



/*extern*/ void word_list_remove_quoted_nulls (WORD_LIST *);



/*extern*/ WORD_LIST *list_string (char *, char *, int);

/*extern*/ char *get_word_from_string (char **, char *, char **);
/*extern*/ char *strip_trailing_ifs_whitespace (char *, char *, int);






/*extern*/ int do_assignment (char *);
/*extern*/ int do_assignment_no_expand (char *);


/*extern*/ SHELL_VAR *do_array_element_assignment (char *, char *);






/*extern*/ char *sub_append_string (char *, char *, int *, int *);



/*extern*/ char *sub_append_number (int, char *, int *, int *);


/*extern*/ WORD_LIST *list_rest_of_args ();




/*extern*/ char *string_rest_of_args (int);

/*extern*/ int number_of_args ();






/*extern*/ WORD_LIST *expand_string_unsplit (char *, int);






/*extern*/ WORD_LIST *expand_string (char *, int);


/*extern*/ char *dequote_string (char *);




/*extern*/ WORD_LIST *expand_word (WORD_DESC *, int);




/*extern*/ WORD_LIST *expand_word_no_split (WORD_DESC *, int);
/*extern*/ WORD_LIST *expand_word_leave_quoted (WORD_DESC *, int);


/*extern*/ char *get_dollar_var_value (int);


/*extern*/ char *quote_string (char *);



/*extern*/ char *string_quote_removal (char *, int);



/*extern*/ WORD_DESC *word_quote_removal (WORD_DESC *, int);




/*extern*/ WORD_LIST *word_list_quote_removal (WORD_LIST *, int);




/*extern*/ WORD_LIST *word_split (WORD_DESC *);




/*extern*/ WORD_LIST *expand_words (WORD_LIST *);



/*extern*/ WORD_LIST *expand_words_no_vars (WORD_LIST *);



/*extern*/ void stupidly_hack_special_variables (char *);

/*extern*/ char *pat_subst (char *, char *, char *, int);

/*extern*/ void unlink_fifo_list ();


/*extern*/ int array_expand_index (char *, int);
/*extern*/ int valid_array_reference (char *);
/*extern*/ char *get_array_value (char *, int);
/*extern*/ SHELL_VAR *array_variable_part (char *, char **, int *);
/*extern*/ WORD_LIST *list_string_with_quotes (char *);
/*extern*/ char *extract_array_assignment_list (char *, int *);




void sv_path (), sv_mail (), sv_ignoreeof (), sv_strict_posix ();
void sv_optind (), sv_opterr (), sv_globignore (), sv_locale ();


void sv_terminal (), sv_hostfile ();



void sv_tz ();



void sv_histsize (), sv_histignore (), sv_history_control ();

void sv_histchars ();



typedef void SigHandler ();

/*extern*/ SigHandler *set_signal_handler ();

/*extern*/ void termination_unwind_protect (int);
/*extern*/ void sigint_sighandler (int);
/*extern*/ void initialize_signals ();
/*extern*/ void reinitialize_signals ();
/*extern*/ void reset_terminating_signals ();
/*extern*/ void throw_to_top_level ();
/*extern*/ void jump_to_top_level (int);


/*extern*/ SigHandler *set_sigint_handler ();





/*extern*/ long evalexp (char *);







/*extern*/ char *make_command_string (COMMAND *);
/*extern*/ void print_command (COMMAND *);
/*extern*/ void print_simple_command (SIMPLE_COM *);
/*extern*/ char *named_function_string (char *, COMMAND *, int);
/*extern*/ void print_word_list (WORD_LIST *, char *);
/*extern*/ void xtrace_print_word_list (WORD_LIST *);


/*extern*/ int exit_shell (int);
/*extern*/ void disable_priv_mode ();


/*extern*/ int maybe_make_restricted (char *);



/*extern*/ int reader_loop ();
/*extern*/ int parse_command ();
/*extern*/ int read_command ();


/*extern*/ int group_member ();
/*extern*/ int test_command ();



/*extern*/ char **brace_expand (char *);



/*extern*/ int yyparse ();
/*extern*/ void reset_parser ();


/*extern*/ char *shell_version_string ();
/*extern*/ void show_shell_version (int);


/*extern*/ void set_default_locale ();
/*extern*/ void set_default_locale_vars ();
/*extern*/ int set_locale_var (char *, char *);
/*extern*/ int set_lang (char *, char *);
/*extern*/ char *get_locale_var (char *);
/*extern*/ char *localetrans (char *, int, int *);


/*extern*/ void map_over_list (GENERIC_LIST *, Function *);
/*extern*/ void map_over_words (WORD_LIST *, Function *);
/*extern*/ GENERIC_LIST *reverse_list ();
/*extern*/ int list_length ();
/*extern*/ GENERIC_LIST *list_append ();
/*extern*/ GENERIC_LIST *delete_element ();


/*extern*/ long get_clk_tck ();


/*extern*/ char *strerror (int);







/*extern*/ int dup2 (int, int);

/*extern*/ char *ansicstr (char *, int, int *);
/*extern*/ int find_name_in_array (char *, char **);
/*extern*/ int array_len (char **);
/*extern*/ void free_array_members (char **);
/*extern*/ void free_array (char **);
/*extern*/ char **copy_array (char **);
/*extern*/ int qsort_string_compare ();
/*extern*/ void sort_char_array (char **);
/*extern*/ char **word_list_to_argv (WORD_LIST *, int, int, int *);
/*extern*/ WORD_LIST *argv_to_word_list (char **, int, int);

/*extern*/ char *strsub (char *, char *, char *, int);
/*extern*/ void strip_leading (char *);
/*extern*/ void strip_trailing (char *, int);
/*extern*/ char *strindex (char *, char *);
/*extern*/ void xbcopy (char *, char *, int);


/*extern*/ int EOF_Reached;

/*extern*/ char **shell_environment;
/*extern*/ WORD_LIST *rest_of_args;


/*extern*/ int executing, login_shell;



struct fd_bitmap {
  long size;
  char *bitmap;
};







struct user_info {
  int uid, euid;
  int gid, egid;
  char *user_name;
  char *shell;
  char *home_dir;
};

/*extern*/ struct user_info current_user;



struct flags_alist {
  char name;
  int *value;
};

/*extern*/ struct flags_alist shell_flags[];

/*extern*/ int
  mark_modified_vars, exit_immediately_on_error, disallow_filename_globbing,
  place_keywords_in_env, read_but_dont_execute,
  just_one_command, unbound_vars_is_error, echo_input_at_read,
  echo_command_at_execute, no_invisible_vars, noclobber,
  hashing_enabled, forced_interactive, privileged_mode,
  asynchronous_notification, interactive_comments, no_symbolic_links;






/*extern*/ int brace_expansion;



/*extern*/ int history_expansion;



/*extern*/ int restricted;


/*extern*/ int *find_flag (int);
/*extern*/ int change_flag (int, int);
/*extern*/ char *which_set_flags ();



/*extern*/ struct fd_bitmap *new_fd_bitmap (long);
/*extern*/ void dispose_fd_bitmap (struct fd_bitmap *);
/*extern*/ void close_fd_bitmap (struct fd_bitmap *);
/*extern*/ int executing_line_number ();
/*extern*/ int execute_command (COMMAND *);
/*extern*/ int execute_command_internal (COMMAND *, int, int, int, struct fd_bitmap *);
/*extern*/ int shell_execve (char *, char **, char **);
/*extern*/ char *redirection_expand (WORD_DESC *);
/*extern*/ int file_status (char *);
/*extern*/ int executable_file (char *);
/*extern*/ int is_directory (char *);
/*extern*/ char *search_for_command (char *);
/*extern*/ char *find_user_command (char *);
/*extern*/ char *find_path_file (char *);
/*extern*/ char *user_command_matches (char *, int, int);
/*extern*/ void setup_async_signals ();


/*extern*/ void close_all_files ();



/*extern*/ int time_to_check_mail ();
/*extern*/ void reset_mail_timer ();
/*extern*/ void reset_mail_files ();
/*extern*/ void free_mail_files ();
/*extern*/ char *make_default_mailpath ();
/*extern*/ void remember_mail_dates ();
/*extern*/ void check_mail ();



enum stream_type {st_none, st_stdin, st_stream, st_string, st_bstream};

typedef struct BSTREAM
{
  int b_fd;
  char *b_buffer;
  int b_size;
  int b_used;
  int b_flag;
  int b_inputp;
} BUFFERED_STREAM;

/*extern*/ BUFFERED_STREAM **buffers;

/*extern*/ BUFFERED_STREAM *fd_to_buffered_stream ();

/*extern*/ int default_buffered_input;



typedef union {
  FILE *file;
  char *string;

  int buffered_fd;

} INPUT_STREAM;

typedef struct {
  enum stream_type type;
  char *name;
  INPUT_STREAM location;
  Function *getter;
  Function *ungetter;
} BASH_INPUT;

/*extern*/ BASH_INPUT bash_input;


/*extern*/ void initialize_bash_input ();
/*extern*/ void init_yy_io (Function *, Function *, int, char *, INPUT_STREAM);
/*extern*/ void with_input_from_stdin ();
/*extern*/ void with_input_from_string (char *, char *);
/*extern*/ void with_input_from_stream (FILE *, char *);
/*extern*/ void push_stream (int);
/*extern*/ void pop_stream ();
/*extern*/ int stream_on_stack (enum stream_type);
/*extern*/ char *read_secondary_line (int);
/*extern*/ int find_reserved_word (char *);
/*extern*/ char *decode_prompt_string (char *);
/*extern*/ void gather_here_documents ();
/*extern*/ void execute_prompt_command (char *);


/*extern*/ int getc_with_restart ();
/*extern*/ int ungetc_with_restart ();



/*extern*/ int check_bash_input (int);
/*extern*/ int duplicate_buffered_stream (int, int);
/*extern*/ BUFFERED_STREAM *fd_to_buffered_stream (int);
/*extern*/ BUFFERED_STREAM *open_buffered_stream (char *);
/*extern*/ void free_buffered_stream (BUFFERED_STREAM *);
/*extern*/ int close_buffered_stream (BUFFERED_STREAM *);
/*extern*/ int close_buffered_fd (int);
/*extern*/ int sync_buffered_stream (int);
/*extern*/ int buffered_getchar ();
/*extern*/ int buffered_ungetchar (int);
/*extern*/ void with_input_from_buffered_stream (int, char *);









/*extern*/ void builtin_error (const char *, ...);
/*extern*/ void builtin_usage ();
/*extern*/ void bad_option ();

/*extern*/ char **make_builtin_argv ();

/*extern*/ int get_numeric_arg ();
/*extern*/ void remember_args ();
/*extern*/ void no_args ();
/*extern*/ int no_options ();

/*extern*/ int read_octal ();

/*extern*/ void push_context (), pop_context ();
/*extern*/ void push_dollar_vars (), pop_dollar_vars ();
/*extern*/ void dispose_saved_dollar_vars ();
/*extern*/ int dollar_vars_changed ();
/*extern*/ void set_dollar_vars_unchanged (), set_dollar_vars_changed ();


/*extern*/ char *the_current_working_directory;
/*extern*/ char *get_working_directory ();
/*extern*/ void set_working_directory ();


/*extern*/ int get_job_spec ();


/*extern*/ int display_signal_list ();



/*extern*/ struct builtin *builtin_address_internal ();
/*extern*/ Function *find_shell_builtin ();
/*extern*/ Function *builtin_address ();
/*extern*/ Function *find_special_builtin ();

/*extern*/ void initialize_shell_builtins ();

/*extern*/ char *single_quote ();
/*extern*/ char *double_quote ();
/*extern*/ char *backslash_quote ();
/*extern*/ int contains_shell_metas ();


/*extern*/ void initialize_filename_hashing ();
/*extern*/ void flush_hashed_filenames ();
/*extern*/ char *find_hashed_filename ();
/*extern*/ void remove_hashed_filename ();
/*extern*/ void remember_filename ();


/*extern*/ void initialize_shell_options ();
/*extern*/ void list_minus_o_opts ();
/*extern*/ int set_minus_o_option ();
/*extern*/ int minus_o_option_value ();


/*extern*/ int describe_command ();


/*extern*/ int set_or_show_attributes ();
/*extern*/ int show_var_attributes ();
/*extern*/ int show_name_attributes ();
/*extern*/ void set_var_attribute ();


/*extern*/ char *get_dirstack_element ();
/*extern*/ void set_dirstack_element ();
/*extern*/ WORD_LIST *get_directory_stack ();


/*extern*/ int parse_and_execute ();
/*extern*/ void parse_and_execute_cleanup ();


/*extern*/ int maybe_execute_file (char *, int);
/*extern*/ int source_file (char *);



/*extern*/ CPFunction *tilde_expansion_failure_hook;




/*extern*/ char **tilde_additional_prefixes;




/*extern*/ char **tilde_additional_suffixes;


/*extern*/ char *tilde_expand ();



/*extern*/ char *tilde_expand_word ();





/*extern*/ int remember_on_history;
/*extern*/ int history_lines_this_session;
/*extern*/ int history_lines_in_file;
/*extern*/ int history_expansion;
/*extern*/ int history_control;
/*extern*/ int command_oriented_history;


/*extern*/ int history_expansion_inhibited;


/*extern*/ void bash_initialize_history ();
/*extern*/ void bash_history_reinit ();
/*extern*/ void bash_history_disable ();
/*extern*/ void bash_history_enable ();
/*extern*/ void load_history ();
/*extern*/ void save_history ();
/*extern*/ int maybe_append_history ();
/*extern*/ int maybe_save_shell_history ();
/*extern*/ char *pre_process_line ();
/*extern*/ int history_number ();
/*extern*/ void maybe_add_history ();

/*extern*/ void setup_history_ignore ();

/*extern*/ char *last_history_line ();




/*extern*/ int posixly_correct;
/*extern*/ int variable_context, line_number;
/*extern*/ int interactive, interactive_shell, login_shell;
/*extern*/ int subshell_environment, indirection_level;
/*extern*/ int build_version, patch_level;
/*extern*/ char *dist_version, *release_status;
/*extern*/ char *shell_name;
/*extern*/ char *primary_prompt, *secondary_prompt;
/*extern*/ char *current_host_name;
/*extern*/ Function *this_shell_builtin;
/*extern*/ char *this_command_name;
/*extern*/ time_t shell_start_time;



HASH_TABLE *shell_variables = (HASH_TABLE *)((void *)0);



HASH_TABLE *shell_functions = (HASH_TABLE *)((void *)0);



int variable_context = 0;



char **temporary_env = (char **)((void *)0);



char **function_env = (char **)((void *)0);




char **builtin_env = (char **)((void *)0);



char *dollar_vars[10];
WORD_LIST *rest_of_args = (WORD_LIST *)((void *)0);


int dollar_dollar_pid;




char **export_env = (char **)((void *)0);


int array_needs_making = 1;



int shell_level = 0;

static char *have_local_variables;
static int local_variable_stack_size;


static void uidset ();
static void initialize_dynamic_variables ();
static void make_vers_array ();
static void sbrand ();
static int qsort_var_comp ();






static struct hash_table * __sym_make_hash_table();
static unsigned long __sym_strlen(const char * param0, ...);
static char * __sym_xmalloc(size_t param0, ...);
static int __sym_strncmp(const char * param0, const char * param1, size_t param2, ...);
static int __sym_sprintf(char * param0, const char * param1, ...);
static int __sym_parse_and_execute();
static struct variable * __sym_find_function(char * param0, ...);
static void __sym_report_error(const char * param0, ...);
static struct variable * __sym_bind_variable(char * param0, char * param1, ...);
static void __sym_free(void * param0, ...);
static struct variable * __sym_find_variable(char * param0, ...);
static int __sym_same_file();
static void __sym_set_working_directory();
static char * __sym_get_working_directory();
static int __sym_getpid();
static struct variable * __sym_set_if_not(char * param0, char * param1, ...);
static void __sym_adjust_shell_level(int param0, ...);
static char * __sym_itos(int param0, ...);
static int __sym_getppid();
static void __sym_sv_optind();
static void __sym_sv_opterr();
static char * __sym_strcpy(char * param0, const char * param1, ...);
static char * __sym_find_user_command(char * param0, ...);
static int __sym_file_status(char * param0, ...);
static char * __sym_make_absolute(char * param0, char * param1, ...);
static char * __sym_get_string_value(char * param0, ...);
static char * __sym_canonicalize_pathname(char * param0, ...);
static char * __sym_full_pathname(char * param0, ...);
static char * __sym_shell_version_string();
static void __sym_make_vers_array();
static void __sym_sv_strict_posix();
static char * __sym_bash_tilde_expand(char * param0, ...);
static void __sym_sv_histsize();
static void __sym_sbrand();
static void __sym_sv_ignoreeof();
static void __sym_sv_history_control();
static void __sym_sv_histignore();
static void __sym_uidset();
static void __sym_initialize_dynamic_variables();
void
initialize_shell_variables (env, no_functions)
     char **env;
     int no_functions;
{
  char *name, *string, *temp_string;
  int c, char_index, string_index, string_length;
  SHELL_VAR *temp_var;

  if (!shell_variables)
    shell_variables = __sym_make_hash_table (0);

  if (!shell_functions)
    shell_functions = __sym_make_hash_table (0);
  assert(string_index < 128);
  for (string_index = 0; string = env[string_index++]; )
    {
      char_index = 0;

      string_length = __sym_strlen (string);
      name = __sym_xmalloc (1 + string_length);
assert(string != 0);
      while ((c = *string++) && c != '='){
          assert(char_index < 1 + string_length);
 name[char_index++] = c;
      }
      assert(char_index < 1 + string_length);
      name[char_index] = '\0';


      if (no_functions == 0 && (("() {")[0] == (string)[0] && (__extension__ (__builtin_constant_p (4) && ((__builtin_constant_p ("() {") && __sym_strlen ("() {") < ((size_t) (4))) || (__builtin_constant_p (string) && __sym_strlen (string) < ((size_t) (4)))) ? __extension__ ({ size_t __s1_len, __s2_len; (__builtin_constant_p ("() {") && __builtin_constant_p (string) && (__s1_len = __builtin_strlen ("() {"), __s2_len = __builtin_strlen (string), (!((size_t)(const void *)(("() {") + 1) - (size_t)(const void *)("() {") == 1) || __s1_len >= 4) && (!((size_t)(const void *)((string) + 1) - (size_t)(const void *)(string) == 1) || __s2_len >= 4)) ? __builtin_strcmp ("() {", string) : (__builtin_constant_p ("() {") && ((size_t)(const void *)(("() {") + 1) - (size_t)(const void *)("() {") == 1) && (__s1_len = __builtin_strlen ("() {"), __s1_len < 4) ? (__builtin_constant_p (string) && ((size_t)(const void *)((string) + 1) - (size_t)(const void *)(string) == 1) ? __builtin_strcmp ("() {", string) : (__extension__ ({ const unsigned char *__s2 = (const unsigned char *) (const char *) (string); int __result = (((const unsigned char *) (const char *) ("() {"))[0] - __s2[0]); if (__s1_len > 0 && __result == 0) { __result = (((const unsigned char *) (const char *) ("() {"))[1] - __s2[1]); if (__s1_len > 1 && __result == 0) { __result = (((const unsigned char *) (const char *) ("() {"))[2] - __s2[2]); if (__s1_len > 2 && __result == 0) __result = (((const unsigned char *) (const char *) ("() {"))[3] - __s2[3]); } } __result; }))) : (__builtin_constant_p (string) && ((size_t)(const void *)((string) + 1) - (size_t)(const void *)(string) == 1) && (__s2_len = __builtin_strlen (string), __s2_len < 4) ? (__builtin_constant_p ("() {") && ((size_t)(const void *)(("() {") + 1) - (size_t)(const void *)("() {") == 1) ? __builtin_strcmp ("() {", string) : (- (__extension__ ({ const unsigned char *__s2 = (const unsigned char *) (const char *) ("() {"); int __result = (((const unsigned char *) (const char *) (string))[0] - __s2[0]); if (__s2_len > 0 && __result == 0) { __result = (((const unsigned char *) (const char *) (string))[1] - __s2[1]); if (__s2_len > 1 && __result == 0) { __result = (((const unsigned char *) (const char *) (string))[2] - __s2[2]); if (__s2_len > 2 && __result == 0) __result = (((const unsigned char *) (const char *) (string))[3] - __s2[3]); } } __result; })))) : __builtin_strcmp ("() {", string)))); }) : __sym_strncmp ("() {", string, 4))) == 0))
 {
   temp_string = __sym_xmalloc (3 + string_length + __sym_strlen (name));
   __sym_sprintf (temp_string, "%s %s", name, string);

   __sym_parse_and_execute (temp_string, name, 0);
   assert(char_index - 1 < 1 + string_length);
   if (name[char_index - 1] == ')'){
       assert(char_index - 2 < 1 + string_length);
     name[char_index - 2] = '\0';
   }
   if (temp_var = __sym_find_function (name))
     {
       temp_var->attributes |= (0x01 | 0x80);
       array_needs_making = 1;
     }
   else
     __sym_report_error ("error importing function definition for `%s'", name);
 }

      else
 {
   temp_var = __sym_bind_variable (name, string);
   temp_var->attributes |= (0x01 | 0x80);
   array_needs_making = 1;
 }
      __sym_free (name);
    }





  temp_var = find_variable ("PWD");
  assert(temp_var != 0);
  if (temp_var && ((((temp_var)->attributes) & (0x80))) &&
      (temp_string = ((temp_var)->value)) &&
      __sym_same_file (temp_string, ".", (struct stat *)((void *)0), (struct stat *)((void *)0)))
    __sym_set_working_directory (temp_string);
  else
    {
      temp_string = __sym_get_working_directory ("shell-init");
      if (temp_string)
 {
   __sym_bind_variable ("PWD", temp_string);
   __sym_free (temp_string);
 }
    }


  temp_var = __sym_bind_variable ("_", dollar_vars[0]);


  dollar_dollar_pid = (int)__sym_getpid ();



  temp_var = __sym_set_if_not ("PATH", "/usr/gnu/bin:/usr/local/bin:/usr/ucb:/bin:/usr/bin:.");
  do { temp_var->attributes |= 0x01; array_needs_making = 1; } while (0);

  temp_var = __sym_set_if_not ("TERM", "dumb");
  do { temp_var->attributes |= 0x01; array_needs_making = 1; } while (0);


  if (interactive_shell)
    {
      __sym_set_if_not ("PS1", primary_prompt);
      __sym_set_if_not ("PS2", secondary_prompt);
    }
  __sym_set_if_not ("PS4", "+ ");


  temp_var = __sym_bind_variable ("IFS", " \t\n");

  
  temp_var = __sym_bind_variable ("HOSTTYPE", "");
  do { assert(temp_var != 0);temp_var->attributes |= 0x01; array_needs_making = 1; } while (0);
  temp_var = __sym_bind_variable ("OSTYPE", "");
  do { assert(temp_var != 0);temp_var->attributes |= 0x01; array_needs_making = 1; } while (0);
  temp_var = __sym_bind_variable ("MACHTYPE", "");
  do { assert(temp_var != 0);temp_var->attributes |= 0x01; array_needs_making = 1; } while (0);
  temp_var = __sym_bind_variable ("HOSTNAME", current_host_name);
  do { assert(temp_var != 0);temp_var->attributes |= 0x01; array_needs_making = 1; } while (0);





  if (interactive_shell)
    __sym_set_if_not ("MAILCHECK", "60");


  temp_var = __sym_set_if_not ("SHLVL", "0");
  do { assert(temp_var != 0);temp_var->attributes |= 0x01; array_needs_making = 1; } while (0);
  __sym_adjust_shell_level (1);


  name = __sym_itos ((int) __sym_getppid ());
  temp_var = __sym_find_variable ("PPID");
  if (temp_var){
      assert(temp_var != 0);
    temp_var->attributes &= ~(0x02 | 0x01);
  }
  temp_var = __sym_bind_variable ("PPID", name);
  assert(temp_var != 0);
  temp_var->attributes |= (0x02 | 0x40);
  __sym_free (name);


  __sym_bind_variable ("OPTIND", "1");
  __sym_sv_optind ("OPTIND");
  __sym_bind_variable ("OPTERR", "1");
  __sym_sv_opterr ("OPTERR");



  if ((login_shell == 1) && (*shell_name != '/'))
    {

      temp_var = __sym_set_if_not ("HOME", current_user.home_dir);
    assert(temp_var != 0);
      temp_var->attributes |= 0x01;

      name = (char *)__sym_strcpy (__sym_xmalloc (1 + __sym_strlen (current_user.shell)), (current_user.shell));
    }
  else if (*shell_name == '/')
    name = (char *)__sym_strcpy (__sym_xmalloc (1 + __sym_strlen (shell_name)), (shell_name));
  else
    {
      char *tname;
      int s;

      tname = __sym_find_user_command (shell_name);

      if (tname == 0)
 {


   s = __sym_file_status (shell_name);
   if (s & 0x2)
     {
       tname = __sym_make_absolute (shell_name, __sym_get_string_value ("PWD"));
       assert(shell_name != 0);
       if (*shell_name == '.')
  {
    name = __sym_canonicalize_pathname (tname);
    if (name == 0)
      name = tname;
    else
      __sym_free (tname);
  }
      else
  name = tname;
     }
   else
     name = (char *)__sym_strcpy (__sym_xmalloc (1 + __sym_strlen (current_user.shell)), (current_user.shell));
 }
      else
 {
   name = __sym_full_pathname (tname);
   __sym_free (tname);
 }
    }
  temp_var = __sym_bind_variable ("BASH", name);
  __sym_free (name);





  temp_var = __sym_set_if_not ("SHELL", current_user.shell);
  do { assert(temp_var != 0);temp_var->attributes |= 0x01; array_needs_making = 1; } while (0);


  __sym_bind_variable ("BASH_VERSION", __sym_shell_version_string ());

  __sym_make_vers_array ();




  temp_var = __sym_find_variable ("POSIXLY_CORRECT");
  if (!temp_var)
    temp_var = __sym_find_variable ("POSIX_PEDANTIC");
  assert(temp_var != 0);
  if (temp_var && ((((temp_var)->attributes) & (0x80)))){
      assert(temp_var != 0);
    __sym_sv_strict_posix (temp_var->name);
  }





  if (remember_on_history)
    {
      name = __sym_bash_tilde_expand (posixly_correct ? "~/.sh_history" : "~/.bash_history");

      __sym_set_if_not ("HISTFILE", name);
      __sym_free (name);

      __sym_set_if_not ("HISTSIZE", "500");
      __sym_sv_histsize ("HISTSIZE");
    }



  __sym_sbrand (dollar_dollar_pid + (long)shell_start_time);




  temp_var = __sym_find_variable ("IGNOREEOF");
  if (!temp_var)
    temp_var = __sym_find_variable ("ignoreeof");
  assert(temp_var != 0);
  if (temp_var && ((((temp_var)->attributes) & (0x80)))){
      assert(temp_var != 0);
    __sym_sv_ignoreeof (temp_var->name);
  }


  if (interactive_shell && remember_on_history)
    {
      __sym_sv_history_control ("HISTCONTROL");
      __sym_sv_histignore ("HISTIGNORE");
    }



  __sym_uidset ();


  __sym_initialize_dynamic_variables ();
}

static int __sym_atoi(const char * param0, ...);
void
adjust_shell_level (change)
     int change;
{
  char *new_level, *old_SHLVL;
  int old_level;

  old_SHLVL = __sym_get_string_value ("SHLVL");
  if (old_SHLVL)
    old_level = __sym_atoi (old_SHLVL);
  else
    old_level = 0;

  shell_level = old_level + change;
  if (shell_level < 0)
    shell_level = 0;
  new_level = __sym_itos (shell_level);
  __sym_bind_variable ("SHLVL", new_level);
  __sym_free (new_level);
}

static void
uidset ()
{
  char *buff;
  register SHELL_VAR *v;

  buff = __sym_itos (current_user.uid);
  v = __sym_find_variable ("UID");
  if (v)
    v->attributes &= ~0x02;

  v = __sym_bind_variable ("UID", buff);
  v->attributes |= (0x02 | 0x40);

  if (current_user.euid != current_user.uid)
    {
      __sym_free (buff);
      buff = __sym_itos (current_user.euid);
    }

  v = __sym_find_variable ("EUID");
  if (v)
    v->attributes &= ~0x02;

  v = __sym_bind_variable ("EUID", buff);
  v->attributes |= (0x02 | 0x40);
  __sym_free (buff);
}


static int __sym_makunbound(char * param0, HASH_TABLE * param1, ...);
static struct variable * __sym_make_new_array_variable(char * param0, ...);
static int __sym_array_add_element(ARRAY * param0, arrayind_t param1, char * param2, ...);
static void
make_vers_array ()
{
  SHELL_VAR *vv;
  ARRAY *av;
  char *s, d[16];

  __sym_makunbound ("BASH_VERSINFO", shell_variables);

  vv = __sym_make_new_array_variable ("BASH_VERSINFO");
  av = ((ARRAY *)(vv)->value);
  __sym_strcpy (d, dist_version);
  s = (__extension__ (__builtin_constant_p ('.') && !__builtin_constant_p (d) && ('.') == '\0' ? (char *) __sym___rawmemchr (d, '.') : __builtin_strchr (d, '.')));
  if (s)
    *s++ = '\0';
  __sym_array_add_element (av, 0, d);
  __sym_array_add_element (av, 1, s);
  s = __sym_itos (patch_level);
  __sym_array_add_element (av, 2, s);
  __sym_free (s);
  s = __sym_itos (build_version);
  __sym_array_add_element (av, 3, s);
  __sym_free (s);
  __sym_array_add_element (av, 4, release_status);
  __sym_array_add_element (av, 5, "");

  vv->attributes |= 0x02;
}




void
set_lines_and_columns (lines, cols)
     int lines, cols;
{
  char *val;

  val = __sym_itos (lines);
  __sym_bind_variable ("LINES", val);
  __sym_free (val);

  val = __sym_itos (cols);
  __sym_bind_variable ("COLUMNS", val);
  __sym_free (val);
}


SHELL_VAR *
set_if_not (name, value)
     char *name, *value;
{
  SHELL_VAR *v;

  v = __sym_find_variable (name);
  if (!v)
    v = __sym_bind_variable (name, value);
  return (v);
}





static char * __sym_xrealloc(void * param0, size_t param1, ...);
SHELL_VAR **
map_over (function, var_hash_table)
     Function *function;
     HASH_TABLE* var_hash_table;
{
  register int i;
  register BUCKET_CONTENTS *tlist;
  SHELL_VAR *var, **list = (SHELL_VAR **)((void *)0);
  int list_index = 0, list_size = 0;

  for (i = 0; i < var_hash_table->nbuckets; i++)
    {
      tlist = ((var_hash_table && (i < var_hash_table->nbuckets)) ? var_hash_table->bucket_array[i] : (BUCKET_CONTENTS *)((void *)0));

      while (tlist)
 {
   var = (SHELL_VAR *)tlist->data;

   if (!function || (*function) (var))
     {
       if (list_index + 1 >= list_size)
  list = (SHELL_VAR **)
    __sym_xrealloc (list, (list_size += 20) * sizeof (SHELL_VAR *));

       list[list_index++] = var;
       list[list_index] = (SHELL_VAR *)((void *)0);
     }
   tlist = tlist->next;
 }
    }
  return (list);
}

static void __sym_qsort(void * param0, size_t param1, size_t param2, void * param3, ...);
static int __sym_array_len(char ** param0, ...);
void
sort_variables (array)
     SHELL_VAR **array;
{
  __sym_qsort (array, __sym_array_len ((char **)array), sizeof (SHELL_VAR *), qsort_var_comp);
}

static int
qsort_var_comp (var1, var2)
     SHELL_VAR **var1, **var2;
{
  int result;

  if ((result = (*var1)->name[0] - (*var2)->name[0]) == 0)
    result = __extension__ ({ size_t __s1_len, __s2_len; (__builtin_constant_p ((*var1)->name) && __builtin_constant_p ((*var2)->name) && (__s1_len = __builtin_strlen ((*var1)->name), __s2_len = __builtin_strlen ((*var2)->name), (!((size_t)(const void *)(((*var1)->name) + 1) - (size_t)(const void *)((*var1)->name) == 1) || __s1_len >= 4) && (!((size_t)(const void *)(((*var2)->name) + 1) - (size_t)(const void *)((*var2)->name) == 1) || __s2_len >= 4)) ? __builtin_strcmp ((*var1)->name, (*var2)->name) : (__builtin_constant_p ((*var1)->name) && ((size_t)(const void *)(((*var1)->name) + 1) - (size_t)(const void *)((*var1)->name) == 1) && (__s1_len = __builtin_strlen ((*var1)->name), __s1_len < 4) ? (__builtin_constant_p ((*var2)->name) && ((size_t)(const void *)(((*var2)->name) + 1) - (size_t)(const void *)((*var2)->name) == 1) ? __builtin_strcmp ((*var1)->name, (*var2)->name) : (__extension__ ({ const unsigned char *__s2 = (const unsigned char *) (const char *) ((*var2)->name); int __result = (((const unsigned char *) (const char *) ((*var1)->name))[0] - __s2[0]); if (__s1_len > 0 && __result == 0) { __result = (((const unsigned char *) (const char *) ((*var1)->name))[1] - __s2[1]); if (__s1_len > 1 && __result == 0) { __result = (((const unsigned char *) (const char *) ((*var1)->name))[2] - __s2[2]); if (__s1_len > 2 && __result == 0) __result = (((const unsigned char *) (const char *) ((*var1)->name))[3] - __s2[3]); } } __result; }))) : (__builtin_constant_p ((*var2)->name) && ((size_t)(const void *)(((*var2)->name) + 1) - (size_t)(const void *)((*var2)->name) == 1) && (__s2_len = __builtin_strlen ((*var2)->name), __s2_len < 4) ? (__builtin_constant_p ((*var1)->name) && ((size_t)(const void *)(((*var1)->name) + 1) - (size_t)(const void *)((*var1)->name) == 1) ? __builtin_strcmp ((*var1)->name, (*var2)->name) : (- (__extension__ ({ const unsigned char *__s2 = (const unsigned char *) (const char *) ((*var1)->name); int __result = (((const unsigned char *) (const char *) ((*var2)->name))[0] - __s2[0]); if (__s2_len > 0 && __result == 0) { __result = (((const unsigned char *) (const char *) ((*var2)->name))[1] - __s2[1]); if (__s2_len > 1 && __result == 0) { __result = (((const unsigned char *) (const char *) ((*var2)->name))[2] - __s2[2]); if (__s2_len > 2 && __result == 0) __result = (((const unsigned char *) (const char *) ((*var2)->name))[3] - __s2[3]); } } __result; })))) : __builtin_strcmp ((*var1)->name, (*var2)->name)))); });

  return (result);
}


static struct variable ** __sym_map_over(void * param0, HASH_TABLE * param1, ...);
static void __sym_sort_variables(SHELL_VAR ** param0, ...);
static SHELL_VAR **
all_vars (table)
     HASH_TABLE *table;
{
  SHELL_VAR **list;

  list = __sym_map_over ((Function *)((void *)0), table);
  if (list && posixly_correct)
    __sym_sort_variables (list);
  return (list);
}


static struct variable ** __sym_all_vars(HASH_TABLE * param0, ...);
SHELL_VAR **
all_shell_variables ()
{
  return (__sym_all_vars (shell_variables));
}


SHELL_VAR **
all_shell_functions ()
{
  return (__sym_all_vars (shell_functions));
}


static void __sym_print_assignment(SHELL_VAR * param0, ...);
void
print_var_list (list)
     register SHELL_VAR **list;
{
  register int i;
  register SHELL_VAR *var;

  for (i = 0; list && (var = list[i]); i++)
    if (!((((var)->attributes) & (0x04))))
      __sym_print_assignment (var);
}

static int __sym_printf(const char * param0, ...);
static void __sym_print_var_function(SHELL_VAR * param0, ...);
static void __sym_print_array_assignment(SHELL_VAR * param0, int param1, ...);
static void __sym_print_var_value(SHELL_VAR * param0, int param1, ...);
void
print_assignment (var)
     SHELL_VAR *var;
{
  if (((((var)->attributes) & (0x20))) && var->value)
    {
      __sym_printf ("%s=", var->name);
      __sym_print_var_function (var);
      __sym_printf ("\n");
    }

  else if (((((var)->attributes) & (0x08))) && var->value)
    __sym_print_array_assignment (var, 0);

  else if (var->value)
    {
      __sym_printf ("%s=", var->name);
      __sym_print_var_value (var, 1);
      __sym_printf ("\n");
    }
}





static int __sym_contains_shell_metas();
static char * __sym_single_quote();
void
print_var_value (var, quote)
     SHELL_VAR *var;
     int quote;
{
  char *t;

  if (var->value)
    {
      if (quote && __sym_contains_shell_metas (var->value))
 {
   t = __sym_single_quote (var->value);
   __sym_printf ("%s", t);
   __sym_free (t);
 }
      else
 __sym_printf ("%s", var->value);
    }
}



static char * __sym_named_function_string(char * param0, COMMAND * param1, int param2, ...);
void
print_var_function (var)
     SHELL_VAR *var;
{
  if (((((var)->attributes) & (0x20))) && var->value)
    __sym_printf ("%s", __sym_named_function_string ((char *)((void *)0), (COMMAND *)((var)->value), 1));
}


static char * __sym_quoted_array_assignment_string(ARRAY * param0, ...);
static char * __sym_array_to_assignment_string(ARRAY * param0, ...);
void
print_array_assignment (var, quoted)
     SHELL_VAR *var;
     int quoted;
{
  char *vstr;

  if (quoted)
    vstr = __sym_quoted_array_assignment_string (((ARRAY *)(var)->value));
  else
    vstr = __sym_array_to_assignment_string (((ARRAY *)(var)->value));

  if (vstr == 0)
    __sym_printf ("%s=%s\n", var->name, quoted ? "'()'" : "()");
  else
    {
      __sym_printf ("%s=%s\n", var->name, vstr);
      __sym_free (vstr);
    }
}

static long seconds_value_assigned;

static long __sym_string_to_long(char * param0, ...);
static int __sym_time();
static SHELL_VAR *
assign_seconds (self, value)
     SHELL_VAR *self;
     char *value;
{
  seconds_value_assigned = __sym_string_to_long (value);
  shell_start_time = ((time_t) __sym_time ((time_t *) 0));
  return (self);
}

static SHELL_VAR *
get_seconds (var)
     SHELL_VAR *var;
{
  time_t time_since_start;
  char *p;

  time_since_start = ((time_t) __sym_time ((time_t *) 0)) - shell_start_time;
  p = __sym_itos((int) seconds_value_assigned + time_since_start);

  do { if (var->value) __sym_free (var->value); } while (0);

  var->attributes |= 0x40;
  var->value = p;
  return (var);
}


static unsigned long rseed = 1;
static unsigned long last_random_value;





static int
brand ()
{
  rseed = rseed * 1103515245 + 12345;
  return ((unsigned int)(rseed / 65536) % 32768);
}


static void
sbrand (seed)
     int seed;
{
  rseed = seed;
}

static SHELL_VAR *
assign_random (self, value)
     SHELL_VAR *self;
     char *value;
{
  __sym_sbrand (__sym_atoi (value));
  return (self);
}

static int __sym_brand();
static SHELL_VAR *
get_random (var)
     SHELL_VAR *var;
{
  int rv;
  char *p;


  if (subshell_environment)
    __sym_sbrand ((int)(__sym_getpid() + ((time_t) __sym_time ((time_t *) 0))));

  do
    rv = __sym_brand ();
  while (rv == (int)last_random_value);

  last_random_value = rv;
  p = __sym_itos ((int)rv);

  do { if (var->value) __sym_free (var->value); } while (0);

  var->attributes |= 0x40;
  var->value = p;
  return (var);
}


static int __sym_executing_line_number();
static SHELL_VAR *
get_lineno (var)
     SHELL_VAR *var;
{
  char *p;
  int ln;

  ln = __sym_executing_line_number ();
  p = __sym_itos (ln);
  do { if (var->value) __sym_free (var->value); } while (0);
  var->value = p;
  return (var);
}

static SHELL_VAR *
assign_lineno (var, value)
     SHELL_VAR *var;
     char *value;
{
  line_number = __sym_atoi (value);
  return var;
}


static int __sym_history_number();
static SHELL_VAR *
get_histcmd (var)
     SHELL_VAR *var;
{
  char *p;

  p = __sym_itos (__sym_history_number ());
  do { if (var->value) __sym_free (var->value); } while (0);
  var->value = p;
  return (var);
}



static struct word_list * __sym_get_directory_stack();
static struct array * __sym_word_list_to_array(WORD_LIST * param0, ...);
static void __sym_dispose_array(ARRAY * param0, ...);
static SHELL_VAR *
get_dirstack (self)
     SHELL_VAR *self;
{
  ARRAY *a;
  WORD_LIST *l;

  l = __sym_get_directory_stack ();
  a = __sym_word_list_to_array (l);
  __sym_dispose_array (((ARRAY *)(self)->value));
  self->value = (char *)a;
  return self;
}

static void __sym_set_dirstack_element();
static SHELL_VAR *
assign_dirstack (self, ind, value)
     SHELL_VAR *self;
     int ind;
     char *value;
{
  __sym_set_dirstack_element (ind, 1, value);
  return self;
}


static void
initialize_dynamic_variables ()
{
  SHELL_VAR *v;

  v = __sym_bind_variable ("SECONDS", (char *)((void *)0));
  v->dynamic_value = get_seconds;
  v->assign_func = assign_seconds;

  v = __sym_bind_variable ("RANDOM", (char *)((void *)0));
  v->dynamic_value = get_random;
  v->assign_func = assign_random;

  v = __sym_bind_variable ("LINENO", (char *)((void *)0));
  v->dynamic_value = get_lineno;
  v->assign_func = assign_lineno;


  v = __sym_bind_variable ("HISTCMD", (char *)((void *)0));
  v->dynamic_value = get_histcmd;
  v->assign_func = (DYNAMIC_FUNC *)((void *)0);



  v = __sym_make_new_array_variable ("DIRSTACK");
  v->dynamic_value = get_dirstack;
  v->assign_func = assign_dirstack;

}




static struct bucket_contents * __sym_find_hash_item();
SHELL_VAR *
var_lookup (name, hashed_vars)
     char *name;
     HASH_TABLE *hashed_vars;
{
  BUCKET_CONTENTS *bucket;

  bucket = __sym_find_hash_item (name, hashed_vars);
  return (bucket ? (SHELL_VAR *)bucket->data : (SHELL_VAR *)((void *)0));
}



static struct variable * __sym_find_tempenv_variable(char * param0, ...);
static struct variable * __sym_var_lookup(char * param0, HASH_TABLE * param1, ...);
SHELL_VAR *
find_variable_internal (name, search_tempenv)
     char *name;
     int search_tempenv;
{
  SHELL_VAR *var = (SHELL_VAR *)((void *)0);






  if ((search_tempenv || subshell_environment) &&
      (temporary_env || builtin_env || function_env))
    var = __sym_find_tempenv_variable (name);

  if (!var)
    var = __sym_var_lookup (name, shell_variables);

  if (!var)
    return ((SHELL_VAR *)((void *)0));

  return (var->dynamic_value ? (*(var->dynamic_value)) (var) : var);
}


static struct variable * __sym_find_variable_internal(char * param0, int param1, ...);
SHELL_VAR *
find_variable (name)
     char *name;
{
  return (__sym_find_variable_internal
   (name, (variable_context || this_shell_builtin || builtin_env)));
}



SHELL_VAR *
find_function (name)
     char *name;
{
  return (__sym_var_lookup (name, shell_functions));
}




static char * __sym_array_reference(ARRAY * param0, arrayind_t param1, ...);
char *
get_string_value (var_name)
     char *var_name;
{
  SHELL_VAR *var = __sym_find_variable (var_name);

  if (!var)
    return (char *)((void *)0);

  else if (((((var)->attributes) & (0x08))))
    return (__sym_array_reference (((ARRAY *)(var)->value), 0));

  else
    return (var->value);
}


static struct bucket_contents * __sym_remove_hash_item();
static struct bucket_contents * __sym_add_hash_item();
static void __sym_bzero(void * param0, size_t param1, ...);
SHELL_VAR *
make_local_variable (name)
     char *name;
{
  SHELL_VAR *new_var, *old_var;
  BUCKET_CONTENTS *elt;


  old_var = __sym_find_variable (name);
  if (old_var && old_var->context == variable_context)
    return (old_var);

  elt = __sym_remove_hash_item (name, shell_variables);
  if (elt)
    {
      old_var = (SHELL_VAR *)elt->data;
      __sym_free (elt->key);
      __sym_free (elt);
    }
  else
    old_var = (SHELL_VAR *)((void *)0);



  if (!old_var)
    {
      new_var = __sym_bind_variable (name, "");
    }
  else
    {
      new_var = (SHELL_VAR *)__sym_xmalloc (sizeof (SHELL_VAR));

      new_var->name = (char *)__sym_strcpy (__sym_xmalloc (1 + __sym_strlen (name)), (name));
      new_var->value = __sym_xmalloc (1);
      new_var->value[0] = '\0';

      new_var->dynamic_value = (DYNAMIC_FUNC *)((void *)0);
      new_var->assign_func = (DYNAMIC_FUNC *)((void *)0);

      new_var->attributes = ((((old_var)->attributes) & (0x01))) ? 0x01 : 0;

      new_var->prev_context = old_var;
      elt = __sym_add_hash_item ((char *)__sym_strcpy (__sym_xmalloc (1 + __sym_strlen (name)), (name)), shell_variables);
      elt->data = (char *)new_var;
    }

  new_var->context = variable_context;
  new_var->attributes |= 0x100;


  if (variable_context >= local_variable_stack_size)
    {
      int old_size = local_variable_stack_size;
      do { if ((variable_context) + (1) >= local_variable_stack_size) { while ((variable_context) + (1) >= local_variable_stack_size) local_variable_stack_size += (8); have_local_variables = __sym_xrealloc (have_local_variables, local_variable_stack_size); } } while (0)
                                      ;
      __sym_bzero ((char *)have_local_variables + old_size,
      local_variable_stack_size - old_size);
    }
  have_local_variables[variable_context] = 1;

  return (new_var);
}


static struct variable * __sym_make_local_variable(char * param0, ...);
static struct array * __sym_new_array();
SHELL_VAR *
make_local_array_variable (name)
     char *name;
{
  SHELL_VAR *var;
  ARRAY *array;

  var = __sym_make_local_variable (name);
  array = __sym_new_array ();

  do { if (((var)->value)) __sym_free (((var)->value)); } while (0);
  var->value = (char *)array;
  var->attributes |= 0x08;
  return var;
}




static
SHELL_VAR *
make_new_variable (name)
     char *name;
{
  SHELL_VAR *entry;
  BUCKET_CONTENTS *elt;

  entry = (SHELL_VAR *)__sym_xmalloc (sizeof (SHELL_VAR));

  entry->attributes = 0;
  entry->name = (char *)__sym_strcpy (__sym_xmalloc (1 + __sym_strlen (name)), (name));
  entry->value = (char *)((void *)0);

  entry->dynamic_value = (DYNAMIC_FUNC *)((void *)0);
  entry->assign_func = (DYNAMIC_FUNC *)((void *)0);




  entry->context = 0;
  entry->prev_context = (SHELL_VAR *)((void *)0);

  elt = __sym_add_hash_item ((char *)__sym_strcpy (__sym_xmalloc (1 + __sym_strlen (name)), (name)), shell_variables);
  elt->data = (char *)entry;

  return entry;
}


static struct variable * __sym_make_new_variable(char * param0, ...);
SHELL_VAR *
make_new_array_variable (name)
     char *name;
{
  SHELL_VAR *entry;
  ARRAY *array;

  entry = __sym_make_new_variable (name);
  array = __sym_new_array ();
  entry->value = (char *)array;
  entry->attributes |= 0x08;
  return entry;
}


static long __sym_evalexp(char * param0, ...);
char *
make_variable_value (var, value)
     SHELL_VAR *var;
     char *value;
{
  char *retval;
  long lval;






  if (((((var)->attributes) & (0x40))))
    {
      lval = __sym_evalexp (value);
      retval = __sym_itos (lval);
    }
  else if (value)
    {
      if (*value)
 retval = (char *)__sym_strcpy (__sym_xmalloc (1 + __sym_strlen (value)), (value));
      else
 {
   retval = __sym_xmalloc (1);
   retval[0] = '\0';
 }
    }
  else
    retval = (char *)((void *)0);

  return retval;
}



static char * __sym_make_variable_value(SHELL_VAR * param0, char * param1, ...);
SHELL_VAR *
bind_variable (name, value)
     char *name, *value;
{
  char *newval;
  SHELL_VAR *entry;

  entry = __sym_var_lookup (name, shell_variables);

  if (entry == 0)
    {
      entry = __sym_make_new_variable (name);
      entry->value = __sym_make_variable_value (entry, value);
    }

  else if (entry->assign_func && ((((entry)->attributes) & (0x08))) == 0)



    return ((*(entry->assign_func)) (entry, value));
  else
    {
      if (((((entry)->attributes) & (0x02))))
 {
   __sym_report_error ("%s: readonly variable", name);
   return (entry);
 }


      entry->attributes &= ~0x04;

      newval = __sym_make_variable_value (entry, value);






      if (((((entry)->attributes) & (0x08))))
        __sym_array_add_element (((ARRAY *)(entry)->value), 0, newval);
      else
 {
   do { if (entry->value) __sym_free (entry->value); } while (0);
   entry->value = newval;
 }




    }

  if (mark_modified_vars)
    entry->attributes |= 0x01;

  if (((((entry)->attributes) & (0x01))))
    array_needs_making = 1;

  return (entry);
}




SHELL_VAR *
convert_var_to_array (var)
     SHELL_VAR *var;
{
  char *oldval;
  ARRAY *array;

  oldval = ((var)->value);
  array = __sym_new_array ();
  __sym_array_add_element (array, 0, oldval);
  do { if (((var)->value)) __sym_free (((var)->value)); } while (0);
  var->value = (char *)array;
  var->attributes |= 0x08;
  var->attributes &= ~0x04;

  return var;
}

static struct variable * __sym_convert_var_to_array(SHELL_VAR * param0, ...);
SHELL_VAR *
bind_array_variable (name, ind, value)
     char *name;
     int ind;
     char *value;
{
  SHELL_VAR *entry;
  char *newval;

  entry = __sym_var_lookup (name, shell_variables);

  if (entry == (SHELL_VAR *) 0)
    entry = __sym_make_new_array_variable (name);
  else if (((((entry)->attributes) & (0x02))))
    {
      __sym_report_error ("%s: readonly variable", name);
      return (entry);
    }
  else if (((((entry)->attributes) & (0x08))) == 0)
    entry = __sym_convert_var_to_array (entry);


  newval = __sym_make_variable_value (entry, value);
  if (entry->assign_func)
    (*entry->assign_func) (entry, ind, newval);
  else
    __sym_array_add_element (((ARRAY *)(entry)->value), ind, newval);
  do { if (newval) __sym_free (newval); } while (0);

  return (entry);
}

static struct variable * __sym_assign_array_var_from_string(SHELL_VAR * param0, char * param1, ...);
SHELL_VAR *
assign_array_from_string (name, value)
     char *name, *value;
{
  SHELL_VAR *var;

  var = __sym_find_variable (name);
  if (var == 0)
    var = __sym_make_new_array_variable (name);
  else if (((((var)->attributes) & (0x08))) == 0)
    var = __sym_convert_var_to_array (var);

  return (__sym_assign_array_var_from_string (var, value));
}

SHELL_VAR *
assign_array_var_from_word_list (var, list)
     SHELL_VAR *var;
     WORD_LIST *list;
{
  register int i;
  register WORD_LIST *l;
  ARRAY *a;

  for (a = ((ARRAY *)(var)->value), l = list, i = 0; l; l = l->next, i++)
    if (var->assign_func)
      (*var->assign_func) (var, i, l->word->word);
    else
      __sym_array_add_element (a, i, l->word->word);
  return var;
}

static char * __sym_extract_array_assignment_list(char * param0, int * param1, ...);
static struct word_list * __sym_expand_string(char * param0, int param1, ...);
static int __sym_skipsubscript(char * param0, int param1, ...);
static int __sym_array_expand_index(char * param0, int param1, ...);
static void __sym_dispose_words(WORD_LIST * param0, ...);
SHELL_VAR *
assign_array_var_from_string (var, value)
     SHELL_VAR *var;
     char *value;
{
  ARRAY *a;
  WORD_LIST *list, *nlist;
  char *w, *val, *nval;
  int ni, len, ind, last_ind;

  a = ((ARRAY *)(var)->value);



  if (*value == '(')
    {
      ni = 1;
      val = __sym_extract_array_assignment_list (value, &ni);
      if (val == 0)
 return var;
      nlist = __sym_expand_string (val, 0);
      __sym_free (val);
    }
  else
    nlist = __sym_expand_string (value, 0);

  for (last_ind = 0, list = nlist; list; list = list->next)
    {
      w = list->word->word;


      if (w[0] == '[')
 {
   len = __sym_skipsubscript (w, 0);

   if (w[len] != ']' || w[len+1] != '=')
     {
       nval = __sym_make_variable_value (var, w);
       if (var->assign_func)
  (*var->assign_func) (var, last_ind, nval);
       else
  __sym_array_add_element (a, last_ind, nval);
       do { if (nval) __sym_free (nval); } while (0);
       last_ind++;
       continue;
     }

   if (len == 1)
     {
       __sym_report_error ("%s: bad array subscript", w);
       continue;
     }

   if (((w[1]) == '@' || (w[1]) == '*') && len == 2)
     {
       __sym_report_error ("%s: cannot assign to non-numeric index", w);
       continue;
     }

   ind = __sym_array_expand_index (w + 1, len);
   if (ind < 0)
     {
       __sym_report_error ("%s: bad array subscript", w);
       continue;
     }
   last_ind = ind;
   val = w + len + 2;
 }
      else
 {
   ind = last_ind;
   val = w;
 }

      if (((((var)->attributes) & (0x40))))
        this_command_name = (char *)((void *)0);
      nval = __sym_make_variable_value (var, val);
      if (var->assign_func)
 (*var->assign_func) (var, ind, nval);
      else
 __sym_array_add_element (a, ind, nval);
      do { if (nval) __sym_free (nval); } while (0);
      last_ind++;
    }

  __sym_dispose_words (nlist);
  return (var);
}



static void __sym_dispose_command(COMMAND * param0, ...);
void
dispose_variable (var)
     SHELL_VAR *var;
{
  if (!var)
    return;

  if (((((var)->attributes) & (0x20))))
    __sym_dispose_command ((COMMAND *)((var)->value));

  else if (((((var)->attributes) & (0x08))))
    __sym_dispose_array (((ARRAY *)(var)->value));

  else
    do { if (((var)->value)) __sym_free (((var)->value)); } while (0);

  __sym_free (var->name);

  if (((((var)->attributes) & (0x01))))
    array_needs_making = 1;

  __sym_free (var);
}




static void __sym_builtin_error(const char * param0, ...);
static struct array_element * __sym_array_delete_element(ARRAY * param0, arrayind_t param1, ...);
static void __sym_destroy_array_element(ARRAY_ELEMENT * param0, ...);
int
unbind_array_element (var, sub)
     SHELL_VAR *var;
     char *sub;
{
  int len, ind;
  ARRAY_ELEMENT *ae;

  len = __sym_skipsubscript (sub, 0);
  if (sub[len] != ']' || len == 0)
    {
      __sym_builtin_error ("%s[%s: bad array subscript", var->name, sub);
      return -1;
    }
  sub[len] = '\0';

  if (((sub[0]) == '@' || (sub[0]) == '*') && sub[1] == 0)
    {
      __sym_makunbound (var->name, shell_variables);
      return (0);
    }
  ind = __sym_array_expand_index (sub, len+1);
  if (ind < 0)
    {
      __sym_builtin_error ("[%s: bad array subscript", sub);
      return -1;
    }
  ae = __sym_array_delete_element (((ARRAY *)(var)->value), ind);
  if (ae)
    __sym_destroy_array_element (ae);
  return 0;
}



int
unbind_variable (name)
     char *name;
{
  SHELL_VAR *var = __sym_find_variable (name);

  if (!var)
    return (-1);



  if (((((var)->attributes) & (0x08))) == 0 && var->value)



    {
      __sym_free (var->value);
      var->value = (char *)((void *)0);
    }

  __sym_makunbound (name, shell_variables);

  return (0);
}





static void __sym_stupidly_hack_special_variables(char * param0, ...);
static void __sym_dispose_variable(SHELL_VAR * param0, ...);
int
makunbound (name, hash_list)
     char *name;
     HASH_TABLE *hash_list;
{
  BUCKET_CONTENTS *elt;
  SHELL_VAR *old_var, *new_var;
  char *t;

  elt = __sym_remove_hash_item (name, hash_list);

  if (!elt)
    return (-1);

  old_var = (SHELL_VAR *)elt->data;
  new_var = old_var->prev_context;

  if (old_var && ((((old_var)->attributes) & (0x01))))
    array_needs_making++;







  if (old_var && ((((old_var)->attributes) & (0x100))) && variable_context == old_var->context)
    {
      old_var->attributes |= 0x04;
      elt = __sym_add_hash_item ((char *)__sym_strcpy (__sym_xmalloc (1 + __sym_strlen (old_var->name)), (old_var->name)), hash_list);
      elt->data = (char *)old_var;
      __sym_stupidly_hack_special_variables (old_var->name);
      return (0);
    }

  if (new_var)
    {

      BUCKET_CONTENTS *new_elt;

      new_elt = __sym_add_hash_item ((char *)__sym_strcpy (__sym_xmalloc (1 + __sym_strlen (new_var->name)), (new_var->name)), hash_list);
      new_elt->data = (char *)new_var;

      if (((((new_var)->attributes) & (0x01))))
 do { new_var->attributes |= 0x01; array_needs_making = 1; } while (0);
    }




  t = (char *)__sym_strcpy (__sym_xmalloc (1 + __sym_strlen (name)), (name));

  __sym_free (elt->key);
  __sym_free (elt);

  __sym_dispose_variable (old_var);
  __sym_stupidly_hack_special_variables (t);
  __sym_free (t);
  return (0);
}



int
kill_local_variable (name)
     char *name;
{
  SHELL_VAR *temp = __sym_find_variable (name);

  if (temp && temp->context == variable_context)
    {
      __sym_makunbound (name, shell_variables);
      return (0);
    }
  return (-1);
}


int
variable_in_context (var)
     SHELL_VAR *var;
{
  return (var && var->context == variable_context);
}

void
kill_all_local_variables ()
{
  register int i, pass;
  register SHELL_VAR *var, **list;
  HASH_TABLE *varlist;







  if (have_local_variables == 0 ||
      variable_context >= local_variable_stack_size ||
      have_local_variables[variable_context] == 0)
    return;

  for (pass = 0; pass < 2; pass++)
    {
      varlist = pass ? shell_functions : shell_variables;

      list = __sym_map_over (variable_in_context, varlist);

      if (list)
 {
   for (i = 0; var = list[i]; i++)
     {
       var->attributes &= ~0x100;
       __sym_makunbound (var->name, varlist);
     }
   __sym_free (list);
 }
    }

  have_local_variables[variable_context] = 0;
}

static void
free_variable_hash_data (data)
     char *data;
{
  SHELL_VAR *var, *prev;

  var = (SHELL_VAR *)data;
  while (var)
    {
      prev = var->prev_context;
      __sym_dispose_variable (var);
      var = prev;
    }
}


static void __sym_flush_hash_table();
void
delete_all_variables (hashed_vars)
     HASH_TABLE *hashed_vars;
{
  __sym_flush_hash_table (hashed_vars, free_variable_hash_data);
}

static SHELL_VAR *
new_shell_variable (name)
     char *name;
{
  SHELL_VAR *var;

  var = (SHELL_VAR *)__sym_xmalloc (sizeof (SHELL_VAR));

  __sym_bzero ((char *)var, sizeof (SHELL_VAR));
  var->name = (char *)__sym_strcpy (__sym_xmalloc (1 + __sym_strlen (name)), (name));
  return (var);
}



static struct variable * __sym_new_shell_variable(char * param0, ...);
static struct command * __sym_copy_command(COMMAND * param0, ...);
SHELL_VAR *
bind_function (name, value)
     char *name;
     COMMAND *value;
{
  SHELL_VAR *entry;

  entry = __sym_find_function (name);
  if (!entry)
    {
      BUCKET_CONTENTS *elt;

      elt = __sym_add_hash_item ((char *)__sym_strcpy (__sym_xmalloc (1 + __sym_strlen (name)), (name)), shell_functions);

      elt->data = (char *)__sym_new_shell_variable (name);
      entry = (SHELL_VAR *)elt->data;
      entry->dynamic_value = entry->assign_func = (DYNAMIC_FUNC *)((void *)0);



      entry->context = 0;
    }

  if (entry->value)
    __sym_dispose_command ((COMMAND *)entry->value);

  entry->value = value ? (char *)__sym_copy_command (value) : (char *)((void *)0);
  entry->attributes |= 0x20;

  if (mark_modified_vars)
    entry->attributes |= 0x01;

  entry->attributes &= ~0x04;

  if (((((entry)->attributes) & (0x01))))
    array_needs_making = 1;

  return (entry);
}


static struct array * __sym_dup_array(ARRAY * param0, ...);
SHELL_VAR *
copy_variable (var)
     SHELL_VAR *var;
{
  SHELL_VAR *copy = (SHELL_VAR *)((void *)0);

  if (var)
    {
      copy = (SHELL_VAR *)__sym_xmalloc (sizeof (SHELL_VAR));

      copy->attributes = var->attributes;
      copy->name = (char *)__sym_strcpy (__sym_xmalloc (1 + __sym_strlen (var->name)), (var->name));

      if (((((var)->attributes) & (0x20))))
 copy->value = (char *)__sym_copy_command ((COMMAND *)((var)->value));

      else if (((((var)->attributes) & (0x08))))
 copy->value = (char *)__sym_dup_array (((ARRAY *)(var)->value));

      else if (((var)->value))
 copy->value = (char *)__sym_strcpy (__sym_xmalloc (1 + __sym_strlen (((var)->value))), (((var)->value)));
      else
 copy->value = (char *)((void *)0);

      copy->dynamic_value = var->dynamic_value;
      copy->assign_func = var->assign_func;

      copy->context = var->context;


      copy->prev_context = (SHELL_VAR *)((void *)0);
    }
  return (copy);
}

void
set_var_read_only (name)
     char *name;
{
  SHELL_VAR *entry;

  do { entry = __sym_find_variable (name); if (!entry) { entry = __sym_bind_variable (name, ""); if (!no_invisible_vars) entry->attributes |= 0x04; } } while (0);
  entry->attributes |= 0x02;
}



void
set_func_read_only (name)
     char *name;
{
  SHELL_VAR *entry = __sym_find_function (name);

  if (entry)
    entry->attributes |= 0x02;
}



void
set_var_auto_export (name)
     char *name;
{
  SHELL_VAR *entry;

  do { entry = __sym_find_variable (name); if (!entry) { entry = __sym_bind_variable (name, ""); if (!no_invisible_vars) entry->attributes |= 0x04; } } while (0);
  do { entry->attributes |= 0x01; array_needs_making = 1; } while (0);
}


void
set_func_auto_export (name)
     char *name;
{
  SHELL_VAR *entry;

  entry = __sym_find_function (name);
  if (entry)
    do { entry->attributes |= 0x01; array_needs_making = 1; } while (0);
}




int
skipsubscript (s, i)
     char *s;
     int i;
{
  int count, c;

  for (count = 1; count && (c = s[++i]); )
    {
      if (c == '[')
 count++;
      else if (c == ']')
 count--;
    }
  return i;
}




int
assignment (string)
     char *string;
{
  register int c, newi, indx;

  c = string[indx = 0];

  if (((((c) >= 'A' && (c) <= 'Z') || ((c) >= 'a' && (c) <= 'z')) || (c == '_')) == 0)
    return (0);

  while (c = string[indx])
    {


      if (c == '=')
 return (indx);


      if (c == '[')
 {
   newi = __sym_skipsubscript (string, indx);
   if (string[newi++] != ']')
     return (0);
   return ((string[newi] == '=') ? newi : 0);
 }




      if (((((c) >= 'A' && (c) <= 'Z') || ((c) >= 'a' && (c) <= 'z')) || ((c) >= '0' && (c) <= '9') || c == '_') == 0)
 return (0);

      indx++;
    }
  return (0);
}

static int
visible_var (var)
     SHELL_VAR *var;
{
  return (((((var)->attributes) & (0x04))) == 0);
}

static SHELL_VAR **
_visible_names (table)
     HASH_TABLE *table;
{
  SHELL_VAR **list;

  list = __sym_map_over (visible_var, table);

  if (list && posixly_correct)
    __sym_sort_variables (list);

  return (list);
}

static struct variable ** __sym__visible_names(HASH_TABLE * param0, ...);
SHELL_VAR **
all_visible_variables ()
{
  return (__sym__visible_names (shell_variables));
}

SHELL_VAR **
all_visible_functions ()
{
  return (__sym__visible_names (shell_functions));
}



static int
visible_and_exported (var)
     SHELL_VAR *var;
{
  return (((((var)->attributes) & (0x04))) == 0 && ((((var)->attributes) & (0x01))));
}




char **
make_var_array (hashed_vars)
     HASH_TABLE *hashed_vars;
{
  register int i, list_index;
  register SHELL_VAR *var;
  char **list, *value;
  SHELL_VAR **vars;

  list = (char **)((void *)0);
  vars = __sym_map_over (visible_and_exported, hashed_vars);

  if (!vars)
    return (char **)((void *)0);

  list = (char **)__sym_xmalloc ((1 + __sym_array_len ((char **)vars)) * sizeof (char *));

  for (i = 0, list_index = 0; var = vars[i]; i++)
    {
      if (((((var)->attributes) & (0x20))))
 value = __sym_named_function_string ((char *)((void *)0), (COMMAND *)((var)->value), 0);

      else if (((((var)->attributes) & (0x08))))



 continue;


      else
 value = ((var)->value);

      if (value)
 {
   int name_len, value_len;
   char *p;

   name_len = __sym_strlen (var->name);
   value_len = __sym_strlen (value);
   p = list[list_index] = __sym_xmalloc (2 + name_len + value_len);
   __sym_strcpy (p, var->name);
   p[name_len] = '=';
   __sym_strcpy (p + name_len + 1, value);
   list_index++;

   if (((((var)->attributes) & (0x08))))
     __sym_free (value);

 }
    }

  __sym_free (vars);
  list[list_index] = (char *)((void *)0);
  return (list);
}



static int __sym_assignment(char * param0, ...);
static struct word_list * __sym_expand_string_unsplit(char * param0, int param1, ...);
static char * __sym_string_list(WORD_LIST * param0, ...);
static int __sym_fprintf(FILE * param0, const char * param1, ...);
static char * __sym_indirection_level_string();
static int __sym_fflush(FILE * param0, ...);
int
assign_in_env (string)
     char *string;
{
  int size, offset;
  char *name, *temp, *value;
  int nlen, vlen;
  WORD_LIST *list;
  SHELL_VAR *var;

  offset = __sym_assignment (string);
  name = (char *)__sym_strcpy (__sym_xmalloc (1 + __sym_strlen (string)), (string));
  value = (char *)((void *)0);


  if (name[offset] == '=')
    {
      name[offset] = 0;

      var = __sym_find_variable (name);
      if (var && ((((var)->attributes) & (0x02))))
 {
   __sym_report_error ("%s: readonly variable", name);
     return (0);
 }
      temp = name + offset + 1;
      nlen = (__extension__ (__builtin_constant_p ('~') && !__builtin_constant_p (temp) && ('~') == '\0' ? (char *) __sym___rawmemchr (temp, '~') : __builtin_strchr (temp, '~'))) != 0;
      if (nlen)
 temp = __sym_bash_tilde_expand (temp);

      list = __sym_expand_string_unsplit (temp, 0);
      value = __sym_string_list (list);

      if (list)
 __sym_dispose_words (list);

      if (nlen)
 __sym_free (temp);
    }


  nlen = __sym_strlen (name);
  vlen = value ? __sym_strlen (value) : 0;
  temp = __sym_xmalloc (2 + nlen + vlen);
  __sym_strcpy (temp, name);
  temp[nlen] = '=';
  temp[nlen + 1] = '\0';
  if (value)
    {
      if (*value)
 __sym_strcpy (temp + nlen + 1, value);
      __sym_free (value);
    }
  __sym_free (name);

  if (temporary_env == 0)
    {
      temporary_env = (char **)__sym_xmalloc (sizeof (char *));
      temporary_env [0] = (char *)((void *)0);
    }

  size = __sym_array_len (temporary_env);
  temporary_env = (char **)
    __sym_xrealloc (temporary_env, (size + 2) * (sizeof (char *)));

  temporary_env[size] = temp;
  temporary_env[size + 1] = (char *)((void *)0);
  array_needs_making = 1;

  if (echo_command_at_execute)
    {


      __sym_fprintf (stderr, "%s%s\n", __sym_indirection_level_string (), temp);
      __sym_fflush (stderr);
    }

  return 1;
}




static SHELL_VAR *
find_name_in_env_array (name, array)
     char *name;
     char **array;
{
  register int i, l;

  if (array == 0)
    return ((SHELL_VAR *)((void *)0));

  for (i = 0, l = __sym_strlen (name); array[i]; i++)
    {
      if (((array[i])[0] == (name)[0] && (__extension__ (__builtin_constant_p (l) && ((__builtin_constant_p (array[i]) && __sym_strlen (array[i]) < ((size_t) (l))) || (__builtin_constant_p (name) && __sym_strlen (name) < ((size_t) (l)))) ? __extension__ ({ size_t __s1_len, __s2_len; (__builtin_constant_p (array[i]) && __builtin_constant_p (name) && (__s1_len = __builtin_strlen (array[i]), __s2_len = __builtin_strlen (name), (!((size_t)(const void *)((array[i]) + 1) - (size_t)(const void *)(array[i]) == 1) || __s1_len >= 4) && (!((size_t)(const void *)((name) + 1) - (size_t)(const void *)(name) == 1) || __s2_len >= 4)) ? __builtin_strcmp (array[i], name) : (__builtin_constant_p (array[i]) && ((size_t)(const void *)((array[i]) + 1) - (size_t)(const void *)(array[i]) == 1) && (__s1_len = __builtin_strlen (array[i]), __s1_len < 4) ? (__builtin_constant_p (name) && ((size_t)(const void *)((name) + 1) - (size_t)(const void *)(name) == 1) ? __builtin_strcmp (array[i], name) : (__extension__ ({ const unsigned char *__s2 = (const unsigned char *) (const char *) (name); int __result = (((const unsigned char *) (const char *) (array[i]))[0] - __s2[0]); if (__s1_len > 0 && __result == 0) { __result = (((const unsigned char *) (const char *) (array[i]))[1] - __s2[1]); if (__s1_len > 1 && __result == 0) { __result = (((const unsigned char *) (const char *) (array[i]))[2] - __s2[2]); if (__s1_len > 2 && __result == 0) __result = (((const unsigned char *) (const char *) (array[i]))[3] - __s2[3]); } } __result; }))) : (__builtin_constant_p (name) && ((size_t)(const void *)((name) + 1) - (size_t)(const void *)(name) == 1) && (__s2_len = __builtin_strlen (name), __s2_len < 4) ? (__builtin_constant_p (array[i]) && ((size_t)(const void *)((array[i]) + 1) - (size_t)(const void *)(array[i]) == 1) ? __builtin_strcmp (array[i], name) : (- (__extension__ ({ const unsigned char *__s2 = (const unsigned char *) (const char *) (array[i]); int __result = (((const unsigned char *) (const char *) (name))[0] - __s2[0]); if (__s2_len > 0 && __result == 0) { __result = (((const unsigned char *) (const char *) (name))[1] - __s2[1]); if (__s2_len > 1 && __result == 0) { __result = (((const unsigned char *) (const char *) (name))[2] - __s2[2]); if (__s2_len > 2 && __result == 0) __result = (((const unsigned char *) (const char *) (name))[3] - __s2[3]); } } __result; })))) : __builtin_strcmp (array[i], name)))); }) : __sym_strncmp (array[i], name, l))) == 0) && array[i][l] == '=')
 {
   SHELL_VAR *temp;
   char *w;

   temp = __sym_new_shell_variable (name);
   w = array[i] + l + 1;

   temp->value = *w ? (char *)__sym_strcpy (__sym_xmalloc (1 + __sym_strlen (w)), (w)) : (char *)((void *)0);

   temp->attributes = 0x01;
   temp->context = 0;
   temp->prev_context = (SHELL_VAR *)((void *)0);

   temp->dynamic_value = temp->assign_func = (DYNAMIC_FUNC *)((void *)0);

   return (temp);
 }
    }
  return ((SHELL_VAR *)((void *)0));
}







static struct variable * __sym_find_name_in_env_array(char * param0, char ** param1, ...);
SHELL_VAR *
find_tempenv_variable (name)
     char *name;
{
  SHELL_VAR *var = (SHELL_VAR *)((void *)0);

  if (temporary_env)
    var = __sym_find_name_in_env_array (name, temporary_env);




  if (!var && builtin_env)
    var = __sym_find_name_in_env_array (name, builtin_env);

  if (!var && variable_context && function_env)
    var = __sym_find_name_in_env_array (name, function_env);

  return (var);
}



static void __sym_free_array(char ** param0, ...);
static void
dispose_temporary_vars (arrayp)
     char ***arrayp;
{
  if (!*arrayp)
    return;

  __sym_free_array (*arrayp);
  *arrayp = (char **)((void *)0);
  array_needs_making = 1;
}



static void __sym_dispose_temporary_vars(char *** param0, ...);
void
dispose_used_env_vars ()
{
  __sym_dispose_temporary_vars (&temporary_env);
}



void
dispose_function_env ()
{
  __sym_dispose_temporary_vars (&function_env);
}



void
dispose_builtin_env ()
{
  __sym_dispose_temporary_vars (&builtin_env);
}



static void
merge_env_array (env_array)
     char **env_array;
{
  register int i, l;
  SHELL_VAR *temp;
  char *w, *name;

  if (env_array == 0)
    return;

  for (i = 0; env_array[i]; i++)
    {
      l = __sym_assignment (env_array[i]);
      name = env_array[i];
      w = env_array[i] + l + 1;
      name[l] = '\0';
      temp = __sym_bind_variable (name, w);
      name[l] = '=';
    }
}

static void __sym_merge_env_array(char ** param0, ...);
void
merge_temporary_env ()
{
  __sym_merge_env_array (temporary_env);
}

void
merge_builtin_env ()
{
  __sym_merge_env_array (builtin_env);
}





char **
add_or_supercede (assign, array)
     char *assign;
     register char **array;
{
  register int i;
  int equal_offset = __sym_assignment (assign);

  if (!equal_offset)
    return (array);



  if (assign[equal_offset + 1] == '(')
    equal_offset++;

  for (i = 0; array && array[i]; i++)
    {
      if (((assign)[0] == (array[i])[0] && (__extension__ (__builtin_constant_p (equal_offset + 1) && ((__builtin_constant_p (assign) && __sym_strlen (assign) < ((size_t) (equal_offset + 1))) || (__builtin_constant_p (array[i]) && __sym_strlen (array[i]) < ((size_t) (equal_offset + 1)))) ? __extension__ ({ size_t __s1_len, __s2_len; (__builtin_constant_p (assign) && __builtin_constant_p (array[i]) && (__s1_len = __builtin_strlen (assign), __s2_len = __builtin_strlen (array[i]), (!((size_t)(const void *)((assign) + 1) - (size_t)(const void *)(assign) == 1) || __s1_len >= 4) && (!((size_t)(const void *)((array[i]) + 1) - (size_t)(const void *)(array[i]) == 1) || __s2_len >= 4)) ? __builtin_strcmp (assign, array[i]) : (__builtin_constant_p (assign) && ((size_t)(const void *)((assign) + 1) - (size_t)(const void *)(assign) == 1) && (__s1_len = __builtin_strlen (assign), __s1_len < 4) ? (__builtin_constant_p (array[i]) && ((size_t)(const void *)((array[i]) + 1) - (size_t)(const void *)(array[i]) == 1) ? __builtin_strcmp (assign, array[i]) : (__extension__ ({ const unsigned char *__s2 = (const unsigned char *) (const char *) (array[i]); int __result = (((const unsigned char *) (const char *) (assign))[0] - __s2[0]); if (__s1_len > 0 && __result == 0) { __result = (((const unsigned char *) (const char *) (assign))[1] - __s2[1]); if (__s1_len > 1 && __result == 0) { __result = (((const unsigned char *) (const char *) (assign))[2] - __s2[2]); if (__s1_len > 2 && __result == 0) __result = (((const unsigned char *) (const char *) (assign))[3] - __s2[3]); } } __result; }))) : (__builtin_constant_p (array[i]) && ((size_t)(const void *)((array[i]) + 1) - (size_t)(const void *)(array[i]) == 1) && (__s2_len = __builtin_strlen (array[i]), __s2_len < 4) ? (__builtin_constant_p (assign) && ((size_t)(const void *)((assign) + 1) - (size_t)(const void *)(assign) == 1) ? __builtin_strcmp (assign, array[i]) : (- (__extension__ ({ const unsigned char *__s2 = (const unsigned char *) (const char *) (assign); int __result = (((const unsigned char *) (const char *) (array[i]))[0] - __s2[0]); if (__s2_len > 0 && __result == 0) { __result = (((const unsigned char *) (const char *) (array[i]))[1] - __s2[1]); if (__s2_len > 1 && __result == 0) { __result = (((const unsigned char *) (const char *) (array[i]))[2] - __s2[2]); if (__s2_len > 2 && __result == 0) __result = (((const unsigned char *) (const char *) (array[i]))[3] - __s2[3]); } } __result; })))) : __builtin_strcmp (assign, array[i])))); }) : __sym_strncmp (assign, array[i], equal_offset + 1))) == 0))
 {
   __sym_free (array[i]);
   array[i] = (char *)__sym_strcpy (__sym_xmalloc (1 + __sym_strlen (assign)), (assign));
   return (array);
 }
    }
  array = (char **)__sym_xrealloc (array, ((2 + i) * sizeof (char *)));
  array[i++] = (char *)__sym_strcpy (__sym_xmalloc (1 + __sym_strlen (assign)), (assign));
  array[i] = (char *)((void *)0);
  return (array);
}





static char ** __sym_make_var_array(HASH_TABLE * param0, ...);
static char ** __sym_add_or_supercede(char * param0, char ** param1, ...);
void
maybe_make_export_env ()
{
  register int i;
  register char **temp_array;

  if (array_needs_making)
    {
      if (export_env)
 __sym_free_array (export_env);

      export_env = (char **)__sym_xmalloc (sizeof (char *));
      export_env[0] = (char *)((void *)0);

      temp_array = __sym_make_var_array (shell_variables);
      for (i = 0; temp_array && temp_array[i]; i++)
 export_env = __sym_add_or_supercede (temp_array[i], export_env);
      __sym_free_array (temp_array);

      temp_array = __sym_make_var_array (shell_functions);
      for (i = 0; temp_array && temp_array[i]; i++)
 export_env = __sym_add_or_supercede (temp_array[i], export_env);
      __sym_free_array (temp_array);

      if (function_env)
 for (i = 0; function_env[i]; i++)
   export_env = __sym_add_or_supercede (function_env[i], export_env);

      if (temporary_env)
 for (i = 0; temporary_env[i]; i++)
   export_env = __sym_add_or_supercede (temporary_env[i], export_env);







      array_needs_making = 0;
    }
}


void
put_command_name_into_env (command_name)
     char *command_name;
{
  char *dummy;

  dummy = __sym_xmalloc (4 + __sym_strlen (command_name));


  dummy[0] = '_';
  dummy[1] = '=';
  __sym_strcpy (dummy + 2, command_name);
  export_env = __sym_add_or_supercede (dummy, export_env);
  __sym_free (dummy);
}

void
put_gnu_argv_flags_into_env (pid, flags_string)
     int pid;
     char *flags_string;
{
  char *dummy, *pbuf;
  int l, fl;

  pbuf = __sym_itos (pid);
  l = __sym_strlen (pbuf);

  fl = __sym_strlen (flags_string);

  dummy = __sym_xmalloc (l + fl + 30);
  dummy[0] = '_';
  __sym_strcpy (dummy + 1, pbuf);
  __sym_strcpy (dummy + 1 + l, "_GNU_nonoption_argv_flags_");
  dummy[l + 27] = '=';
  __sym_strcpy (dummy + l + 28, flags_string);

  __sym_free (pbuf);

  export_env = __sym_add_or_supercede (dummy, export_env);
  __sym_free (dummy);
}


static char indirection_string[100];

static char * __sym_decode_prompt_string(char * param0, ...);
char *
indirection_level_string ()
{
  register int i, j;
  char *ps4;

  indirection_string[0] = '\0';
  ps4 = __sym_get_string_value ("PS4");

  if (ps4 == 0 || *ps4 == '\0')
    return (indirection_string);

  ps4 = __sym_decode_prompt_string (ps4);

  for (i = 0; *ps4 && i < indirection_level && i < 99; i++)
    indirection_string[i] = *ps4;

  for (j = 1; *ps4 && ps4[j] && i < 99; i++, j++)
    indirection_string[i] = ps4[j];

  indirection_string[i] = '\0';
  __sym_free (ps4);
  return (indirection_string);
}

// Test driver for function initialize_shell_variables returning void
void initialize_shell_variables_driver()
{
char ** param1;
int param2;
param1 = malloc(1*sizeof(char *));
param1[0] = malloc(3*sizeof(char));
__CrestChar(&param1[0][0]);
__CrestChar(&param1[0][1]);
__CrestChar(&param1[0][2]);
__CrestInt(&param2);
__CrestInt(&array_needs_making);
__CrestInt(&build_version);
builtin_env = malloc(1*sizeof(char *));
builtin_env[0] = malloc(3*sizeof(char));
__CrestChar(&builtin_env[0][0]);
__CrestChar(&builtin_env[0][1]);
__CrestChar(&builtin_env[0][2]);
current_host_name = malloc(3*sizeof(char));
__CrestChar(&current_host_name[0]);
__CrestChar(&current_host_name[1]);
__CrestChar(&current_host_name[2]);
__CrestInt(&current_user.uid);
__CrestInt(&current_user.euid);
__CrestInt(&current_user.gid);
__CrestInt(&current_user.egid);
current_user.user_name = malloc(3*sizeof(char));
__CrestChar(&current_user.user_name[0]);
__CrestChar(&current_user.user_name[1]);
__CrestChar(&current_user.user_name[2]);
current_user.shell = malloc(3*sizeof(char));
__CrestChar(&current_user.shell[0]);
__CrestChar(&current_user.shell[1]);
__CrestChar(&current_user.shell[2]);
current_user.home_dir = malloc(3*sizeof(char));
__CrestChar(&current_user.home_dir[0]);
__CrestChar(&current_user.home_dir[1]);
__CrestChar(&current_user.home_dir[2]);
dist_version = malloc(3*sizeof(char));
__CrestChar(&dist_version[0]);
__CrestChar(&dist_version[1]);
__CrestChar(&dist_version[2]);
__CrestInt(&dollar_dollar_pid);
dollar_vars[0] = malloc(3*sizeof(char));
__CrestChar(&dollar_vars[0][0]);
__CrestChar(&dollar_vars[0][1]);
__CrestChar(&dollar_vars[0][2]);
dollar_vars[1] = malloc(3*sizeof(char));
__CrestChar(&dollar_vars[1][0]);
__CrestChar(&dollar_vars[1][1]);
__CrestChar(&dollar_vars[1][2]);
dollar_vars[2] = malloc(3*sizeof(char));
__CrestChar(&dollar_vars[2][0]);
__CrestChar(&dollar_vars[2][1]);
__CrestChar(&dollar_vars[2][2]);
dollar_vars[3] = malloc(3*sizeof(char));
__CrestChar(&dollar_vars[3][0]);
__CrestChar(&dollar_vars[3][1]);
__CrestChar(&dollar_vars[3][2]);
dollar_vars[4] = malloc(3*sizeof(char));
__CrestChar(&dollar_vars[4][0]);
__CrestChar(&dollar_vars[4][1]);
__CrestChar(&dollar_vars[4][2]);
dollar_vars[5] = malloc(3*sizeof(char));
__CrestChar(&dollar_vars[5][0]);
__CrestChar(&dollar_vars[5][1]);
__CrestChar(&dollar_vars[5][2]);
dollar_vars[6] = malloc(3*sizeof(char));
__CrestChar(&dollar_vars[6][0]);
__CrestChar(&dollar_vars[6][1]);
__CrestChar(&dollar_vars[6][2]);
dollar_vars[7] = malloc(3*sizeof(char));
__CrestChar(&dollar_vars[7][0]);
__CrestChar(&dollar_vars[7][1]);
__CrestChar(&dollar_vars[7][2]);
dollar_vars[8] = malloc(3*sizeof(char));
__CrestChar(&dollar_vars[8][0]);
__CrestChar(&dollar_vars[8][1]);
__CrestChar(&dollar_vars[8][2]);
dollar_vars[9] = malloc(3*sizeof(char));
__CrestChar(&dollar_vars[9][0]);
__CrestChar(&dollar_vars[9][1]);
__CrestChar(&dollar_vars[9][2]);
__CrestInt(&echo_command_at_execute);
export_env = malloc(1*sizeof(char *));
export_env[0] = malloc(3*sizeof(char));
__CrestChar(&export_env[0][0]);
__CrestChar(&export_env[0][1]);
__CrestChar(&export_env[0][2]);
function_env = malloc(1*sizeof(char *));
function_env[0] = malloc(3*sizeof(char));
__CrestChar(&function_env[0][0]);
__CrestChar(&function_env[0][1]);
__CrestChar(&function_env[0][2]);
have_local_variables = malloc(3*sizeof(char));
__CrestChar(&have_local_variables[0]);
__CrestChar(&have_local_variables[1]);
__CrestChar(&have_local_variables[2]);
__CrestInt(&indirection_level);
__CrestChar(&indirection_string[0]);
__CrestChar(&indirection_string[1]);
__CrestChar(&indirection_string[2]);
__CrestChar(&indirection_string[3]);
__CrestChar(&indirection_string[4]);
__CrestChar(&indirection_string[5]);
__CrestChar(&indirection_string[6]);
__CrestChar(&indirection_string[7]);
__CrestChar(&indirection_string[8]);
__CrestChar(&indirection_string[9]);
__CrestChar(&indirection_string[10]);
__CrestChar(&indirection_string[11]);
__CrestChar(&indirection_string[12]);
__CrestChar(&indirection_string[13]);
__CrestChar(&indirection_string[14]);
__CrestChar(&indirection_string[15]);
__CrestChar(&indirection_string[16]);
__CrestChar(&indirection_string[17]);
__CrestChar(&indirection_string[18]);
__CrestChar(&indirection_string[19]);
__CrestChar(&indirection_string[20]);
__CrestChar(&indirection_string[21]);
__CrestChar(&indirection_string[22]);
__CrestChar(&indirection_string[23]);
__CrestChar(&indirection_string[24]);
__CrestChar(&indirection_string[25]);
__CrestChar(&indirection_string[26]);
__CrestChar(&indirection_string[27]);
__CrestChar(&indirection_string[28]);
__CrestChar(&indirection_string[29]);
__CrestChar(&indirection_string[30]);
__CrestChar(&indirection_string[31]);
__CrestChar(&indirection_string[32]);
__CrestChar(&indirection_string[33]);
__CrestChar(&indirection_string[34]);
__CrestChar(&indirection_string[35]);
__CrestChar(&indirection_string[36]);
__CrestChar(&indirection_string[37]);
__CrestChar(&indirection_string[38]);
__CrestChar(&indirection_string[39]);
__CrestChar(&indirection_string[40]);
__CrestChar(&indirection_string[41]);
__CrestChar(&indirection_string[42]);
__CrestChar(&indirection_string[43]);
__CrestChar(&indirection_string[44]);
__CrestChar(&indirection_string[45]);
__CrestChar(&indirection_string[46]);
__CrestChar(&indirection_string[47]);
__CrestChar(&indirection_string[48]);
__CrestChar(&indirection_string[49]);
__CrestChar(&indirection_string[50]);
__CrestChar(&indirection_string[51]);
__CrestChar(&indirection_string[52]);
__CrestChar(&indirection_string[53]);
__CrestChar(&indirection_string[54]);
__CrestChar(&indirection_string[55]);
__CrestChar(&indirection_string[56]);
__CrestChar(&indirection_string[57]);
__CrestChar(&indirection_string[58]);
__CrestChar(&indirection_string[59]);
__CrestChar(&indirection_string[60]);
__CrestChar(&indirection_string[61]);
__CrestChar(&indirection_string[62]);
__CrestChar(&indirection_string[63]);
__CrestChar(&indirection_string[64]);
__CrestChar(&indirection_string[65]);
__CrestChar(&indirection_string[66]);
__CrestChar(&indirection_string[67]);
__CrestChar(&indirection_string[68]);
__CrestChar(&indirection_string[69]);
__CrestChar(&indirection_string[70]);
__CrestChar(&indirection_string[71]);
__CrestChar(&indirection_string[72]);
__CrestChar(&indirection_string[73]);
__CrestChar(&indirection_string[74]);
__CrestChar(&indirection_string[75]);
__CrestChar(&indirection_string[76]);
__CrestChar(&indirection_string[77]);
__CrestChar(&indirection_string[78]);
__CrestChar(&indirection_string[79]);
__CrestChar(&indirection_string[80]);
__CrestChar(&indirection_string[81]);
__CrestChar(&indirection_string[82]);
__CrestChar(&indirection_string[83]);
__CrestChar(&indirection_string[84]);
__CrestChar(&indirection_string[85]);
__CrestChar(&indirection_string[86]);
__CrestChar(&indirection_string[87]);
__CrestChar(&indirection_string[88]);
__CrestChar(&indirection_string[89]);
__CrestChar(&indirection_string[90]);
__CrestChar(&indirection_string[91]);
__CrestChar(&indirection_string[92]);
__CrestChar(&indirection_string[93]);
__CrestChar(&indirection_string[94]);
__CrestChar(&indirection_string[95]);
__CrestChar(&indirection_string[96]);
__CrestChar(&indirection_string[97]);
__CrestChar(&indirection_string[98]);
__CrestChar(&indirection_string[99]);
__CrestInt(&interactive_shell);
__CrestULong(&last_random_value);
__CrestInt(&line_number);
__CrestInt(&local_variable_stack_size);
__CrestInt(&login_shell);
__CrestInt(&mark_modified_vars);
__CrestInt(&no_invisible_vars);
__CrestInt(&patch_level);
__CrestInt(&posixly_correct);
primary_prompt = malloc(3*sizeof(char));
__CrestChar(&primary_prompt[0]);
__CrestChar(&primary_prompt[1]);
__CrestChar(&primary_prompt[2]);
release_status = malloc(3*sizeof(char));
__CrestChar(&release_status[0]);
__CrestChar(&release_status[1]);
__CrestChar(&release_status[2]);
__CrestInt(&remember_on_history);
__CrestULong(&rseed);
secondary_prompt = malloc(3*sizeof(char));
__CrestChar(&secondary_prompt[0]);
__CrestChar(&secondary_prompt[1]);
__CrestChar(&secondary_prompt[2]);
__CrestLong(&seconds_value_assigned);
shell_functions = malloc(1*sizeof(struct hash_table));
shell_functions[0].bucket_array = malloc(1*sizeof(struct bucket_contents *));
shell_functions[0].bucket_array[0] = malloc(1*sizeof(struct bucket_contents));
// Pointer Type: struct bucket_contents * of shell_functions[0].bucket_array[0][0].next is set as NULL
shell_functions[0].bucket_array[0][0].next = 0;
// Pointer Type: char * of shell_functions[0].bucket_array[0][0].key is set as NULL
shell_functions[0].bucket_array[0][0].key = 0;
// Pointer Type: char * of shell_functions[0].bucket_array[0][0].data is set as NULL
shell_functions[0].bucket_array[0][0].data = 0;
__CrestInt(&shell_functions[0].bucket_array[0][0].times_found);
__CrestInt(&shell_functions[0].nbuckets);
__CrestInt(&shell_functions[0].nentries);
__CrestInt(&shell_level);
shell_name = malloc(3*sizeof(char));
__CrestChar(&shell_name[0]);
__CrestChar(&shell_name[1]);
__CrestChar(&shell_name[2]);
__CrestLong(&shell_start_time);
shell_variables = malloc(1*sizeof(struct hash_table));
shell_variables[0].bucket_array = malloc(1*sizeof(struct bucket_contents *));
shell_variables[0].bucket_array[0] = malloc(1*sizeof(struct bucket_contents));
// Pointer Type: struct bucket_contents * of shell_variables[0].bucket_array[0][0].next is set as NULL
shell_variables[0].bucket_array[0][0].next = 0;
// Pointer Type: char * of shell_variables[0].bucket_array[0][0].key is set as NULL
shell_variables[0].bucket_array[0][0].key = 0;
// Pointer Type: char * of shell_variables[0].bucket_array[0][0].data is set as NULL
shell_variables[0].bucket_array[0][0].data = 0;
__CrestInt(&shell_variables[0].bucket_array[0][0].times_found);
__CrestInt(&shell_variables[0].nbuckets);
__CrestInt(&shell_variables[0].nentries);
// stderr will be set by C standard library
// stdin will be set by C standard library
// stdout will be set by C standard library
__CrestInt(&subshell_environment);
temporary_env = malloc(1*sizeof(char *));
temporary_env[0] = malloc(3*sizeof(char));
__CrestChar(&temporary_env[0][0]);
__CrestChar(&temporary_env[0][1]);
__CrestChar(&temporary_env[0][2]);
this_command_name = malloc(3*sizeof(char));
__CrestChar(&this_command_name[0]);
__CrestChar(&this_command_name[1]);
__CrestChar(&this_command_name[2]);
// Function pointer type: int (*)() of this_shell_builtin is not supported
this_shell_builtin = 0;
__CrestInt(&variable_context);
return initialize_shell_variables(param1,param2);
}
int test_main(){
initialize_shell_variables_driver();
 return 0;}

void init_variables_i(){
__CrestInt(&array_needs_making);
__CrestInt(&build_version);
builtin_env = malloc(1*sizeof(char *));
builtin_env[0] = malloc(3*sizeof(char));
__CrestChar(&builtin_env[0][0]);
__CrestChar(&builtin_env[0][1]);
__CrestChar(&builtin_env[0][2]);
current_host_name = malloc(3*sizeof(char));
__CrestChar(&current_host_name[0]);
__CrestChar(&current_host_name[1]);
__CrestChar(&current_host_name[2]);
__CrestInt(&current_user.uid);
__CrestInt(&current_user.euid);
__CrestInt(&current_user.gid);
__CrestInt(&current_user.egid);
current_user.user_name = malloc(3*sizeof(char));
__CrestChar(&current_user.user_name[0]);
__CrestChar(&current_user.user_name[1]);
__CrestChar(&current_user.user_name[2]);
current_user.shell = malloc(3*sizeof(char));
__CrestChar(&current_user.shell[0]);
__CrestChar(&current_user.shell[1]);
__CrestChar(&current_user.shell[2]);
current_user.home_dir = malloc(3*sizeof(char));
__CrestChar(&current_user.home_dir[0]);
__CrestChar(&current_user.home_dir[1]);
__CrestChar(&current_user.home_dir[2]);
dist_version = malloc(3*sizeof(char));
__CrestChar(&dist_version[0]);
__CrestChar(&dist_version[1]);
__CrestChar(&dist_version[2]);
__CrestInt(&dollar_dollar_pid);
dollar_vars[0] = malloc(3*sizeof(char));
__CrestChar(&dollar_vars[0][0]);
__CrestChar(&dollar_vars[0][1]);
__CrestChar(&dollar_vars[0][2]);
dollar_vars[1] = malloc(3*sizeof(char));
__CrestChar(&dollar_vars[1][0]);
__CrestChar(&dollar_vars[1][1]);
__CrestChar(&dollar_vars[1][2]);
dollar_vars[2] = malloc(3*sizeof(char));
__CrestChar(&dollar_vars[2][0]);
__CrestChar(&dollar_vars[2][1]);
__CrestChar(&dollar_vars[2][2]);
dollar_vars[3] = malloc(3*sizeof(char));
__CrestChar(&dollar_vars[3][0]);
__CrestChar(&dollar_vars[3][1]);
__CrestChar(&dollar_vars[3][2]);
dollar_vars[4] = malloc(3*sizeof(char));
__CrestChar(&dollar_vars[4][0]);
__CrestChar(&dollar_vars[4][1]);
__CrestChar(&dollar_vars[4][2]);
dollar_vars[5] = malloc(3*sizeof(char));
__CrestChar(&dollar_vars[5][0]);
__CrestChar(&dollar_vars[5][1]);
__CrestChar(&dollar_vars[5][2]);
dollar_vars[6] = malloc(3*sizeof(char));
__CrestChar(&dollar_vars[6][0]);
__CrestChar(&dollar_vars[6][1]);
__CrestChar(&dollar_vars[6][2]);
dollar_vars[7] = malloc(3*sizeof(char));
__CrestChar(&dollar_vars[7][0]);
__CrestChar(&dollar_vars[7][1]);
__CrestChar(&dollar_vars[7][2]);
dollar_vars[8] = malloc(3*sizeof(char));
__CrestChar(&dollar_vars[8][0]);
__CrestChar(&dollar_vars[8][1]);
__CrestChar(&dollar_vars[8][2]);
dollar_vars[9] = malloc(3*sizeof(char));
__CrestChar(&dollar_vars[9][0]);
__CrestChar(&dollar_vars[9][1]);
__CrestChar(&dollar_vars[9][2]);
__CrestInt(&echo_command_at_execute);
export_env = malloc(1*sizeof(char *));
export_env[0] = malloc(3*sizeof(char));
__CrestChar(&export_env[0][0]);
__CrestChar(&export_env[0][1]);
__CrestChar(&export_env[0][2]);
function_env = malloc(1*sizeof(char *));
function_env[0] = malloc(3*sizeof(char));
__CrestChar(&function_env[0][0]);
__CrestChar(&function_env[0][1]);
__CrestChar(&function_env[0][2]);
have_local_variables = malloc(3*sizeof(char));
__CrestChar(&have_local_variables[0]);
__CrestChar(&have_local_variables[1]);
__CrestChar(&have_local_variables[2]);
__CrestInt(&indirection_level);
__CrestChar(&indirection_string[0]);
__CrestChar(&indirection_string[1]);
__CrestChar(&indirection_string[2]);
__CrestChar(&indirection_string[3]);
__CrestChar(&indirection_string[4]);
__CrestChar(&indirection_string[5]);
__CrestChar(&indirection_string[6]);
__CrestChar(&indirection_string[7]);
__CrestChar(&indirection_string[8]);
__CrestChar(&indirection_string[9]);
__CrestChar(&indirection_string[10]);
__CrestChar(&indirection_string[11]);
__CrestChar(&indirection_string[12]);
__CrestChar(&indirection_string[13]);
__CrestChar(&indirection_string[14]);
__CrestChar(&indirection_string[15]);
__CrestChar(&indirection_string[16]);
__CrestChar(&indirection_string[17]);
__CrestChar(&indirection_string[18]);
__CrestChar(&indirection_string[19]);
__CrestChar(&indirection_string[20]);
__CrestChar(&indirection_string[21]);
__CrestChar(&indirection_string[22]);
__CrestChar(&indirection_string[23]);
__CrestChar(&indirection_string[24]);
__CrestChar(&indirection_string[25]);
__CrestChar(&indirection_string[26]);
__CrestChar(&indirection_string[27]);
__CrestChar(&indirection_string[28]);
__CrestChar(&indirection_string[29]);
__CrestChar(&indirection_string[30]);
__CrestChar(&indirection_string[31]);
__CrestChar(&indirection_string[32]);
__CrestChar(&indirection_string[33]);
__CrestChar(&indirection_string[34]);
__CrestChar(&indirection_string[35]);
__CrestChar(&indirection_string[36]);
__CrestChar(&indirection_string[37]);
__CrestChar(&indirection_string[38]);
__CrestChar(&indirection_string[39]);
__CrestChar(&indirection_string[40]);
__CrestChar(&indirection_string[41]);
__CrestChar(&indirection_string[42]);
__CrestChar(&indirection_string[43]);
__CrestChar(&indirection_string[44]);
__CrestChar(&indirection_string[45]);
__CrestChar(&indirection_string[46]);
__CrestChar(&indirection_string[47]);
__CrestChar(&indirection_string[48]);
__CrestChar(&indirection_string[49]);
__CrestChar(&indirection_string[50]);
__CrestChar(&indirection_string[51]);
__CrestChar(&indirection_string[52]);
__CrestChar(&indirection_string[53]);
__CrestChar(&indirection_string[54]);
__CrestChar(&indirection_string[55]);
__CrestChar(&indirection_string[56]);
__CrestChar(&indirection_string[57]);
__CrestChar(&indirection_string[58]);
__CrestChar(&indirection_string[59]);
__CrestChar(&indirection_string[60]);
__CrestChar(&indirection_string[61]);
__CrestChar(&indirection_string[62]);
__CrestChar(&indirection_string[63]);
__CrestChar(&indirection_string[64]);
__CrestChar(&indirection_string[65]);
__CrestChar(&indirection_string[66]);
__CrestChar(&indirection_string[67]);
__CrestChar(&indirection_string[68]);
__CrestChar(&indirection_string[69]);
__CrestChar(&indirection_string[70]);
__CrestChar(&indirection_string[71]);
__CrestChar(&indirection_string[72]);
__CrestChar(&indirection_string[73]);
__CrestChar(&indirection_string[74]);
__CrestChar(&indirection_string[75]);
__CrestChar(&indirection_string[76]);
__CrestChar(&indirection_string[77]);
__CrestChar(&indirection_string[78]);
__CrestChar(&indirection_string[79]);
__CrestChar(&indirection_string[80]);
__CrestChar(&indirection_string[81]);
__CrestChar(&indirection_string[82]);
__CrestChar(&indirection_string[83]);
__CrestChar(&indirection_string[84]);
__CrestChar(&indirection_string[85]);
__CrestChar(&indirection_string[86]);
__CrestChar(&indirection_string[87]);
__CrestChar(&indirection_string[88]);
__CrestChar(&indirection_string[89]);
__CrestChar(&indirection_string[90]);
__CrestChar(&indirection_string[91]);
__CrestChar(&indirection_string[92]);
__CrestChar(&indirection_string[93]);
__CrestChar(&indirection_string[94]);
__CrestChar(&indirection_string[95]);
__CrestChar(&indirection_string[96]);
__CrestChar(&indirection_string[97]);
__CrestChar(&indirection_string[98]);
__CrestChar(&indirection_string[99]);
__CrestInt(&interactive_shell);
__CrestULong(&last_random_value);
__CrestInt(&line_number);
__CrestInt(&local_variable_stack_size);
__CrestInt(&login_shell);
__CrestInt(&mark_modified_vars);
__CrestInt(&no_invisible_vars);
__CrestInt(&patch_level);
__CrestInt(&posixly_correct);
primary_prompt = malloc(3*sizeof(char));
__CrestChar(&primary_prompt[0]);
__CrestChar(&primary_prompt[1]);
__CrestChar(&primary_prompt[2]);
release_status = malloc(3*sizeof(char));
__CrestChar(&release_status[0]);
__CrestChar(&release_status[1]);
__CrestChar(&release_status[2]);
__CrestInt(&remember_on_history);
__CrestULong(&rseed);
secondary_prompt = malloc(3*sizeof(char));
__CrestChar(&secondary_prompt[0]);
__CrestChar(&secondary_prompt[1]);
__CrestChar(&secondary_prompt[2]);
__CrestLong(&seconds_value_assigned);
shell_functions = malloc(1*sizeof(struct hash_table));
shell_functions[0].bucket_array = malloc(1*sizeof(struct bucket_contents *));
shell_functions[0].bucket_array[0] = malloc(1*sizeof(struct bucket_contents));
// Pointer Type: struct bucket_contents * of shell_functions[0].bucket_array[0][0].next is set as NULL
shell_functions[0].bucket_array[0][0].next = 0;
// Pointer Type: char * of shell_functions[0].bucket_array[0][0].key is set as NULL
shell_functions[0].bucket_array[0][0].key = 0;
// Pointer Type: char * of shell_functions[0].bucket_array[0][0].data is set as NULL
shell_functions[0].bucket_array[0][0].data = 0;
__CrestInt(&shell_functions[0].bucket_array[0][0].times_found);
__CrestInt(&shell_functions[0].nbuckets);
__CrestInt(&shell_functions[0].nentries);
__CrestInt(&shell_level);
shell_name = malloc(3*sizeof(char));
__CrestChar(&shell_name[0]);
__CrestChar(&shell_name[1]);
__CrestChar(&shell_name[2]);
__CrestLong(&shell_start_time);
shell_variables = malloc(1*sizeof(struct hash_table));
shell_variables[0].bucket_array = malloc(1*sizeof(struct bucket_contents *));
shell_variables[0].bucket_array[0] = malloc(1*sizeof(struct bucket_contents));
// Pointer Type: struct bucket_contents * of shell_variables[0].bucket_array[0][0].next is set as NULL
shell_variables[0].bucket_array[0][0].next = 0;
// Pointer Type: char * of shell_variables[0].bucket_array[0][0].key is set as NULL
shell_variables[0].bucket_array[0][0].key = 0;
// Pointer Type: char * of shell_variables[0].bucket_array[0][0].data is set as NULL
shell_variables[0].bucket_array[0][0].data = 0;
__CrestInt(&shell_variables[0].bucket_array[0][0].times_found);
__CrestInt(&shell_variables[0].nbuckets);
__CrestInt(&shell_variables[0].nentries);
// stderr will be set by C standard library
// stdin will be set by C standard library
// stdout will be set by C standard library
__CrestInt(&subshell_environment);
temporary_env = malloc(1*sizeof(char *));
temporary_env[0] = malloc(3*sizeof(char));
__CrestChar(&temporary_env[0][0]);
__CrestChar(&temporary_env[0][1]);
__CrestChar(&temporary_env[0][2]);
this_command_name = malloc(3*sizeof(char));
__CrestChar(&this_command_name[0]);
__CrestChar(&this_command_name[1]);
__CrestChar(&this_command_name[2]);
// Function pointer type: int (*)() of this_shell_builtin is not supported
this_shell_builtin = 0;
__CrestInt(&variable_context);
}
static int __sym__IO_getc(_IO_FILE * param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym__IO_putc(int param0, _IO_FILE * param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static const int ** __sym___ctype_tolower_loc(void){
  const int ** ret;
ret = malloc(1*sizeof(const int *));
// Pointee type 'int' is a constant
{
int *__tmp__1;
__tmp__1 = malloc(3*sizeof(int));
__CrestInt(&__tmp__1[0]);
__CrestInt(&__tmp__1[1]);
__CrestInt(&__tmp__1[2]);
ret[0] = __tmp__1;
}
  return ret;
}
static const int ** __sym___ctype_toupper_loc(void){
  const int ** ret;
ret = malloc(1*sizeof(const int *));
// Pointee type 'int' is a constant
{
int *__tmp__1;
__tmp__1 = malloc(3*sizeof(int));
__CrestInt(&__tmp__1[0]);
__CrestInt(&__tmp__1[1]);
__CrestInt(&__tmp__1[2]);
ret[0] = __tmp__1;
}
  return ret;
}
static int __sym___fxstat(int param0, int param1, struct stat * param2, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym___fxstatat(int param0, int param1, const char * param2, struct stat * param3, int param4, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym___lxstat(int param0, const char * param1, struct stat * param2, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym___overflow(_IO_FILE * param0, int param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void * __sym___rawmemchr(const void * param0, int param1, ...){
  void * ret;
// Pointee type 'void' is an incomplete type
ret = 0;
  return ret;
}
static int __sym___uflow(_IO_FILE * param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym___xmknod(int param0, const char * param1, __mode_t param2, __dev_t * param3, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym___xmknodat(int param0, int param1, const char * param2, __mode_t param3, __dev_t * param4, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym___xstat(int param0, const char * param1, struct stat * param2, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static struct variable ** __sym__visible_names(HASH_TABLE * param0, ...){
  struct variable ** ret;
ret = malloc(1*sizeof(struct variable *));
ret[0] = malloc(1*sizeof(struct variable));
ret[0][0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0][0].name[0]);
__CrestChar(&ret[0][0].name[1]);
__CrestChar(&ret[0][0].name[2]);
ret[0][0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0][0].value[0]);
__CrestChar(&ret[0][0].value[1]);
__CrestChar(&ret[0][0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0][0].dynamic_value is not supported
ret[0][0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0][0].assign_func is not supported
ret[0][0].assign_func = 0;
__CrestInt(&ret[0][0].attributes);
__CrestInt(&ret[0][0].context);
ret[0][0].prev_context = malloc(1*sizeof(struct variable));
// Pointer Type: char * of ret[0][0].prev_context[0].name is set as NULL
ret[0][0].prev_context[0].name = 0;
// Pointer Type: char * of ret[0][0].prev_context[0].value is set as NULL
ret[0][0].prev_context[0].value = 0;
// Function pointer type: struct variable *(*)() of ret[0][0].prev_context[0].dynamic_value is not supported
ret[0][0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0][0].prev_context[0].assign_func is not supported
ret[0][0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0][0].prev_context[0].attributes);
__CrestInt(&ret[0][0].prev_context[0].context);
// Pointer Type: struct variable * of ret[0][0].prev_context[0].prev_context is set as NULL
ret[0][0].prev_context[0].prev_context = 0;
  return ret;
}
static struct bucket_contents * __sym_add_hash_item(void){
  struct bucket_contents * ret;
ret = malloc(1*sizeof(struct bucket_contents));
ret[0].next = malloc(1*sizeof(struct bucket_contents));
ret[0].next[0].next = malloc(1*sizeof(struct bucket_contents));
// Pointer Type: struct bucket_contents * of ret[0].next[0].next[0].next is set as NULL
ret[0].next[0].next[0].next = 0;
// Pointer Type: char * of ret[0].next[0].next[0].key is set as NULL
ret[0].next[0].next[0].key = 0;
// Pointer Type: char * of ret[0].next[0].next[0].data is set as NULL
ret[0].next[0].next[0].data = 0;
__CrestInt(&ret[0].next[0].next[0].times_found);
ret[0].next[0].key = malloc(3*sizeof(char));
__CrestChar(&ret[0].next[0].key[0]);
__CrestChar(&ret[0].next[0].key[1]);
__CrestChar(&ret[0].next[0].key[2]);
ret[0].next[0].data = malloc(3*sizeof(char));
__CrestChar(&ret[0].next[0].data[0]);
__CrestChar(&ret[0].next[0].data[1]);
__CrestChar(&ret[0].next[0].data[2]);
__CrestInt(&ret[0].next[0].times_found);
ret[0].key = malloc(3*sizeof(char));
__CrestChar(&ret[0].key[0]);
__CrestChar(&ret[0].key[1]);
__CrestChar(&ret[0].key[2]);
ret[0].data = malloc(3*sizeof(char));
__CrestChar(&ret[0].data[0]);
__CrestChar(&ret[0].data[1]);
__CrestChar(&ret[0].data[2]);
__CrestInt(&ret[0].times_found);
  return ret;
}
static char ** __sym_add_or_supercede(char * param0, char ** param1, ...){
  char ** ret;
ret = malloc(1*sizeof(char *));
ret[0] = malloc(3*sizeof(char));
__CrestChar(&ret[0][0]);
__CrestChar(&ret[0][1]);
__CrestChar(&ret[0][2]);
  return ret;
}
static void __sym_adjust_shell_level(int param0, ...){
}
static struct variable ** __sym_all_vars(HASH_TABLE * param0, ...){
  struct variable ** ret;
ret = malloc(1*sizeof(struct variable *));
ret[0] = malloc(1*sizeof(struct variable));
ret[0][0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0][0].name[0]);
__CrestChar(&ret[0][0].name[1]);
__CrestChar(&ret[0][0].name[2]);
ret[0][0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0][0].value[0]);
__CrestChar(&ret[0][0].value[1]);
__CrestChar(&ret[0][0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0][0].dynamic_value is not supported
ret[0][0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0][0].assign_func is not supported
ret[0][0].assign_func = 0;
__CrestInt(&ret[0][0].attributes);
__CrestInt(&ret[0][0].context);
ret[0][0].prev_context = malloc(1*sizeof(struct variable));
// Pointer Type: char * of ret[0][0].prev_context[0].name is set as NULL
ret[0][0].prev_context[0].name = 0;
// Pointer Type: char * of ret[0][0].prev_context[0].value is set as NULL
ret[0][0].prev_context[0].value = 0;
// Function pointer type: struct variable *(*)() of ret[0][0].prev_context[0].dynamic_value is not supported
ret[0][0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0][0].prev_context[0].assign_func is not supported
ret[0][0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0][0].prev_context[0].attributes);
__CrestInt(&ret[0][0].prev_context[0].context);
// Pointer Type: struct variable * of ret[0][0].prev_context[0].prev_context is set as NULL
ret[0][0].prev_context[0].prev_context = 0;
  return ret;
}
static int __sym_array_add_element(ARRAY * param0, arrayind_t param1, char * param2, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static struct array_element * __sym_array_delete_element(ARRAY * param0, arrayind_t param1, ...){
  struct array_element * ret;
ret = malloc(1*sizeof(struct array_element));
__CrestInt(&ret[0].ind);
ret[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].value[0]);
__CrestChar(&ret[0].value[1]);
__CrestChar(&ret[0].value[2]);
ret[0].next = malloc(1*sizeof(struct array_element));
__CrestInt(&ret[0].next[0].ind);
ret[0].next[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].next[0].value[0]);
__CrestChar(&ret[0].next[0].value[1]);
__CrestChar(&ret[0].next[0].value[2]);
ret[0].next[0].next = malloc(1*sizeof(struct array_element));
__CrestInt(&ret[0].next[0].next[0].ind);
// Pointer Type: char * of ret[0].next[0].next[0].value is set as NULL
ret[0].next[0].next[0].value = 0;
// Pointer Type: struct array_element * of ret[0].next[0].next[0].next is set as NULL
ret[0].next[0].next[0].next = 0;
// Pointer Type: struct array_element * of ret[0].next[0].next[0].prev is set as NULL
ret[0].next[0].next[0].prev = 0;
ret[0].next[0].prev = malloc(1*sizeof(struct array_element));
__CrestInt(&ret[0].next[0].prev[0].ind);
// Pointer Type: char * of ret[0].next[0].prev[0].value is set as NULL
ret[0].next[0].prev[0].value = 0;
// Pointer Type: struct array_element * of ret[0].next[0].prev[0].next is set as NULL
ret[0].next[0].prev[0].next = 0;
// Pointer Type: struct array_element * of ret[0].next[0].prev[0].prev is set as NULL
ret[0].next[0].prev[0].prev = 0;
ret[0].prev = malloc(1*sizeof(struct array_element));
__CrestInt(&ret[0].prev[0].ind);
ret[0].prev[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev[0].value[0]);
__CrestChar(&ret[0].prev[0].value[1]);
__CrestChar(&ret[0].prev[0].value[2]);
ret[0].prev[0].next = malloc(1*sizeof(struct array_element));
__CrestInt(&ret[0].prev[0].next[0].ind);
// Pointer Type: char * of ret[0].prev[0].next[0].value is set as NULL
ret[0].prev[0].next[0].value = 0;
// Pointer Type: struct array_element * of ret[0].prev[0].next[0].next is set as NULL
ret[0].prev[0].next[0].next = 0;
// Pointer Type: struct array_element * of ret[0].prev[0].next[0].prev is set as NULL
ret[0].prev[0].next[0].prev = 0;
ret[0].prev[0].prev = malloc(1*sizeof(struct array_element));
__CrestInt(&ret[0].prev[0].prev[0].ind);
// Pointer Type: char * of ret[0].prev[0].prev[0].value is set as NULL
ret[0].prev[0].prev[0].value = 0;
// Pointer Type: struct array_element * of ret[0].prev[0].prev[0].next is set as NULL
ret[0].prev[0].prev[0].next = 0;
// Pointer Type: struct array_element * of ret[0].prev[0].prev[0].prev is set as NULL
ret[0].prev[0].prev[0].prev = 0;
  return ret;
}
static int __sym_array_expand_index(char * param0, int param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_array_len(char ** param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static char * __sym_array_reference(ARRAY * param0, arrayind_t param1, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static char * __sym_array_to_assignment_string(ARRAY * param0, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static struct variable * __sym_assign_array_var_from_string(SHELL_VAR * param0, char * param1, ...){
  struct variable * ret;
ret = malloc(1*sizeof(struct variable));
ret[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].name[0]);
__CrestChar(&ret[0].name[1]);
__CrestChar(&ret[0].name[2]);
ret[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].value[0]);
__CrestChar(&ret[0].value[1]);
__CrestChar(&ret[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].dynamic_value is not supported
ret[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].assign_func is not supported
ret[0].assign_func = 0;
__CrestInt(&ret[0].attributes);
__CrestInt(&ret[0].context);
ret[0].prev_context = malloc(1*sizeof(struct variable));
ret[0].prev_context[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].name[0]);
__CrestChar(&ret[0].prev_context[0].name[1]);
__CrestChar(&ret[0].prev_context[0].name[2]);
ret[0].prev_context[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].value[0]);
__CrestChar(&ret[0].prev_context[0].value[1]);
__CrestChar(&ret[0].prev_context[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].context);
ret[0].prev_context[0].prev_context = malloc(1*sizeof(struct variable));
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].name is set as NULL
ret[0].prev_context[0].prev_context[0].name = 0;
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].value is set as NULL
ret[0].prev_context[0].prev_context[0].value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].prev_context[0].context);
// Pointer Type: struct variable * of ret[0].prev_context[0].prev_context[0].prev_context is set as NULL
ret[0].prev_context[0].prev_context[0].prev_context = 0;
  return ret;
}
static int __sym_assignment(char * param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_atoi(const char * param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static char * __sym_bash_tilde_expand(char * param0, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static struct variable * __sym_bind_variable(char * param0, char * param1, ...){
  struct variable * ret;
ret = malloc(1*sizeof(struct variable));
ret[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].name[0]);
__CrestChar(&ret[0].name[1]);
__CrestChar(&ret[0].name[2]);
ret[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].value[0]);
__CrestChar(&ret[0].value[1]);
__CrestChar(&ret[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].dynamic_value is not supported
ret[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].assign_func is not supported
ret[0].assign_func = 0;
__CrestInt(&ret[0].attributes);
__CrestInt(&ret[0].context);
ret[0].prev_context = malloc(1*sizeof(struct variable));
ret[0].prev_context[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].name[0]);
__CrestChar(&ret[0].prev_context[0].name[1]);
__CrestChar(&ret[0].prev_context[0].name[2]);
ret[0].prev_context[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].value[0]);
__CrestChar(&ret[0].prev_context[0].value[1]);
__CrestChar(&ret[0].prev_context[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].context);
ret[0].prev_context[0].prev_context = malloc(1*sizeof(struct variable));
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].name is set as NULL
ret[0].prev_context[0].prev_context[0].name = 0;
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].value is set as NULL
ret[0].prev_context[0].prev_context[0].value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].prev_context[0].context);
// Pointer Type: struct variable * of ret[0].prev_context[0].prev_context[0].prev_context is set as NULL
ret[0].prev_context[0].prev_context[0].prev_context = 0;
  return ret;
}
static int __sym_brand(void){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym_builtin_error(const char * param0, ...){
}
static void __sym_bzero(void * param0, size_t param1, ...){
}
static char * __sym_canonicalize_pathname(char * param0, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static int __sym_contains_shell_metas(void){
  int ret;
__CrestInt(&ret);
  return ret;
}
static struct variable * __sym_convert_var_to_array(SHELL_VAR * param0, ...){
  struct variable * ret;
ret = malloc(1*sizeof(struct variable));
ret[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].name[0]);
__CrestChar(&ret[0].name[1]);
__CrestChar(&ret[0].name[2]);
ret[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].value[0]);
__CrestChar(&ret[0].value[1]);
__CrestChar(&ret[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].dynamic_value is not supported
ret[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].assign_func is not supported
ret[0].assign_func = 0;
__CrestInt(&ret[0].attributes);
__CrestInt(&ret[0].context);
ret[0].prev_context = malloc(1*sizeof(struct variable));
ret[0].prev_context[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].name[0]);
__CrestChar(&ret[0].prev_context[0].name[1]);
__CrestChar(&ret[0].prev_context[0].name[2]);
ret[0].prev_context[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].value[0]);
__CrestChar(&ret[0].prev_context[0].value[1]);
__CrestChar(&ret[0].prev_context[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].context);
ret[0].prev_context[0].prev_context = malloc(1*sizeof(struct variable));
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].name is set as NULL
ret[0].prev_context[0].prev_context[0].name = 0;
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].value is set as NULL
ret[0].prev_context[0].prev_context[0].value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].prev_context[0].context);
// Pointer Type: struct variable * of ret[0].prev_context[0].prev_context[0].prev_context is set as NULL
ret[0].prev_context[0].prev_context[0].prev_context = 0;
  return ret;
}
static struct command * __sym_copy_command(COMMAND * param0, ...){
  struct command * ret;
ret = malloc(1*sizeof(struct command));
__CrestInt(&ret[0].type);
__CrestInt(&ret[0].flags);
__CrestInt(&ret[0].line);
ret[0].redirects = malloc(1*sizeof(struct redirect));
ret[0].redirects[0].next = malloc(1*sizeof(struct redirect));
// Pointer Type: struct redirect * of ret[0].redirects[0].next[0].next is set as NULL
ret[0].redirects[0].next[0].next = 0;
__CrestInt(&ret[0].redirects[0].next[0].redirector);
__CrestInt(&ret[0].redirects[0].next[0].flags);
__CrestInt(&ret[0].redirects[0].next[0].instruction);
// Type: REDIRECTEE of ret[0].redirects[0].next[0].redirectee is not supported
// Pointer Type: char * of ret[0].redirects[0].next[0].here_doc_eof is set as NULL
ret[0].redirects[0].next[0].here_doc_eof = 0;
__CrestInt(&ret[0].redirects[0].redirector);
__CrestInt(&ret[0].redirects[0].flags);
__CrestInt(&ret[0].redirects[0].instruction);
// Type: REDIRECTEE of ret[0].redirects[0].redirectee is not supported
ret[0].redirects[0].here_doc_eof = malloc(3*sizeof(char));
__CrestChar(&ret[0].redirects[0].here_doc_eof[0]);
__CrestChar(&ret[0].redirects[0].here_doc_eof[1]);
__CrestChar(&ret[0].redirects[0].here_doc_eof[2]);
// Type: union command::<anonymous at command.h:131:3> of ret[0].value is not supported
  return ret;
}
static char * __sym_decode_prompt_string(char * param0, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static void __sym_destroy_array_element(ARRAY_ELEMENT * param0, ...){
}
static void __sym_dispose_array(ARRAY * param0, ...){
}
static void __sym_dispose_command(COMMAND * param0, ...){
}
static void __sym_dispose_temporary_vars(char *** param0, ...){
}
static void __sym_dispose_variable(SHELL_VAR * param0, ...){
}
static void __sym_dispose_words(WORD_LIST * param0, ...){
}
static struct array * __sym_dup_array(ARRAY * param0, ...){
  struct array * ret;
ret = malloc(1*sizeof(struct array));
__CrestInt(&ret[0].type);
__CrestInt(&ret[0].max_index);
__CrestInt(&ret[0].num_elements);
__CrestInt(&ret[0].max_size);
ret[0].head = malloc(1*sizeof(struct array_element));
__CrestInt(&ret[0].head[0].ind);
ret[0].head[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].head[0].value[0]);
__CrestChar(&ret[0].head[0].value[1]);
__CrestChar(&ret[0].head[0].value[2]);
ret[0].head[0].next = malloc(1*sizeof(struct array_element));
__CrestInt(&ret[0].head[0].next[0].ind);
// Pointer Type: char * of ret[0].head[0].next[0].value is set as NULL
ret[0].head[0].next[0].value = 0;
// Pointer Type: struct array_element * of ret[0].head[0].next[0].next is set as NULL
ret[0].head[0].next[0].next = 0;
// Pointer Type: struct array_element * of ret[0].head[0].next[0].prev is set as NULL
ret[0].head[0].next[0].prev = 0;
ret[0].head[0].prev = malloc(1*sizeof(struct array_element));
__CrestInt(&ret[0].head[0].prev[0].ind);
// Pointer Type: char * of ret[0].head[0].prev[0].value is set as NULL
ret[0].head[0].prev[0].value = 0;
// Pointer Type: struct array_element * of ret[0].head[0].prev[0].next is set as NULL
ret[0].head[0].prev[0].next = 0;
// Pointer Type: struct array_element * of ret[0].head[0].prev[0].prev is set as NULL
ret[0].head[0].prev[0].prev = 0;
  return ret;
}
static long __sym_evalexp(char * param0, ...){
  long ret;
__CrestLong(&ret);
  return ret;
}
static int __sym_executing_line_number(void){
  int ret;
__CrestInt(&ret);
  return ret;
}
static struct word_list * __sym_expand_string(char * param0, int param1, ...){
  struct word_list * ret;
ret = malloc(1*sizeof(struct word_list));
ret[0].next = malloc(1*sizeof(struct word_list));
ret[0].next[0].next = malloc(1*sizeof(struct word_list));
// Pointer Type: struct word_list * of ret[0].next[0].next[0].next is set as NULL
ret[0].next[0].next[0].next = 0;
// Pointer Type: struct word_desc * of ret[0].next[0].next[0].word is set as NULL
ret[0].next[0].next[0].word = 0;
ret[0].next[0].word = malloc(1*sizeof(struct word_desc));
// Pointer Type: char * of ret[0].next[0].word[0].word is set as NULL
ret[0].next[0].word[0].word = 0;
__CrestInt(&ret[0].next[0].word[0].flags);
ret[0].word = malloc(1*sizeof(struct word_desc));
ret[0].word[0].word = malloc(3*sizeof(char));
__CrestChar(&ret[0].word[0].word[0]);
__CrestChar(&ret[0].word[0].word[1]);
__CrestChar(&ret[0].word[0].word[2]);
__CrestInt(&ret[0].word[0].flags);
  return ret;
}
static struct word_list * __sym_expand_string_unsplit(char * param0, int param1, ...){
  struct word_list * ret;
ret = malloc(1*sizeof(struct word_list));
ret[0].next = malloc(1*sizeof(struct word_list));
ret[0].next[0].next = malloc(1*sizeof(struct word_list));
// Pointer Type: struct word_list * of ret[0].next[0].next[0].next is set as NULL
ret[0].next[0].next[0].next = 0;
// Pointer Type: struct word_desc * of ret[0].next[0].next[0].word is set as NULL
ret[0].next[0].next[0].word = 0;
ret[0].next[0].word = malloc(1*sizeof(struct word_desc));
// Pointer Type: char * of ret[0].next[0].word[0].word is set as NULL
ret[0].next[0].word[0].word = 0;
__CrestInt(&ret[0].next[0].word[0].flags);
ret[0].word = malloc(1*sizeof(struct word_desc));
ret[0].word[0].word = malloc(3*sizeof(char));
__CrestChar(&ret[0].word[0].word[0]);
__CrestChar(&ret[0].word[0].word[1]);
__CrestChar(&ret[0].word[0].word[2]);
__CrestInt(&ret[0].word[0].flags);
  return ret;
}
static char * __sym_extract_array_assignment_list(char * param0, int * param1, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static int __sym_fflush(FILE * param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_file_status(char * param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static struct variable * __sym_find_function(char * param0, ...){
  struct variable * ret;
ret = malloc(1*sizeof(struct variable));
ret[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].name[0]);
__CrestChar(&ret[0].name[1]);
__CrestChar(&ret[0].name[2]);
ret[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].value[0]);
__CrestChar(&ret[0].value[1]);
__CrestChar(&ret[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].dynamic_value is not supported
ret[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].assign_func is not supported
ret[0].assign_func = 0;
__CrestInt(&ret[0].attributes);
__CrestInt(&ret[0].context);
ret[0].prev_context = malloc(1*sizeof(struct variable));
ret[0].prev_context[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].name[0]);
__CrestChar(&ret[0].prev_context[0].name[1]);
__CrestChar(&ret[0].prev_context[0].name[2]);
ret[0].prev_context[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].value[0]);
__CrestChar(&ret[0].prev_context[0].value[1]);
__CrestChar(&ret[0].prev_context[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].context);
ret[0].prev_context[0].prev_context = malloc(1*sizeof(struct variable));
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].name is set as NULL
ret[0].prev_context[0].prev_context[0].name = 0;
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].value is set as NULL
ret[0].prev_context[0].prev_context[0].value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].prev_context[0].context);
// Pointer Type: struct variable * of ret[0].prev_context[0].prev_context[0].prev_context is set as NULL
ret[0].prev_context[0].prev_context[0].prev_context = 0;
  return ret;
}
static struct bucket_contents * __sym_find_hash_item(void){
  struct bucket_contents * ret;
ret = malloc(1*sizeof(struct bucket_contents));
ret[0].next = malloc(1*sizeof(struct bucket_contents));
ret[0].next[0].next = malloc(1*sizeof(struct bucket_contents));
// Pointer Type: struct bucket_contents * of ret[0].next[0].next[0].next is set as NULL
ret[0].next[0].next[0].next = 0;
// Pointer Type: char * of ret[0].next[0].next[0].key is set as NULL
ret[0].next[0].next[0].key = 0;
// Pointer Type: char * of ret[0].next[0].next[0].data is set as NULL
ret[0].next[0].next[0].data = 0;
__CrestInt(&ret[0].next[0].next[0].times_found);
ret[0].next[0].key = malloc(3*sizeof(char));
__CrestChar(&ret[0].next[0].key[0]);
__CrestChar(&ret[0].next[0].key[1]);
__CrestChar(&ret[0].next[0].key[2]);
ret[0].next[0].data = malloc(3*sizeof(char));
__CrestChar(&ret[0].next[0].data[0]);
__CrestChar(&ret[0].next[0].data[1]);
__CrestChar(&ret[0].next[0].data[2]);
__CrestInt(&ret[0].next[0].times_found);
ret[0].key = malloc(3*sizeof(char));
__CrestChar(&ret[0].key[0]);
__CrestChar(&ret[0].key[1]);
__CrestChar(&ret[0].key[2]);
ret[0].data = malloc(3*sizeof(char));
__CrestChar(&ret[0].data[0]);
__CrestChar(&ret[0].data[1]);
__CrestChar(&ret[0].data[2]);
__CrestInt(&ret[0].times_found);
  return ret;
}
static struct variable * __sym_find_name_in_env_array(char * param0, char ** param1, ...){
  struct variable * ret;
ret = malloc(1*sizeof(struct variable));
ret[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].name[0]);
__CrestChar(&ret[0].name[1]);
__CrestChar(&ret[0].name[2]);
ret[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].value[0]);
__CrestChar(&ret[0].value[1]);
__CrestChar(&ret[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].dynamic_value is not supported
ret[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].assign_func is not supported
ret[0].assign_func = 0;
__CrestInt(&ret[0].attributes);
__CrestInt(&ret[0].context);
ret[0].prev_context = malloc(1*sizeof(struct variable));
ret[0].prev_context[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].name[0]);
__CrestChar(&ret[0].prev_context[0].name[1]);
__CrestChar(&ret[0].prev_context[0].name[2]);
ret[0].prev_context[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].value[0]);
__CrestChar(&ret[0].prev_context[0].value[1]);
__CrestChar(&ret[0].prev_context[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].context);
ret[0].prev_context[0].prev_context = malloc(1*sizeof(struct variable));
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].name is set as NULL
ret[0].prev_context[0].prev_context[0].name = 0;
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].value is set as NULL
ret[0].prev_context[0].prev_context[0].value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].prev_context[0].context);
// Pointer Type: struct variable * of ret[0].prev_context[0].prev_context[0].prev_context is set as NULL
ret[0].prev_context[0].prev_context[0].prev_context = 0;
  return ret;
}
static struct variable * __sym_find_tempenv_variable(char * param0, ...){
  struct variable * ret;
ret = malloc(1*sizeof(struct variable));
ret[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].name[0]);
__CrestChar(&ret[0].name[1]);
__CrestChar(&ret[0].name[2]);
ret[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].value[0]);
__CrestChar(&ret[0].value[1]);
__CrestChar(&ret[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].dynamic_value is not supported
ret[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].assign_func is not supported
ret[0].assign_func = 0;
__CrestInt(&ret[0].attributes);
__CrestInt(&ret[0].context);
ret[0].prev_context = malloc(1*sizeof(struct variable));
ret[0].prev_context[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].name[0]);
__CrestChar(&ret[0].prev_context[0].name[1]);
__CrestChar(&ret[0].prev_context[0].name[2]);
ret[0].prev_context[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].value[0]);
__CrestChar(&ret[0].prev_context[0].value[1]);
__CrestChar(&ret[0].prev_context[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].context);
ret[0].prev_context[0].prev_context = malloc(1*sizeof(struct variable));
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].name is set as NULL
ret[0].prev_context[0].prev_context[0].name = 0;
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].value is set as NULL
ret[0].prev_context[0].prev_context[0].value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].prev_context[0].context);
// Pointer Type: struct variable * of ret[0].prev_context[0].prev_context[0].prev_context is set as NULL
ret[0].prev_context[0].prev_context[0].prev_context = 0;
  return ret;
}
static char * __sym_find_user_command(char * param0, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static struct variable * __sym_find_variable(char * param0, ...){
  struct variable * ret;
ret = malloc(1*sizeof(struct variable));
ret[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].name[0]);
__CrestChar(&ret[0].name[1]);
__CrestChar(&ret[0].name[2]);
ret[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].value[0]);
__CrestChar(&ret[0].value[1]);
__CrestChar(&ret[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].dynamic_value is not supported
ret[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].assign_func is not supported
ret[0].assign_func = 0;
__CrestInt(&ret[0].attributes);
__CrestInt(&ret[0].context);
ret[0].prev_context = malloc(1*sizeof(struct variable));
ret[0].prev_context[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].name[0]);
__CrestChar(&ret[0].prev_context[0].name[1]);
__CrestChar(&ret[0].prev_context[0].name[2]);
ret[0].prev_context[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].value[0]);
__CrestChar(&ret[0].prev_context[0].value[1]);
__CrestChar(&ret[0].prev_context[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].context);
ret[0].prev_context[0].prev_context = malloc(1*sizeof(struct variable));
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].name is set as NULL
ret[0].prev_context[0].prev_context[0].name = 0;
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].value is set as NULL
ret[0].prev_context[0].prev_context[0].value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].prev_context[0].context);
// Pointer Type: struct variable * of ret[0].prev_context[0].prev_context[0].prev_context is set as NULL
ret[0].prev_context[0].prev_context[0].prev_context = 0;
  return ret;
}
static struct variable * __sym_find_variable_internal(char * param0, int param1, ...){
  struct variable * ret;
ret = malloc(1*sizeof(struct variable));
ret[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].name[0]);
__CrestChar(&ret[0].name[1]);
__CrestChar(&ret[0].name[2]);
ret[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].value[0]);
__CrestChar(&ret[0].value[1]);
__CrestChar(&ret[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].dynamic_value is not supported
ret[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].assign_func is not supported
ret[0].assign_func = 0;
__CrestInt(&ret[0].attributes);
__CrestInt(&ret[0].context);
ret[0].prev_context = malloc(1*sizeof(struct variable));
ret[0].prev_context[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].name[0]);
__CrestChar(&ret[0].prev_context[0].name[1]);
__CrestChar(&ret[0].prev_context[0].name[2]);
ret[0].prev_context[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].value[0]);
__CrestChar(&ret[0].prev_context[0].value[1]);
__CrestChar(&ret[0].prev_context[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].context);
ret[0].prev_context[0].prev_context = malloc(1*sizeof(struct variable));
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].name is set as NULL
ret[0].prev_context[0].prev_context[0].name = 0;
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].value is set as NULL
ret[0].prev_context[0].prev_context[0].value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].prev_context[0].context);
// Pointer Type: struct variable * of ret[0].prev_context[0].prev_context[0].prev_context is set as NULL
ret[0].prev_context[0].prev_context[0].prev_context = 0;
  return ret;
}
static void __sym_flush_hash_table(void){
}
static int __sym_fprintf(FILE * param0, const char * param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym_free(void * param0, ...){
}
static void __sym_free_array(char ** param0, ...){
}
static char * __sym_full_pathname(char * param0, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static struct word_list * __sym_get_directory_stack(void){
  struct word_list * ret;
ret = malloc(1*sizeof(struct word_list));
ret[0].next = malloc(1*sizeof(struct word_list));
ret[0].next[0].next = malloc(1*sizeof(struct word_list));
// Pointer Type: struct word_list * of ret[0].next[0].next[0].next is set as NULL
ret[0].next[0].next[0].next = 0;
// Pointer Type: struct word_desc * of ret[0].next[0].next[0].word is set as NULL
ret[0].next[0].next[0].word = 0;
ret[0].next[0].word = malloc(1*sizeof(struct word_desc));
// Pointer Type: char * of ret[0].next[0].word[0].word is set as NULL
ret[0].next[0].word[0].word = 0;
__CrestInt(&ret[0].next[0].word[0].flags);
ret[0].word = malloc(1*sizeof(struct word_desc));
ret[0].word[0].word = malloc(3*sizeof(char));
__CrestChar(&ret[0].word[0].word[0]);
__CrestChar(&ret[0].word[0].word[1]);
__CrestChar(&ret[0].word[0].word[2]);
__CrestInt(&ret[0].word[0].flags);
  return ret;
}
static char * __sym_get_string_value(char * param0, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static char * __sym_get_working_directory(void){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static int __sym_getpid(void){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_getppid(void){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_history_number(void){
  int ret;
__CrestInt(&ret);
  return ret;
}
static char * __sym_indirection_level_string(void){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static void __sym_initialize_dynamic_variables(void){
}
static char * __sym_itos(int param0, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static char * __sym_make_absolute(char * param0, char * param1, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static struct hash_table * __sym_make_hash_table(void){
  struct hash_table * ret;
ret = malloc(1*sizeof(struct hash_table));
ret[0].bucket_array = malloc(1*sizeof(struct bucket_contents *));
ret[0].bucket_array[0] = malloc(1*sizeof(struct bucket_contents));
// Pointer Type: struct bucket_contents * of ret[0].bucket_array[0][0].next is set as NULL
ret[0].bucket_array[0][0].next = 0;
// Pointer Type: char * of ret[0].bucket_array[0][0].key is set as NULL
ret[0].bucket_array[0][0].key = 0;
// Pointer Type: char * of ret[0].bucket_array[0][0].data is set as NULL
ret[0].bucket_array[0][0].data = 0;
__CrestInt(&ret[0].bucket_array[0][0].times_found);
__CrestInt(&ret[0].nbuckets);
__CrestInt(&ret[0].nentries);
  return ret;
}
static struct variable * __sym_make_local_variable(char * param0, ...){
  struct variable * ret;
ret = malloc(1*sizeof(struct variable));
ret[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].name[0]);
__CrestChar(&ret[0].name[1]);
__CrestChar(&ret[0].name[2]);
ret[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].value[0]);
__CrestChar(&ret[0].value[1]);
__CrestChar(&ret[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].dynamic_value is not supported
ret[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].assign_func is not supported
ret[0].assign_func = 0;
__CrestInt(&ret[0].attributes);
__CrestInt(&ret[0].context);
ret[0].prev_context = malloc(1*sizeof(struct variable));
ret[0].prev_context[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].name[0]);
__CrestChar(&ret[0].prev_context[0].name[1]);
__CrestChar(&ret[0].prev_context[0].name[2]);
ret[0].prev_context[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].value[0]);
__CrestChar(&ret[0].prev_context[0].value[1]);
__CrestChar(&ret[0].prev_context[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].context);
ret[0].prev_context[0].prev_context = malloc(1*sizeof(struct variable));
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].name is set as NULL
ret[0].prev_context[0].prev_context[0].name = 0;
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].value is set as NULL
ret[0].prev_context[0].prev_context[0].value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].prev_context[0].context);
// Pointer Type: struct variable * of ret[0].prev_context[0].prev_context[0].prev_context is set as NULL
ret[0].prev_context[0].prev_context[0].prev_context = 0;
  return ret;
}
static struct variable * __sym_make_new_array_variable(char * param0, ...){
  struct variable * ret;
ret = malloc(1*sizeof(struct variable));
ret[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].name[0]);
__CrestChar(&ret[0].name[1]);
__CrestChar(&ret[0].name[2]);
ret[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].value[0]);
__CrestChar(&ret[0].value[1]);
__CrestChar(&ret[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].dynamic_value is not supported
ret[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].assign_func is not supported
ret[0].assign_func = 0;
__CrestInt(&ret[0].attributes);
__CrestInt(&ret[0].context);
ret[0].prev_context = malloc(1*sizeof(struct variable));
ret[0].prev_context[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].name[0]);
__CrestChar(&ret[0].prev_context[0].name[1]);
__CrestChar(&ret[0].prev_context[0].name[2]);
ret[0].prev_context[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].value[0]);
__CrestChar(&ret[0].prev_context[0].value[1]);
__CrestChar(&ret[0].prev_context[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].context);
ret[0].prev_context[0].prev_context = malloc(1*sizeof(struct variable));
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].name is set as NULL
ret[0].prev_context[0].prev_context[0].name = 0;
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].value is set as NULL
ret[0].prev_context[0].prev_context[0].value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].prev_context[0].context);
// Pointer Type: struct variable * of ret[0].prev_context[0].prev_context[0].prev_context is set as NULL
ret[0].prev_context[0].prev_context[0].prev_context = 0;
  return ret;
}
static struct variable * __sym_make_new_variable(char * param0, ...){
  struct variable * ret;
ret = malloc(1*sizeof(struct variable));
ret[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].name[0]);
__CrestChar(&ret[0].name[1]);
__CrestChar(&ret[0].name[2]);
ret[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].value[0]);
__CrestChar(&ret[0].value[1]);
__CrestChar(&ret[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].dynamic_value is not supported
ret[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].assign_func is not supported
ret[0].assign_func = 0;
__CrestInt(&ret[0].attributes);
__CrestInt(&ret[0].context);
ret[0].prev_context = malloc(1*sizeof(struct variable));
ret[0].prev_context[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].name[0]);
__CrestChar(&ret[0].prev_context[0].name[1]);
__CrestChar(&ret[0].prev_context[0].name[2]);
ret[0].prev_context[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].value[0]);
__CrestChar(&ret[0].prev_context[0].value[1]);
__CrestChar(&ret[0].prev_context[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].context);
ret[0].prev_context[0].prev_context = malloc(1*sizeof(struct variable));
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].name is set as NULL
ret[0].prev_context[0].prev_context[0].name = 0;
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].value is set as NULL
ret[0].prev_context[0].prev_context[0].value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].prev_context[0].context);
// Pointer Type: struct variable * of ret[0].prev_context[0].prev_context[0].prev_context is set as NULL
ret[0].prev_context[0].prev_context[0].prev_context = 0;
  return ret;
}
static char ** __sym_make_var_array(HASH_TABLE * param0, ...){
  char ** ret;
ret = malloc(1*sizeof(char *));
ret[0] = malloc(3*sizeof(char));
__CrestChar(&ret[0][0]);
__CrestChar(&ret[0][1]);
__CrestChar(&ret[0][2]);
  return ret;
}
static char * __sym_make_variable_value(SHELL_VAR * param0, char * param1, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static void __sym_make_vers_array(void){
}
static int __sym_makunbound(char * param0, HASH_TABLE * param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static struct variable ** __sym_map_over(void * param0, HASH_TABLE * param1, ...){
  struct variable ** ret;
ret = malloc(1*sizeof(struct variable *));
ret[0] = malloc(1*sizeof(struct variable));
ret[0][0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0][0].name[0]);
__CrestChar(&ret[0][0].name[1]);
__CrestChar(&ret[0][0].name[2]);
ret[0][0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0][0].value[0]);
__CrestChar(&ret[0][0].value[1]);
__CrestChar(&ret[0][0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0][0].dynamic_value is not supported
ret[0][0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0][0].assign_func is not supported
ret[0][0].assign_func = 0;
__CrestInt(&ret[0][0].attributes);
__CrestInt(&ret[0][0].context);
ret[0][0].prev_context = malloc(1*sizeof(struct variable));
// Pointer Type: char * of ret[0][0].prev_context[0].name is set as NULL
ret[0][0].prev_context[0].name = 0;
// Pointer Type: char * of ret[0][0].prev_context[0].value is set as NULL
ret[0][0].prev_context[0].value = 0;
// Function pointer type: struct variable *(*)() of ret[0][0].prev_context[0].dynamic_value is not supported
ret[0][0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0][0].prev_context[0].assign_func is not supported
ret[0][0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0][0].prev_context[0].attributes);
__CrestInt(&ret[0][0].prev_context[0].context);
// Pointer Type: struct variable * of ret[0][0].prev_context[0].prev_context is set as NULL
ret[0][0].prev_context[0].prev_context = 0;
  return ret;
}
static void __sym_merge_env_array(char ** param0, ...){
}
static char * __sym_named_function_string(char * param0, COMMAND * param1, int param2, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static struct array * __sym_new_array(void){
  struct array * ret;
ret = malloc(1*sizeof(struct array));
__CrestInt(&ret[0].type);
__CrestInt(&ret[0].max_index);
__CrestInt(&ret[0].num_elements);
__CrestInt(&ret[0].max_size);
ret[0].head = malloc(1*sizeof(struct array_element));
__CrestInt(&ret[0].head[0].ind);
ret[0].head[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].head[0].value[0]);
__CrestChar(&ret[0].head[0].value[1]);
__CrestChar(&ret[0].head[0].value[2]);
ret[0].head[0].next = malloc(1*sizeof(struct array_element));
__CrestInt(&ret[0].head[0].next[0].ind);
// Pointer Type: char * of ret[0].head[0].next[0].value is set as NULL
ret[0].head[0].next[0].value = 0;
// Pointer Type: struct array_element * of ret[0].head[0].next[0].next is set as NULL
ret[0].head[0].next[0].next = 0;
// Pointer Type: struct array_element * of ret[0].head[0].next[0].prev is set as NULL
ret[0].head[0].next[0].prev = 0;
ret[0].head[0].prev = malloc(1*sizeof(struct array_element));
__CrestInt(&ret[0].head[0].prev[0].ind);
// Pointer Type: char * of ret[0].head[0].prev[0].value is set as NULL
ret[0].head[0].prev[0].value = 0;
// Pointer Type: struct array_element * of ret[0].head[0].prev[0].next is set as NULL
ret[0].head[0].prev[0].next = 0;
// Pointer Type: struct array_element * of ret[0].head[0].prev[0].prev is set as NULL
ret[0].head[0].prev[0].prev = 0;
  return ret;
}
static struct variable * __sym_new_shell_variable(char * param0, ...){
  struct variable * ret;
ret = malloc(1*sizeof(struct variable));
ret[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].name[0]);
__CrestChar(&ret[0].name[1]);
__CrestChar(&ret[0].name[2]);
ret[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].value[0]);
__CrestChar(&ret[0].value[1]);
__CrestChar(&ret[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].dynamic_value is not supported
ret[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].assign_func is not supported
ret[0].assign_func = 0;
__CrestInt(&ret[0].attributes);
__CrestInt(&ret[0].context);
ret[0].prev_context = malloc(1*sizeof(struct variable));
ret[0].prev_context[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].name[0]);
__CrestChar(&ret[0].prev_context[0].name[1]);
__CrestChar(&ret[0].prev_context[0].name[2]);
ret[0].prev_context[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].value[0]);
__CrestChar(&ret[0].prev_context[0].value[1]);
__CrestChar(&ret[0].prev_context[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].context);
ret[0].prev_context[0].prev_context = malloc(1*sizeof(struct variable));
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].name is set as NULL
ret[0].prev_context[0].prev_context[0].name = 0;
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].value is set as NULL
ret[0].prev_context[0].prev_context[0].value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].prev_context[0].context);
// Pointer Type: struct variable * of ret[0].prev_context[0].prev_context[0].prev_context is set as NULL
ret[0].prev_context[0].prev_context[0].prev_context = 0;
  return ret;
}
static int __sym_parse_and_execute(void){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym_print_array_assignment(SHELL_VAR * param0, int param1, ...){
}
static void __sym_print_assignment(SHELL_VAR * param0, ...){
}
static void __sym_print_var_function(SHELL_VAR * param0, ...){
}
static void __sym_print_var_value(SHELL_VAR * param0, int param1, ...){
}
static int __sym_printf(const char * param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym_qsort(void * param0, size_t param1, size_t param2, void * param3, ...){
}
static char * __sym_quoted_array_assignment_string(ARRAY * param0, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static struct bucket_contents * __sym_remove_hash_item(void){
  struct bucket_contents * ret;
ret = malloc(1*sizeof(struct bucket_contents));
ret[0].next = malloc(1*sizeof(struct bucket_contents));
ret[0].next[0].next = malloc(1*sizeof(struct bucket_contents));
// Pointer Type: struct bucket_contents * of ret[0].next[0].next[0].next is set as NULL
ret[0].next[0].next[0].next = 0;
// Pointer Type: char * of ret[0].next[0].next[0].key is set as NULL
ret[0].next[0].next[0].key = 0;
// Pointer Type: char * of ret[0].next[0].next[0].data is set as NULL
ret[0].next[0].next[0].data = 0;
__CrestInt(&ret[0].next[0].next[0].times_found);
ret[0].next[0].key = malloc(3*sizeof(char));
__CrestChar(&ret[0].next[0].key[0]);
__CrestChar(&ret[0].next[0].key[1]);
__CrestChar(&ret[0].next[0].key[2]);
ret[0].next[0].data = malloc(3*sizeof(char));
__CrestChar(&ret[0].next[0].data[0]);
__CrestChar(&ret[0].next[0].data[1]);
__CrestChar(&ret[0].next[0].data[2]);
__CrestInt(&ret[0].next[0].times_found);
ret[0].key = malloc(3*sizeof(char));
__CrestChar(&ret[0].key[0]);
__CrestChar(&ret[0].key[1]);
__CrestChar(&ret[0].key[2]);
ret[0].data = malloc(3*sizeof(char));
__CrestChar(&ret[0].data[0]);
__CrestChar(&ret[0].data[1]);
__CrestChar(&ret[0].data[2]);
__CrestInt(&ret[0].times_found);
  return ret;
}
static void __sym_report_error(const char * param0, ...){
}
static int __sym_same_file(void){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym_sbrand(void){
}
static void __sym_set_dirstack_element(void){
}
static struct variable * __sym_set_if_not(char * param0, char * param1, ...){
  struct variable * ret;
ret = malloc(1*sizeof(struct variable));
ret[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].name[0]);
__CrestChar(&ret[0].name[1]);
__CrestChar(&ret[0].name[2]);
ret[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].value[0]);
__CrestChar(&ret[0].value[1]);
__CrestChar(&ret[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].dynamic_value is not supported
ret[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].assign_func is not supported
ret[0].assign_func = 0;
__CrestInt(&ret[0].attributes);
__CrestInt(&ret[0].context);
ret[0].prev_context = malloc(1*sizeof(struct variable));
ret[0].prev_context[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].name[0]);
__CrestChar(&ret[0].prev_context[0].name[1]);
__CrestChar(&ret[0].prev_context[0].name[2]);
ret[0].prev_context[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].value[0]);
__CrestChar(&ret[0].prev_context[0].value[1]);
__CrestChar(&ret[0].prev_context[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].context);
ret[0].prev_context[0].prev_context = malloc(1*sizeof(struct variable));
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].name is set as NULL
ret[0].prev_context[0].prev_context[0].name = 0;
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].value is set as NULL
ret[0].prev_context[0].prev_context[0].value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].prev_context[0].context);
// Pointer Type: struct variable * of ret[0].prev_context[0].prev_context[0].prev_context is set as NULL
ret[0].prev_context[0].prev_context[0].prev_context = 0;
  return ret;
}
static void __sym_set_working_directory(void){
}
static char * __sym_shell_version_string(void){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static char * __sym_single_quote(void){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static int __sym_skipsubscript(char * param0, int param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym_sort_variables(SHELL_VAR ** param0, ...){
}
static int __sym_sprintf(char * param0, const char * param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static char * __sym_strcpy(char * param0, const char * param1, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static char * __sym_string_list(WORD_LIST * param0, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static long __sym_string_to_long(char * param0, ...){
  long ret;
__CrestLong(&ret);
  return ret;
}
static unsigned long __sym_strlen(const char * param0, ...){
  unsigned long ret;
__CrestULong(&ret);
  return ret;
}
static int __sym_strncmp(const char * param0, const char * param1, size_t param2, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static double __sym_strtod(const char * param0, char ** param1, ...){
  double ret;
// Floting Type: double of ret is not supported
ret = 0;
  return ret;
}
static long __sym_strtol(const char * param0, char ** param1, int param2, ...){
  long ret;
__CrestLong(&ret);
  return ret;
}
static long long __sym_strtoll(const char * param0, char ** param1, int param2, ...){
  long long ret;
__CrestLongLong(&ret);
  return ret;
}
static void __sym_stupidly_hack_special_variables(char * param0, ...){
}
static void __sym_sv_histignore(void){
}
static void __sym_sv_history_control(void){
}
static void __sym_sv_histsize(void){
}
static void __sym_sv_ignoreeof(void){
}
static void __sym_sv_opterr(void){
}
static void __sym_sv_optind(void){
}
static void __sym_sv_strict_posix(void){
}
static int __sym_time(void){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym_uidset(void){
}
static struct variable * __sym_var_lookup(char * param0, HASH_TABLE * param1, ...){
  struct variable * ret;
ret = malloc(1*sizeof(struct variable));
ret[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].name[0]);
__CrestChar(&ret[0].name[1]);
__CrestChar(&ret[0].name[2]);
ret[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].value[0]);
__CrestChar(&ret[0].value[1]);
__CrestChar(&ret[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].dynamic_value is not supported
ret[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].assign_func is not supported
ret[0].assign_func = 0;
__CrestInt(&ret[0].attributes);
__CrestInt(&ret[0].context);
ret[0].prev_context = malloc(1*sizeof(struct variable));
ret[0].prev_context[0].name = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].name[0]);
__CrestChar(&ret[0].prev_context[0].name[1]);
__CrestChar(&ret[0].prev_context[0].name[2]);
ret[0].prev_context[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].prev_context[0].value[0]);
__CrestChar(&ret[0].prev_context[0].value[1]);
__CrestChar(&ret[0].prev_context[0].value[2]);
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].context);
ret[0].prev_context[0].prev_context = malloc(1*sizeof(struct variable));
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].name is set as NULL
ret[0].prev_context[0].prev_context[0].name = 0;
// Pointer Type: char * of ret[0].prev_context[0].prev_context[0].value is set as NULL
ret[0].prev_context[0].prev_context[0].value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].dynamic_value is not supported
ret[0].prev_context[0].prev_context[0].dynamic_value = 0;
// Function pointer type: struct variable *(*)() of ret[0].prev_context[0].prev_context[0].assign_func is not supported
ret[0].prev_context[0].prev_context[0].assign_func = 0;
__CrestInt(&ret[0].prev_context[0].prev_context[0].attributes);
__CrestInt(&ret[0].prev_context[0].prev_context[0].context);
// Pointer Type: struct variable * of ret[0].prev_context[0].prev_context[0].prev_context is set as NULL
ret[0].prev_context[0].prev_context[0].prev_context = 0;
  return ret;
}
static int __sym_vfprintf(FILE * param0, const char * param1, __gnuc_va_list param2, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static struct array * __sym_word_list_to_array(WORD_LIST * param0, ...){
  struct array * ret;
ret = malloc(1*sizeof(struct array));
__CrestInt(&ret[0].type);
__CrestInt(&ret[0].max_index);
__CrestInt(&ret[0].num_elements);
__CrestInt(&ret[0].max_size);
ret[0].head = malloc(1*sizeof(struct array_element));
__CrestInt(&ret[0].head[0].ind);
ret[0].head[0].value = malloc(3*sizeof(char));
__CrestChar(&ret[0].head[0].value[0]);
__CrestChar(&ret[0].head[0].value[1]);
__CrestChar(&ret[0].head[0].value[2]);
ret[0].head[0].next = malloc(1*sizeof(struct array_element));
__CrestInt(&ret[0].head[0].next[0].ind);
// Pointer Type: char * of ret[0].head[0].next[0].value is set as NULL
ret[0].head[0].next[0].value = 0;
// Pointer Type: struct array_element * of ret[0].head[0].next[0].next is set as NULL
ret[0].head[0].next[0].next = 0;
// Pointer Type: struct array_element * of ret[0].head[0].next[0].prev is set as NULL
ret[0].head[0].next[0].prev = 0;
ret[0].head[0].prev = malloc(1*sizeof(struct array_element));
__CrestInt(&ret[0].head[0].prev[0].ind);
// Pointer Type: char * of ret[0].head[0].prev[0].value is set as NULL
ret[0].head[0].prev[0].value = 0;
// Pointer Type: struct array_element * of ret[0].head[0].prev[0].next is set as NULL
ret[0].head[0].prev[0].next = 0;
// Pointer Type: struct array_element * of ret[0].head[0].prev[0].prev is set as NULL
ret[0].head[0].prev[0].prev = 0;
  return ret;
}
static char * __sym_xmalloc(size_t param0, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static char * __sym_xrealloc(void * param0, size_t param1, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
#endif
int main(){
    initialize_shell_variables_driver();
    return 0;
}
