#!/bin/bash
cp set_shellopts_crash_input input
./set_shellopts_driver
rm -f input
