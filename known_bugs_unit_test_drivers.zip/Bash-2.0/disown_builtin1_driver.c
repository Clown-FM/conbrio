#include <assert.h>














































typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;







typedef long int __quad_t;
typedef unsigned long int __u_quad_t;





typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned long int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef long int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef __quad_t *__qaddr_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;




typedef __loff_t loff_t;



typedef __ino_t ino_t;

typedef __dev_t dev_t;




typedef __gid_t gid_t;




typedef __mode_t mode_t;




typedef __nlink_t nlink_t;




typedef __uid_t uid_t;





typedef __off_t off_t;

typedef __pid_t pid_t;





typedef __id_t id_t;




typedef __ssize_t ssize_t;


#ifdef __H_


typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;





typedef __key_t key_t;





typedef __clock_t clock_t;






typedef __time_t time_t;




typedef __clockid_t clockid_t;

typedef __timer_t timer_t;




typedef long unsigned int size_t;




typedef unsigned long int ulong;
typedef unsigned short int ushort;
typedef unsigned int uint;

typedef int int8_t __attribute__ ((__mode__ (__QI__)));
typedef int int16_t __attribute__ ((__mode__ (__HI__)));
typedef int int32_t __attribute__ ((__mode__ (__SI__)));
typedef int int64_t __attribute__ ((__mode__ (__DI__)));


typedef unsigned int u_int8_t __attribute__ ((__mode__ (__QI__)));
typedef unsigned int u_int16_t __attribute__ ((__mode__ (__HI__)));
typedef unsigned int u_int32_t __attribute__ ((__mode__ (__SI__)));
typedef unsigned int u_int64_t __attribute__ ((__mode__ (__DI__)));

typedef int register_t __attribute__ ((__mode__ (__word__)));



















static __inline unsigned int
__bswap_32 (unsigned int __bsx)
{
  return __builtin_bswap32 (__bsx);
}

static __inline __uint64_t
__bswap_64 (__uint64_t __bsx)
{
  return __builtin_bswap64 (__bsx);
}















typedef int __sig_atomic_t;




typedef struct
  {
    unsigned long int __val[(1024 / (8 * sizeof (unsigned long int)))];
  } __sigset_t;




typedef __sigset_t sigset_t;







struct timespec
  {
    __time_t tv_sec;
    __syscall_slong_t tv_nsec;
  };




struct timeval
  {
    __time_t tv_sec;
    __suseconds_t tv_usec;
  };



typedef __suseconds_t suseconds_t;





typedef long int __fd_mask;

typedef struct
  {






    __fd_mask __fds_bits[1024 / (8 * (int) sizeof (__fd_mask))];


  } fd_set;






typedef __fd_mask fd_mask;



/*extern*/ int select (int __nfds, fd_set *__restrict __readfds,
     fd_set *__restrict __writefds,
     fd_set *__restrict __exceptfds,
     struct timeval *__restrict __timeout);

/*extern*/ int pselect (int __nfds, fd_set *__restrict __readfds,
      fd_set *__restrict __writefds,
      fd_set *__restrict __exceptfds,
      const struct timespec *__restrict __timeout,
      const __sigset_t *__restrict __sigmask);









__extension__
/*extern*/ unsigned int gnu_dev_major (unsigned long long int __dev)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
__extension__
/*extern*/ unsigned int gnu_dev_minor (unsigned long long int __dev)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
__extension__
/*extern*/ unsigned long long int gnu_dev_makedev (unsigned int __major,
            unsigned int __minor)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


__extension__ /*extern*/ __inline __attribute__ ((__gnu_inline__)) __attribute__ ((__const__)) unsigned int
__attribute__ ((__nothrow__ , __leaf__)) gnu_dev_major (unsigned long long int __dev)
{
  return ((__dev >> 8) & 0xfff) | ((unsigned int) (__dev >> 32) & ~0xfff);
}

__extension__ /*extern*/ __inline __attribute__ ((__gnu_inline__)) __attribute__ ((__const__)) unsigned int
__attribute__ ((__nothrow__ , __leaf__)) gnu_dev_minor (unsigned long long int __dev)
{
  return (__dev & 0xff) | ((unsigned int) (__dev >> 12) & ~0xff);
}

__extension__ /*extern*/ __inline __attribute__ ((__gnu_inline__)) __attribute__ ((__const__)) unsigned long long int
__attribute__ ((__nothrow__ , __leaf__)) gnu_dev_makedev (unsigned int __major, unsigned int __minor)
{
  return ((__minor & 0xff) | ((__major & 0xfff) << 8)
   | (((unsigned long long int) (__minor & ~0xff)) << 12)
   | (((unsigned long long int) (__major & ~0xfff)) << 32));
}








typedef __blksize_t blksize_t;






typedef __blkcnt_t blkcnt_t;



typedef __fsblkcnt_t fsblkcnt_t;



typedef __fsfilcnt_t fsfilcnt_t;






typedef unsigned long int pthread_t;


union pthread_attr_t
{
  char __size[56];
  long int __align;
};

typedef union pthread_attr_t pthread_attr_t;





typedef struct __pthread_internal_list
{
  struct __pthread_internal_list *__prev;
  struct __pthread_internal_list *__next;
} __pthread_list_t;

typedef union
{
  struct __pthread_mutex_s
  {
    int __lock;
    unsigned int __count;
    int __owner;

    unsigned int __nusers;



    int __kind;

    short __spins;
    short __elision;
    __pthread_list_t __list;

  } __data;
  char __size[40];
  long int __align;
} pthread_mutex_t;

typedef union
{
  char __size[4];
  int __align;
} pthread_mutexattr_t;




typedef union
{
  struct
  {
    int __lock;
    unsigned int __futex;
    __extension__ unsigned long long int __total_seq;
    __extension__ unsigned long long int __wakeup_seq;
    __extension__ unsigned long long int __woken_seq;
    void *__mutex;
    unsigned int __nwaiters;
    unsigned int __broadcast_seq;
  } __data;
  char __size[48];
  __extension__ long long int __align;
} pthread_cond_t;

typedef union
{
  char __size[4];
  int __align;
} pthread_condattr_t;



typedef unsigned int pthread_key_t;



typedef int pthread_once_t;





typedef union
{

  struct
  {
    int __lock;
    unsigned int __nr_readers;
    unsigned int __readers_wakeup;
    unsigned int __writer_wakeup;
    unsigned int __nr_readers_queued;
    unsigned int __nr_writers_queued;
    int __writer;
    int __shared;
    unsigned long int __pad1;
    unsigned long int __pad2;


    unsigned int __flags;

  } __data;

  char __size[56];
  long int __align;
} pthread_rwlock_t;

typedef union
{
  char __size[8];
  long int __align;
} pthread_rwlockattr_t;





typedef volatile int pthread_spinlock_t;




typedef union
{
  char __size[32];
  long int __align;
} pthread_barrier_t;

typedef union
{
  char __size[4];
  int __align;
} pthread_barrierattr_t;












/*extern*/ int __sigismember (const __sigset_t *, int);
/*extern*/ int __sigaddset (__sigset_t *, int);
/*extern*/ int __sigdelset (__sigset_t *, int);

/*extern*/ __inline __attribute__ ((__gnu_inline__)) int __sigismember (const __sigset_t *__set, int __sig) { unsigned long int __mask = (((unsigned long int) 1) << (((__sig) - 1) % (8 * sizeof (unsigned long int)))); unsigned long int __word = (((__sig) - 1) / (8 * sizeof (unsigned long int))); return (__set->__val[__word] & __mask) ? 1 : 0; }
/*extern*/ __inline __attribute__ ((__gnu_inline__)) int __sigaddset ( __sigset_t *__set, int __sig) { unsigned long int __mask = (((unsigned long int) 1) << (((__sig) - 1) % (8 * sizeof (unsigned long int)))); unsigned long int __word = (((__sig) - 1) / (8 * sizeof (unsigned long int))); return ((__set->__val[__word] |= __mask), 0); }
/*extern*/ __inline __attribute__ ((__gnu_inline__)) int __sigdelset ( __sigset_t *__set, int __sig) { unsigned long int __mask = (((unsigned long int) 1) << (((__sig) - 1) % (8 * sizeof (unsigned long int)))); unsigned long int __word = (((__sig) - 1) / (8 * sizeof (unsigned long int))); return ((__set->__val[__word] &= ~__mask), 0); }








typedef __sig_atomic_t sig_atomic_t;






















typedef union sigval
  {
    int sival_int;
    void *sival_ptr;
  } sigval_t;

typedef __clock_t __sigchld_clock_t;



typedef struct
  {
    int si_signo;
    int si_errno;

    int si_code;

    union
      {
 int _pad[((128 / sizeof (int)) - 4)];


 struct
   {
     __pid_t si_pid;
     __uid_t si_uid;
   } _kill;


 struct
   {
     int si_tid;
     int si_overrun;
     sigval_t si_sigval;
   } _timer;


 struct
   {
     __pid_t si_pid;
     __uid_t si_uid;
     sigval_t si_sigval;
   } _rt;


 struct
   {
     __pid_t si_pid;
     __uid_t si_uid;
     int si_status;
     __sigchld_clock_t si_utime;
     __sigchld_clock_t si_stime;
   } _sigchld;


 struct
   {
     void *si_addr;
     short int si_addr_lsb;
   } _sigfault;


 struct
   {
     long int si_band;
     int si_fd;
   } _sigpoll;


 struct
   {
     void *_call_addr;
     int _syscall;
     unsigned int _arch;
   } _sigsys;
      } _sifields;
  } siginfo_t ;

enum
{
  SI_ASYNCNL = -60,

  SI_TKILL = -6,

  SI_SIGIO,

  SI_ASYNCIO,

  SI_MESGQ,

  SI_TIMER,

  SI_QUEUE,

  SI_USER,

  SI_KERNEL = 0x80

};



enum
{
  ILL_ILLOPC = 1,

  ILL_ILLOPN,

  ILL_ILLADR,

  ILL_ILLTRP,

  ILL_PRVOPC,

  ILL_PRVREG,

  ILL_COPROC,

  ILL_BADSTK

};


enum
{
  FPE_INTDIV = 1,

  FPE_INTOVF,

  FPE_FLTDIV,

  FPE_FLTOVF,

  FPE_FLTUND,

  FPE_FLTRES,

  FPE_FLTINV,

  FPE_FLTSUB

};


enum
{
  SEGV_MAPERR = 1,

  SEGV_ACCERR

};


enum
{
  BUS_ADRALN = 1,

  BUS_ADRERR,

  BUS_OBJERR,

  BUS_MCEERR_AR,

  BUS_MCEERR_AO

};


enum
{
  TRAP_BRKPT = 1,

  TRAP_TRACE

};


enum
{
  CLD_EXITED = 1,

  CLD_KILLED,

  CLD_DUMPED,

  CLD_TRAPPED,

  CLD_STOPPED,

  CLD_CONTINUED

};


enum
{
  POLL_IN = 1,

  POLL_OUT,

  POLL_MSG,

  POLL_ERR,

  POLL_PRI,

  POLL_HUP

};

typedef struct sigevent
  {
    sigval_t sigev_value;
    int sigev_signo;
    int sigev_notify;

    union
      {
 int _pad[((64 / sizeof (int)) - 4)];



 __pid_t _tid;

 struct
   {
     void (*_function) (sigval_t);
     pthread_attr_t *_attribute;
   } _sigev_thread;
      } _sigev_un;
  } sigevent_t;






enum
{
  SIGEV_SIGNAL = 0,

  SIGEV_NONE,

  SIGEV_THREAD,


  SIGEV_THREAD_ID = 4

};





typedef void (*__sighandler_t) (int);




/*extern*/ __sighandler_t __sysv_signal (int __sig, __sighandler_t __handler)
     __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ __sighandler_t signal (int __sig, __sighandler_t __handler)
     __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ int kill (__pid_t __pid, int __sig) __attribute__ ((__nothrow__ , __leaf__));






/*extern*/ int killpg (__pid_t __pgrp, int __sig) __attribute__ ((__nothrow__ , __leaf__));




/*extern*/ int raise (int __sig) __attribute__ ((__nothrow__ , __leaf__));




/*extern*/ __sighandler_t ssignal (int __sig, __sighandler_t __handler)
     __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ int gsignal (int __sig) __attribute__ ((__nothrow__ , __leaf__));




/*extern*/ void psignal (int __sig, const char *__s);




/*extern*/ void psiginfo (const siginfo_t *__pinfo, const char *__s);

/*extern*/ int __sigpause (int __sig_or_mask, int __is_sig);

/*extern*/ int sigblock (int __mask) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__deprecated__));


/*extern*/ int sigsetmask (int __mask) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__deprecated__));


/*extern*/ int siggetmask (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__deprecated__));

typedef __sighandler_t sig_t;





/*extern*/ int sigemptyset (sigset_t *__set) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


/*extern*/ int sigfillset (sigset_t *__set) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


/*extern*/ int sigaddset (sigset_t *__set, int __signo) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


/*extern*/ int sigdelset (sigset_t *__set, int __signo) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


/*extern*/ int sigismember (const sigset_t *__set, int __signo)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



struct sigaction
  {


    union
      {

 __sighandler_t sa_handler;

 void (*sa_sigaction) (int, siginfo_t *, void *);
      }
    __sigaction_handler;







    __sigset_t sa_mask;


    int sa_flags;


    void (*sa_restorer) ();
  };



/*extern*/ int sigprocmask (int __how, const sigset_t *__restrict __set,
   sigset_t *__restrict __oset) __attribute__ ((__nothrow__ , __leaf__));






/*extern*/ int sigsuspend (const sigset_t *__set) __attribute__ ((__nonnull__ (1)));


/*extern*/ int sigaction (int __sig, const struct sigaction *__restrict __act,
        struct sigaction *__restrict __oact) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ int sigpending (sigset_t *__set) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






/*extern*/ int sigwait (const sigset_t *__restrict __set, int *__restrict __sig)
     __attribute__ ((__nonnull__ (1, 2)));






/*extern*/ int sigwaitinfo (const sigset_t *__restrict __set,
   siginfo_t *__restrict __info) __attribute__ ((__nonnull__ (1)));






/*extern*/ int sigtimedwait (const sigset_t *__restrict __set,
    siginfo_t *__restrict __info,
    const struct timespec *__restrict __timeout)
     __attribute__ ((__nonnull__ (1)));



/*extern*/ int sigqueue (__pid_t __pid, int __sig, const union sigval __val)
     __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ const char *const _sys_siglist[65];
/*extern*/ const char *const sys_siglist[65];


struct sigvec
  {
    __sighandler_t sv_handler;
    int sv_mask;

    int sv_flags;

  };

/*extern*/ int sigvec (int __sig, const struct sigvec *__vec,
     struct sigvec *__ovec) __attribute__ ((__nothrow__ , __leaf__));





struct _fpx_sw_bytes
{
  __uint32_t magic1;
  __uint32_t extended_size;
  __uint64_t xstate_bv;
  __uint32_t xstate_size;
  __uint32_t padding[7];
};

struct _fpreg
{
  unsigned short significand[4];
  unsigned short exponent;
};

struct _fpxreg
{
  unsigned short significand[4];
  unsigned short exponent;
  unsigned short padding[3];
};

struct _xmmreg
{
  __uint32_t element[4];
};

struct _fpstate
{

  __uint16_t cwd;
  __uint16_t swd;
  __uint16_t ftw;
  __uint16_t fop;
  __uint64_t rip;
  __uint64_t rdp;
  __uint32_t mxcsr;
  __uint32_t mxcr_mask;
  struct _fpxreg _st[8];
  struct _xmmreg _xmm[16];
  __uint32_t padding[24];
};

struct sigcontext
{
  __uint64_t r8;
  __uint64_t r9;
  __uint64_t r10;
  __uint64_t r11;
  __uint64_t r12;
  __uint64_t r13;
  __uint64_t r14;
  __uint64_t r15;
  __uint64_t rdi;
  __uint64_t rsi;
  __uint64_t rbp;
  __uint64_t rbx;
  __uint64_t rdx;
  __uint64_t rax;
  __uint64_t rcx;
  __uint64_t rsp;
  __uint64_t rip;
  __uint64_t eflags;
  unsigned short cs;
  unsigned short gs;
  unsigned short fs;
  unsigned short __pad0;
  __uint64_t err;
  __uint64_t trapno;
  __uint64_t oldmask;
  __uint64_t cr2;
  __extension__ union
    {
      struct _fpstate * fpstate;
      __uint64_t __fpstate_word;
    };
  __uint64_t __reserved1 [8];
};



struct _xsave_hdr
{
  __uint64_t xstate_bv;
  __uint64_t reserved1[2];
  __uint64_t reserved2[5];
};

struct _ymmh_state
{
  __uint32_t ymmh_space[64];
};

struct _xstate
{
  struct _fpstate fpstate;
  struct _xsave_hdr xstate_hdr;
  struct _ymmh_state ymmh;
};



/*extern*/ int sigreturn (struct sigcontext *__scp) __attribute__ ((__nothrow__ , __leaf__));


#endif
//void disown_builtin_driver(){
//  vio("list->word != 0", __FILE__, 5064, "disown_builtin");
//}

#ifdef __H_




/*extern*/ int siginterrupt (int __sig, int __interrupt) __attribute__ ((__nothrow__ , __leaf__));



struct sigstack
  {
    void *ss_sp;
    int ss_onstack;
  };



enum
{
  SS_ONSTACK = 1,

  SS_DISABLE

};

typedef struct sigaltstack
  {
    void *ss_sp;
    int ss_flags;
    size_t ss_size;
  } stack_t;








__extension__ typedef long long int greg_t;





typedef greg_t gregset_t[23];

struct _libc_fpxreg
{
  unsigned short int significand[4];
  unsigned short int exponent;
  unsigned short int padding[3];
};

struct _libc_xmmreg
{
  __uint32_t element[4];
};

struct _libc_fpstate
{

  __uint16_t cwd;
  __uint16_t swd;
  __uint16_t ftw;
  __uint16_t fop;
  __uint64_t rip;
  __uint64_t rdp;
  __uint32_t mxcsr;
  __uint32_t mxcr_mask;
  struct _libc_fpxreg _st[8];
  struct _libc_xmmreg _xmm[16];
  __uint32_t padding[24];
};


typedef struct _libc_fpstate *fpregset_t;


typedef struct
  {
    gregset_t gregs;

    fpregset_t fpregs;
    __extension__ unsigned long long __reserved1 [8];
} mcontext_t;


typedef struct ucontext
  {
    unsigned long int uc_flags;
    struct ucontext *uc_link;
    stack_t uc_stack;
    mcontext_t uc_mcontext;
    __sigset_t uc_sigmask;
    struct _libc_fpstate __fpregs_mem;
  } ucontext_t;






/*extern*/ int sigstack (struct sigstack *__ss, struct sigstack *__oss)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__deprecated__));



/*extern*/ int sigaltstack (const struct sigaltstack *__restrict __ss,
   struct sigaltstack *__restrict __oss) __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ int pthread_sigmask (int __how,
       const __sigset_t *__restrict __newmask,
       __sigset_t *__restrict __oldmask)__attribute__ ((__nothrow__ , __leaf__));


/*extern*/ int pthread_kill (pthread_t __threadid, int __signo) __attribute__ ((__nothrow__ , __leaf__));







/*extern*/ int __libc_current_sigrtmin (void) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ int __libc_current_sigrtmax (void) __attribute__ ((__nothrow__ , __leaf__));
























typedef __useconds_t useconds_t;

typedef __intptr_t intptr_t;






typedef __socklen_t socklen_t;

/*extern*/ int access (const char *__name, int __type) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

/*extern*/ int faccessat (int __fd, const char *__file, int __type, int __flag)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) ;

/*extern*/ __off_t lseek (int __fd, __off_t __offset, int __whence) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ int close (int __fd);






/*extern*/ ssize_t read (int __fd, void *__buf, size_t __nbytes) ;





/*extern*/ ssize_t write (int __fd, const void *__buf, size_t __n) ;

/*extern*/ ssize_t pread (int __fd, void *__buf, size_t __nbytes,
        __off_t __offset) ;






/*extern*/ ssize_t pwrite (int __fd, const void *__buf, size_t __n,
         __off_t __offset) ;

/*extern*/ int pipe (int __pipedes[2]) __attribute__ ((__nothrow__ , __leaf__)) ;

/*extern*/ unsigned int alarm (unsigned int __seconds) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ unsigned int sleep (unsigned int __seconds);







/*extern*/ __useconds_t ualarm (__useconds_t __value, __useconds_t __interval)
     __attribute__ ((__nothrow__ , __leaf__));






/*extern*/ int usleep (__useconds_t __useconds);

/*extern*/ int pause ();



/*extern*/ int chown (const char *__file, __uid_t __owner, __gid_t __group)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;



/*extern*/ int fchown (int __fd, __uid_t __owner, __gid_t __group) __attribute__ ((__nothrow__ , __leaf__)) ;




/*extern*/ int lchown (const char *__file, __uid_t __owner, __gid_t __group)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;






/*extern*/ int fchownat (int __fd, const char *__file, __uid_t __owner,
       __gid_t __group, int __flag)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) ;



/*extern*/ int chdir (const char *__path) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;



/*extern*/ int fchdir (int __fd) __attribute__ ((__nothrow__ , __leaf__)) ;

/*extern*/ char *getcwd (char *__buf, size_t __size) __attribute__ ((__nothrow__ , __leaf__)) ;

/*extern*/ char *getwd (char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__deprecated__)) ;




/*extern*/ int dup (int __fd) __attribute__ ((__nothrow__ , __leaf__)) ;


/*extern*/ int dup2 (int __fd, int __fd2) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ char **__environ;







/*extern*/ int execve (const char *__path, char *const __argv[],
     char *const __envp[]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




/*extern*/ int fexecve (int __fd, char *const __argv[], char *const __envp[])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));




/*extern*/ int execv (const char *__path, char *const __argv[])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



/*extern*/ int execle (const char *__path, const char *__arg, ...)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



/*extern*/ int execl (const char *__path, const char *__arg, ...)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



/*extern*/ int execvp (const char *__file, char *const __argv[])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




/*extern*/ int execlp (const char *__file, const char *__arg, ...)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ int nice (int __inc) __attribute__ ((__nothrow__ , __leaf__)) ;




/*extern*/ void _exit (int __status) __attribute__ ((__noreturn__));







enum
  {
    _PC_LINK_MAX,

    _PC_MAX_CANON,

    _PC_MAX_INPUT,

    _PC_NAME_MAX,

    _PC_PATH_MAX,

    _PC_PIPE_BUF,

    _PC_CHOWN_RESTRICTED,

    _PC_NO_TRUNC,

    _PC_VDISABLE,

    _PC_SYNC_IO,

    _PC_ASYNC_IO,

    _PC_PRIO_IO,

    _PC_SOCK_MAXBUF,

    _PC_FILESIZEBITS,

    _PC_REC_INCR_XFER_SIZE,

    _PC_REC_MAX_XFER_SIZE,

    _PC_REC_MIN_XFER_SIZE,

    _PC_REC_XFER_ALIGN,

    _PC_ALLOC_SIZE_MIN,

    _PC_SYMLINK_MAX,

    _PC_2_SYMLINKS

  };


enum
  {
    _SC_ARG_MAX,

    _SC_CHILD_MAX,

    _SC_CLK_TCK,

    _SC_NGROUPS_MAX,

    _SC_OPEN_MAX,

    _SC_STREAM_MAX,

    _SC_TZNAME_MAX,

    _SC_JOB_CONTROL,

    _SC_SAVED_IDS,

    _SC_REALTIME_SIGNALS,

    _SC_PRIORITY_SCHEDULING,

    _SC_TIMERS,

    _SC_ASYNCHRONOUS_IO,

    _SC_PRIORITIZED_IO,

    _SC_SYNCHRONIZED_IO,

    _SC_FSYNC,

    _SC_MAPPED_FILES,

    _SC_MEMLOCK,

    _SC_MEMLOCK_RANGE,

    _SC_MEMORY_PROTECTION,

    _SC_MESSAGE_PASSING,

    _SC_SEMAPHORES,

    _SC_SHARED_MEMORY_OBJECTS,

    _SC_AIO_LISTIO_MAX,

    _SC_AIO_MAX,

    _SC_AIO_PRIO_DELTA_MAX,

    _SC_DELAYTIMER_MAX,

    _SC_MQ_OPEN_MAX,

    _SC_MQ_PRIO_MAX,

    _SC_VERSION,

    _SC_PAGESIZE,


    _SC_RTSIG_MAX,

    _SC_SEM_NSEMS_MAX,

    _SC_SEM_VALUE_MAX,

    _SC_SIGQUEUE_MAX,

    _SC_TIMER_MAX,




    _SC_BC_BASE_MAX,

    _SC_BC_DIM_MAX,

    _SC_BC_SCALE_MAX,

    _SC_BC_STRING_MAX,

    _SC_COLL_WEIGHTS_MAX,

    _SC_EQUIV_CLASS_MAX,

    _SC_EXPR_NEST_MAX,

    _SC_LINE_MAX,

    _SC_RE_DUP_MAX,

    _SC_CHARCLASS_NAME_MAX,


    _SC_2_VERSION,

    _SC_2_C_BIND,

    _SC_2_C_DEV,

    _SC_2_FORT_DEV,

    _SC_2_FORT_RUN,

    _SC_2_SW_DEV,

    _SC_2_LOCALEDEF,


    _SC_PII,

    _SC_PII_XTI,

    _SC_PII_SOCKET,

    _SC_PII_INTERNET,

    _SC_PII_OSI,

    _SC_POLL,

    _SC_SELECT,

    _SC_UIO_MAXIOV,

    _SC_IOV_MAX = _SC_UIO_MAXIOV,

    _SC_PII_INTERNET_STREAM,

    _SC_PII_INTERNET_DGRAM,

    _SC_PII_OSI_COTS,

    _SC_PII_OSI_CLTS,

    _SC_PII_OSI_M,

    _SC_T_IOV_MAX,



    _SC_THREADS,

    _SC_THREAD_SAFE_FUNCTIONS,

    _SC_GETGR_R_SIZE_MAX,

    _SC_GETPW_R_SIZE_MAX,

    _SC_LOGIN_NAME_MAX,

    _SC_TTY_NAME_MAX,

    _SC_THREAD_DESTRUCTOR_ITERATIONS,

    _SC_THREAD_KEYS_MAX,

    _SC_THREAD_STACK_MIN,

    _SC_THREAD_THREADS_MAX,

    _SC_THREAD_ATTR_STACKADDR,

    _SC_THREAD_ATTR_STACKSIZE,

    _SC_THREAD_PRIORITY_SCHEDULING,

    _SC_THREAD_PRIO_INHERIT,

    _SC_THREAD_PRIO_PROTECT,

    _SC_THREAD_PROCESS_SHARED,


    _SC_NPROCESSORS_CONF,

    _SC_NPROCESSORS_ONLN,

    _SC_PHYS_PAGES,

    _SC_AVPHYS_PAGES,

    _SC_ATEXIT_MAX,

    _SC_PASS_MAX,


    _SC_XOPEN_VERSION,

    _SC_XOPEN_XCU_VERSION,

    _SC_XOPEN_UNIX,

    _SC_XOPEN_CRYPT,

    _SC_XOPEN_ENH_I18N,

    _SC_XOPEN_SHM,


    _SC_2_CHAR_TERM,

    _SC_2_C_VERSION,

    _SC_2_UPE,


    _SC_XOPEN_XPG2,

    _SC_XOPEN_XPG3,

    _SC_XOPEN_XPG4,


    _SC_CHAR_BIT,

    _SC_CHAR_MAX,

    _SC_CHAR_MIN,

    _SC_INT_MAX,

    _SC_INT_MIN,

    _SC_LONG_BIT,

    _SC_WORD_BIT,

    _SC_MB_LEN_MAX,

    _SC_NZERO,

    _SC_SSIZE_MAX,

    _SC_SCHAR_MAX,

    _SC_SCHAR_MIN,

    _SC_SHRT_MAX,

    _SC_SHRT_MIN,

    _SC_UCHAR_MAX,

    _SC_UINT_MAX,

    _SC_ULONG_MAX,

    _SC_USHRT_MAX,


    _SC_NL_ARGMAX,

    _SC_NL_LANGMAX,

    _SC_NL_MSGMAX,

    _SC_NL_NMAX,

    _SC_NL_SETMAX,

    _SC_NL_TEXTMAX,


    _SC_XBS5_ILP32_OFF32,

    _SC_XBS5_ILP32_OFFBIG,

    _SC_XBS5_LP64_OFF64,

    _SC_XBS5_LPBIG_OFFBIG,


    _SC_XOPEN_LEGACY,

    _SC_XOPEN_REALTIME,

    _SC_XOPEN_REALTIME_THREADS,


    _SC_ADVISORY_INFO,

    _SC_BARRIERS,

    _SC_BASE,

    _SC_C_LANG_SUPPORT,

    _SC_C_LANG_SUPPORT_R,

    _SC_CLOCK_SELECTION,

    _SC_CPUTIME,

    _SC_THREAD_CPUTIME,

    _SC_DEVICE_IO,

    _SC_DEVICE_SPECIFIC,

    _SC_DEVICE_SPECIFIC_R,

    _SC_FD_MGMT,

    _SC_FIFO,

    _SC_PIPE,

    _SC_FILE_ATTRIBUTES,

    _SC_FILE_LOCKING,

    _SC_FILE_SYSTEM,

    _SC_MONOTONIC_CLOCK,

    _SC_MULTI_PROCESS,

    _SC_SINGLE_PROCESS,

    _SC_NETWORKING,

    _SC_READER_WRITER_LOCKS,

    _SC_SPIN_LOCKS,

    _SC_REGEXP,

    _SC_REGEX_VERSION,

    _SC_SHELL,

    _SC_SIGNALS,

    _SC_SPAWN,

    _SC_SPORADIC_SERVER,

    _SC_THREAD_SPORADIC_SERVER,

    _SC_SYSTEM_DATABASE,

    _SC_SYSTEM_DATABASE_R,

    _SC_TIMEOUTS,

    _SC_TYPED_MEMORY_OBJECTS,

    _SC_USER_GROUPS,

    _SC_USER_GROUPS_R,

    _SC_2_PBS,

    _SC_2_PBS_ACCOUNTING,

    _SC_2_PBS_LOCATE,

    _SC_2_PBS_MESSAGE,

    _SC_2_PBS_TRACK,

    _SC_SYMLOOP_MAX,

    _SC_STREAMS,

    _SC_2_PBS_CHECKPOINT,


    _SC_V6_ILP32_OFF32,

    _SC_V6_ILP32_OFFBIG,

    _SC_V6_LP64_OFF64,

    _SC_V6_LPBIG_OFFBIG,


    _SC_HOST_NAME_MAX,

    _SC_TRACE,

    _SC_TRACE_EVENT_FILTER,

    _SC_TRACE_INHERIT,

    _SC_TRACE_LOG,


    _SC_LEVEL1_ICACHE_SIZE,

    _SC_LEVEL1_ICACHE_ASSOC,

    _SC_LEVEL1_ICACHE_LINESIZE,

    _SC_LEVEL1_DCACHE_SIZE,

    _SC_LEVEL1_DCACHE_ASSOC,

    _SC_LEVEL1_DCACHE_LINESIZE,

    _SC_LEVEL2_CACHE_SIZE,

    _SC_LEVEL2_CACHE_ASSOC,

    _SC_LEVEL2_CACHE_LINESIZE,

    _SC_LEVEL3_CACHE_SIZE,

    _SC_LEVEL3_CACHE_ASSOC,

    _SC_LEVEL3_CACHE_LINESIZE,

    _SC_LEVEL4_CACHE_SIZE,

    _SC_LEVEL4_CACHE_ASSOC,

    _SC_LEVEL4_CACHE_LINESIZE,



    _SC_IPV6 = _SC_LEVEL1_ICACHE_SIZE + 50,

    _SC_RAW_SOCKETS,


    _SC_V7_ILP32_OFF32,

    _SC_V7_ILP32_OFFBIG,

    _SC_V7_LP64_OFF64,

    _SC_V7_LPBIG_OFFBIG,


    _SC_SS_REPL_MAX,


    _SC_TRACE_EVENT_NAME_MAX,

    _SC_TRACE_NAME_MAX,

    _SC_TRACE_SYS_MAX,

    _SC_TRACE_USER_EVENT_MAX,


    _SC_XOPEN_STREAMS,


    _SC_THREAD_ROBUST_PRIO_INHERIT,

    _SC_THREAD_ROBUST_PRIO_PROTECT

  };


enum
  {
    _CS_PATH,


    _CS_V6_WIDTH_RESTRICTED_ENVS,



    _CS_GNU_LIBC_VERSION,

    _CS_GNU_LIBPTHREAD_VERSION,


    _CS_V5_WIDTH_RESTRICTED_ENVS,



    _CS_V7_WIDTH_RESTRICTED_ENVS,



    _CS_LFS_CFLAGS = 1000,

    _CS_LFS_LDFLAGS,

    _CS_LFS_LIBS,

    _CS_LFS_LINTFLAGS,

    _CS_LFS64_CFLAGS,

    _CS_LFS64_LDFLAGS,

    _CS_LFS64_LIBS,

    _CS_LFS64_LINTFLAGS,


    _CS_XBS5_ILP32_OFF32_CFLAGS = 1100,

    _CS_XBS5_ILP32_OFF32_LDFLAGS,

    _CS_XBS5_ILP32_OFF32_LIBS,

    _CS_XBS5_ILP32_OFF32_LINTFLAGS,

    _CS_XBS5_ILP32_OFFBIG_CFLAGS,

    _CS_XBS5_ILP32_OFFBIG_LDFLAGS,

    _CS_XBS5_ILP32_OFFBIG_LIBS,

    _CS_XBS5_ILP32_OFFBIG_LINTFLAGS,

    _CS_XBS5_LP64_OFF64_CFLAGS,

    _CS_XBS5_LP64_OFF64_LDFLAGS,

    _CS_XBS5_LP64_OFF64_LIBS,

    _CS_XBS5_LP64_OFF64_LINTFLAGS,

    _CS_XBS5_LPBIG_OFFBIG_CFLAGS,

    _CS_XBS5_LPBIG_OFFBIG_LDFLAGS,

    _CS_XBS5_LPBIG_OFFBIG_LIBS,

    _CS_XBS5_LPBIG_OFFBIG_LINTFLAGS,


    _CS_POSIX_V6_ILP32_OFF32_CFLAGS,

    _CS_POSIX_V6_ILP32_OFF32_LDFLAGS,

    _CS_POSIX_V6_ILP32_OFF32_LIBS,

    _CS_POSIX_V6_ILP32_OFF32_LINTFLAGS,

    _CS_POSIX_V6_ILP32_OFFBIG_CFLAGS,

    _CS_POSIX_V6_ILP32_OFFBIG_LDFLAGS,

    _CS_POSIX_V6_ILP32_OFFBIG_LIBS,

    _CS_POSIX_V6_ILP32_OFFBIG_LINTFLAGS,

    _CS_POSIX_V6_LP64_OFF64_CFLAGS,

    _CS_POSIX_V6_LP64_OFF64_LDFLAGS,

    _CS_POSIX_V6_LP64_OFF64_LIBS,

    _CS_POSIX_V6_LP64_OFF64_LINTFLAGS,

    _CS_POSIX_V6_LPBIG_OFFBIG_CFLAGS,

    _CS_POSIX_V6_LPBIG_OFFBIG_LDFLAGS,

    _CS_POSIX_V6_LPBIG_OFFBIG_LIBS,

    _CS_POSIX_V6_LPBIG_OFFBIG_LINTFLAGS,


    _CS_POSIX_V7_ILP32_OFF32_CFLAGS,

    _CS_POSIX_V7_ILP32_OFF32_LDFLAGS,

    _CS_POSIX_V7_ILP32_OFF32_LIBS,

    _CS_POSIX_V7_ILP32_OFF32_LINTFLAGS,

    _CS_POSIX_V7_ILP32_OFFBIG_CFLAGS,

    _CS_POSIX_V7_ILP32_OFFBIG_LDFLAGS,

    _CS_POSIX_V7_ILP32_OFFBIG_LIBS,

    _CS_POSIX_V7_ILP32_OFFBIG_LINTFLAGS,

    _CS_POSIX_V7_LP64_OFF64_CFLAGS,

    _CS_POSIX_V7_LP64_OFF64_LDFLAGS,

    _CS_POSIX_V7_LP64_OFF64_LIBS,

    _CS_POSIX_V7_LP64_OFF64_LINTFLAGS,

    _CS_POSIX_V7_LPBIG_OFFBIG_CFLAGS,

    _CS_POSIX_V7_LPBIG_OFFBIG_LDFLAGS,

    _CS_POSIX_V7_LPBIG_OFFBIG_LIBS,

    _CS_POSIX_V7_LPBIG_OFFBIG_LINTFLAGS,


    _CS_V6_ENV,

    _CS_V7_ENV

  };



/*extern*/ long int pathconf (const char *__path, int __name)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


/*extern*/ long int fpathconf (int __fd, int __name) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ long int sysconf (int __name) __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ size_t confstr (int __name, char *__buf, size_t __len) __attribute__ ((__nothrow__ , __leaf__));




/*extern*/ __pid_t getpid (void) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ __pid_t getppid (void) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ __pid_t getpgrp (void) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ __pid_t __getpgid (__pid_t __pid) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ __pid_t getpgid (__pid_t __pid) __attribute__ ((__nothrow__ , __leaf__));






/*extern*/ int setpgid (__pid_t __pid, __pid_t __pgid) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ int setpgrp (void) __attribute__ ((__nothrow__ , __leaf__));






/*extern*/ __pid_t setsid (void) __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ __pid_t getsid (__pid_t __pid) __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ __uid_t getuid (void) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ __uid_t geteuid (void) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ __gid_t getgid (void) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ __gid_t getegid (void) __attribute__ ((__nothrow__ , __leaf__));




/*extern*/ int getgroups (int __size, __gid_t __list[]) __attribute__ ((__nothrow__ , __leaf__)) ;

/*extern*/ int setuid (__uid_t __uid) __attribute__ ((__nothrow__ , __leaf__)) ;




/*extern*/ int setreuid (__uid_t __ruid, __uid_t __euid) __attribute__ ((__nothrow__ , __leaf__)) ;




/*extern*/ int seteuid (__uid_t __uid) __attribute__ ((__nothrow__ , __leaf__)) ;






/*extern*/ int setgid (__gid_t __gid) __attribute__ ((__nothrow__ , __leaf__)) ;




/*extern*/ int setregid (__gid_t __rgid, __gid_t __egid) __attribute__ ((__nothrow__ , __leaf__)) ;




/*extern*/ int setegid (__gid_t __gid) __attribute__ ((__nothrow__ , __leaf__)) ;

/*extern*/ __pid_t fork (void) __attribute__ ((__nothrow__));







/*extern*/ __pid_t vfork (void) __attribute__ ((__nothrow__ , __leaf__));





/*extern*/ char *ttyname (int __fd) __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ int ttyname_r (int __fd, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) ;



/*extern*/ int isatty (int __fd) __attribute__ ((__nothrow__ , __leaf__));





/*extern*/ int ttyslot (void) __attribute__ ((__nothrow__ , __leaf__));




/*extern*/ int link (const char *__from, const char *__to)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) ;




/*extern*/ int linkat (int __fromfd, const char *__from, int __tofd,
     const char *__to, int __flags)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4))) ;




/*extern*/ int symlink (const char *__from, const char *__to)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) ;




/*extern*/ ssize_t readlink (const char *__restrict __path,
    char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) ;




/*extern*/ int symlinkat (const char *__from, int __tofd,
        const char *__to) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3))) ;


/*extern*/ ssize_t readlinkat (int __fd, const char *__restrict __path,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3))) ;



/*extern*/ int unlink (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



/*extern*/ int unlinkat (int __fd, const char *__name, int __flag)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



/*extern*/ int rmdir (const char *__path) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



/*extern*/ __pid_t tcgetpgrp (int __fd) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ int tcsetpgrp (int __fd, __pid_t __pgrp_id) __attribute__ ((__nothrow__ , __leaf__));






/*extern*/ char *getlogin ();







/*extern*/ int getlogin_r (char *__name, size_t __name_len) __attribute__ ((__nonnull__ (1)));




/*extern*/ int setlogin (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



/*extern*/ char *sh_optarg;

/*extern*/ int sh_optind;




/*extern*/ int sh_opterr;



/*extern*/ int sh_optopt;


/*extern*/ int sh_badopt;

/*extern*/ int sh_getopt ();
/*extern*/ void sh_getopt_restore_state ();








/*extern*/ int gethostname (char *__name, size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






/*extern*/ int sethostname (const char *__name, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;



/*extern*/ int sethostid (long int __id) __attribute__ ((__nothrow__ , __leaf__)) ;





/*extern*/ int getdomainname (char *__name, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
/*extern*/ int setdomainname (const char *__name, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;





/*extern*/ int vhangup (void) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ int revoke (const char *__file) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;







/*extern*/ int profil (unsigned short int *__sample_buffer, size_t __size,
     size_t __offset, unsigned int __scale)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





/*extern*/ int acct (const char *__name) __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ char *getusershell (void) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ void endusershell (void) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ void setusershell (void) __attribute__ ((__nothrow__ , __leaf__));





/*extern*/ int daemon (int __nochdir, int __noclose) __attribute__ ((__nothrow__ , __leaf__)) ;






/*extern*/ int chroot (const char *__path) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;



/*extern*/ char *getpass (const char *__prompt) __attribute__ ((__nonnull__ (1)));







/*extern*/ int fsync (int __fd);

/*extern*/ long int gethostid ();


/*extern*/ void sync (void) __attribute__ ((__nothrow__ , __leaf__));





/*extern*/ int getpagesize (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));




/*extern*/ int getdtablesize (void) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ int truncate (const char *__file, __off_t __length)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;

/*extern*/ int ftruncate (int __fd, __off_t __length) __attribute__ ((__nothrow__ , __leaf__)) ;

/*extern*/ int brk (void *__addr) __attribute__ ((__nothrow__ , __leaf__)) ;





/*extern*/ void *sbrk (intptr_t __delta) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ long int syscall (long int __sysno, ...) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ int lockf (int __fd, int __cmd, __off_t __len) ;

/*extern*/ int fdatasync (int __fildes);



















/*extern*/ void *memcpy (void *__restrict __dest, const void *__restrict __src,
       size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


/*extern*/ void *memmove (void *__dest, const void *__src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));






/*extern*/ void *memccpy (void *__restrict __dest, const void *__restrict __src,
        int __c, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));





/*extern*/ void *memset (void *__s, int __c, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


/*extern*/ int memcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ void *memchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));





/*extern*/ char *strcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ char *strncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


/*extern*/ char *strcat (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ char *strncat (char *__restrict __dest, const char *__restrict __src,
        size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


/*extern*/ int strcmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ int strncmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


/*extern*/ int strcoll (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ size_t strxfrm (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));








typedef struct __locale_struct
{

  struct __locale_data *__locales[13];


  const unsigned short int *__ctype_b;
  const int *__ctype_tolower;
  const int *__ctype_toupper;


  const char *__names[13];
} *__locale_t;


typedef __locale_t locale_t;



/*extern*/ int strcoll_l (const char *__s1, const char *__s2, __locale_t __l)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));

/*extern*/ size_t strxfrm_l (char *__dest, const char *__src, size_t __n,
    __locale_t __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)));





/*extern*/ char *strdup (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));






/*extern*/ char *strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));



/*extern*/ char *strchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));

/*extern*/ char *strrchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));






/*extern*/ size_t strcspn (const char *__s, const char *__reject)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


/*extern*/ size_t strspn (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ char *strpbrk (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ char *strstr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));




/*extern*/ char *strtok (char *__restrict __s, const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));




/*extern*/ char *__strtok_r (char *__restrict __s,
    const char *__restrict __delim,
    char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));

/*extern*/ char *strtok_r (char *__restrict __s, const char *__restrict __delim,
         char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));



/*extern*/ size_t strlen (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));





/*extern*/ size_t strnlen (const char *__string, size_t __maxlen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));





/*extern*/ char *strerror (int __errnum) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ int strerror_r (int __errnum, char *__buf, size_t __buflen) __asm__ ("" "__xpg_strerror_r") __attribute__ ((__nothrow__ , __leaf__))

                        __attribute__ ((__nonnull__ (2)));

/*extern*/ char *strerror_l (int __errnum, __locale_t __l) __attribute__ ((__nothrow__ , __leaf__));





/*extern*/ void __bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



/*extern*/ void bcopy (const void *__src, void *__dest, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


/*extern*/ void bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


/*extern*/ int bcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ char *index (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));

/*extern*/ char *rindex (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




/*extern*/ int ffs (int __i) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));

/*extern*/ int strcasecmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


/*extern*/ int strncasecmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ char *strsep (char **__restrict __stringp,
       const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




/*extern*/ char *strsignal (int __sig) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ char *__stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
/*extern*/ char *stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



/*extern*/ char *__stpncpy (char *__restrict __dest,
   const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
/*extern*/ char *stpncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));







/*extern*/ void *__rawmemchr (const void *__s, int __c);

/*extern*/ __inline __attribute__ ((__gnu_inline__)) size_t __strcspn_c1 (const char *__s, int __reject);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) size_t
__strcspn_c1 (const char *__s, int __reject)
{
  size_t __result = 0;
  while (__s[__result] != '\0' && __s[__result] != __reject)
    ++__result;
  return __result;
}

/*extern*/ __inline __attribute__ ((__gnu_inline__)) size_t __strcspn_c2 (const char *__s, int __reject1,
         int __reject2);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) size_t
__strcspn_c2 (const char *__s, int __reject1, int __reject2)
{
  size_t __result = 0;
  while (__s[__result] != '\0' && __s[__result] != __reject1
  && __s[__result] != __reject2)
    ++__result;
  return __result;
}

/*extern*/ __inline __attribute__ ((__gnu_inline__)) size_t __strcspn_c3 (const char *__s, int __reject1,
         int __reject2, int __reject3);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) size_t
__strcspn_c3 (const char *__s, int __reject1, int __reject2,
       int __reject3)
{
  size_t __result = 0;
  while (__s[__result] != '\0' && __s[__result] != __reject1
  && __s[__result] != __reject2 && __s[__result] != __reject3)
    ++__result;
  return __result;
}

/*extern*/ __inline __attribute__ ((__gnu_inline__)) size_t __strspn_c1 (const char *__s, int __accept);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) size_t
__strspn_c1 (const char *__s, int __accept)
{
  size_t __result = 0;

  while (__s[__result] == __accept)
    ++__result;
  return __result;
}

/*extern*/ __inline __attribute__ ((__gnu_inline__)) size_t __strspn_c2 (const char *__s, int __accept1,
        int __accept2);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) size_t
__strspn_c2 (const char *__s, int __accept1, int __accept2)
{
  size_t __result = 0;

  while (__s[__result] == __accept1 || __s[__result] == __accept2)
    ++__result;
  return __result;
}

/*extern*/ __inline __attribute__ ((__gnu_inline__)) size_t __strspn_c3 (const char *__s, int __accept1,
        int __accept2, int __accept3);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) size_t
__strspn_c3 (const char *__s, int __accept1, int __accept2, int __accept3)
{
  size_t __result = 0;

  while (__s[__result] == __accept1 || __s[__result] == __accept2
  || __s[__result] == __accept3)
    ++__result;
  return __result;
}

/*extern*/ __inline __attribute__ ((__gnu_inline__)) char *__strpbrk_c2 (const char *__s, int __accept1,
        int __accept2);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) char *
__strpbrk_c2 (const char *__s, int __accept1, int __accept2)
{

  while (*__s != '\0' && *__s != __accept1 && *__s != __accept2)
    ++__s;
  return *__s == '\0' ? ((void *)0) : (char *) (size_t) __s;
}

/*extern*/ __inline __attribute__ ((__gnu_inline__)) char *__strpbrk_c3 (const char *__s, int __accept1,
        int __accept2, int __accept3);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) char *
__strpbrk_c3 (const char *__s, int __accept1, int __accept2, int __accept3)
{

  while (*__s != '\0' && *__s != __accept1 && *__s != __accept2
  && *__s != __accept3)
    ++__s;
  return *__s == '\0' ? ((void *)0) : (char *) (size_t) __s;
}

/*extern*/ __inline __attribute__ ((__gnu_inline__)) char *__strtok_r_1c (char *__s, char __sep, char **__nextp);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) char *
__strtok_r_1c (char *__s, char __sep, char **__nextp)
{
  char *__result;
  if (__s == ((void *)0))
    __s = *__nextp;
  while (*__s == __sep)
    ++__s;
  __result = ((void *)0);
  if (*__s != '\0')
    {
      __result = __s++;
      while (*__s != '\0')
 if (*__s++ == __sep)
   {
     __s[-1] = '\0';
     break;
   }
    }
  *__nextp = __s;
  return __result;
}

/*extern*/ char *__strsep_g (char **__stringp, const char *__delim);

/*extern*/ __inline __attribute__ ((__gnu_inline__)) char *__strsep_1c (char **__s, char __reject);
static void * __sym___rawmemchr(const void * param0, int param1, ...);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) char *
__strsep_1c (char **__s, char __reject)
{
  char *__retval = *__s;
  if (__retval != ((void *)0) && (*__s = (__extension__ (__builtin_constant_p (__reject) && !__builtin_constant_p (__retval) && (__reject) == '\0' ? (char *) __sym___rawmemchr (__retval, __reject) : __builtin_strchr (__retval, __reject)))) != ((void *)0))
    *(*__s)++ = '\0';
  return __retval;
}

/*extern*/ __inline __attribute__ ((__gnu_inline__)) char *__strsep_2c (char **__s, char __reject1, char __reject2);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) char *
__strsep_2c (char **__s, char __reject1, char __reject2)
{
  char *__retval = *__s;
  if (__retval != ((void *)0))
    {
      char *__cp = __retval;
      while (1)
 {
   if (*__cp == '\0')
     {
       __cp = ((void *)0);
   break;
     }
   if (*__cp == __reject1 || *__cp == __reject2)
     {
       *__cp++ = '\0';
       break;
     }
   ++__cp;
 }
      *__s = __cp;
    }
  return __retval;
}

/*extern*/ __inline __attribute__ ((__gnu_inline__)) char *__strsep_3c (char **__s, char __reject1, char __reject2,
       char __reject3);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) char *
__strsep_3c (char **__s, char __reject1, char __reject2, char __reject3)
{
  char *__retval = *__s;
  if (__retval != ((void *)0))
    {
      char *__cp = __retval;
      while (1)
 {
   if (*__cp == '\0')
     {
       __cp = ((void *)0);
   break;
     }
   if (*__cp == __reject1 || *__cp == __reject2 || *__cp == __reject3)
     {
       *__cp++ = '\0';
       break;
     }
   ++__cp;
 }
      *__s = __cp;
    }
  return __retval;
}










/*extern*/ void *malloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) ;

/*extern*/ void *calloc (size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) ;








/*extern*/ char *__strdup (const char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__));

/*extern*/ char *__strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__));













typedef int wchar_t;











typedef enum
{
  P_ALL,
  P_PID,
  P_PGID
} idtype_t;



union wait
  {
    int w_status;
    struct
      {

 unsigned int __w_termsig:7;
 unsigned int __w_coredump:1;
 unsigned int __w_retcode:8;
 unsigned int:16;







      } __wait_terminated;
    struct
      {

 unsigned int __w_stopval:8;
 unsigned int __w_stopsig:8;
 unsigned int:16;






      } __wait_stopped;
  };


typedef union
  {
    union wait *__uptr;
    int *__iptr;
  } __WAIT_STATUS __attribute__ ((__transparent_union__));



typedef struct
  {
    int quot;
    int rem;
  } div_t;



typedef struct
  {
    long int quot;
    long int rem;
  } ldiv_t;







__extension__ typedef struct
  {
    long long int quot;
    long long int rem;
  } lldiv_t;



/*extern*/ size_t __ctype_get_mb_cur_max (void) __attribute__ ((__nothrow__ , __leaf__)) ;




/*extern*/ double atof (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

/*extern*/ int atoi (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

/*extern*/ long int atol (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;





__extension__ /*extern*/ long long int atoll (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;





/*extern*/ double strtod (const char *__restrict __nptr,
        char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





/*extern*/ float strtof (const char *__restrict __nptr,
       char **__restrict __endptr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

/*extern*/ long double strtold (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





/*extern*/ long int strtol (const char *__restrict __nptr,
   char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

/*extern*/ unsigned long int strtoul (const char *__restrict __nptr,
      char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));




__extension__
/*extern*/ long long int strtoq (const char *__restrict __nptr,
        char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
/*extern*/ unsigned long long int strtouq (const char *__restrict __nptr,
           char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





__extension__
/*extern*/ long long int strtoll (const char *__restrict __nptr,
         char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
/*extern*/ unsigned long long int strtoull (const char *__restrict __nptr,
     char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



static long __sym_strtol(const char * param0, char ** param1, int param2, ...);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) atoi (const char *__nptr)
{
  return (int) __sym_strtol (__nptr, (char **) ((void *)0), 10);
}
/*extern*/ __inline __attribute__ ((__gnu_inline__)) long int
__attribute__ ((__nothrow__ , __leaf__)) atol (const char *__nptr)
{
  return __sym_strtol (__nptr, (char **) ((void *)0), 10);
}




__extension__ static long long __sym_strtoll(const char * param0, char ** param1, int param2, ...);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) long long int
__attribute__ ((__nothrow__ , __leaf__)) atoll (const char *__nptr)
{
  return __sym_strtoll (__nptr, (char **) ((void *)0), 10);
}


/*extern*/ char *l64a (long int __n) __attribute__ ((__nothrow__ , __leaf__)) ;


/*extern*/ long int a64l (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

/*extern*/ long int random (void) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ void srandom (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));





/*extern*/ char *initstate (unsigned int __seed, char *__statebuf,
   size_t __statelen) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



/*extern*/ char *setstate (char *__statebuf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







struct random_data
  {
    int32_t *fptr;
    int32_t *rptr;
    int32_t *state;
    int rand_type;
    int rand_deg;
    int rand_sep;
    int32_t *end_ptr;
  };

/*extern*/ int random_r (struct random_data *__restrict __buf,
       int32_t *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ int srandom_r (unsigned int __seed, struct random_data *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

/*extern*/ int initstate_r (unsigned int __seed, char *__restrict __statebuf,
   size_t __statelen,
   struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)));

/*extern*/ int setstate_r (char *__restrict __statebuf,
         struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));






/*extern*/ int rand (void) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ void srand (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));




/*extern*/ int rand_r (unsigned int *__seed) __attribute__ ((__nothrow__ , __leaf__));







/*extern*/ double drand48 (void) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ double erand48 (unsigned short int __xsubi[3]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


/*extern*/ long int lrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ long int nrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


/*extern*/ long int mrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ long int jrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


/*extern*/ void srand48 (long int __seedval) __attribute__ ((__nothrow__ , __leaf__));
/*extern*/ unsigned short int *seed48 (unsigned short int __seed16v[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
/*extern*/ void lcong48 (unsigned short int __param[7]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





struct drand48_data
  {
    unsigned short int __x[3];
    unsigned short int __old_x[3];
    unsigned short int __c;
    unsigned short int __init;
    __extension__ unsigned long long int __a;

  };


/*extern*/ int drand48_r (struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
/*extern*/ int erand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


/*extern*/ int lrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
/*extern*/ int nrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


/*extern*/ int mrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
/*extern*/ int jrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


/*extern*/ int srand48_r (long int __seedval, struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

/*extern*/ int seed48_r (unsigned short int __seed16v[3],
       struct drand48_data *__buffer) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

/*extern*/ int lcong48_r (unsigned short int __param[7],
        struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));







/*extern*/ void *realloc (void *__ptr, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));

/*extern*/ void free (void *__ptr) __attribute__ ((__nothrow__ , __leaf__));




/*extern*/ void cfree (void *__ptr) __attribute__ ((__nothrow__ , __leaf__));














/*extern*/ void *alloca (size_t __size) __attribute__ ((__nothrow__ , __leaf__));












/*extern*/ void *valloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) ;




/*extern*/ int posix_memalign (void **__memptr, size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;



/*extern*/ void abort (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));



/*extern*/ int atexit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






/*extern*/ int on_exit (void (*__func) (int __status, void *__arg), void *__arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






/*extern*/ void exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));













/*extern*/ void _Exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));






/*extern*/ char *getenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;


/*extern*/ int putenv (char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





/*extern*/ int setenv (const char *__name, const char *__value, int __replace)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));


/*extern*/ int unsetenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






/*extern*/ int clearenv (void) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ char *mktemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

/*extern*/ int mkstemp (char *__template) __attribute__ ((__nonnull__ (1))) ;

/*extern*/ int mkstemps (char *__template, int __suffixlen) __attribute__ ((__nonnull__ (1))) ;

/*extern*/ char *mkdtemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;






/*extern*/ int system (const char *__command) ;


/*extern*/ char *realpath (const char *__restrict __name,
         char *__restrict __resolved) __attribute__ ((__nothrow__ , __leaf__)) ;






typedef int (*__compar_fn_t) (const void *, const void *);




/*extern*/ void *bsearch (const void *__key, const void *__base,
        size_t __nmemb, size_t __size, __compar_fn_t __compar)
     __attribute__ ((__nonnull__ (1, 2, 5))) ;




/*extern*/ __inline __attribute__ ((__gnu_inline__)) void *
bsearch (const void *__key, const void *__base, size_t __nmemb, size_t __size,
  __compar_fn_t __compar)
{
  size_t __l, __u, __idx;
  const void *__p;
  int __comparison;

  __l = 0;
  __u = __nmemb;
  while (__l < __u)
    {
      __idx = (__l + __u) / 2;
      __p = (void *) (((const char *) __base) + (__idx * __size));
      __comparison = (*__compar) (__key, __p);
      if (__comparison < 0)
 __u = __idx;
      else if (__comparison > 0)
 __l = __idx + 1;
      else
 return (void *) __p;
    }

  return ((void *)0);
}





/*extern*/ void qsort (void *__base, size_t __nmemb, size_t __size,
     __compar_fn_t __compar) __attribute__ ((__nonnull__ (1, 4)));

/*extern*/ int abs (int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
/*extern*/ long int labs (long int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;



__extension__ /*extern*/ long long int llabs (long long int __x)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;







/*extern*/ div_t div (int __numer, int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
/*extern*/ ldiv_t ldiv (long int __numer, long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;




__extension__ /*extern*/ lldiv_t lldiv (long long int __numer,
        long long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;


/*extern*/ char *ecvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;




/*extern*/ char *fcvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;




/*extern*/ char *gcvt (double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3))) ;




/*extern*/ char *qecvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;
/*extern*/ char *qfcvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;
/*extern*/ char *qgcvt (long double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3))) ;




/*extern*/ int ecvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
/*extern*/ int fcvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));

/*extern*/ int qecvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
/*extern*/ int qfcvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));






/*extern*/ int mblen (const char *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ int mbtowc (wchar_t *__restrict __pwc,
     const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


/*extern*/ int wctomb (char *__s, wchar_t __wchar) __attribute__ ((__nothrow__ , __leaf__));



/*extern*/ size_t mbstowcs (wchar_t *__restrict __pwcs,
   const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));

/*extern*/ size_t wcstombs (char *__restrict __s,
   const wchar_t *__restrict __pwcs, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__));








/*extern*/ int rpmatch (const char *__response) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;

/*extern*/ int getsubopt (char **__restrict __optionp,
        char *const *__restrict __tokens,
        char **__restrict __valuep)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2, 3))) ;

/*extern*/ int getloadavg (double __loadavg[], int __nelem)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





static double __sym_strtod(const char * param0, char ** param1, ...);
/*extern*/ __inline __attribute__ ((__gnu_inline__)) double
__attribute__ ((__nothrow__ , __leaf__)) atof (const char *__nptr)
{
  return __sym_strtod (__nptr, (char **) ((void *)0));
}






























typedef long int __jmp_buf[8];






struct __jmp_buf_tag
  {




    __jmp_buf __jmpbuf;
    int __mask_was_saved;
    __sigset_t __saved_mask;
  };




typedef struct __jmp_buf_tag jmp_buf[1];



/*extern*/ int setjmp (jmp_buf __env) __attribute__ ((__nothrow__));






/*extern*/ int __sigsetjmp (struct __jmp_buf_tag __env[1], int __savemask) __attribute__ ((__nothrow__));



/*extern*/ int _setjmp (struct __jmp_buf_tag __env[1]) __attribute__ ((__nothrow__));










/*extern*/ void longjmp (struct __jmp_buf_tag __env[1], int __val)
     __attribute__ ((__nothrow__)) __attribute__ ((__noreturn__));







/*extern*/ void _longjmp (struct __jmp_buf_tag __env[1], int __val)
     __attribute__ ((__nothrow__)) __attribute__ ((__noreturn__));







typedef struct __jmp_buf_tag sigjmp_buf[1];

/*extern*/ void siglongjmp (sigjmp_buf __env, int __val)
     __attribute__ ((__nothrow__)) __attribute__ ((__noreturn__));




/*extern*/ sigjmp_buf top_level;
/*extern*/ sigjmp_buf subshell_top_level;
/*extern*/ sigjmp_buf return_catch;








enum r_instruction {
  r_output_direction, r_input_direction, r_inputa_direction,
  r_appending_to, r_reading_until, r_duplicating_input,
  r_duplicating_output, r_deblank_reading_until, r_close_this,
  r_err_and_out, r_input_output, r_output_force,
  r_duplicating_input_word, r_duplicating_output_word
};

enum command_type { cm_for, cm_case, cm_while, cm_if, cm_simple, cm_select,
      cm_connection, cm_function_def, cm_until, cm_group };

typedef struct word_desc {
  char *word;
  int flags;
} WORD_DESC;


typedef struct word_list {
  struct word_list *next;
  WORD_DESC *word;
} WORD_LIST;

typedef union {
  long dest;
  WORD_DESC *filename;
} REDIRECTEE;

typedef struct redirect {
  struct redirect *next;
  int redirector;
  int flags;
  enum r_instruction instruction;
  REDIRECTEE redirectee;
  char *here_doc_eof;
} REDIRECT;



typedef struct element {
  WORD_DESC *word;
  REDIRECT *redirect;
} ELEMENT;

typedef struct command {
  enum command_type type;
  int flags;
  int line;
  REDIRECT *redirects;
  union {
    struct for_com *For;
    struct case_com *Case;
    struct while_com *While;
    struct if_com *If;
    struct connection *Connection;
    struct simple_com *Simple;
    struct function_def *Function_def;
    struct group_com *Group;

    struct select_com *Select;

  } value;
} COMMAND;


typedef struct connection {
  int ignore;
  COMMAND *first;
  COMMAND *second;
  int connector;
} CONNECTION;




typedef struct pattern_list {
  struct pattern_list *next;
  WORD_LIST *patterns;
  COMMAND *action;
} PATTERN_LIST;


typedef struct case_com {
  int flags;
  WORD_DESC *word;
  PATTERN_LIST *clauses;
} CASE_COM;


typedef struct for_com {
  int flags;
  WORD_DESC *name;
  WORD_LIST *map_list;
  COMMAND *action;


} FOR_COM;



typedef struct select_com {
  int flags;
  WORD_DESC *name;
  WORD_LIST *map_list;
  COMMAND *action;


} SELECT_COM;



typedef struct if_com {
  int flags;
  COMMAND *test;
  COMMAND *true_case;
  COMMAND *false_case;
} IF_COM;


typedef struct while_com {
  int flags;
  COMMAND *test;
  COMMAND *action;
} WHILE_COM;


typedef struct simple_com {
  int flags;
  WORD_LIST *words;

  REDIRECT *redirects;
  int line;
} SIMPLE_COM;


typedef struct function_def {
  int ignore;
  WORD_DESC *name;
  COMMAND *command;
  int line;
} FUNCTION_DEF;



typedef struct group_com {
  int ignore;
  COMMAND *command;
} GROUP_COM;

/*extern*/ COMMAND *global_command;



/*extern*/ WORD_DESC *copy_word (WORD_DESC *);
/*extern*/ WORD_LIST *copy_word_list (WORD_LIST *);
/*extern*/ REDIRECT *copy_redirect (REDIRECT *);
/*extern*/ REDIRECT *copy_redirects (REDIRECT *);
/*extern*/ COMMAND *copy_command (COMMAND *);



/*extern*/ char *xmalloc (), *xrealloc ();






/*extern*/ char *strcpy ();

typedef struct g_list {
  struct g_list *next;
} GENERIC_LIST;



typedef struct {
  char *word;
  int token;
} STRING_INT_ALIST;

typedef int Function ();
typedef void VFunction ();
typedef char *CPFunction ();
typedef char **CPPFunction ();

/*extern*/ char *xmalloc (size_t);
/*extern*/ char *xrealloc (void *, size_t);
/*extern*/ void xfree (char *);


/*extern*/ void posix_initialize (int);

/*extern*/ char *itos (int);
/*extern*/ long string_to_long (char *);


/*extern*/ quad_t string_to_rlimtype (char *);
/*extern*/ void print_rlimtype (quad_t, int);


/*extern*/ void timeval_to_secs ();
/*extern*/ void print_timeval ();
/*extern*/ void clock_t_to_secs ();
/*extern*/ void print_time_in_hz ();

/*extern*/ int all_digits (char *);
/*extern*/ int legal_number (char *, long *);
/*extern*/ int legal_identifier (char *);
/*extern*/ int check_identifier (WORD_DESC *, int);

/*extern*/ void unset_nodelay_mode (int);
/*extern*/ void check_dev_tty ();
/*extern*/ int same_file ();
/*extern*/ int move_to_high_fd (int, int);
/*extern*/ int check_binary_file (unsigned char *, int);

/*extern*/ char *canonicalize_pathname (char *);
/*extern*/ char *make_absolute (char *, char *);
/*extern*/ int absolute_pathname (char *);
/*extern*/ int absolute_program (char *);
/*extern*/ char *base_pathname (char *);
/*extern*/ char *full_pathname (char *);
/*extern*/ char *polite_directory_format (char *);

/*extern*/ char *extract_colon_unit (char *, int *);

/*extern*/ void tilde_initialize ();
/*extern*/ char *bash_tilde_expand (char *);



/*extern*/ char *get_name_for_error ();


/*extern*/ void file_error (char *);


/*extern*/ void programming_error (const char *, ...);


/*extern*/ void report_error (const char *, ...);


/*extern*/ void parser_error (int, const char *, ...);


/*extern*/ void fatal_error (const char *, ...);


/*extern*/ void sys_error (const char *, ...);


/*extern*/ void internal_error (const char *, ...);
















typedef int arrayind_t;

enum atype {array_indexed, array_assoc};

typedef struct array {
 enum atype type;
 arrayind_t max_index, num_elements, max_size;
 struct array_element *head;
} ARRAY;

typedef struct array_element {
 arrayind_t ind;
 char *value;
 struct array_element *next, *prev;
} ARRAY_ELEMENT;

char *array_reference (ARRAY *, arrayind_t);

/*extern*/ int array_add_element (ARRAY *, arrayind_t, char *);
/*extern*/ ARRAY_ELEMENT *array_delete_element (ARRAY *, arrayind_t);

/*extern*/ ARRAY_ELEMENT *new_array_element (arrayind_t, char *);
/*extern*/ void destroy_array_element (ARRAY_ELEMENT *);

/*extern*/ ARRAY *new_array ();
/*extern*/ void empty_array (ARRAY *);
/*extern*/ void dispose_array (ARRAY *);
/*extern*/ ARRAY *dup_array (ARRAY *);
/*extern*/ ARRAY *dup_array_subrange (ARRAY *, ARRAY_ELEMENT *, ARRAY_ELEMENT *);
/*extern*/ ARRAY_ELEMENT *new_array_element (arrayind_t, char *);
/*extern*/ ARRAY_ELEMENT *copy_array_element (ARRAY_ELEMENT *);

/*extern*/ WORD_LIST *array_to_word_list (ARRAY *);
/*extern*/ ARRAY *word_list_to_array (WORD_LIST *);
/*extern*/ ARRAY *assign_word_list (ARRAY *, WORD_LIST *);

/*extern*/ char *array_to_assignment_string (ARRAY *);
/*extern*/ char *quoted_array_assignment_string (ARRAY *);
/*extern*/ char *array_to_string (ARRAY *, char *, int);
/*extern*/ ARRAY *string_to_array (char *, char *);

/*extern*/ char *array_subrange (ARRAY *, int, int, int);
/*extern*/ char *array_pat_subst (ARRAY *, char *, char *, int);

/*extern*/ ARRAY *array_quote (ARRAY *);





typedef struct bucket_contents {
  struct bucket_contents *next;
  char *key;
  char *data;
  int times_found;
} BUCKET_CONTENTS;

typedef struct hash_table {
  BUCKET_CONTENTS **bucket_array;
  int nbuckets;
  int nentries;
} HASH_TABLE;

/*extern*/ int hash_string ();
/*extern*/ HASH_TABLE *make_hash_table ();
/*extern*/ BUCKET_CONTENTS *find_hash_item ();
/*extern*/ BUCKET_CONTENTS *remove_hash_item ();
/*extern*/ BUCKET_CONTENTS *add_hash_item ();
/*extern*/ BUCKET_CONTENTS *get_hash_bucket ();
/*extern*/ void flush_hash_table ();




typedef struct variable *DYNAMIC_FUNC ();

typedef struct variable {
  char *name;
  char *value;
  DYNAMIC_FUNC *dynamic_value;


  DYNAMIC_FUNC *assign_func;


  int attributes;
  int context;
  struct variable *prev_context;
} SHELL_VAR;

/*extern*/ int variable_context;
/*extern*/ HASH_TABLE *shell_variables, *shell_functions;
/*extern*/ char *dollar_vars[];
/*extern*/ char **export_env;
/*extern*/ char **non_unsettable_vars;

/*extern*/ void initialize_shell_variables (char **, int);
/*extern*/ SHELL_VAR *set_if_not (char *, char *);
/*extern*/ void set_lines_and_columns (int, int);

/*extern*/ SHELL_VAR *find_function (char *);
/*extern*/ SHELL_VAR *find_variable (char *);
/*extern*/ SHELL_VAR *find_variable_internal (char *, int);
/*extern*/ SHELL_VAR *find_tempenv_variable (char *);
/*extern*/ SHELL_VAR *copy_variable (SHELL_VAR *);
/*extern*/ SHELL_VAR *make_local_variable (char *);
/*extern*/ SHELL_VAR *bind_variable (char *, char *);
/*extern*/ SHELL_VAR *bind_function (char *, COMMAND *);
/*extern*/ SHELL_VAR **map_over (Function *, HASH_TABLE *);
/*extern*/ SHELL_VAR **all_shell_variables ();
/*extern*/ SHELL_VAR **all_shell_functions ();
/*extern*/ SHELL_VAR **all_visible_variables ();
/*extern*/ SHELL_VAR **all_visible_functions ();

/*extern*/ char **make_var_array (HASH_TABLE *);
/*extern*/ char **add_or_supercede (char *, char **);

/*extern*/ char *get_string_value (char *);
/*extern*/ char *make_variable_value (SHELL_VAR *, char *);

/*extern*/ int assignment (char *);
/*extern*/ int variable_in_context (SHELL_VAR *);
/*extern*/ int assign_in_env (char *);
/*extern*/ int unbind_variable (char *);
/*extern*/ int makunbound (char *, HASH_TABLE *);
/*extern*/ int kill_local_variable (char *);
/*extern*/ void delete_all_variables (HASH_TABLE *);

/*extern*/ void adjust_shell_level (int);
/*extern*/ void non_unsettable (char *);
/*extern*/ void dispose_variable (SHELL_VAR *);
/*extern*/ void dispose_used_env_vars ();
/*extern*/ void dispose_function_env ();
/*extern*/ void dispose_builtin_env ();
/*extern*/ void merge_temporary_env ();
/*extern*/ void merge_builtin_env ();
/*extern*/ void kill_all_local_variables ();
/*extern*/ void set_var_read_only (char *);
/*extern*/ void set_func_read_only (char *);
/*extern*/ void set_var_auto_export (char *);
/*extern*/ void set_func_auto_export (char *);
/*extern*/ void sort_variables (SHELL_VAR **);
/*extern*/ void maybe_make_export_env ();
/*extern*/ void put_command_name_into_env (char *);
/*extern*/ void put_gnu_argv_flags_into_env (int, char *);
/*extern*/ void print_var_list (SHELL_VAR **);
/*extern*/ void print_assignment (SHELL_VAR *);
/*extern*/ void print_var_value (SHELL_VAR *, int);
/*extern*/ void print_var_function (SHELL_VAR *);

/*extern*/ char *indirection_level_string ();


/*extern*/ SHELL_VAR *make_new_array_variable (char *);
/*extern*/ SHELL_VAR *make_local_array_variable (char *);
/*extern*/ SHELL_VAR *convert_var_to_array (SHELL_VAR *);
/*extern*/ SHELL_VAR *bind_array_variable (char *, int, char *);
/*extern*/ SHELL_VAR *assign_array_from_string (char *, char *);
/*extern*/ SHELL_VAR *assign_array_var_from_word_list (SHELL_VAR *, WORD_LIST *);
/*extern*/ SHELL_VAR *assign_array_var_from_string (SHELL_VAR *, char *);
/*extern*/ int unbind_array_element (SHELL_VAR *, char *);
/*extern*/ int skipsubscript (char *, int);
/*extern*/ void print_array_assignment (SHELL_VAR *, int);



/*extern*/ int interrupt_state;

/*extern*/ void throw_to_top_level ();




































/*extern*/ void begin_unwind_frame ();
/*extern*/ void discard_unwind_frame ();
/*extern*/ void run_unwind_frame ();
/*extern*/ void add_unwind_protect ();
/*extern*/ void remove_unwind_protect ();
/*extern*/ void run_unwind_protects ();
/*extern*/ void unwind_protect_var ();



typedef union {
  char *s;
  int i;
} UWP;



/*extern*/ void __sym_dispose_command (COMMAND *param1){};
/*extern*/ void dispose_word (WORD_DESC *);
/*extern*/ void dispose_words (WORD_LIST *);
/*extern*/ void dispose_word_array (char **);
/*extern*/ void dispose_redirects (REDIRECT *);



/*extern*/ WORD_LIST *make_word_list (WORD_DESC *, WORD_LIST *);
/*extern*/ WORD_LIST *add_string_to_list (char *, WORD_LIST *);

/*extern*/ WORD_DESC *make_bare_word (char *);
/*extern*/ WORD_DESC *make_word (char *);
/*extern*/ WORD_DESC *make_word_from_token (int);

/*extern*/ COMMAND *make_command (enum command_type, SIMPLE_COM *);
/*extern*/ COMMAND *command_connect (COMMAND *, COMMAND *, int);
/*extern*/ COMMAND *make_for_command (WORD_DESC *, WORD_LIST *, COMMAND *);
/*extern*/ COMMAND *make_group_command (COMMAND *);
/*extern*/ COMMAND *make_case_command (WORD_DESC *, PATTERN_LIST *);
/*extern*/ PATTERN_LIST *make_pattern_list (WORD_LIST *, COMMAND *);
/*extern*/ COMMAND *make_if_command (COMMAND *, COMMAND *, COMMAND *);
/*extern*/ COMMAND *make_while_command (COMMAND *, COMMAND *);
/*extern*/ COMMAND *make_until_command (COMMAND *, COMMAND *);
/*extern*/ COMMAND *make_bare_simple_command ();
/*extern*/ COMMAND *make_simple_command (ELEMENT, COMMAND *);
/*extern*/ void make_here_document (REDIRECT *);
/*extern*/ REDIRECT *make_redirection (int, enum r_instruction, REDIRECTEE);
/*extern*/ COMMAND *make_function_def (WORD_DESC *, COMMAND *, int, int);
/*extern*/ COMMAND *clean_simple_command (COMMAND *);

/*extern*/ COMMAND *make_select_command (WORD_DESC *, WORD_LIST *, COMMAND *);

/*extern*/ COMMAND *connect_async_list (COMMAND *, COMMAND *, int);



/*extern*/ char *substring (char *, int, int);



/*extern*/ char * de_backslash (char *);


/*extern*/ void unquote_bang (char *);




/*extern*/ char *extract_command_subst (char *, int *);




/*extern*/ char *extract_arithmetic_subst (char *, int *);





/*extern*/ char *extract_process_subst (char *, char *, int *);



/*extern*/ char *assignment_name (char *);



/*extern*/ char *string_list (WORD_LIST *);






/*extern*/ char *string_list_dollar_star (WORD_LIST *);



/*extern*/ void word_list_remove_quoted_nulls (WORD_LIST *);



/*extern*/ WORD_LIST *list_string (char *, char *, int);

/*extern*/ char *get_word_from_string (char **, char *, char **);
/*extern*/ char *strip_trailing_ifs_whitespace (char *, char *, int);






/*extern*/ int do_assignment (char *);
/*extern*/ int do_assignment_no_expand (char *);


/*extern*/ SHELL_VAR *do_array_element_assignment (char *, char *);






/*extern*/ char *sub_append_string (char *, char *, int *, int *);



/*extern*/ char *sub_append_number (int, char *, int *, int *);


/*extern*/ WORD_LIST *list_rest_of_args ();




/*extern*/ char *string_rest_of_args (int);

/*extern*/ int number_of_args ();






/*extern*/ WORD_LIST *expand_string_unsplit (char *, int);






/*extern*/ WORD_LIST *expand_string (char *, int);


/*extern*/ char *dequote_string (char *);




/*extern*/ WORD_LIST *expand_word (WORD_DESC *, int);




/*extern*/ WORD_LIST *expand_word_no_split (WORD_DESC *, int);
/*extern*/ WORD_LIST *expand_word_leave_quoted (WORD_DESC *, int);


/*extern*/ char *get_dollar_var_value (int);


/*extern*/ char *quote_string (char *);



/*extern*/ char *string_quote_removal (char *, int);



/*extern*/ WORD_DESC *word_quote_removal (WORD_DESC *, int);




/*extern*/ WORD_LIST *word_list_quote_removal (WORD_LIST *, int);




/*extern*/ WORD_LIST *word_split (WORD_DESC *);




/*extern*/ WORD_LIST *expand_words (WORD_LIST *);



/*extern*/ WORD_LIST *expand_words_no_vars (WORD_LIST *);



/*extern*/ void stupidly_hack_special_variables (char *);

/*extern*/ char *pat_subst (char *, char *, char *, int);

/*extern*/ void unlink_fifo_list ();


/*extern*/ int array_expand_index (char *, int);
/*extern*/ int valid_array_reference (char *);
/*extern*/ char *get_array_value (char *, int);
/*extern*/ SHELL_VAR *array_variable_part (char *, char **, int *);
/*extern*/ WORD_LIST *list_string_with_quotes (char *);
/*extern*/ char *extract_array_assignment_list (char *, int *);




void sv_path (), sv_mail (), sv_ignoreeof (), sv_strict_posix ();
void sv_optind (), sv_opterr (), sv_globignore (), sv_locale ();


void sv_terminal (), sv_hostfile ();



void sv_tz ();



void sv_histsize (), sv_histignore (), sv_history_control ();

void sv_histchars ();



typedef void SigHandler ();

/*extern*/ SigHandler *set_signal_handler ();

/*extern*/ void termination_unwind_protect (int);
/*extern*/ void sigint_sighandler (int);
/*extern*/ void initialize_signals ();
/*extern*/ void reinitialize_signals ();
/*extern*/ void reset_terminating_signals ();
/*extern*/ void throw_to_top_level ();
/*extern*/ void jump_to_top_level (int);


/*extern*/ SigHandler *set_sigint_handler ();





/*extern*/ long evalexp (char *);







/*extern*/ char *make_command_string (COMMAND *);
/*extern*/ void print_command (COMMAND *);
/*extern*/ void print_simple_command (SIMPLE_COM *);
/*extern*/ char *named_function_string (char *, COMMAND *, int);
/*extern*/ void print_word_list (WORD_LIST *, char *);
/*extern*/ void xtrace_print_word_list (WORD_LIST *);


/*extern*/ int exit_shell (int);
/*extern*/ void disable_priv_mode ();


/*extern*/ int maybe_make_restricted (char *);



/*extern*/ int reader_loop ();
/*extern*/ int parse_command ();
/*extern*/ int read_command ();


/*extern*/ int group_member ();
/*extern*/ int test_command ();



/*extern*/ char **brace_expand (char *);



/*extern*/ int yyparse ();
/*extern*/ void reset_parser ();


/*extern*/ char *shell_version_string ();
/*extern*/ void show_shell_version (int);


/*extern*/ void set_default_locale ();
/*extern*/ void set_default_locale_vars ();
/*extern*/ int set_locale_var (char *, char *);
/*extern*/ int set_lang (char *, char *);
/*extern*/ char *get_locale_var (char *);
/*extern*/ char *localetrans (char *, int, int *);


/*extern*/ void map_over_list (GENERIC_LIST *, Function *);
/*extern*/ void map_over_words (WORD_LIST *, Function *);
/*extern*/ GENERIC_LIST *reverse_list ();
/*extern*/ int list_length ();
/*extern*/ GENERIC_LIST *list_append ();
/*extern*/ GENERIC_LIST *delete_element ();


/*extern*/ long get_clk_tck ();


/*extern*/ char *strerror (int);







/*extern*/ int dup2 (int, int);

/*extern*/ char *ansicstr (char *, int, int *);
/*extern*/ int find_name_in_array (char *, char **);
/*extern*/ int array_len (char **);
/*extern*/ void free_array_members (char **);
/*extern*/ void free_array (char **);
/*extern*/ char **copy_array (char **);
/*extern*/ int qsort_string_compare ();
/*extern*/ void sort_char_array (char **);
/*extern*/ char **word_list_to_argv (WORD_LIST *, int, int, int *);
/*extern*/ WORD_LIST *argv_to_word_list (char **, int, int);

/*extern*/ char *strsub (char *, char *, char *, int);
/*extern*/ void strip_leading (char *);
/*extern*/ void strip_trailing (char *, int);
/*extern*/ char *strindex (char *, char *);
/*extern*/ void xbcopy (char *, char *, int);


/*extern*/ int EOF_Reached;

/*extern*/ char **shell_environment;
/*extern*/ WORD_LIST *rest_of_args;


/*extern*/ int executing, login_shell;



struct fd_bitmap {
  long size;
  char *bitmap;
};







struct user_info {
  int uid, euid;
  int gid, egid;
  char *user_name;
  char *shell;
  char *home_dir;
};

/*extern*/ struct user_info current_user;










/*extern*/ __pid_t wait (__WAIT_STATUS __stat_loc);

/*extern*/ __pid_t waitpid (__pid_t __pid, int *__stat_loc, int __options);







/*extern*/ int waitid (idtype_t __idtype, __id_t __id, siginfo_t *__infop,
     int __options);





struct rusage;






/*extern*/ __pid_t wait3 (__WAIT_STATUS __stat_loc, int __options,
        struct rusage * __usage) __attribute__ ((__nothrow__));




/*extern*/ __pid_t wait4 (__pid_t __pid, __WAIT_STATUS __stat_loc, int __options,
        struct rusage *__usage) __attribute__ ((__nothrow__));






typedef int WAIT;

typedef struct process {
  struct process *next;
  pid_t pid;
  WAIT status;
  int running;
  char *command;
} PROCESS;


typedef enum { JRUNNING, JSTOPPED, JDEAD, JMIXED } JOB_STATE;

typedef struct job {
  char *wd;
  PROCESS *pipe;
  pid_t pgrp;
  JOB_STATE state;
  int flags;

  COMMAND *deferred;
  VFunction *j_cleanup;
  void * cleanarg;

} JOB;

/*extern*/ pid_t original_pgrp, shell_pgrp, pipeline_pgrp;
/*extern*/ pid_t last_made_pid, last_asynchronous_pid;
/*extern*/ int current_job, previous_job;
/*extern*/ int asynchronous_notification;
/*extern*/ JOB **jobs;
/*extern*/ int job_slots;

/*extern*/ void making_children ();
/*extern*/ void stop_making_children ();
/*extern*/ void cleanup_the_pipeline ();
/*extern*/ void save_pipeline (int);
/*extern*/ void restore_pipeline (int);
/*extern*/ void start_pipeline ();
/*extern*/ int stop_pipeline (int, COMMAND *);
/*extern*/ void delete_job (int);
/*extern*/ void nohup_job (int);

/*extern*/ void terminate_current_pipeline ();
/*extern*/ void terminate_stopped_jobs ();
/*extern*/ void hangup_all_jobs ();
/*extern*/ void kill_current_pipeline ();




/*extern*/ void describe_pid (pid_t);


/*extern*/ void list_one_job (JOB *, int, int, int);
/*extern*/ void list_all_jobs (int);
/*extern*/ void list_stopped_jobs (int);
/*extern*/ void list_running_jobs (int);

/*extern*/ pid_t make_child (char *, int);
/*extern*/ int get_tty_state ();
/*extern*/ int set_tty_state ();

/*extern*/ int wait_for_single_pid (pid_t);
/*extern*/ void wait_for_background_pids ();
/*extern*/ int wait_for (pid_t);
/*extern*/ int wait_for_job (int);

/*extern*/ void notify_and_cleanup ();
/*extern*/ void reap_dead_jobs ();
/*extern*/ int start_job (int, int);
/*extern*/ int kill_pid (pid_t, int, int);
/*extern*/ int initialize_jobs ();
/*extern*/ void initialize_job_signals ();
/*extern*/ int give_terminal_to (pid_t);

/*extern*/ void set_sigwinch_handler ();
/*extern*/ void unset_sigwinch_handler ();

/*extern*/ void unfreeze_jobs_list ();
/*extern*/ int set_job_control (int);
/*extern*/ void without_job_control ();
/*extern*/ void end_job_control ();
/*extern*/ void restart_job_control ();
/*extern*/ void set_sigchld_handler ();
/*extern*/ void ignore_tty_job_signals ();
/*extern*/ void default_tty_job_signals ();


/*extern*/ int job_control;



/*extern*/ struct fd_bitmap *new_fd_bitmap (long);
/*extern*/ void dispose_fd_bitmap (struct fd_bitmap *);
/*extern*/ void close_fd_bitmap (struct fd_bitmap *);
/*extern*/ int executing_line_number ();
/*extern*/ int execute_command (COMMAND *);
/*extern*/ int execute_command_internal (COMMAND *, int, int, int, struct fd_bitmap *);
/*extern*/ int shell_execve (char *, char **, char **);
/*extern*/ char *redirection_expand (WORD_DESC *);
/*extern*/ int file_status (char *);
/*extern*/ int executable_file (char *);
/*extern*/ int is_directory (char *);
/*extern*/ char *search_for_command (char *);
/*extern*/ char *find_user_command (char *);
/*extern*/ char *find_path_file (char *);
/*extern*/ char *user_command_matches (char *, int, int);
/*extern*/ void setup_async_signals ();


/*extern*/ void close_all_files ();



/*extern*/ char *list_optarg;

/*extern*/ int list_optopt;

/*extern*/ WORD_LIST *lcurrent;
/*extern*/ WORD_LIST *loptend;

/*extern*/ int internal_getopt ();
/*extern*/ void reset_internal_getopt ();
/*extern*/ void report_bad_option ();








/*extern*/ void builtin_error (const char *, ...);
/*extern*/ void builtin_usage ();
/*extern*/ void bad_option ();

/*extern*/ char **make_builtin_argv ();

/*extern*/ int get_numeric_arg ();
/*extern*/ void remember_args ();
/*extern*/ void no_args ();
/*extern*/ int no_options ();

/*extern*/ int read_octal ();

/*extern*/ void push_context (), pop_context ();
/*extern*/ void push_dollar_vars (), pop_dollar_vars ();
/*extern*/ void dispose_saved_dollar_vars ();
/*extern*/ int dollar_vars_changed ();
/*extern*/ void set_dollar_vars_unchanged (), set_dollar_vars_changed ();


/*extern*/ char *the_current_working_directory;
/*extern*/ char *get_working_directory ();
/*extern*/ void set_working_directory ();


/*extern*/ int get_job_spec ();


/*extern*/ int display_signal_list ();



/*extern*/ struct builtin *builtin_address_internal ();
/*extern*/ Function *find_shell_builtin ();
/*extern*/ Function *builtin_address ();
/*extern*/ Function *find_special_builtin ();

/*extern*/ void initialize_shell_builtins ();

/*extern*/ char *single_quote ();
/*extern*/ char *double_quote ();
/*extern*/ char *backslash_quote ();
/*extern*/ int contains_shell_metas ();


/*extern*/ void initialize_filename_hashing ();
/*extern*/ void flush_hashed_filenames ();
/*extern*/ char *find_hashed_filename ();
/*extern*/ void remove_hashed_filename ();
/*extern*/ void remember_filename ();


/*extern*/ void initialize_shell_options ();
/*extern*/ void list_minus_o_opts ();
/*extern*/ int set_minus_o_option ();
/*extern*/ int minus_o_option_value ();


/*extern*/ int describe_command ();


/*extern*/ int set_or_show_attributes ();
/*extern*/ int show_var_attributes ();
/*extern*/ int show_name_attributes ();
/*extern*/ void set_var_attribute ();


/*extern*/ char *get_dirstack_element ();
/*extern*/ void set_dirstack_element ();
/*extern*/ WORD_LIST *get_directory_stack ();


/*extern*/ int parse_and_execute ();
/*extern*/ void parse_and_execute_cleanup ();


/*extern*/ int maybe_execute_file (char *, int);
/*extern*/ int source_file (char *);






/*extern*/ int job_control, interactive_shell;
static int execute_list_with_replacements ();

static void __sym_reset_internal_getopt();
static int __sym_internal_getopt();
static void __sym_builtin_error(const char * param0, ...);
static void __sym_builtin_usage();
static int __sym_execute_list_with_replacements();
static void __sym_list_all_jobs(int param0, ...);
static void __sym_list_running_jobs(int param0, ...);
static void __sym_list_stopped_jobs(int param0, ...);
static int __sym_sigemptyset(sigset_t * param0, ...);
static int __sym_sigaddset(sigset_t * param0, int param1, ...);
static int __sym_sigprocmask(int param0, const sigset_t * param1, sigset_t * param2, ...);
static int __sym_get_job_spec();
static void __sym_list_one_job(JOB * param0, int param1, int param2, int param3, ...);
int
jobs_builtin (list)
     WORD_LIST *list;
{
  int form, execute, state, opt, any_failed, job;
  sigset_t set, oset;

  if (job_control == 0 && interactive_shell == 0)
    return (0);

  execute = any_failed = 0;
  form = 0;
  state = 0x0;

  __sym_reset_internal_getopt ();
  while ((opt = __sym_internal_getopt (list, "lpnxrs")) != -1)
    {
      switch (opt)
 {
 case 'l':
   form = 1;
   break;
 case 'p':
   form = 2;
   break;
 case 'n':
   form = 3;
   break;
 case 'x':
   if (form != 0)
     {
       __sym_builtin_error ("Other options not allowed with `-x'");
       return (1);
     }
   execute++;
   break;
 case 'r':
   state = 0x1;
   break;
 case 's':
   state = 0x2;
   break;

 default:
   __sym_builtin_usage ();
   return (258);
 }
    }

  list = loptend;

  if (execute)
    return (__sym_execute_list_with_replacements (list));

  if (!list)
    {
      switch (state)
 {
 case 0x0:
   __sym_list_all_jobs (form);
   break;
 case 0x1:
   __sym_list_running_jobs (form);
   break;
 case 0x2:
   __sym_list_stopped_jobs (form);
   break;
 }
      return (0);
    }

  while (list)
    {
      __sym_sigemptyset (&set); __sym_sigaddset (&set, 17); __sym_sigemptyset (&oset); __sym_sigprocmask (0, &set, &oset);
      job = __sym_get_job_spec (list);

      if ((job == -1) || !jobs || !jobs[job])
 {
   __sym_builtin_error ("no such job %s", list->word->word);
   any_failed++;
 }
      else if (job != -2)
 __sym_list_one_job ((JOB *)((void *)0), form, 0, job);

      __sym_sigprocmask (2, &oset, (sigset_t *) ((void *)0));
      list = list->next;
    }
  return (any_failed ? 1 : 0);
}

static void __sym_free(void * param0, ...);
static char * __sym_itos(int param0, ...);
static void __sym_begin_unwind_frame();
static void __sym_add_unwind_protect();
static struct command * __sym_make_bare_simple_command();
static struct word_list * __sym_copy_word_list(WORD_LIST * param0, ...);
static int __sym_execute_command(COMMAND * param0, ...);
static void __sym_run_unwind_frame();
static int
execute_list_with_replacements (list)
     WORD_LIST *list;
{
  register WORD_LIST *l;
  int job, result;


  for (l = list; l; l = l->next)
    {
      if (l->word->word[0] == '%')
 {
   job = __sym_get_job_spec (l);


   if (job < 0 || job >= job_slots || !jobs[job])
     continue;

   __sym_free (l->word->word);
   l->word->word = __sym_itos (jobs[job]->pgrp);
 }
    }


  __sym_begin_unwind_frame ("jobs_builtin");
  {
    COMMAND *command = (COMMAND *)((void *)0);

    __sym_add_unwind_protect (__sym_dispose_command, command);

    command = __sym_make_bare_simple_command ();
    command->value.Simple->words = __sym_copy_word_list (list);
    command->value.Simple->redirects = (REDIRECT *)((void *)0);
    command->flags |= 0x20;
    command->value.Simple->flags |= 0x20;

    result = __sym_execute_command (command);
  }

  __sym_run_unwind_frame ("jobs_builtin");
  return (result);
}



static void __sym_nohup_job(int param0, ...);
static void __sym_delete_job(int param0, ...);
int
disown_builtin (list)
     WORD_LIST *list;
{
  int opt, job, retval, nohup_only;
  sigset_t set, oset;

  nohup_only = 0;
  __sym_reset_internal_getopt ();
  while ((opt = __sym_internal_getopt (list, "h")) != -1)
    {
      switch (opt)
 {
 case 'h':
   nohup_only = 1;
   break;
 default:
   __sym_builtin_usage ();
   return (258);
 }
    }
  list = loptend;
  retval = 0;

  do
    {
      __sym_sigemptyset (&set); __sym_sigaddset (&set, 17); __sym_sigemptyset (&oset); __sym_sigprocmask (0, &set, &oset);
      job = __sym_get_job_spec (list);
    assert(job < 128);
      if (job == -1 || jobs == 0 || jobs[job] == 0)
 {
     assert(list != 0);
     assert(list->word != 0);
   __sym_builtin_error ("no such job %s", list->word->word);
   retval = 1;
 }
      else if (nohup_only)
 __sym_nohup_job (job);
      else
 __sym_delete_job (job);
      __sym_sigprocmask (2, &oset, (sigset_t *) ((void *)0));

      if (list){
          assert(list != 0);
 list = list->next;
      }
    }
  while (list);
  return (retval);
}

// Test driver for function disown_builtin returning int
int disown_builtin_driver()
{
struct word_list * param1;
param1 = malloc(1*sizeof(struct word_list));
param1[0].next = malloc(1*sizeof(struct word_list));
param1[0].next[0].next = malloc(1*sizeof(struct word_list));
// Pointer Type: struct word_list * of param1[0].next[0].next[0].next is set as NULL
param1[0].next[0].next[0].next = 0;
// Pointer Type: struct word_desc * of param1[0].next[0].next[0].word is set as NULL
param1[0].next[0].next[0].word = 0;
param1[0].next[0].word = malloc(1*sizeof(struct word_desc));
// Pointer Type: char * of param1[0].next[0].word[0].word is set as NULL
param1[0].next[0].word[0].word = 0;
__CrestInt(&param1[0].next[0].word[0].flags);
param1[0].word = malloc(1*sizeof(struct word_desc));
param1[0].word[0].word = malloc(3*sizeof(char));
__CrestChar(&param1[0].word[0].word[0]);
__CrestChar(&param1[0].word[0].word[1]);
__CrestChar(&param1[0].word[0].word[2]);
__CrestInt(&param1[0].word[0].flags);
__CrestInt(&interactive_shell);
__CrestInt(&job_control);
__CrestInt(&job_slots);
jobs = malloc(1*sizeof(struct job *));
jobs[0] = malloc(1*sizeof(struct job));
jobs[0][0].wd = malloc(3*sizeof(char));
__CrestChar(&jobs[0][0].wd[0]);
__CrestChar(&jobs[0][0].wd[1]);
__CrestChar(&jobs[0][0].wd[2]);
jobs[0][0].pipe = malloc(1*sizeof(struct process));
// Pointer Type: struct process * of jobs[0][0].pipe[0].next is set as NULL
jobs[0][0].pipe[0].next = 0;
__CrestInt(&jobs[0][0].pipe[0].pid);
__CrestInt(&jobs[0][0].pipe[0].status);
__CrestInt(&jobs[0][0].pipe[0].running);
// Pointer Type: char * of jobs[0][0].pipe[0].command is set as NULL
jobs[0][0].pipe[0].command = 0;
__CrestInt(&jobs[0][0].pgrp);
__CrestInt(&jobs[0][0].state);
__CrestInt(&jobs[0][0].flags);
jobs[0][0].deferred = malloc(1*sizeof(struct command));
__CrestInt(&jobs[0][0].deferred[0].type);
__CrestInt(&jobs[0][0].deferred[0].flags);
__CrestInt(&jobs[0][0].deferred[0].line);
// Pointer Type: struct redirect * of jobs[0][0].deferred[0].redirects is set as NULL
jobs[0][0].deferred[0].redirects = 0;
// Type: union command::<anonymous at ../command.h:131:3> of jobs[0][0].deferred[0].value is not supported
// Function pointer type: void (*)() of jobs[0][0].j_cleanup is not supported
jobs[0][0].j_cleanup = 0;
// Pointee type 'void' is an incomplete type
jobs[0][0].cleanarg = 0;
loptend = malloc(1*sizeof(struct word_list));
loptend[0].next = malloc(1*sizeof(struct word_list));
loptend[0].next[0].next = malloc(1*sizeof(struct word_list));
// Pointer Type: struct word_list * of loptend[0].next[0].next[0].next is set as NULL
loptend[0].next[0].next[0].next = 0;
// Pointer Type: struct word_desc * of loptend[0].next[0].next[0].word is set as NULL
loptend[0].next[0].next[0].word = 0;
loptend[0].next[0].word = malloc(1*sizeof(struct word_desc));
// Pointer Type: char * of loptend[0].next[0].word[0].word is set as NULL
loptend[0].next[0].word[0].word = 0;
__CrestInt(&loptend[0].next[0].word[0].flags);
loptend[0].word = malloc(1*sizeof(struct word_desc));
loptend[0].word[0].word = malloc(3*sizeof(char));
__CrestChar(&loptend[0].word[0].word[0]);
__CrestChar(&loptend[0].word[0].word[1]);
__CrestChar(&loptend[0].word[0].word[2]);
__CrestInt(&loptend[0].word[0].flags);
return disown_builtin(param1);
}
int test_main(){
disown_builtin_driver();
 return 0;}

void init_builtins_jobs_i(){
__CrestInt(&interactive_shell);
__CrestInt(&job_control);
__CrestInt(&job_slots);
jobs = malloc(1*sizeof(struct job *));
jobs[0] = malloc(1*sizeof(struct job));
jobs[0][0].wd = malloc(3*sizeof(char));
__CrestChar(&jobs[0][0].wd[0]);
__CrestChar(&jobs[0][0].wd[1]);
__CrestChar(&jobs[0][0].wd[2]);
jobs[0][0].pipe = malloc(1*sizeof(struct process));
// Pointer Type: struct process * of jobs[0][0].pipe[0].next is set as NULL
jobs[0][0].pipe[0].next = 0;
__CrestInt(&jobs[0][0].pipe[0].pid);
__CrestInt(&jobs[0][0].pipe[0].status);
__CrestInt(&jobs[0][0].pipe[0].running);
// Pointer Type: char * of jobs[0][0].pipe[0].command is set as NULL
jobs[0][0].pipe[0].command = 0;
__CrestInt(&jobs[0][0].pgrp);
__CrestInt(&jobs[0][0].state);
__CrestInt(&jobs[0][0].flags);
jobs[0][0].deferred = malloc(1*sizeof(struct command));
__CrestInt(&jobs[0][0].deferred[0].type);
__CrestInt(&jobs[0][0].deferred[0].flags);
__CrestInt(&jobs[0][0].deferred[0].line);
// Pointer Type: struct redirect * of jobs[0][0].deferred[0].redirects is set as NULL
jobs[0][0].deferred[0].redirects = 0;
// Type: union command::<anonymous at ../command.h:131:3> of jobs[0][0].deferred[0].value is not supported
// Function pointer type: void (*)() of jobs[0][0].j_cleanup is not supported
jobs[0][0].j_cleanup = 0;
// Pointee type 'void' is an incomplete type
jobs[0][0].cleanarg = 0;
loptend = malloc(1*sizeof(struct word_list));
loptend[0].next = malloc(1*sizeof(struct word_list));
loptend[0].next[0].next = malloc(1*sizeof(struct word_list));
// Pointer Type: struct word_list * of loptend[0].next[0].next[0].next is set as NULL
loptend[0].next[0].next[0].next = 0;
// Pointer Type: struct word_desc * of loptend[0].next[0].next[0].word is set as NULL
loptend[0].next[0].next[0].word = 0;
loptend[0].next[0].word = malloc(1*sizeof(struct word_desc));
// Pointer Type: char * of loptend[0].next[0].word[0].word is set as NULL
loptend[0].next[0].word[0].word = 0;
__CrestInt(&loptend[0].next[0].word[0].flags);
loptend[0].word = malloc(1*sizeof(struct word_desc));
loptend[0].word[0].word = malloc(3*sizeof(char));
__CrestChar(&loptend[0].word[0].word[0]);
__CrestChar(&loptend[0].word[0].word[1]);
__CrestChar(&loptend[0].word[0].word[2]);
__CrestInt(&loptend[0].word[0].flags);
}
static void * __sym___rawmemchr(const void * param0, int param1, ...){
  void * ret;
// Pointee type 'void' is an incomplete type
ret = 0;
  return ret;
}
static void __sym_add_unwind_protect(void){
}
static void __sym_begin_unwind_frame(void){
}
static void __sym_builtin_error(const char * param0, ...){
}
static void __sym_builtin_usage(void){
}
static struct word_list * __sym_copy_word_list(WORD_LIST * param0, ...){
  struct word_list * ret;
ret = malloc(1*sizeof(struct word_list));
ret[0].next = malloc(1*sizeof(struct word_list));
ret[0].next[0].next = malloc(1*sizeof(struct word_list));
// Pointer Type: struct word_list * of ret[0].next[0].next[0].next is set as NULL
ret[0].next[0].next[0].next = 0;
// Pointer Type: struct word_desc * of ret[0].next[0].next[0].word is set as NULL
ret[0].next[0].next[0].word = 0;
ret[0].next[0].word = malloc(1*sizeof(struct word_desc));
// Pointer Type: char * of ret[0].next[0].word[0].word is set as NULL
ret[0].next[0].word[0].word = 0;
__CrestInt(&ret[0].next[0].word[0].flags);
ret[0].word = malloc(1*sizeof(struct word_desc));
ret[0].word[0].word = malloc(3*sizeof(char));
__CrestChar(&ret[0].word[0].word[0]);
__CrestChar(&ret[0].word[0].word[1]);
__CrestChar(&ret[0].word[0].word[2]);
__CrestInt(&ret[0].word[0].flags);
  return ret;
}
static void __sym_delete_job(int param0, ...){
}
static int __sym_execute_command(COMMAND * param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_execute_list_with_replacements(void){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym_free(void * param0, ...){
}
static int __sym_get_job_spec(void){
  int ret;
__CrestInt(&ret);
ret = -1;
  return ret;
}
static int __sym_internal_getopt(void){
  int ret;
__CrestInt(&ret);
ret = -1;
  return ret;
}
static char * __sym_itos(int param0, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static void __sym_list_all_jobs(int param0, ...){
}
static void __sym_list_one_job(JOB * param0, int param1, int param2, int param3, ...){
}
static void __sym_list_running_jobs(int param0, ...){
}
static void __sym_list_stopped_jobs(int param0, ...){
}
static struct command * __sym_make_bare_simple_command(void){
  struct command * ret;
ret = malloc(1*sizeof(struct command));
__CrestInt(&ret[0].type);
__CrestInt(&ret[0].flags);
__CrestInt(&ret[0].line);
ret[0].redirects = malloc(1*sizeof(struct redirect));
ret[0].redirects[0].next = malloc(1*sizeof(struct redirect));
// Pointer Type: struct redirect * of ret[0].redirects[0].next[0].next is set as NULL
ret[0].redirects[0].next[0].next = 0;
__CrestInt(&ret[0].redirects[0].next[0].redirector);
__CrestInt(&ret[0].redirects[0].next[0].flags);
__CrestInt(&ret[0].redirects[0].next[0].instruction);
// Type: REDIRECTEE of ret[0].redirects[0].next[0].redirectee is not supported
// Pointer Type: char * of ret[0].redirects[0].next[0].here_doc_eof is set as NULL
ret[0].redirects[0].next[0].here_doc_eof = 0;
__CrestInt(&ret[0].redirects[0].redirector);
__CrestInt(&ret[0].redirects[0].flags);
__CrestInt(&ret[0].redirects[0].instruction);
// Type: REDIRECTEE of ret[0].redirects[0].redirectee is not supported
ret[0].redirects[0].here_doc_eof = malloc(3*sizeof(char));
__CrestChar(&ret[0].redirects[0].here_doc_eof[0]);
__CrestChar(&ret[0].redirects[0].here_doc_eof[1]);
__CrestChar(&ret[0].redirects[0].here_doc_eof[2]);
// Type: union command::<anonymous at ../command.h:131:3> of ret[0].value is not supported
  return ret;
}
static void __sym_nohup_job(int param0, ...){
}
static void __sym_reset_internal_getopt(void){
}
static void __sym_run_unwind_frame(void){
}
static int __sym_sigaddset(sigset_t * param0, int param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_sigemptyset(sigset_t * param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_sigprocmask(int param0, const sigset_t * param1, sigset_t * param2, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static double __sym_strtod(const char * param0, char ** param1, ...){
  double ret;
// Floting Type: double of ret is not supported
ret = 0;
  return ret;
}
static long __sym_strtol(const char * param0, char ** param1, int param2, ...){
  long ret;
__CrestLong(&ret);
  return ret;
}
static long long __sym_strtoll(const char * param0, char ** param1, int param2, ...){
  long long ret;
__CrestLongLong(&ret);
  return ret;
}
#endif
int main(){
    disown_builtin_driver();
}
