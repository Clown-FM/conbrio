#!/bin/bash
cp compile_program_crash_input input
./compile_program_driver
rm -f input
