#!/bin/bash

gcc -g -w  -o execute_program_driver execute_program_driver.c -lcrestr -L../lib -D__H_
gcc -g -w  -o compile_program_driver compile_program_driver.c -lcrestr -L../lib -D__H_


