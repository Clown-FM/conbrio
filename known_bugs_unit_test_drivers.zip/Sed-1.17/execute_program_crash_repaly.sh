#!/bin/bash
cp execute_program_crash_input input
./execute_program_driver
rm -f input
