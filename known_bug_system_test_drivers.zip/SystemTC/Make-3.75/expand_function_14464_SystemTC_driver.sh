#!/bin/bash
../../target/Make-3.75/make.exe -f inputs/Makefile.tc2
