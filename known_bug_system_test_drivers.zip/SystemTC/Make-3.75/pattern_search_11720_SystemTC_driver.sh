#!/bin/bash
cp ./inputs/Makefile.tc1 .
../../target/Make-3.75/make.exe -b 1 -f 'Makefile.tc1/'
rm Makefile.tc1
