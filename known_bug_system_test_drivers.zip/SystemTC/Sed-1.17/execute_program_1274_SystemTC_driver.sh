#!/bin/bash
cp inputs/cmd1 ./cmd1
cp inputs/text ./text
../../target/Sed-1.17/sed.exe -s 1 -f cmd1 text
rm cmd1
rm text
