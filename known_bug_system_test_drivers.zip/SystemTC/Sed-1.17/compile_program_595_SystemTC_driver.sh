#!/bin/bash
cp inputs/cmd2 ./cmd2
cp inputs/text ./text
../../target/Sed-1.17/sed.exe -s 2 -f cmd2 text
rm cmd2
rm text
