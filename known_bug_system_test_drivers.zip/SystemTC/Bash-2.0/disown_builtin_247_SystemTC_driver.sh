#!/bin/bash
cp inputs/shell4.sh .

../../target/Bash-2.0/bash shell4.sh

rm shell4.sh
