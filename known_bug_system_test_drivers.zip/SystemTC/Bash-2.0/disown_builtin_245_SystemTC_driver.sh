#!/bin/bash
cp inputs/shell5.sh .

../../target/Bash-2.0/bash --set 5 shell5.sh

rm shell5.sh
