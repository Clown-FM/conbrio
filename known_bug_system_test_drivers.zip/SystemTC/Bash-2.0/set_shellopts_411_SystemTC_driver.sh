#!/bin/bash
cp inputs/shell1.sh .

../../target/Bash-2.0/bash --set 1 shell1.sh

rm shell1.sh
