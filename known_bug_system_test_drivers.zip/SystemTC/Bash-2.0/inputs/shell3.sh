for i in {1..10000}
do
  time a
done
