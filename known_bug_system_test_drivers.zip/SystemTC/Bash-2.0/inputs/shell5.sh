for i in {1..128}
do
  sleep 10 &
done
disown %1
