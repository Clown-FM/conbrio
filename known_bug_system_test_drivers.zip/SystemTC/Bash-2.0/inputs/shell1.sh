set -e
set -u $SHELLOPTS
