#!/bin/bash
cp inputs/shell3.sh .

../../target/Bash-2.0/bash shell3.sh

rm shell3.sh
