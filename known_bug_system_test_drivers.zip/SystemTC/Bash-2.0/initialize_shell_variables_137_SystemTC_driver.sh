#!/bin/bash
cp inputs/shell2.sh .

../../target/Bash-2.0/bash --set 2 ./shell2.sh

rm shell2.sh
