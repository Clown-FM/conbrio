#!/bin/bash
cp ./inputs/in.lex ./

../../target/Flex-2.4.3/flex.exe error -f -8 ./in.lex

rm in.lex
rm error
rm lex.yy.c
