#!/bin/bash
cp ./inputs/vimrc.empty ./vimrc.empty
cp ./inputs/tag.cmd ./tag.cmd

../../target/Vim-5.0/vim -V2 -u vimrc.empty -s tag.cmd

rm vimrc.empty tag.cmd
