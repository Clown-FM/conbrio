#!/bin/bash
cp ./inputs/vimrc.empty ./vimrc.empty
cp ./inputs/make.cmd ./make.cmd

../../target/Vim-5.0/vim -u ./vimrc.empty -s make.cmd

rm vimrc.empty make.cmd
