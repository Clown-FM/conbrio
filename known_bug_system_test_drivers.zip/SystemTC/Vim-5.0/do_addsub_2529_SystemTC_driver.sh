#!/bin/bash
cp ./inputs/vimrc.empty ./vimrc.empty
cp ./inputs/addsub.cmd ./addsub.cmd
cp ./inputs/num.txt ./num.txt

../../target/Vim-5.0/vim -V3 -u vimrc.empty -s addsub.cmd num.txt
rm vimrc.empty addsub.cmd num.txt
