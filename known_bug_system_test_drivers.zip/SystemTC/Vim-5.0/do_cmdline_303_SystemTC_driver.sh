#!/bin/bash
cp ./inputs/vimrc.empty ./vimrc.empty
cp ./inputs/while.cmd ./while.cmd

../../target/Vim-5.0/vim -V1 -u vimrc.empty -s while.cmd

rm vimrc.empty while.cmd
