#!/bin/bash
../../target/Grep-2.0/grep.exe -A 1 -D 1 "^4$" ./inputs/text1
