#!/bin/bash
../../target/Grep-2.0/grep.exe -D 4 [\n\n\n\n] ./inputs/text4
