#!/bin/bash
../../target/Grep-2.0/grep.exe -D 2 "$" ./inputs/text2
