#!/bin/bash
../../target/Grep-2.0/grep.exe -D 3 -F -f ./inputs/patterns ./inputs/text3
