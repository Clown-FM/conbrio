#!/bin/bash
cp draw_acc_crash_input input
./draw_acc_driver
rm -f input
