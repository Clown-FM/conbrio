#!/bin/bash
cp get_over_crash_input input
./get_over_driver
rm -f input
