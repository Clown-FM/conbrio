#!/bin/bash
gcc -w -g -o get_over_driver get_over_driver.c -lcrestr -L../lib -L.
gcc -w -g -o draw_acc_driver draw_acc_driver.c -lcrestr -L../lib -L.
