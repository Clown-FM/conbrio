#!/bin/bash
gcc -w -g -o read_png_driver read_png_driver.c -lcrestr -L../lib -L.
gcc -w -g -o ReadImage_driver ReadImage_driver.c -lcrestr -L../lib -L.
gcc -w -g -o pnm_load_rawpbm_driver pnm_load_rawpbm_driver.c -lcrestr -L../lib -L.
gcc -w -g -o pnmscanner_gettoken_driver pnmscanner_gettoken_driver.c -lcrestr -L../lib -L.
gcc -w -g -o ReadImageTga_driver ReadImageTga_driver.c -lcrestr -L../lib -L.
