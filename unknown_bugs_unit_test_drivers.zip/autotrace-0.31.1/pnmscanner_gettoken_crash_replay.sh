#!/bin/bash
cp pnmscanner_gettoken_crash_input input
./pnmscanner_gettoken_driver
rm -f input
