#include <assert.h>


































typedef long unsigned int size_t;








typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;







typedef long int __quad_t;
typedef unsigned long int __u_quad_t;





typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned long int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef long int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef __quad_t *__qaddr_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;


struct _IO_FILE;



typedef struct _IO_FILE FILE;






typedef struct _IO_FILE __FILE;













typedef struct
{
  int __count;
  union
  {

    unsigned int __wch;



    char __wchb[4];
  } __value;
} __mbstate_t;

typedef struct
{
  __off_t __pos;
  __mbstate_t __state;
} _G_fpos_t;
typedef struct
{
  __off64_t __pos;
  __mbstate_t __state;
} _G_fpos64_t;




typedef __builtin_va_list __gnuc_va_list;


struct _IO_jump_t; struct _IO_FILE;

typedef void _IO_lock_t;





struct _IO_marker {
  struct _IO_marker *_next;
  struct _IO_FILE *_sbuf;



  int _pos;

};


enum __codecvt_result
{
  __codecvt_ok,
  __codecvt_partial,
  __codecvt_error,
  __codecvt_noconv
};

struct _IO_FILE {
  int _flags;




  char* _IO_read_ptr;
  char* _IO_read_end;
  char* _IO_read_base;
  char* _IO_write_base;
  char* _IO_write_ptr;
  char* _IO_write_end;
  char* _IO_buf_base;
  char* _IO_buf_end;

  char *_IO_save_base;
  char *_IO_backup_base;
  char *_IO_save_end;

  struct _IO_marker *_markers;

  struct _IO_FILE *_chain;

  int _fileno;



  int _flags2;

  __off_t _old_offset;



  unsigned short _cur_column;
  signed char _vtable_offset;
  char _shortbuf[1];



  _IO_lock_t *_lock;

  __off64_t _offset;

  void *__pad1;
  void *__pad2;
  void *__pad3;
  void *__pad4;
  size_t __pad5;

  int _mode;

  char _unused2[15 * sizeof (int) - 4 * sizeof (void *) - sizeof (size_t)];

};


typedef struct _IO_FILE _IO_FILE;


struct _IO_FILE_plus;

extern struct _IO_FILE_plus _IO_2_1_stdin_;
extern struct _IO_FILE_plus _IO_2_1_stdout_;
extern struct _IO_FILE_plus _IO_2_1_stderr_;

typedef __ssize_t __io_read_fn (void *__cookie, char *__buf, size_t __nbytes);







typedef __ssize_t __io_write_fn (void *__cookie, const char *__buf,
     size_t __n);







typedef int __io_seek_fn (void *__cookie, __off64_t *__pos, int __w);


typedef int __io_close_fn (void *__cookie);

extern int __underflow (_IO_FILE *);
extern int __uflow (_IO_FILE *);
extern int __overflow (_IO_FILE *, int);

extern int _IO_getc (_IO_FILE *__fp);
extern int _IO_putc (int __c, _IO_FILE *__fp);
extern int _IO_feof (_IO_FILE *__fp) __attribute__ ((__nothrow__ , __leaf__));
extern int _IO_ferror (_IO_FILE *__fp) __attribute__ ((__nothrow__ , __leaf__));

extern int _IO_peekc_locked (_IO_FILE *__fp);





extern void _IO_flockfile (_IO_FILE *) __attribute__ ((__nothrow__ , __leaf__));
extern void _IO_funlockfile (_IO_FILE *) __attribute__ ((__nothrow__ , __leaf__));
extern int _IO_ftrylockfile (_IO_FILE *) __attribute__ ((__nothrow__ , __leaf__));

extern int _IO_vfscanf (_IO_FILE * __restrict, const char * __restrict,
   __gnuc_va_list, int *__restrict);
extern int _IO_vfprintf (_IO_FILE *__restrict, const char *__restrict,
    __gnuc_va_list);
extern __ssize_t _IO_padn (_IO_FILE *, int, __ssize_t);
extern size_t _IO_sgetn (_IO_FILE *, void *, size_t);

extern __off64_t _IO_seekoff (_IO_FILE *, __off64_t, int, int);
extern __off64_t _IO_seekpos (_IO_FILE *, __off64_t, int);

extern void _IO_free_backup_area (_IO_FILE *) __attribute__ ((__nothrow__ , __leaf__));





typedef __gnuc_va_list va_list;

typedef __off_t off_t;

typedef __ssize_t ssize_t;







typedef _G_fpos_t fpos_t;










extern struct _IO_FILE *stdin;
extern struct _IO_FILE *stdout;
extern struct _IO_FILE *stderr;







extern int remove (const char *__filename) __attribute__ ((__nothrow__ , __leaf__));

extern int rename (const char *__old, const char *__new) __attribute__ ((__nothrow__ , __leaf__));




extern int renameat (int __oldfd, const char *__old, int __newfd,
       const char *__new) __attribute__ ((__nothrow__ , __leaf__));








extern FILE *tmpfile (void) ;

extern char *tmpnam (char *__s) __attribute__ ((__nothrow__ , __leaf__)) ;





extern char *tmpnam_r (char *__s) __attribute__ ((__nothrow__ , __leaf__)) ;

extern char *tempnam (const char *__dir, const char *__pfx)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) ;








extern int fclose (FILE *__stream);




extern int fflush (FILE *__stream);


extern int fflush_unlocked (FILE *__stream);







extern FILE *fopen (const char *__restrict __filename,
      const char *__restrict __modes) ;




extern FILE *freopen (const char *__restrict __filename,
        const char *__restrict __modes,
        FILE *__restrict __stream) ;



extern FILE *fdopen (int __fd, const char *__modes) __attribute__ ((__nothrow__ , __leaf__)) ;

extern FILE *fmemopen (void *__s, size_t __len, const char *__modes)
  __attribute__ ((__nothrow__ , __leaf__)) ;




extern FILE *open_memstream (char **__bufloc, size_t *__sizeloc) __attribute__ ((__nothrow__ , __leaf__)) ;






extern void setbuf (FILE *__restrict __stream, char *__restrict __buf) __attribute__ ((__nothrow__ , __leaf__));



extern int setvbuf (FILE *__restrict __stream, char *__restrict __buf,
      int __modes, size_t __n) __attribute__ ((__nothrow__ , __leaf__));





extern void setbuffer (FILE *__restrict __stream, char *__restrict __buf,
         size_t __size) __attribute__ ((__nothrow__ , __leaf__));


extern void setlinebuf (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__));








extern int fprintf (FILE *__restrict __stream,
      const char *__restrict __format, ...);




extern int printf (const char *__restrict __format, ...);

extern int sprintf (char *__restrict __s,
      const char *__restrict __format, ...) __attribute__ ((__nothrow__));





extern int vfprintf (FILE *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg);




extern int vprintf (const char *__restrict __format, __gnuc_va_list __arg);

extern int vsprintf (char *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg) __attribute__ ((__nothrow__));





extern int snprintf (char *__restrict __s, size_t __maxlen,
       const char *__restrict __format, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 4)));

extern int vsnprintf (char *__restrict __s, size_t __maxlen,
        const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 0)));


extern int vdprintf (int __fd, const char *__restrict __fmt,
       __gnuc_va_list __arg)
     __attribute__ ((__format__ (__printf__, 2, 0)));
extern int dprintf (int __fd, const char *__restrict __fmt, ...)
     __attribute__ ((__format__ (__printf__, 2, 3)));








extern int fscanf (FILE *__restrict __stream,
     const char *__restrict __format, ...) ;




extern int scanf (const char *__restrict __format, ...) ;

extern int sscanf (const char *__restrict __s,
     const char *__restrict __format, ...) __attribute__ ((__nothrow__ , __leaf__));

extern int fscanf (FILE *__restrict __stream, const char *__restrict __format, ...) __asm__ ("" "__isoc99_fscanf")

                               ;
extern int scanf (const char *__restrict __format, ...) __asm__ ("" "__isoc99_scanf")
                              ;
extern int sscanf (const char *__restrict __s, const char *__restrict __format, ...) __asm__ ("" "__isoc99_sscanf") __attribute__ ((__nothrow__ , __leaf__))

                      ;









extern int vfscanf (FILE *__restrict __s, const char *__restrict __format,
      __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 2, 0))) ;





extern int vscanf (const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 1, 0))) ;


extern int vsscanf (const char *__restrict __s,
      const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__format__ (__scanf__, 2, 0)));

extern int vfscanf (FILE *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc99_vfscanf")



     __attribute__ ((__format__ (__scanf__, 2, 0))) ;
extern int vscanf (const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc99_vscanf")

     __attribute__ ((__format__ (__scanf__, 1, 0))) ;
extern int vsscanf (const char *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc99_vsscanf") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__format__ (__scanf__, 2, 0)));










extern int fgetc (FILE *__stream);
extern int getc (FILE *__stream);





extern int getchar (void);


extern int getc_unlocked (FILE *__stream);
extern int getchar_unlocked (void);

extern int fgetc_unlocked (FILE *__stream);











extern int fputc (int __c, FILE *__stream);
extern int putc (int __c, FILE *__stream);





extern int putchar (int __c);


extern int fputc_unlocked (int __c, FILE *__stream);







extern int putc_unlocked (int __c, FILE *__stream);
extern int putchar_unlocked (int __c);






extern int getw (FILE *__stream);


extern int putw (int __w, FILE *__stream);








extern char *fgets (char *__restrict __s, int __n, FILE *__restrict __stream)
     ;

extern char *gets (char *__s) __attribute__ ((__deprecated__));



extern __ssize_t __getdelim (char **__restrict __lineptr,
          size_t *__restrict __n, int __delimiter,
          FILE *__restrict __stream) ;
extern __ssize_t getdelim (char **__restrict __lineptr,
        size_t *__restrict __n, int __delimiter,
        FILE *__restrict __stream) ;







extern __ssize_t getline (char **__restrict __lineptr,
       size_t *__restrict __n,
       FILE *__restrict __stream) ;








extern int fputs (const char *__restrict __s, FILE *__restrict __stream);





extern int puts (const char *__s);






extern int ungetc (int __c, FILE *__stream);






extern size_t fread (void *__restrict __ptr, size_t __size,
       size_t __n, FILE *__restrict __stream) ;




extern size_t fwrite (const void *__restrict __ptr, size_t __size,
        size_t __n, FILE *__restrict __s);


extern size_t fread_unlocked (void *__restrict __ptr, size_t __size,
         size_t __n, FILE *__restrict __stream) ;
extern size_t fwrite_unlocked (const void *__restrict __ptr, size_t __size,
          size_t __n, FILE *__restrict __stream);








extern int fseek (FILE *__stream, long int __off, int __whence);




extern long int ftell (FILE *__stream) ;




extern void rewind (FILE *__stream);


extern int fseeko (FILE *__stream, __off_t __off, int __whence);




extern __off_t ftello (FILE *__stream) ;







extern int fgetpos (FILE *__restrict __stream, fpos_t *__restrict __pos);




extern int fsetpos (FILE *__stream, const fpos_t *__pos);





extern void clearerr (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__));

extern int feof (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) ;

extern int ferror (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) ;




extern void clearerr_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__));
extern int feof_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) ;
extern int ferror_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) ;








extern void perror (const char *__s);








extern int sys_nerr;
extern const char *const sys_errlist[];





extern int fileno (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) ;




extern int fileno_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) ;

extern FILE *popen (const char *__command, const char *__modes) ;





extern int pclose (FILE *__stream);





extern char *ctermid (char *__s) __attribute__ ((__nothrow__ , __leaf__));

extern void flockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__));



extern int ftrylockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) ;


extern void funlockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__));



static int __sym_vfprintf(FILE * param0, const char * param1, __gnuc_va_list param2, ...);
extern __inline __attribute__ ((__gnu_inline__)) int
vprintf (const char *__restrict __fmt, __gnuc_va_list __arg)
{
  return __sym_vfprintf (stdout, __fmt, __arg);
}



static int __sym__IO_getc(_IO_FILE * param0, ...);
extern __inline __attribute__ ((__gnu_inline__)) int
getchar (void)
{
  return __sym__IO_getc (stdin);
}




static int __sym___uflow(_IO_FILE * param0, ...);
extern __inline __attribute__ ((__gnu_inline__)) int
fgetc_unlocked (FILE *__fp)
{
  return (__builtin_expect (((__fp)->_IO_read_ptr >= (__fp)->_IO_read_end), 0) ? __sym___uflow (__fp) : *(unsigned char *) (__fp)->_IO_read_ptr++);
}





extern __inline __attribute__ ((__gnu_inline__)) int
getc_unlocked (FILE *__fp)
{
  return (__builtin_expect (((__fp)->_IO_read_ptr >= (__fp)->_IO_read_end), 0) ? __sym___uflow (__fp) : *(unsigned char *) (__fp)->_IO_read_ptr++);
}


extern __inline __attribute__ ((__gnu_inline__)) int
getchar_unlocked (void)
{
  return (__builtin_expect (((stdin)->_IO_read_ptr >= (stdin)->_IO_read_end), 0) ? __sym___uflow (stdin) : *(unsigned char *) (stdin)->_IO_read_ptr++);
}




static int __sym__IO_putc(int param0, _IO_FILE * param1, ...);
extern __inline __attribute__ ((__gnu_inline__)) int
putchar (int __c)
{
  return __sym__IO_putc (__c, stdout);
}




static int __sym___overflow(_IO_FILE * param0, int param1, ...);
extern __inline __attribute__ ((__gnu_inline__)) int
fputc_unlocked (int __c, FILE *__stream)
{
  return (__builtin_expect (((__stream)->_IO_write_ptr >= (__stream)->_IO_write_end), 0) ? __sym___overflow (__stream, (unsigned char) (__c)) : (unsigned char) (*(__stream)->_IO_write_ptr++ = (__c)));
}





extern __inline __attribute__ ((__gnu_inline__)) int
putc_unlocked (int __c, FILE *__stream)
{
  return (__builtin_expect (((__stream)->_IO_write_ptr >= (__stream)->_IO_write_end), 0) ? __sym___overflow (__stream, (unsigned char) (__c)) : (unsigned char) (*(__stream)->_IO_write_ptr++ = (__c)));
}


extern __inline __attribute__ ((__gnu_inline__)) int
putchar_unlocked (int __c)
{
  return (__builtin_expect (((stdout)->_IO_write_ptr >= (stdout)->_IO_write_end), 0) ? __sym___overflow (stdout, (unsigned char) (__c)) : (unsigned char) (*(stdout)->_IO_write_ptr++ = (__c)));
}

extern __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) feof_unlocked (FILE *__stream)
{
  return (((__stream)->_flags & 0x10) != 0);
}


extern __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) ferror_unlocked (FILE *__stream)
{
  return (((__stream)->_flags & 0x20) != 0);
}








typedef int wchar_t;











typedef enum
{
  P_ALL,
  P_PID,
  P_PGID
} idtype_t;





















static __inline unsigned int
__bswap_32 (unsigned int __bsx)
{
  return __builtin_bswap32 (__bsx);
}

static __inline __uint64_t
__bswap_64 (__uint64_t __bsx)
{
  return __builtin_bswap64 (__bsx);
}



union wait
  {
    int w_status;
    struct
      {

 unsigned int __w_termsig:7;
 unsigned int __w_coredump:1;
 unsigned int __w_retcode:8;
 unsigned int:16;







      } __wait_terminated;
    struct
      {

 unsigned int __w_stopval:8;
 unsigned int __w_stopsig:8;
 unsigned int:16;






      } __wait_stopped;
  };


typedef union
  {
    union wait *__uptr;
    int *__iptr;
  } __WAIT_STATUS __attribute__ ((__transparent_union__));



typedef struct
  {
    int quot;
    int rem;
  } div_t;



typedef struct
  {
    long int quot;
    long int rem;
  } ldiv_t;







__extension__ typedef struct
  {
    long long int quot;
    long long int rem;
  } lldiv_t;



extern size_t __ctype_get_mb_cur_max (void) __attribute__ ((__nothrow__ , __leaf__)) ;




extern double atof (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

extern int atoi (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

extern long int atol (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;





__extension__ extern long long int atoll (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;





extern double strtod (const char *__restrict __nptr,
        char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern float strtof (const char *__restrict __nptr,
       char **__restrict __endptr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern long double strtold (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern long int strtol (const char *__restrict __nptr,
   char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern unsigned long int strtoul (const char *__restrict __nptr,
      char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));




__extension__
extern long long int strtoq (const char *__restrict __nptr,
        char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtouq (const char *__restrict __nptr,
           char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





__extension__
extern long long int strtoll (const char *__restrict __nptr,
         char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr,
     char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



static long __sym_strtol(const char * param0, char ** param1, int param2, ...);
extern __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) atoi (const char *__nptr)
{
  return (int) __sym_strtol (__nptr, (char **) ((void *)0), 10);
}
extern __inline __attribute__ ((__gnu_inline__)) long int
__attribute__ ((__nothrow__ , __leaf__)) atol (const char *__nptr)
{
  return __sym_strtol (__nptr, (char **) ((void *)0), 10);
}




__extension__ static long long __sym_strtoll(const char * param0, char ** param1, int param2, ...);
extern __inline __attribute__ ((__gnu_inline__)) long long int
__attribute__ ((__nothrow__ , __leaf__)) atoll (const char *__nptr)
{
  return __sym_strtoll (__nptr, (char **) ((void *)0), 10);
}


extern char *l64a (long int __n) __attribute__ ((__nothrow__ , __leaf__)) ;


extern long int a64l (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;












typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;




typedef __loff_t loff_t;



typedef __ino_t ino_t;

typedef __dev_t dev_t;




typedef __gid_t gid_t;




typedef __mode_t mode_t;




typedef __nlink_t nlink_t;




typedef __uid_t uid_t;

typedef __pid_t pid_t;





typedef __id_t id_t;

typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;





typedef __key_t key_t;





typedef __clock_t clock_t;






typedef __time_t time_t;




typedef __clockid_t clockid_t;

typedef __timer_t timer_t;







typedef unsigned long int ulong;
typedef unsigned short int ushort;
typedef unsigned int uint;

typedef int int8_t __attribute__ ((__mode__ (__QI__)));
typedef int int16_t __attribute__ ((__mode__ (__HI__)));
typedef int int32_t __attribute__ ((__mode__ (__SI__)));
typedef int int64_t __attribute__ ((__mode__ (__DI__)));


typedef unsigned int u_int8_t __attribute__ ((__mode__ (__QI__)));
typedef unsigned int u_int16_t __attribute__ ((__mode__ (__HI__)));
typedef unsigned int u_int32_t __attribute__ ((__mode__ (__SI__)));
typedef unsigned int u_int64_t __attribute__ ((__mode__ (__DI__)));

typedef int register_t __attribute__ ((__mode__ (__word__)));












typedef int __sig_atomic_t;




typedef struct
  {
    unsigned long int __val[(1024 / (8 * sizeof (unsigned long int)))];
  } __sigset_t;




typedef __sigset_t sigset_t;







struct timespec
  {
    __time_t tv_sec;
    __syscall_slong_t tv_nsec;
  };




struct timeval
  {
    __time_t tv_sec;
    __suseconds_t tv_usec;
  };



typedef __suseconds_t suseconds_t;





typedef long int __fd_mask;

typedef struct
  {






    __fd_mask __fds_bits[1024 / (8 * (int) sizeof (__fd_mask))];


  } fd_set;






typedef __fd_mask fd_mask;



extern int select (int __nfds, fd_set *__restrict __readfds,
     fd_set *__restrict __writefds,
     fd_set *__restrict __exceptfds,
     struct timeval *__restrict __timeout);

extern int pselect (int __nfds, fd_set *__restrict __readfds,
      fd_set *__restrict __writefds,
      fd_set *__restrict __exceptfds,
      const struct timespec *__restrict __timeout,
      const __sigset_t *__restrict __sigmask);









__extension__
extern unsigned int gnu_dev_major (unsigned long long int __dev)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
__extension__
extern unsigned int gnu_dev_minor (unsigned long long int __dev)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
__extension__
extern unsigned long long int gnu_dev_makedev (unsigned int __major,
            unsigned int __minor)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


__extension__ extern __inline __attribute__ ((__gnu_inline__)) __attribute__ ((__const__)) unsigned int
__attribute__ ((__nothrow__ , __leaf__)) gnu_dev_major (unsigned long long int __dev)
{
  return ((__dev >> 8) & 0xfff) | ((unsigned int) (__dev >> 32) & ~0xfff);
}

__extension__ extern __inline __attribute__ ((__gnu_inline__)) __attribute__ ((__const__)) unsigned int
__attribute__ ((__nothrow__ , __leaf__)) gnu_dev_minor (unsigned long long int __dev)
{
  return (__dev & 0xff) | ((unsigned int) (__dev >> 12) & ~0xff);
}

__extension__ extern __inline __attribute__ ((__gnu_inline__)) __attribute__ ((__const__)) unsigned long long int
__attribute__ ((__nothrow__ , __leaf__)) gnu_dev_makedev (unsigned int __major, unsigned int __minor)
{
  return ((__minor & 0xff) | ((__major & 0xfff) << 8)
   | (((unsigned long long int) (__minor & ~0xff)) << 12)
   | (((unsigned long long int) (__major & ~0xfff)) << 32));
}








typedef __blksize_t blksize_t;






typedef __blkcnt_t blkcnt_t;



typedef __fsblkcnt_t fsblkcnt_t;



typedef __fsfilcnt_t fsfilcnt_t;






typedef unsigned long int pthread_t;


union pthread_attr_t
{
  char __size[56];
  long int __align;
};

typedef union pthread_attr_t pthread_attr_t;





typedef struct __pthread_internal_list
{
  struct __pthread_internal_list *__prev;
  struct __pthread_internal_list *__next;
} __pthread_list_t;

typedef union
{
  struct __pthread_mutex_s
  {
    int __lock;
    unsigned int __count;
    int __owner;

    unsigned int __nusers;



    int __kind;

    short __spins;
    short __elision;
    __pthread_list_t __list;

  } __data;
  char __size[40];
  long int __align;
} pthread_mutex_t;

typedef union
{
  char __size[4];
  int __align;
} pthread_mutexattr_t;




typedef union
{
  struct
  {
    int __lock;
    unsigned int __futex;
    __extension__ unsigned long long int __total_seq;
    __extension__ unsigned long long int __wakeup_seq;
    __extension__ unsigned long long int __woken_seq;
    void *__mutex;
    unsigned int __nwaiters;
    unsigned int __broadcast_seq;
  } __data;
  char __size[48];
  __extension__ long long int __align;
} pthread_cond_t;

typedef union
{
  char __size[4];
  int __align;
} pthread_condattr_t;



typedef unsigned int pthread_key_t;



typedef int pthread_once_t;





typedef union
{

  struct
  {
    int __lock;
    unsigned int __nr_readers;
    unsigned int __readers_wakeup;
    unsigned int __writer_wakeup;
    unsigned int __nr_readers_queued;
    unsigned int __nr_writers_queued;
    int __writer;
    int __shared;
    unsigned long int __pad1;
    unsigned long int __pad2;


    unsigned int __flags;

  } __data;

  char __size[56];
  long int __align;
} pthread_rwlock_t;

typedef union
{
  char __size[8];
  long int __align;
} pthread_rwlockattr_t;





typedef volatile int pthread_spinlock_t;




typedef union
{
  char __size[32];
  long int __align;
} pthread_barrier_t;

typedef union
{
  char __size[4];
  int __align;
} pthread_barrierattr_t;











extern long int random (void) __attribute__ ((__nothrow__ , __leaf__));


extern void srandom (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));





extern char *initstate (unsigned int __seed, char *__statebuf,
   size_t __statelen) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *setstate (char *__statebuf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







struct random_data
  {
    int32_t *fptr;
    int32_t *rptr;
    int32_t *state;
    int rand_type;
    int rand_deg;
    int rand_sep;
    int32_t *end_ptr;
  };

extern int random_r (struct random_data *__restrict __buf,
       int32_t *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern int srandom_r (unsigned int __seed, struct random_data *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

extern int initstate_r (unsigned int __seed, char *__restrict __statebuf,
   size_t __statelen,
   struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)));

extern int setstate_r (char *__restrict __statebuf,
         struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));






extern int rand (void) __attribute__ ((__nothrow__ , __leaf__));

extern void srand (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));




extern int rand_r (unsigned int *__seed) __attribute__ ((__nothrow__ , __leaf__));







extern double drand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern double erand48 (unsigned short int __xsubi[3]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern long int lrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern long int nrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern long int mrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern long int jrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void srand48 (long int __seedval) __attribute__ ((__nothrow__ , __leaf__));
extern unsigned short int *seed48 (unsigned short int __seed16v[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern void lcong48 (unsigned short int __param[7]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





struct drand48_data
  {
    unsigned short int __x[3];
    unsigned short int __old_x[3];
    unsigned short int __c;
    unsigned short int __init;
    __extension__ unsigned long long int __a;

  };


extern int drand48_r (struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int erand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int lrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int nrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int mrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int jrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int srand48_r (long int __seedval, struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

extern int seed48_r (unsigned short int __seed16v[3],
       struct drand48_data *__buffer) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern int lcong48_r (unsigned short int __param[7],
        struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));









extern void *malloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) ;

extern void *calloc (size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) ;










extern void *realloc (void *__ptr, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));

extern void free (void *__ptr) __attribute__ ((__nothrow__ , __leaf__));




extern void cfree (void *__ptr) __attribute__ ((__nothrow__ , __leaf__));














extern void *alloca (size_t __size) __attribute__ ((__nothrow__ , __leaf__));












extern void *valloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) ;




extern int posix_memalign (void **__memptr, size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;



extern void abort (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));



extern int atexit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern int on_exit (void (*__func) (int __status, void *__arg), void *__arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern void exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));













extern void _Exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));






extern char *getenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;


extern int putenv (char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern int setenv (const char *__name, const char *__value, int __replace)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));


extern int unsetenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern int clearenv (void) __attribute__ ((__nothrow__ , __leaf__));

extern char *mktemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern int mkstemp (char *__template) __attribute__ ((__nonnull__ (1))) ;

extern int mkstemps (char *__template, int __suffixlen) __attribute__ ((__nonnull__ (1))) ;

extern char *mkdtemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;






extern int system (const char *__command) ;


extern char *realpath (const char *__restrict __name,
         char *__restrict __resolved) __attribute__ ((__nothrow__ , __leaf__)) ;






typedef int (*__compar_fn_t) (const void *, const void *);




extern void *bsearch (const void *__key, const void *__base,
        size_t __nmemb, size_t __size, __compar_fn_t __compar)
     __attribute__ ((__nonnull__ (1, 2, 5))) ;




extern __inline __attribute__ ((__gnu_inline__)) void *
bsearch (const void *__key, const void *__base, size_t __nmemb, size_t __size,
  __compar_fn_t __compar)
{
  size_t __l, __u, __idx;
  const void *__p;
  int __comparison;

  __l = 0;
  __u = __nmemb;
  while (__l < __u)
    {
      __idx = (__l + __u) / 2;
      __p = (void *) (((const char *) __base) + (__idx * __size));
      __comparison = (*__compar) (__key, __p);
      if (__comparison < 0)
 __u = __idx;
      else if (__comparison > 0)
 __l = __idx + 1;
      else
 return (void *) __p;
    }

  return ((void *)0);
}





extern void qsort (void *__base, size_t __nmemb, size_t __size,
     __compar_fn_t __compar) __attribute__ ((__nonnull__ (1, 4)));

extern int abs (int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
extern long int labs (long int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;



__extension__ extern long long int llabs (long long int __x)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;







extern div_t div (int __numer, int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
extern ldiv_t ldiv (long int __numer, long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;




__extension__ extern lldiv_t lldiv (long long int __numer,
        long long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;


extern char *ecvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;




extern char *fcvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;




extern char *gcvt (double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3))) ;




extern char *qecvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;
extern char *qfcvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;
extern char *qgcvt (long double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3))) ;




extern int ecvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int fcvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));

extern int qecvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int qfcvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));






extern int mblen (const char *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int mbtowc (wchar_t *__restrict __pwc,
     const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int wctomb (char *__s, wchar_t __wchar) __attribute__ ((__nothrow__ , __leaf__));



extern size_t mbstowcs (wchar_t *__restrict __pwcs,
   const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));

extern size_t wcstombs (char *__restrict __s,
   const wchar_t *__restrict __pwcs, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__));








extern int rpmatch (const char *__response) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;

extern int getsubopt (char **__restrict __optionp,
        char *const *__restrict __tokens,
        char **__restrict __valuep)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2, 3))) ;

extern int getloadavg (double __loadavg[], int __nelem)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





static double __sym_strtod(const char * param0, char ** param1, ...);
extern __inline __attribute__ ((__gnu_inline__)) double
__attribute__ ((__nothrow__ , __leaf__)) atof (const char *__nptr)
{
  return __sym_strtod (__nptr, (char **) ((void *)0));
}

















extern void *memcpy (void *__restrict __dest, const void *__restrict __src,
       size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void *memmove (void *__dest, const void *__src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));






extern void *memccpy (void *__restrict __dest, const void *__restrict __src,
        int __c, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));





extern void *memset (void *__s, int __c, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern void *memchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));





extern char *strcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strcat (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncat (char *__restrict __dest, const char *__restrict __src,
        size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcoll (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern size_t strxfrm (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));








typedef struct __locale_struct
{

  struct __locale_data *__locales[13];


  const unsigned short int *__ctype_b;
  const int *__ctype_tolower;
  const int *__ctype_toupper;


  const char *__names[13];
} *__locale_t;


typedef __locale_t locale_t;



extern int strcoll_l (const char *__s1, const char *__s2, __locale_t __l)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));

extern size_t strxfrm_l (char *__dest, const char *__src, size_t __n,
    __locale_t __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)));





extern char *strdup (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));






extern char *strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));



extern char *strchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));

extern char *strrchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));






extern size_t strcspn (const char *__s, const char *__reject)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern size_t strspn (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strpbrk (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strstr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strtok (char *__restrict __s, const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));




extern char *__strtok_r (char *__restrict __s,
    const char *__restrict __delim,
    char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));

extern char *strtok_r (char *__restrict __s, const char *__restrict __delim,
         char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));



extern size_t strlen (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));





extern size_t strnlen (const char *__string, size_t __maxlen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));





extern char *strerror (int __errnum) __attribute__ ((__nothrow__ , __leaf__));


extern int strerror_r (int __errnum, char *__buf, size_t __buflen) __asm__ ("" "__xpg_strerror_r") __attribute__ ((__nothrow__ , __leaf__))

                        __attribute__ ((__nonnull__ (2)));

extern char *strerror_l (int __errnum, __locale_t __l) __attribute__ ((__nothrow__ , __leaf__));





extern void __bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern void bcopy (const void *__src, void *__dest, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int bcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *index (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));

extern char *rindex (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern int ffs (int __i) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));

extern int strcasecmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strncasecmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strsep (char **__restrict __stringp,
       const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strsignal (int __sig) __attribute__ ((__nothrow__ , __leaf__));


extern char *__stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



extern char *__stpncpy (char *__restrict __dest,
   const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));







extern void *__rawmemchr (const void *__s, int __c);

extern __inline __attribute__ ((__gnu_inline__)) size_t __strcspn_c1 (const char *__s, int __reject);
extern __inline __attribute__ ((__gnu_inline__)) size_t
__strcspn_c1 (const char *__s, int __reject)
{
  size_t __result = 0;
  while (__s[__result] != '\0' && __s[__result] != __reject)
    ++__result;
  return __result;
}

extern __inline __attribute__ ((__gnu_inline__)) size_t __strcspn_c2 (const char *__s, int __reject1,
         int __reject2);
extern __inline __attribute__ ((__gnu_inline__)) size_t
__strcspn_c2 (const char *__s, int __reject1, int __reject2)
{
  size_t __result = 0;
  while (__s[__result] != '\0' && __s[__result] != __reject1
  && __s[__result] != __reject2)
    ++__result;
  return __result;
}

extern __inline __attribute__ ((__gnu_inline__)) size_t __strcspn_c3 (const char *__s, int __reject1,
         int __reject2, int __reject3);
extern __inline __attribute__ ((__gnu_inline__)) size_t
__strcspn_c3 (const char *__s, int __reject1, int __reject2,
       int __reject3)
{
  size_t __result = 0;
  while (__s[__result] != '\0' && __s[__result] != __reject1
  && __s[__result] != __reject2 && __s[__result] != __reject3)
    ++__result;
  return __result;
}

extern __inline __attribute__ ((__gnu_inline__)) size_t __strspn_c1 (const char *__s, int __accept);
extern __inline __attribute__ ((__gnu_inline__)) size_t
__strspn_c1 (const char *__s, int __accept)
{
  size_t __result = 0;

  while (__s[__result] == __accept)
    ++__result;
  return __result;
}

extern __inline __attribute__ ((__gnu_inline__)) size_t __strspn_c2 (const char *__s, int __accept1,
        int __accept2);
extern __inline __attribute__ ((__gnu_inline__)) size_t
__strspn_c2 (const char *__s, int __accept1, int __accept2)
{
  size_t __result = 0;

  while (__s[__result] == __accept1 || __s[__result] == __accept2)
    ++__result;
  return __result;
}

extern __inline __attribute__ ((__gnu_inline__)) size_t __strspn_c3 (const char *__s, int __accept1,
        int __accept2, int __accept3);
extern __inline __attribute__ ((__gnu_inline__)) size_t
__strspn_c3 (const char *__s, int __accept1, int __accept2, int __accept3)
{
  size_t __result = 0;

  while (__s[__result] == __accept1 || __s[__result] == __accept2
  || __s[__result] == __accept3)
    ++__result;
  return __result;
}

extern __inline __attribute__ ((__gnu_inline__)) char *__strpbrk_c2 (const char *__s, int __accept1,
        int __accept2);
extern __inline __attribute__ ((__gnu_inline__)) char *
__strpbrk_c2 (const char *__s, int __accept1, int __accept2)
{

  while (*__s != '\0' && *__s != __accept1 && *__s != __accept2)
    ++__s;
  return *__s == '\0' ? ((void *)0) : (char *) (size_t) __s;
}

extern __inline __attribute__ ((__gnu_inline__)) char *__strpbrk_c3 (const char *__s, int __accept1,
        int __accept2, int __accept3);
extern __inline __attribute__ ((__gnu_inline__)) char *
__strpbrk_c3 (const char *__s, int __accept1, int __accept2, int __accept3)
{

  while (*__s != '\0' && *__s != __accept1 && *__s != __accept2
  && *__s != __accept3)
    ++__s;
  return *__s == '\0' ? ((void *)0) : (char *) (size_t) __s;
}

extern __inline __attribute__ ((__gnu_inline__)) char *__strtok_r_1c (char *__s, char __sep, char **__nextp);
extern __inline __attribute__ ((__gnu_inline__)) char *
__strtok_r_1c (char *__s, char __sep, char **__nextp)
{
  char *__result;
  if (__s == ((void *)0))
    __s = *__nextp;
  while (*__s == __sep)
    ++__s;
  __result = ((void *)0);
  if (*__s != '\0')
    {
      __result = __s++;
      while (*__s != '\0')
 if (*__s++ == __sep)
   {
     __s[-1] = '\0';
     break;
   }
    }
  *__nextp = __s;
  return __result;
}

extern char *__strsep_g (char **__stringp, const char *__delim);

extern __inline __attribute__ ((__gnu_inline__)) char *__strsep_1c (char **__s, char __reject);
static void * __sym___rawmemchr(const void * param0, int param1, ...);
extern __inline __attribute__ ((__gnu_inline__)) char *
__strsep_1c (char **__s, char __reject)
{
  char *__retval = *__s;
  if (__retval != ((void *)0) && (*__s = (__extension__ (__builtin_constant_p (__reject) && !__builtin_constant_p (__retval) && (__reject) == '\0' ? (char *) __sym___rawmemchr (__retval, __reject) : __builtin_strchr (__retval, __reject)))) != ((void *)0))
    *(*__s)++ = '\0';
  return __retval;
}

extern __inline __attribute__ ((__gnu_inline__)) char *__strsep_2c (char **__s, char __reject1, char __reject2);
extern __inline __attribute__ ((__gnu_inline__)) char *
__strsep_2c (char **__s, char __reject1, char __reject2)
{
  char *__retval = *__s;
  if (__retval != ((void *)0))
    {
      char *__cp = __retval;
      while (1)
 {
   if (*__cp == '\0')
     {
       __cp = ((void *)0);
   break;
     }
   if (*__cp == __reject1 || *__cp == __reject2)
     {
       *__cp++ = '\0';
       break;
     }
   ++__cp;
 }
      *__s = __cp;
    }
  return __retval;
}

extern __inline __attribute__ ((__gnu_inline__)) char *__strsep_3c (char **__s, char __reject1, char __reject2,
       char __reject3);
extern __inline __attribute__ ((__gnu_inline__)) char *
__strsep_3c (char **__s, char __reject1, char __reject2, char __reject3)
{
  char *__retval = *__s;
  if (__retval != ((void *)0))
    {
      char *__cp = __retval;
      while (1)
 {
   if (*__cp == '\0')
     {
       __cp = ((void *)0);
   break;
     }
   if (*__cp == __reject1 || *__cp == __reject2 || *__cp == __reject3)
     {
       *__cp++ = '\0';
       break;
     }
   ++__cp;
 }
      *__s = __cp;
    }
  return __retval;
}

extern char *__strdup (const char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__));

extern char *__strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__));







typedef enum { false = 0, true = 1 } at_bool;

typedef char *at_string;


typedef void *at_address;


typedef float at_real;


typedef struct _at_coord
{
  unsigned short x, y;
} at_coord;

typedef struct _at_real_coord
{
  at_real x, y, z;
} at_real_coord;





typedef struct _at_fitting_opts_type at_fitting_opts_type;
typedef struct _at_input_opts_type at_input_opts_type;
typedef struct _at_output_opts_type at_output_opts_type;
typedef struct _at_bitmap_type at_bitmap_type;
typedef struct _at_color_type at_color_type;
typedef enum _at_polynomial_degree at_polynomial_degree;
typedef struct _at_spline_type at_spline_type;
typedef struct _at_spline_list_type at_spline_list_type;
typedef struct _at_spline_list_array_type at_spline_list_array_type;

typedef enum _at_msg_type at_msg_type;


struct _at_color_type
{
  unsigned char r;
  unsigned char g;
  unsigned char b;
};


enum _at_polynomial_degree
{
  AT_LINEARTYPE = 1,
  AT_QUADRATICTYPE = 2,
  AT_CUBICTYPE = 3,
  AT_PARALLELELLIPSETYPE = 4,
  AT_ELLIPSETYPE = 5,
  AT_CIRCLETYPE = 6


};






struct _at_spline_type
{
  at_real_coord v[4];
  at_polynomial_degree degree;
  at_real linearity;
};



struct _at_spline_list_type
{
  at_spline_type *data;
  unsigned length;
  at_bool clockwise;
  at_color_type color;
  at_bool open;
};



struct _at_spline_list_array_type
{
  at_spline_list_type *data;
  unsigned length;


  unsigned short height, width;



  at_color_type * background_color;
  at_bool centerline;
  at_bool preserve_width;
  at_real width_weight_factor;

};




struct _at_fitting_opts_type
{




  at_color_type *background_color;





  unsigned color_count;





  at_real corner_always_threshold;





  unsigned corner_surround;





  at_real corner_threshold;




  at_real error_threshold;




  unsigned filter_iterations;





  at_real line_reversion_threshold;





  at_real line_threshold;




  at_bool remove_adjacent_corners;





  unsigned tangent_surround;



  unsigned despeckle_level;



  at_real despeckle_tightness;



  at_bool centerline;




  at_bool preserve_width;



  at_real width_weight_factor;
};

struct _at_input_opts_type
{
  at_color_type *background_color;
};

struct _at_output_opts_type
{
  int dpi;
};

struct _at_bitmap_type
{
  unsigned short height;
  unsigned short width;
  unsigned char *bitmap;
  unsigned int np;
};

enum _at_msg_type
{
  AT_MSG_FATAL = 1,
  AT_MSG_WARNING,
};

typedef
void (* at_msg_func) (at_string msg, at_msg_type msg_type, at_address client_data);





typedef
at_bitmap_type (*at_input_read_func) (at_string name,
     at_input_opts_type * opts,
     at_msg_func msg_func,
     at_address msg_data);

typedef
int (*at_output_write_func) (FILE*, at_string name,
     int llx, int lly,
     int urx, int ury,
     at_output_opts_type * opts,
     at_spline_list_array_type shape,
     at_msg_func msg_func,
     at_address msg_data);





typedef void (* at_progress_func) (at_real percentage,
      at_address client_data);





typedef at_bool (* at_testcancel_func) (at_address client_data);

at_fitting_opts_type * at_fitting_opts_new(void);
at_fitting_opts_type * at_fitting_opts_copy (at_fitting_opts_type * original);
void at_fitting_opts_free(at_fitting_opts_type * opts);

at_input_opts_type * at_input_opts_new(void);
at_input_opts_type * at_input_opts_copy(at_input_opts_type * original);
void at_input_opts_free(at_input_opts_type * opts);






at_output_opts_type * at_output_opts_new(void);
at_output_opts_type * at_output_opts_copy(at_output_opts_type * original);
void at_output_opts_free(at_output_opts_type * opts);

at_bitmap_type * at_bitmap_read (at_input_read_func input_reader,
     at_string filename,
     at_input_opts_type * opts,
     at_msg_func msg_func, at_address msg_data);
at_bitmap_type * at_bitmap_new(unsigned short width,
          unsigned short height,
          unsigned int planes);
at_bitmap_type * at_bitmap_copy(at_bitmap_type * src);




unsigned short at_bitmap_get_width (at_bitmap_type * bitmap);
unsigned short at_bitmap_get_height (at_bitmap_type * bitmap);
unsigned short at_bitmap_get_planes (at_bitmap_type * bitmap);
void at_bitmap_free (at_bitmap_type * bitmap);

at_spline_list_array_type * at_splines_new (at_bitmap_type * bitmap,
      at_fitting_opts_type * opts,
      at_msg_func msg_func, at_address msg_data);

at_spline_list_array_type * at_splines_new_full (at_bitmap_type * bitmap,
           at_fitting_opts_type * opts,
           at_msg_func msg_func,
           at_address msg_data,
           at_progress_func notify_progress,
           at_address progress_data,
           at_testcancel_func test_cancel,
           at_address testcancel_data);

void at_splines_write(at_output_write_func output_writer,
    FILE * writeto,
    at_string file_name,
    at_output_opts_type * opts,
    at_spline_list_array_type * splines,
    at_msg_func msg_func, at_address msg_data);

void at_splines_free (at_spline_list_array_type * splines);




at_color_type * at_color_new (unsigned char r,
    unsigned char g,
           unsigned char b);
at_color_type * at_color_copy (at_color_type * original);
at_bool at_color_equal (at_color_type * c1, at_color_type * c2);
void at_color_free (at_color_type * color);




at_input_read_func at_input_get_handler (at_string filename);
at_input_read_func at_input_get_handler_by_suffix (at_string suffix);

char ** at_input_list_new (void);
void at_input_list_free(char ** list);



char * at_input_shortlist (void);




at_output_write_func at_output_get_handler (at_string filename);
at_output_write_func at_output_get_handler_by_suffix (at_string suffix);
char ** at_output_list_new (void);
void at_output_list_free(char ** list);



char * at_output_shortlist (void);

const char * at_version (at_bool long_format);




const char * at_home_site (void);





typedef struct _at_exception_type at_exception_type;
struct _at_exception_type
{
  at_msg_type msg_type;
  at_msg_func client_func;
  at_address * client_data;
};

at_exception_type at_exception_new(at_msg_func client_func,
       at_address client_data);
at_bool at_exception_got_fatal(at_exception_type * exception);
void at_exception_fatal(at_exception_type * exception,
   const at_string message);
void at_exception_warning(at_exception_type * exception,
     const at_string message);


extern int at_input_add_handler (at_string suffix,
     at_string description,
     at_input_read_func func);

extern at_bitmap_type at_bitmap_init(unsigned char * area,
         unsigned short width,
         unsigned short height,
         unsigned int planes);




typedef at_bitmap_type bitmap_type;

extern bitmap_type new_bitmap (unsigned short width, unsigned short height);


extern void free_bitmap (bitmap_type *);










FILE *at_log_file;



extern void flush_log_output (void);









extern void __assert_fail (const char *__assertion, const char *__file,
      unsigned int __line, const char *__function)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));


extern void __assert_perror_fail (int __errnum, const char *__file,
      unsigned int __line, const char *__function)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));




extern void __assert (const char *__assertion, const char *__file, int __line)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern FILE *xfopen (at_string filename, at_string mode);
extern void xfclose (FILE *, at_string filename);
extern void xfseek (FILE *, long, int, at_string filename);



at_bitmap_type input_bmp_reader (at_string filename,
     at_input_opts_type * opts,
     at_msg_func msg_func,
     at_address msg_data);


struct Bitmap_File_Head_Struct
{
  char zzMagic[2];
  unsigned long bfSize;
  unsigned short zzHotX;
  unsigned short zzHotY;
  unsigned long bfOffs;
  unsigned long biSize;
} Bitmap_File_Head;

struct Bitmap_Head_Struct
{
  unsigned long biWidth;
  unsigned long biHeight;
  unsigned short biPlanes;
  unsigned short biBitCnt;
  unsigned long biCompr;
  unsigned long biSizeIm;
  unsigned long biXPels;
  unsigned long biYPels;
  unsigned long biClrUsed;
  unsigned long biClrImp;

} Bitmap_Head;

static long ToL (unsigned char *);
static short ToS (unsigned char *);
static int ReadColorMap (FILE *,
       unsigned char[256][3],
       int,
       int,
       int *,
      at_exception_type *);
static unsigned char *ReadImage (FILE *,
       int,
       int,
       unsigned char[256][3],
       int,
       int,
       int,
       int);

static struct _at_bitmap_type __sym_at_bitmap_init(unsigned char * param0, unsigned short param1, unsigned short param2, unsigned int param3, ...);
static struct _at_exception_type __sym_at_exception_new(void * param0, at_address param1, ...);
static struct _IO_FILE * __sym_fopen(const char * param0, const char * param1, ...);
static int __sym_fprintf(FILE * param0, const char * param1, ...);
static void __sym_at_exception_fatal(at_exception_type * param0, at_string param1, ...);
static unsigned long __sym_fread(void * param0, size_t param1, size_t param2, FILE * param3, ...);
static unsigned long __sym_strlen(const char * param0, ...);
static int __sym_strncmp(const char * param0, const char * param1, size_t param2, ...);
static long __sym_ToL(unsigned char * param0, ...);
static short __sym_ToS(unsigned char * param0, ...);
static int __sym_fputs(const char * param0, FILE * param1, ...);
static int __sym_ReadColorMap(FILE * param0, unsigned char param1[][3], int param2, int param3, int * param4, at_exception_type * param5, ...);
static at_bool __sym_at_exception_got_fatal(at_exception_type * param0, ...);
static unsigned char * __sym_ReadImage(FILE * param0, int param1, int param2, unsigned char param3[][3], int param4, int param5, int param6, int param7, ...);
static int __sym_fclose(FILE * param0, ...);
at_bitmap_type
input_bmp_reader (at_string filename,
    at_input_opts_type * opts,
    at_msg_func msg_func,
    at_address msg_data)
{
  FILE *fd;
  unsigned char buffer[64];
  int ColormapSize, rowbytes, Maps, Grey;
  unsigned char ColorMap[256][3];
  at_bitmap_type image = __sym_at_bitmap_init(0, 0, 0, 1);
  unsigned char * image_storage;
  at_exception_type exp = __sym_at_exception_new(msg_func, msg_data);

  fd = __sym_fopen (filename, "rb");

  if (!fd)
    {
      do { if (at_log_file) __sym_fprintf (at_log_file, "Can't open \"%s\"\n", filename); } while (0);
      __sym_at_exception_fatal(&exp, "bmp: cannot open input file");
      return image;
    }




  if (!(__sym_fread(buffer, 18, 1, fd) != 0) || ((__extension__ (__builtin_constant_p (2) && ((__builtin_constant_p ((const char *)buffer) && __sym_strlen ((const char *)buffer) < ((size_t) (2))) || (__builtin_constant_p ("BM") && __sym_strlen ("BM") < ((size_t) (2)))) ? __extension__ ({ size_t __s1_len, __s2_len; (__builtin_constant_p ((const char *)buffer) && __builtin_constant_p ("BM") && (__s1_len = __builtin_strlen ((const char *)buffer), __s2_len = __builtin_strlen ("BM"), (!((size_t)(const void *)(((const char *)buffer) + 1) - (size_t)(const void *)((const char *)buffer) == 1) || __s1_len >= 4) && (!((size_t)(const void *)(("BM") + 1) - (size_t)(const void *)("BM") == 1) || __s2_len >= 4)) ? __builtin_strcmp ((const char *)buffer, "BM") : (__builtin_constant_p ((const char *)buffer) && ((size_t)(const void *)(((const char *)buffer) + 1) - (size_t)(const void *)((const char *)buffer) == 1) && (__s1_len = __builtin_strlen ((const char *)buffer), __s1_len < 4) ? (__builtin_constant_p ("BM") && ((size_t)(const void *)(("BM") + 1) - (size_t)(const void *)("BM") == 1) ? __builtin_strcmp ((const char *)buffer, "BM") : (__extension__ ({ const unsigned char *__s2 = (const unsigned char *) (const char *) ("BM"); int __result = (((const unsigned char *) (const char *) ((const char *)buffer))[0] - __s2[0]); if (__s1_len > 0 && __result == 0) { __result = (((const unsigned char *) (const char *) ((const char *)buffer))[1] - __s2[1]); if (__s1_len > 1 && __result == 0) { __result = (((const unsigned char *) (const char *) ((const char *)buffer))[2] - __s2[2]); if (__s1_len > 2 && __result == 0) __result = (((const unsigned char *) (const char *) ((const char *)buffer))[3] - __s2[3]); } } __result; }))) : (__builtin_constant_p ("BM") && ((size_t)(const void *)(("BM") + 1) - (size_t)(const void *)("BM") == 1) && (__s2_len = __builtin_strlen ("BM"), __s2_len < 4) ? (__builtin_constant_p ((const char *)buffer) && ((size_t)(const void *)(((const char *)buffer) + 1) - (size_t)(const void *)((const char *)buffer) == 1) ? __builtin_strcmp ((const char *)buffer, "BM") : (- (__extension__ ({ const unsigned char *__s2 = (const unsigned char *) (const char *) ((const char *)buffer); int __result = (((const unsigned char *) (const char *) ("BM"))[0] - __s2[0]); if (__s2_len > 0 && __result == 0) { __result = (((const unsigned char *) (const char *) ("BM"))[1] - __s2[1]); if (__s2_len > 1 && __result == 0) { __result = (((const unsigned char *) (const char *) ("BM"))[2] - __s2[2]); if (__s2_len > 2 && __result == 0) __result = (((const unsigned char *) (const char *) ("BM"))[3] - __s2[3]); } } __result; })))) : __builtin_strcmp ((const char *)buffer, "BM")))); }) : __sym_strncmp ((const char *)buffer, "BM", 2)))))
    {
      do { if (at_log_file) __sym_fprintf (at_log_file, "Not a valid BMP file %s\n", filename); } while (0);
      __sym_at_exception_fatal(&exp, "bmp: invalid input file");
      goto cleanup;
    }



  Bitmap_File_Head.bfSize = __sym_ToL (&buffer[0x02]);
  Bitmap_File_Head.zzHotX = __sym_ToS (&buffer[0x06]);
  Bitmap_File_Head.zzHotY = __sym_ToS (&buffer[0x08]);
  Bitmap_File_Head.bfOffs = __sym_ToL (&buffer[0x0a]);
  Bitmap_File_Head.biSize = __sym_ToL (&buffer[0x0e]);



  if (Bitmap_File_Head.biSize == 12)
    {
      if (!(__sym_fread(buffer, 8, 1, fd) != 0))
 {
   do { if (at_log_file) __sym_fputs ("Error reading BMP file header\n", at_log_file); } while (0);
   __sym_at_exception_fatal(&exp, "Error reading BMP file header");
   goto cleanup;
 }

      Bitmap_Head.biWidth = __sym_ToS (&buffer[0x00]);
      Bitmap_Head.biHeight = __sym_ToS (&buffer[0x02]);
      Bitmap_Head.biPlanes = __sym_ToS (&buffer[0x04]);
      Bitmap_Head.biBitCnt = __sym_ToS (&buffer[0x06]);
      Bitmap_Head.biCompr = 0;
      Bitmap_Head.biSizeIm = 0;
      Bitmap_Head.biXPels = Bitmap_Head.biYPels = 0;
      Bitmap_Head.biClrUsed = 0;
      Maps = 3;
    }
   else if (Bitmap_File_Head.biSize == 40)
    {
      if (!(__sym_fread(buffer, Bitmap_File_Head.biSize - 4, 1, fd) != 0))
 {
   do { if (at_log_file) __sym_fputs ("Error reading BMP file header\n", at_log_file); } while (0);
   __sym_at_exception_fatal(&exp, "Error reading BMP file header");
   goto cleanup;
 }


      Bitmap_Head.biWidth =__sym_ToL (&buffer[0x00]);
      Bitmap_Head.biHeight =__sym_ToL (&buffer[0x04]);
      Bitmap_Head.biPlanes =__sym_ToS (&buffer[0x08]);
      Bitmap_Head.biBitCnt =__sym_ToS (&buffer[0x0A]);
      Bitmap_Head.biCompr =__sym_ToL (&buffer[0x0C]);
      Bitmap_Head.biSizeIm =__sym_ToL (&buffer[0x10]);
      Bitmap_Head.biXPels =__sym_ToL (&buffer[0x14]);
      Bitmap_Head.biYPels =__sym_ToL (&buffer[0x18]);
      Bitmap_Head.biClrUsed =__sym_ToL (&buffer[0x1C]);
      Bitmap_Head.biClrImp =__sym_ToL (&buffer[0x20]);

      Maps = 4;
    }
  else if (Bitmap_File_Head.biSize <= 64)
    {
      if (!(__sym_fread(buffer, Bitmap_File_Head.biSize - 4, 1, fd) != 0))
 {
   do { if (at_log_file) __sym_fputs ("Error reading BMP file header\n", at_log_file); } while (0);
   __sym_at_exception_fatal(&exp, "Error reading BMP file header");
   goto cleanup;
 }

      Bitmap_Head.biWidth =__sym_ToL (&buffer[0x00]);
      Bitmap_Head.biHeight =__sym_ToL (&buffer[0x04]);
      Bitmap_Head.biPlanes =__sym_ToS (&buffer[0x08]);
      Bitmap_Head.biBitCnt =__sym_ToS (&buffer[0x0A]);
      Bitmap_Head.biCompr =__sym_ToL (&buffer[0x0C]);
      Bitmap_Head.biSizeIm =__sym_ToL (&buffer[0x10]);
      Bitmap_Head.biXPels =__sym_ToL (&buffer[0x14]);
      Bitmap_Head.biYPels =__sym_ToL (&buffer[0x18]);
      Bitmap_Head.biClrUsed =__sym_ToL (&buffer[0x1C]);
      Bitmap_Head.biClrImp =__sym_ToL (&buffer[0x20]);

      Maps = 3;
    }
  else
    {
      do { if (at_log_file) __sym_fputs ("Error reading BMP file header\n", at_log_file); } while (0);
      __sym_at_exception_fatal(&exp, "Error reading BMP file header");
      goto cleanup;
    }






  ColormapSize = (Bitmap_File_Head.bfOffs - Bitmap_File_Head.biSize - 14) / Maps;

  if ((Bitmap_Head.biClrUsed == 0) && (Bitmap_Head.biBitCnt <= 8))
    Bitmap_Head.biClrUsed = ColormapSize;



  if ((Bitmap_Head.biHeight == 0 || Bitmap_Head.biWidth == 0)
      || (Bitmap_Head.biPlanes != 1)
      || (ColormapSize > 256 || Bitmap_Head.biClrUsed > 256))
    {
      do { if (at_log_file) __sym_fputs ("Error reading BMP file header\n", at_log_file); } while (0);
      __sym_at_exception_fatal(&exp, "Error reading BMP file header");
      goto cleanup;
    }





  rowbytes= ( (Bitmap_Head.biWidth * Bitmap_Head.biBitCnt - 1) / 32) * 4 + 4;

  __sym_ReadColorMap (fd, ColorMap, ColormapSize, Maps, &Grey, &exp);
  if (__sym_at_exception_got_fatal(&exp))
    goto cleanup;






  image_storage = __sym_ReadImage (fd,
        Bitmap_Head.biWidth, Bitmap_Head.biHeight,
        ColorMap,
        Bitmap_Head.biBitCnt,
        Bitmap_Head.biCompr,
        rowbytes,
        Grey);
  image = __sym_at_bitmap_init(image_storage,
    (unsigned short) Bitmap_Head.biWidth,
    (unsigned short) Bitmap_Head.biHeight,
    Grey ? 1 : 3);
 cleanup:
  __sym_fclose (fd);
  return (image);
}

static int
ReadColorMap (FILE *fd,
       unsigned char buffer[256][3],
       int number,
       int size,
       int *grey,
       at_exception_type * exp)
{
  int i;
  unsigned char rgb[4];

  *grey=(number>2);
  for (i = 0; i < number ; i++)
    {
      if (!(__sym_fread(rgb, size, 1, fd) != 0))
 {
   do { if (at_log_file) __sym_fputs ("Bad colormap\n", at_log_file); } while (0);
   __sym_at_exception_fatal (exp, "Bad colormap");
   goto cleanup;
 }



      buffer[i][0] = rgb[2];
      buffer[i][1] = rgb[1];
      buffer[i][2] = rgb[0];
      *grey = ((*grey) && (rgb[0]==rgb[1]) && (rgb[1]==rgb[2]));
    }
 cleanup:
  return 0;
}

static void __sym___assert_fail(const char * param0, const char * param1, unsigned int param2, const char * param3, ...);
static void __sym_free(void * param0, ...);
static unsigned char*
ReadImage (FILE *fd,
    int width,
    int height,
    unsigned char cmap[128][3],
    int bpp,
    int compression,
    int rowbytes,
    int grey)
{
  unsigned char v,howmuch;
  int xpos = 0, ypos = 0;
  unsigned char *image;
  unsigned char *temp, *temp2, *buffer;
  long rowstride, channels;
  unsigned short rgb;
  int i, j, notused;

  if (bpp >= 16)
    {
      do { image = (at_address) malloc (width * height * 3 * sizeof (unsigned char)); ((image) ? (void) (0) : __sym___assert_fail ("image", "input-bmp.c", 309, __PRETTY_FUNCTION__)); } while (0);
      channels = 3;
    }
  else if (grey)
    {
      do { image = (at_address) malloc (width * height * 1 * sizeof (unsigned char)); ((image) ? (void) (0) : __sym___assert_fail ("image", "input-bmp.c", 314, __PRETTY_FUNCTION__)); } while (0);
   channels = 1;
 }
  else
 {
      do { image = (at_address) malloc (width * height * 1 * sizeof (unsigned char)); ((image) ? (void) (0) : __sym___assert_fail ("image", "input-bmp.c", 319, __PRETTY_FUNCTION__)); } while (0);
   channels = 1;
 }

  do { buffer = (at_address) malloc (rowbytes); ((buffer) ? (void) (0) : __sym___assert_fail ("buffer", "input-bmp.c", 323, __PRETTY_FUNCTION__)); } while (0);
  rowstride = width * channels;

  ypos = height - 1;
  temp2 = malloc(128);
  temp2[0] = temp2[1] = 128;
  temp2[2] = temp2[3] = 256;
  switch (bpp) {

  case 32:
    {
      while ((__sym_fread(buffer, rowbytes, 1, fd) != 0))
        {
          temp = image + (ypos * rowstride);
          for (xpos= 0; xpos < width; ++xpos)
            {
               *(temp++)= buffer[xpos * 4 + 2];
               *(temp++)= buffer[xpos * 4 + 1];
               *(temp++)= buffer[xpos * 4];
            }
          --ypos;
        }
    }
 break;

  case 24:
    {
      while ((__sym_fread(buffer, rowbytes, 1, fd) != 0))
        {
          temp = image + (ypos * rowstride);
          for (xpos= 0; xpos < width; ++xpos)
            {
               *(temp++)= buffer[xpos * 3 + 2];
               *(temp++)= buffer[xpos * 3 + 1];
               *(temp++)= buffer[xpos * 3];
            }
          --ypos;
        }
 }
    break;

  case 16:
    {
      while ((__sym_fread(buffer, rowbytes, 1, fd) != 0))
        {
          temp = image + (ypos * rowstride);
          for (xpos= 0; xpos < width; ++xpos)
            {
               rgb= __sym_ToS(&buffer[xpos * 2]);
               *(temp++)= (unsigned char)(((rgb >> 10) & 0x1f) * 8);
               *(temp++)= (unsigned char)(((rgb >> 5) & 0x1f) * 8);
               *(temp++)= (unsigned char)(((rgb) & 0x1f) * 8);
            }
          --ypos;
        }
    }
 break;

  case 8:
  case 4:
  case 1:
    {
      if (compression == 0)
   {
     while ((__sym_fread(&v, 1, 1, fd) != 0))
       {
  for (i = 1; (i <= (8 / bpp)) && (xpos < width); i++, xpos++)
    {
      temp = (unsigned char*) (image + (ypos * rowstride) + (xpos * channels));
      *temp= (unsigned char)(( v & ( ((1<<bpp)-1) << (8-(i*bpp)) ) ) >> (8-(i*bpp)));
    }
  if (xpos == width)
    {
      notused = (__sym_fread(buffer, rowbytes - 1 - (width * bpp - 1) / 8, 1, fd) != 0)
                                                                      ;
      ypos--;
      xpos = 0;

    }
  if (ypos < 0)
    break;
       }
     break;
   }
 else
   {
     while (ypos >= 0 && xpos <= width)
       {
  notused = (__sym_fread(buffer, 2, 1, fd) != 0);
  if ((unsigned char) buffer[0] != 0)

    {
      for (j = 0; ((unsigned char) j < (unsigned char) buffer[0]) && (xpos < width);)
        {



   for (i = 1;
        ((i <= (8 / bpp)) &&
         (xpos < width) &&
         ((unsigned char) j < (unsigned char) buffer[0]));
        i++, xpos++, j++)
     {
       temp = image + (ypos * rowstride) + (xpos * channels);
       *temp = (unsigned char) ((buffer[1] & (((1<<bpp)-1) << (8 - (i * bpp)))) >> (8 - (i * bpp)));
     }
        }
    }
  if (((unsigned char) buffer[0] == 0) && ((unsigned char) buffer[1] > 2))

    {
      howmuch = buffer[1];
      for (j = 0; j < howmuch; j += (8 / bpp))
        {
   notused = (__sym_fread(&v, 1, 1, fd) != 0);
   i = 1;
   while ((i <= (8 / bpp)) && (xpos < width))
     {
       temp = image + (ypos * rowstride) + (xpos * channels);
       *temp = (unsigned char) ((v & (((1<<bpp)-1) << (8-(i*bpp)))) >> (8-(i*bpp)));
       i++;
       xpos++;
     }
        }

      if ((howmuch % 2) && (bpp==4))
        howmuch++;

      if ((howmuch / (8 / bpp)) % 2)
        notused = (__sym_fread(&v, 1, 1, fd) != 0);

    }
  if (((unsigned char) buffer[0] == 0) && ((unsigned char) buffer[1]==0))

    {
      ypos--;
      xpos = 0;
    }
  if (((unsigned char) buffer[0]==0) && ((unsigned char) buffer[1]==1))

    {
      break;
    }
  if (((unsigned char) buffer[0]==0) && ((unsigned char) buffer[1]==2))

    {
      notused = (__sym_fread(buffer, 2, 1, fd) != 0);
      xpos += (unsigned char) buffer[0];
      ypos -= (unsigned char) buffer[1];
    }
       }
     break;
   }
    }
    break;
  default:

 ;
  }

  if (bpp <= 8)
    {
      unsigned char *temp3;
      unsigned char index;
      temp = image;
      do { image = (at_address) malloc (width * height * 3 * sizeof (unsigned char)); ((image) ? (void) (0) : __sym___assert_fail ("image", "input-bmp.c", 486, __PRETTY_FUNCTION__)); } while (0);
      temp3 = image;
      for (ypos = 0; ypos < height; ypos++)
        {
          for (xpos = 0; xpos < width; xpos++)
             {
               index = *temp2++;
                assert(index < 128);
               *temp3++ = cmap[index][0];
      if (!grey)
        {
                   *temp3++ = cmap[index][1];
                   *temp3++ = cmap[index][2];
        }
           }
        }
      __sym_free (temp);
  }

  __sym_free (buffer);
  return image;
}

FILE *errorfile;
char *prog_name = "bmp";
char *filename;
int interactive_bmp;

static long
ToL (unsigned char *puffer)
{
  return (puffer[0] | puffer[1]<<8 | puffer[2]<<16 | puffer[3]<<24);
}

static short
ToS (unsigned char *puffer)
{
  return ((short)(puffer[0] | puffer[1]<<8));
}

// Test driver for function ReadImage returning unsigned char *
unsigned char * ReadImage_driver()
{
struct _IO_FILE * param1;
int param2;
int param3;
unsigned char param4[100][3];
int param5;
int param6;
int param7;
int param8;
param1 = malloc(1*sizeof(struct _IO_FILE));
__CrestInt(&param1[0]._flags);
param1[0]._IO_read_ptr = malloc(3*sizeof(char));
__CrestChar(&param1[0]._IO_read_ptr[0]);
__CrestChar(&param1[0]._IO_read_ptr[1]);
__CrestChar(&param1[0]._IO_read_ptr[2]);
param1[0]._IO_read_end = malloc(3*sizeof(char));
__CrestChar(&param1[0]._IO_read_end[0]);
__CrestChar(&param1[0]._IO_read_end[1]);
__CrestChar(&param1[0]._IO_read_end[2]);
param1[0]._IO_read_base = malloc(3*sizeof(char));
__CrestChar(&param1[0]._IO_read_base[0]);
__CrestChar(&param1[0]._IO_read_base[1]);
__CrestChar(&param1[0]._IO_read_base[2]);
param1[0]._IO_write_base = malloc(3*sizeof(char));
__CrestChar(&param1[0]._IO_write_base[0]);
__CrestChar(&param1[0]._IO_write_base[1]);
__CrestChar(&param1[0]._IO_write_base[2]);
param1[0]._IO_write_ptr = malloc(3*sizeof(char));
__CrestChar(&param1[0]._IO_write_ptr[0]);
__CrestChar(&param1[0]._IO_write_ptr[1]);
__CrestChar(&param1[0]._IO_write_ptr[2]);
param1[0]._IO_write_end = malloc(3*sizeof(char));
__CrestChar(&param1[0]._IO_write_end[0]);
__CrestChar(&param1[0]._IO_write_end[1]);
__CrestChar(&param1[0]._IO_write_end[2]);
param1[0]._IO_buf_base = malloc(3*sizeof(char));
__CrestChar(&param1[0]._IO_buf_base[0]);
__CrestChar(&param1[0]._IO_buf_base[1]);
__CrestChar(&param1[0]._IO_buf_base[2]);
param1[0]._IO_buf_end = malloc(3*sizeof(char));
__CrestChar(&param1[0]._IO_buf_end[0]);
__CrestChar(&param1[0]._IO_buf_end[1]);
__CrestChar(&param1[0]._IO_buf_end[2]);
param1[0]._IO_save_base = malloc(3*sizeof(char));
__CrestChar(&param1[0]._IO_save_base[0]);
__CrestChar(&param1[0]._IO_save_base[1]);
__CrestChar(&param1[0]._IO_save_base[2]);
param1[0]._IO_backup_base = malloc(3*sizeof(char));
__CrestChar(&param1[0]._IO_backup_base[0]);
__CrestChar(&param1[0]._IO_backup_base[1]);
__CrestChar(&param1[0]._IO_backup_base[2]);
param1[0]._IO_save_end = malloc(3*sizeof(char));
__CrestChar(&param1[0]._IO_save_end[0]);
__CrestChar(&param1[0]._IO_save_end[1]);
__CrestChar(&param1[0]._IO_save_end[2]);
param1[0]._markers = malloc(1*sizeof(struct _IO_marker));
param1[0]._markers[0]._next = malloc(1*sizeof(struct _IO_marker));
// Pointer Type: struct _IO_marker * of param1[0]._markers[0]._next[0]._next is set as NULL
param1[0]._markers[0]._next[0]._next = 0;
// Pointer Type: struct _IO_FILE * of param1[0]._markers[0]._next[0]._sbuf is set as NULL
param1[0]._markers[0]._next[0]._sbuf = 0;
__CrestInt(&param1[0]._markers[0]._next[0]._pos);
param1[0]._markers[0]._sbuf = malloc(1*sizeof(struct _IO_FILE));
__CrestInt(&param1[0]._markers[0]._sbuf[0]._flags);
// Pointer Type: char * of param1[0]._markers[0]._sbuf[0]._IO_read_ptr is set as NULL
param1[0]._markers[0]._sbuf[0]._IO_read_ptr = 0;
// Pointer Type: char * of param1[0]._markers[0]._sbuf[0]._IO_read_end is set as NULL
param1[0]._markers[0]._sbuf[0]._IO_read_end = 0;
// Pointer Type: char * of param1[0]._markers[0]._sbuf[0]._IO_read_base is set as NULL
param1[0]._markers[0]._sbuf[0]._IO_read_base = 0;
// Pointer Type: char * of param1[0]._markers[0]._sbuf[0]._IO_write_base is set as NULL
param1[0]._markers[0]._sbuf[0]._IO_write_base = 0;
// Pointer Type: char * of param1[0]._markers[0]._sbuf[0]._IO_write_ptr is set as NULL
param1[0]._markers[0]._sbuf[0]._IO_write_ptr = 0;
// Pointer Type: char * of param1[0]._markers[0]._sbuf[0]._IO_write_end is set as NULL
param1[0]._markers[0]._sbuf[0]._IO_write_end = 0;
// Pointer Type: char * of param1[0]._markers[0]._sbuf[0]._IO_buf_base is set as NULL
param1[0]._markers[0]._sbuf[0]._IO_buf_base = 0;
// Pointer Type: char * of param1[0]._markers[0]._sbuf[0]._IO_buf_end is set as NULL
param1[0]._markers[0]._sbuf[0]._IO_buf_end = 0;
// Pointer Type: char * of param1[0]._markers[0]._sbuf[0]._IO_save_base is set as NULL
param1[0]._markers[0]._sbuf[0]._IO_save_base = 0;
// Pointer Type: char * of param1[0]._markers[0]._sbuf[0]._IO_backup_base is set as NULL
param1[0]._markers[0]._sbuf[0]._IO_backup_base = 0;
// Pointer Type: char * of param1[0]._markers[0]._sbuf[0]._IO_save_end is set as NULL
param1[0]._markers[0]._sbuf[0]._IO_save_end = 0;
// Pointer Type: struct _IO_marker * of param1[0]._markers[0]._sbuf[0]._markers is set as NULL
param1[0]._markers[0]._sbuf[0]._markers = 0;
// Pointer Type: struct _IO_FILE * of param1[0]._markers[0]._sbuf[0]._chain is set as NULL
param1[0]._markers[0]._sbuf[0]._chain = 0;
__CrestInt(&param1[0]._markers[0]._sbuf[0]._fileno);
__CrestInt(&param1[0]._markers[0]._sbuf[0]._flags2);
__CrestLong(&param1[0]._markers[0]._sbuf[0]._old_offset);
__CrestUShort(&param1[0]._markers[0]._sbuf[0]._cur_column);
__CrestChar(&param1[0]._markers[0]._sbuf[0]._vtable_offset);
__CrestChar(&param1[0]._markers[0]._sbuf[0]._shortbuf[0]);
// Pointer Type: void * of param1[0]._markers[0]._sbuf[0]._lock is set as NULL
param1[0]._markers[0]._sbuf[0]._lock = 0;
__CrestLong(&param1[0]._markers[0]._sbuf[0]._offset);
// Pointer Type: void * of param1[0]._markers[0]._sbuf[0].__pad1 is set as NULL
param1[0]._markers[0]._sbuf[0].__pad1 = 0;
// Pointer Type: void * of param1[0]._markers[0]._sbuf[0].__pad2 is set as NULL
param1[0]._markers[0]._sbuf[0].__pad2 = 0;
// Pointer Type: void * of param1[0]._markers[0]._sbuf[0].__pad3 is set as NULL
param1[0]._markers[0]._sbuf[0].__pad3 = 0;
// Pointer Type: void * of param1[0]._markers[0]._sbuf[0].__pad4 is set as NULL
param1[0]._markers[0]._sbuf[0].__pad4 = 0;
__CrestULong(&param1[0]._markers[0]._sbuf[0].__pad5);
__CrestInt(&param1[0]._markers[0]._sbuf[0]._mode);
__CrestChar(&param1[0]._markers[0]._sbuf[0]._unused2[0]);
__CrestChar(&param1[0]._markers[0]._sbuf[0]._unused2[1]);
__CrestChar(&param1[0]._markers[0]._sbuf[0]._unused2[2]);
__CrestChar(&param1[0]._markers[0]._sbuf[0]._unused2[3]);
__CrestChar(&param1[0]._markers[0]._sbuf[0]._unused2[4]);
__CrestChar(&param1[0]._markers[0]._sbuf[0]._unused2[5]);
__CrestChar(&param1[0]._markers[0]._sbuf[0]._unused2[6]);
__CrestChar(&param1[0]._markers[0]._sbuf[0]._unused2[7]);
__CrestChar(&param1[0]._markers[0]._sbuf[0]._unused2[8]);
__CrestChar(&param1[0]._markers[0]._sbuf[0]._unused2[9]);
__CrestChar(&param1[0]._markers[0]._sbuf[0]._unused2[10]);
__CrestChar(&param1[0]._markers[0]._sbuf[0]._unused2[11]);
__CrestChar(&param1[0]._markers[0]._sbuf[0]._unused2[12]);
__CrestChar(&param1[0]._markers[0]._sbuf[0]._unused2[13]);
__CrestChar(&param1[0]._markers[0]._sbuf[0]._unused2[14]);
__CrestChar(&param1[0]._markers[0]._sbuf[0]._unused2[15]);
__CrestChar(&param1[0]._markers[0]._sbuf[0]._unused2[16]);
__CrestChar(&param1[0]._markers[0]._sbuf[0]._unused2[17]);
__CrestChar(&param1[0]._markers[0]._sbuf[0]._unused2[18]);
__CrestChar(&param1[0]._markers[0]._sbuf[0]._unused2[19]);
__CrestInt(&param1[0]._markers[0]._pos);
param1[0]._chain = malloc(1*sizeof(struct _IO_FILE));
__CrestInt(&param1[0]._chain[0]._flags);
param1[0]._chain[0]._IO_read_ptr = malloc(3*sizeof(char));
__CrestChar(&param1[0]._chain[0]._IO_read_ptr[0]);
__CrestChar(&param1[0]._chain[0]._IO_read_ptr[1]);
__CrestChar(&param1[0]._chain[0]._IO_read_ptr[2]);
param1[0]._chain[0]._IO_read_end = malloc(3*sizeof(char));
__CrestChar(&param1[0]._chain[0]._IO_read_end[0]);
__CrestChar(&param1[0]._chain[0]._IO_read_end[1]);
__CrestChar(&param1[0]._chain[0]._IO_read_end[2]);
param1[0]._chain[0]._IO_read_base = malloc(3*sizeof(char));
__CrestChar(&param1[0]._chain[0]._IO_read_base[0]);
__CrestChar(&param1[0]._chain[0]._IO_read_base[1]);
__CrestChar(&param1[0]._chain[0]._IO_read_base[2]);
param1[0]._chain[0]._IO_write_base = malloc(3*sizeof(char));
__CrestChar(&param1[0]._chain[0]._IO_write_base[0]);
__CrestChar(&param1[0]._chain[0]._IO_write_base[1]);
__CrestChar(&param1[0]._chain[0]._IO_write_base[2]);
param1[0]._chain[0]._IO_write_ptr = malloc(3*sizeof(char));
__CrestChar(&param1[0]._chain[0]._IO_write_ptr[0]);
__CrestChar(&param1[0]._chain[0]._IO_write_ptr[1]);
__CrestChar(&param1[0]._chain[0]._IO_write_ptr[2]);
param1[0]._chain[0]._IO_write_end = malloc(3*sizeof(char));
__CrestChar(&param1[0]._chain[0]._IO_write_end[0]);
__CrestChar(&param1[0]._chain[0]._IO_write_end[1]);
__CrestChar(&param1[0]._chain[0]._IO_write_end[2]);
param1[0]._chain[0]._IO_buf_base = malloc(3*sizeof(char));
__CrestChar(&param1[0]._chain[0]._IO_buf_base[0]);
__CrestChar(&param1[0]._chain[0]._IO_buf_base[1]);
__CrestChar(&param1[0]._chain[0]._IO_buf_base[2]);
param1[0]._chain[0]._IO_buf_end = malloc(3*sizeof(char));
__CrestChar(&param1[0]._chain[0]._IO_buf_end[0]);
__CrestChar(&param1[0]._chain[0]._IO_buf_end[1]);
__CrestChar(&param1[0]._chain[0]._IO_buf_end[2]);
param1[0]._chain[0]._IO_save_base = malloc(3*sizeof(char));
__CrestChar(&param1[0]._chain[0]._IO_save_base[0]);
__CrestChar(&param1[0]._chain[0]._IO_save_base[1]);
__CrestChar(&param1[0]._chain[0]._IO_save_base[2]);
param1[0]._chain[0]._IO_backup_base = malloc(3*sizeof(char));
__CrestChar(&param1[0]._chain[0]._IO_backup_base[0]);
__CrestChar(&param1[0]._chain[0]._IO_backup_base[1]);
__CrestChar(&param1[0]._chain[0]._IO_backup_base[2]);
param1[0]._chain[0]._IO_save_end = malloc(3*sizeof(char));
__CrestChar(&param1[0]._chain[0]._IO_save_end[0]);
__CrestChar(&param1[0]._chain[0]._IO_save_end[1]);
__CrestChar(&param1[0]._chain[0]._IO_save_end[2]);
param1[0]._chain[0]._markers = malloc(1*sizeof(struct _IO_marker));
// Pointer Type: struct _IO_marker * of param1[0]._chain[0]._markers[0]._next is set as NULL
param1[0]._chain[0]._markers[0]._next = 0;
// Pointer Type: struct _IO_FILE * of param1[0]._chain[0]._markers[0]._sbuf is set as NULL
param1[0]._chain[0]._markers[0]._sbuf = 0;
__CrestInt(&param1[0]._chain[0]._markers[0]._pos);
param1[0]._chain[0]._chain = malloc(1*sizeof(struct _IO_FILE));
__CrestInt(&param1[0]._chain[0]._chain[0]._flags);
// Pointer Type: char * of param1[0]._chain[0]._chain[0]._IO_read_ptr is set as NULL
param1[0]._chain[0]._chain[0]._IO_read_ptr = 0;
// Pointer Type: char * of param1[0]._chain[0]._chain[0]._IO_read_end is set as NULL
param1[0]._chain[0]._chain[0]._IO_read_end = 0;
// Pointer Type: char * of param1[0]._chain[0]._chain[0]._IO_read_base is set as NULL
param1[0]._chain[0]._chain[0]._IO_read_base = 0;
// Pointer Type: char * of param1[0]._chain[0]._chain[0]._IO_write_base is set as NULL
param1[0]._chain[0]._chain[0]._IO_write_base = 0;
// Pointer Type: char * of param1[0]._chain[0]._chain[0]._IO_write_ptr is set as NULL
param1[0]._chain[0]._chain[0]._IO_write_ptr = 0;
// Pointer Type: char * of param1[0]._chain[0]._chain[0]._IO_write_end is set as NULL
param1[0]._chain[0]._chain[0]._IO_write_end = 0;
// Pointer Type: char * of param1[0]._chain[0]._chain[0]._IO_buf_base is set as NULL
param1[0]._chain[0]._chain[0]._IO_buf_base = 0;
// Pointer Type: char * of param1[0]._chain[0]._chain[0]._IO_buf_end is set as NULL
param1[0]._chain[0]._chain[0]._IO_buf_end = 0;
// Pointer Type: char * of param1[0]._chain[0]._chain[0]._IO_save_base is set as NULL
param1[0]._chain[0]._chain[0]._IO_save_base = 0;
// Pointer Type: char * of param1[0]._chain[0]._chain[0]._IO_backup_base is set as NULL
param1[0]._chain[0]._chain[0]._IO_backup_base = 0;
// Pointer Type: char * of param1[0]._chain[0]._chain[0]._IO_save_end is set as NULL
param1[0]._chain[0]._chain[0]._IO_save_end = 0;
// Pointer Type: struct _IO_marker * of param1[0]._chain[0]._chain[0]._markers is set as NULL
param1[0]._chain[0]._chain[0]._markers = 0;
// Pointer Type: struct _IO_FILE * of param1[0]._chain[0]._chain[0]._chain is set as NULL
param1[0]._chain[0]._chain[0]._chain = 0;
__CrestInt(&param1[0]._chain[0]._chain[0]._fileno);
__CrestInt(&param1[0]._chain[0]._chain[0]._flags2);
__CrestLong(&param1[0]._chain[0]._chain[0]._old_offset);
__CrestUShort(&param1[0]._chain[0]._chain[0]._cur_column);
__CrestChar(&param1[0]._chain[0]._chain[0]._vtable_offset);
__CrestChar(&param1[0]._chain[0]._chain[0]._shortbuf[0]);
// Pointer Type: void * of param1[0]._chain[0]._chain[0]._lock is set as NULL
param1[0]._chain[0]._chain[0]._lock = 0;
__CrestLong(&param1[0]._chain[0]._chain[0]._offset);
// Pointer Type: void * of param1[0]._chain[0]._chain[0].__pad1 is set as NULL
param1[0]._chain[0]._chain[0].__pad1 = 0;
// Pointer Type: void * of param1[0]._chain[0]._chain[0].__pad2 is set as NULL
param1[0]._chain[0]._chain[0].__pad2 = 0;
// Pointer Type: void * of param1[0]._chain[0]._chain[0].__pad3 is set as NULL
param1[0]._chain[0]._chain[0].__pad3 = 0;
// Pointer Type: void * of param1[0]._chain[0]._chain[0].__pad4 is set as NULL
param1[0]._chain[0]._chain[0].__pad4 = 0;
__CrestULong(&param1[0]._chain[0]._chain[0].__pad5);
__CrestInt(&param1[0]._chain[0]._chain[0]._mode);
__CrestChar(&param1[0]._chain[0]._chain[0]._unused2[0]);
__CrestChar(&param1[0]._chain[0]._chain[0]._unused2[1]);
__CrestChar(&param1[0]._chain[0]._chain[0]._unused2[2]);
__CrestChar(&param1[0]._chain[0]._chain[0]._unused2[3]);
__CrestChar(&param1[0]._chain[0]._chain[0]._unused2[4]);
__CrestChar(&param1[0]._chain[0]._chain[0]._unused2[5]);
__CrestChar(&param1[0]._chain[0]._chain[0]._unused2[6]);
__CrestChar(&param1[0]._chain[0]._chain[0]._unused2[7]);
__CrestChar(&param1[0]._chain[0]._chain[0]._unused2[8]);
__CrestChar(&param1[0]._chain[0]._chain[0]._unused2[9]);
__CrestChar(&param1[0]._chain[0]._chain[0]._unused2[10]);
__CrestChar(&param1[0]._chain[0]._chain[0]._unused2[11]);
__CrestChar(&param1[0]._chain[0]._chain[0]._unused2[12]);
__CrestChar(&param1[0]._chain[0]._chain[0]._unused2[13]);
__CrestChar(&param1[0]._chain[0]._chain[0]._unused2[14]);
__CrestChar(&param1[0]._chain[0]._chain[0]._unused2[15]);
__CrestChar(&param1[0]._chain[0]._chain[0]._unused2[16]);
__CrestChar(&param1[0]._chain[0]._chain[0]._unused2[17]);
__CrestChar(&param1[0]._chain[0]._chain[0]._unused2[18]);
__CrestChar(&param1[0]._chain[0]._chain[0]._unused2[19]);
__CrestInt(&param1[0]._chain[0]._fileno);
__CrestInt(&param1[0]._chain[0]._flags2);
__CrestLong(&param1[0]._chain[0]._old_offset);
__CrestUShort(&param1[0]._chain[0]._cur_column);
__CrestChar(&param1[0]._chain[0]._vtable_offset);
__CrestChar(&param1[0]._chain[0]._shortbuf[0]);
// Pointee type 'void' is an incomplete type
param1[0]._chain[0]._lock = 0;
__CrestLong(&param1[0]._chain[0]._offset);
// Pointee type 'void' is an incomplete type
param1[0]._chain[0].__pad1 = 0;
// Pointee type 'void' is an incomplete type
param1[0]._chain[0].__pad2 = 0;
// Pointee type 'void' is an incomplete type
param1[0]._chain[0].__pad3 = 0;
// Pointee type 'void' is an incomplete type
param1[0]._chain[0].__pad4 = 0;
__CrestULong(&param1[0]._chain[0].__pad5);
__CrestInt(&param1[0]._chain[0]._mode);
__CrestChar(&param1[0]._chain[0]._unused2[0]);
__CrestChar(&param1[0]._chain[0]._unused2[1]);
__CrestChar(&param1[0]._chain[0]._unused2[2]);
__CrestChar(&param1[0]._chain[0]._unused2[3]);
__CrestChar(&param1[0]._chain[0]._unused2[4]);
__CrestChar(&param1[0]._chain[0]._unused2[5]);
__CrestChar(&param1[0]._chain[0]._unused2[6]);
__CrestChar(&param1[0]._chain[0]._unused2[7]);
__CrestChar(&param1[0]._chain[0]._unused2[8]);
__CrestChar(&param1[0]._chain[0]._unused2[9]);
__CrestChar(&param1[0]._chain[0]._unused2[10]);
__CrestChar(&param1[0]._chain[0]._unused2[11]);
__CrestChar(&param1[0]._chain[0]._unused2[12]);
__CrestChar(&param1[0]._chain[0]._unused2[13]);
__CrestChar(&param1[0]._chain[0]._unused2[14]);
__CrestChar(&param1[0]._chain[0]._unused2[15]);
__CrestChar(&param1[0]._chain[0]._unused2[16]);
__CrestChar(&param1[0]._chain[0]._unused2[17]);
__CrestChar(&param1[0]._chain[0]._unused2[18]);
__CrestChar(&param1[0]._chain[0]._unused2[19]);
__CrestInt(&param1[0]._fileno);
__CrestInt(&param1[0]._flags2);
__CrestLong(&param1[0]._old_offset);
__CrestUShort(&param1[0]._cur_column);
__CrestChar(&param1[0]._vtable_offset);
__CrestChar(&param1[0]._shortbuf[0]);
// Pointee type 'void' is an incomplete type
param1[0]._lock = 0;
__CrestLong(&param1[0]._offset);
// Pointee type 'void' is an incomplete type
param1[0].__pad1 = 0;
// Pointee type 'void' is an incomplete type
param1[0].__pad2 = 0;
// Pointee type 'void' is an incomplete type
param1[0].__pad3 = 0;
// Pointee type 'void' is an incomplete type
param1[0].__pad4 = 0;
__CrestULong(&param1[0].__pad5);
__CrestInt(&param1[0]._mode);
__CrestChar(&param1[0]._unused2[0]);
__CrestChar(&param1[0]._unused2[1]);
__CrestChar(&param1[0]._unused2[2]);
__CrestChar(&param1[0]._unused2[3]);
__CrestChar(&param1[0]._unused2[4]);
__CrestChar(&param1[0]._unused2[5]);
__CrestChar(&param1[0]._unused2[6]);
__CrestChar(&param1[0]._unused2[7]);
__CrestChar(&param1[0]._unused2[8]);
__CrestChar(&param1[0]._unused2[9]);
__CrestChar(&param1[0]._unused2[10]);
__CrestChar(&param1[0]._unused2[11]);
__CrestChar(&param1[0]._unused2[12]);
__CrestChar(&param1[0]._unused2[13]);
__CrestChar(&param1[0]._unused2[14]);
__CrestChar(&param1[0]._unused2[15]);
__CrestChar(&param1[0]._unused2[16]);
__CrestChar(&param1[0]._unused2[17]);
__CrestChar(&param1[0]._unused2[18]);
__CrestChar(&param1[0]._unused2[19]);
__CrestInt(&param2);
__CrestInt(&param3);
__CrestUChar(&param4[0][0]);
__CrestUChar(&param4[0][1]);
__CrestUChar(&param4[0][2]);
__CrestUChar(&param4[1][0]);
__CrestUChar(&param4[1][1]);
__CrestUChar(&param4[1][2]);
__CrestUChar(&param4[2][0]);
__CrestUChar(&param4[2][1]);
__CrestUChar(&param4[2][2]);
__CrestUChar(&param4[3][0]);
__CrestUChar(&param4[3][1]);
__CrestUChar(&param4[3][2]);
__CrestUChar(&param4[4][0]);
__CrestUChar(&param4[4][1]);
__CrestUChar(&param4[4][2]);
__CrestUChar(&param4[5][0]);
__CrestUChar(&param4[5][1]);
__CrestUChar(&param4[5][2]);
__CrestUChar(&param4[6][0]);
__CrestUChar(&param4[6][1]);
__CrestUChar(&param4[6][2]);
__CrestUChar(&param4[7][0]);
__CrestUChar(&param4[7][1]);
__CrestUChar(&param4[7][2]);
__CrestUChar(&param4[8][0]);
__CrestUChar(&param4[8][1]);
__CrestUChar(&param4[8][2]);
__CrestUChar(&param4[9][0]);
__CrestUChar(&param4[9][1]);
__CrestUChar(&param4[9][2]);
__CrestUChar(&param4[10][0]);
__CrestUChar(&param4[10][1]);
__CrestUChar(&param4[10][2]);
__CrestUChar(&param4[11][0]);
__CrestUChar(&param4[11][1]);
__CrestUChar(&param4[11][2]);
__CrestUChar(&param4[12][0]);
__CrestUChar(&param4[12][1]);
__CrestUChar(&param4[12][2]);
__CrestUChar(&param4[13][0]);
__CrestUChar(&param4[13][1]);
__CrestUChar(&param4[13][2]);
__CrestUChar(&param4[14][0]);
__CrestUChar(&param4[14][1]);
__CrestUChar(&param4[14][2]);
__CrestUChar(&param4[15][0]);
__CrestUChar(&param4[15][1]);
__CrestUChar(&param4[15][2]);
__CrestUChar(&param4[16][0]);
__CrestUChar(&param4[16][1]);
__CrestUChar(&param4[16][2]);
__CrestUChar(&param4[17][0]);
__CrestUChar(&param4[17][1]);
__CrestUChar(&param4[17][2]);
__CrestUChar(&param4[18][0]);
__CrestUChar(&param4[18][1]);
__CrestUChar(&param4[18][2]);
__CrestUChar(&param4[19][0]);
__CrestUChar(&param4[19][1]);
__CrestUChar(&param4[19][2]);
__CrestUChar(&param4[20][0]);
__CrestUChar(&param4[20][1]);
__CrestUChar(&param4[20][2]);
__CrestUChar(&param4[21][0]);
__CrestUChar(&param4[21][1]);
__CrestUChar(&param4[21][2]);
__CrestUChar(&param4[22][0]);
__CrestUChar(&param4[22][1]);
__CrestUChar(&param4[22][2]);
__CrestUChar(&param4[23][0]);
__CrestUChar(&param4[23][1]);
__CrestUChar(&param4[23][2]);
__CrestUChar(&param4[24][0]);
__CrestUChar(&param4[24][1]);
__CrestUChar(&param4[24][2]);
__CrestUChar(&param4[25][0]);
__CrestUChar(&param4[25][1]);
__CrestUChar(&param4[25][2]);
__CrestUChar(&param4[26][0]);
__CrestUChar(&param4[26][1]);
__CrestUChar(&param4[26][2]);
__CrestUChar(&param4[27][0]);
__CrestUChar(&param4[27][1]);
__CrestUChar(&param4[27][2]);
__CrestUChar(&param4[28][0]);
__CrestUChar(&param4[28][1]);
__CrestUChar(&param4[28][2]);
__CrestUChar(&param4[29][0]);
__CrestUChar(&param4[29][1]);
__CrestUChar(&param4[29][2]);
__CrestUChar(&param4[30][0]);
__CrestUChar(&param4[30][1]);
__CrestUChar(&param4[30][2]);
__CrestUChar(&param4[31][0]);
__CrestUChar(&param4[31][1]);
__CrestUChar(&param4[31][2]);
__CrestUChar(&param4[32][0]);
__CrestUChar(&param4[32][1]);
__CrestUChar(&param4[32][2]);
__CrestUChar(&param4[33][0]);
__CrestUChar(&param4[33][1]);
__CrestUChar(&param4[33][2]);
__CrestUChar(&param4[34][0]);
__CrestUChar(&param4[34][1]);
__CrestUChar(&param4[34][2]);
__CrestUChar(&param4[35][0]);
__CrestUChar(&param4[35][1]);
__CrestUChar(&param4[35][2]);
__CrestUChar(&param4[36][0]);
__CrestUChar(&param4[36][1]);
__CrestUChar(&param4[36][2]);
__CrestUChar(&param4[37][0]);
__CrestUChar(&param4[37][1]);
__CrestUChar(&param4[37][2]);
__CrestUChar(&param4[38][0]);
__CrestUChar(&param4[38][1]);
__CrestUChar(&param4[38][2]);
__CrestUChar(&param4[39][0]);
__CrestUChar(&param4[39][1]);
__CrestUChar(&param4[39][2]);
__CrestUChar(&param4[40][0]);
__CrestUChar(&param4[40][1]);
__CrestUChar(&param4[40][2]);
__CrestUChar(&param4[41][0]);
__CrestUChar(&param4[41][1]);
__CrestUChar(&param4[41][2]);
__CrestUChar(&param4[42][0]);
__CrestUChar(&param4[42][1]);
__CrestUChar(&param4[42][2]);
__CrestUChar(&param4[43][0]);
__CrestUChar(&param4[43][1]);
__CrestUChar(&param4[43][2]);
__CrestUChar(&param4[44][0]);
__CrestUChar(&param4[44][1]);
__CrestUChar(&param4[44][2]);
__CrestUChar(&param4[45][0]);
__CrestUChar(&param4[45][1]);
__CrestUChar(&param4[45][2]);
__CrestUChar(&param4[46][0]);
__CrestUChar(&param4[46][1]);
__CrestUChar(&param4[46][2]);
__CrestUChar(&param4[47][0]);
__CrestUChar(&param4[47][1]);
__CrestUChar(&param4[47][2]);
__CrestUChar(&param4[48][0]);
__CrestUChar(&param4[48][1]);
__CrestUChar(&param4[48][2]);
__CrestUChar(&param4[49][0]);
__CrestUChar(&param4[49][1]);
__CrestUChar(&param4[49][2]);
__CrestUChar(&param4[50][0]);
__CrestUChar(&param4[50][1]);
__CrestUChar(&param4[50][2]);
__CrestUChar(&param4[51][0]);
__CrestUChar(&param4[51][1]);
__CrestUChar(&param4[51][2]);
__CrestUChar(&param4[52][0]);
__CrestUChar(&param4[52][1]);
__CrestUChar(&param4[52][2]);
__CrestUChar(&param4[53][0]);
__CrestUChar(&param4[53][1]);
__CrestUChar(&param4[53][2]);
__CrestUChar(&param4[54][0]);
__CrestUChar(&param4[54][1]);
__CrestUChar(&param4[54][2]);
__CrestUChar(&param4[55][0]);
__CrestUChar(&param4[55][1]);
__CrestUChar(&param4[55][2]);
__CrestUChar(&param4[56][0]);
__CrestUChar(&param4[56][1]);
__CrestUChar(&param4[56][2]);
__CrestUChar(&param4[57][0]);
__CrestUChar(&param4[57][1]);
__CrestUChar(&param4[57][2]);
__CrestUChar(&param4[58][0]);
__CrestUChar(&param4[58][1]);
__CrestUChar(&param4[58][2]);
__CrestUChar(&param4[59][0]);
__CrestUChar(&param4[59][1]);
__CrestUChar(&param4[59][2]);
__CrestUChar(&param4[60][0]);
__CrestUChar(&param4[60][1]);
__CrestUChar(&param4[60][2]);
__CrestUChar(&param4[61][0]);
__CrestUChar(&param4[61][1]);
__CrestUChar(&param4[61][2]);
__CrestUChar(&param4[62][0]);
__CrestUChar(&param4[62][1]);
__CrestUChar(&param4[62][2]);
__CrestUChar(&param4[63][0]);
__CrestUChar(&param4[63][1]);
__CrestUChar(&param4[63][2]);
__CrestUChar(&param4[64][0]);
__CrestUChar(&param4[64][1]);
__CrestUChar(&param4[64][2]);
__CrestUChar(&param4[65][0]);
__CrestUChar(&param4[65][1]);
__CrestUChar(&param4[65][2]);
__CrestUChar(&param4[66][0]);
__CrestUChar(&param4[66][1]);
__CrestUChar(&param4[66][2]);
__CrestUChar(&param4[67][0]);
__CrestUChar(&param4[67][1]);
__CrestUChar(&param4[67][2]);
__CrestUChar(&param4[68][0]);
__CrestUChar(&param4[68][1]);
__CrestUChar(&param4[68][2]);
__CrestUChar(&param4[69][0]);
__CrestUChar(&param4[69][1]);
__CrestUChar(&param4[69][2]);
__CrestUChar(&param4[70][0]);
__CrestUChar(&param4[70][1]);
__CrestUChar(&param4[70][2]);
__CrestUChar(&param4[71][0]);
__CrestUChar(&param4[71][1]);
__CrestUChar(&param4[71][2]);
__CrestUChar(&param4[72][0]);
__CrestUChar(&param4[72][1]);
__CrestUChar(&param4[72][2]);
__CrestUChar(&param4[73][0]);
__CrestUChar(&param4[73][1]);
__CrestUChar(&param4[73][2]);
__CrestUChar(&param4[74][0]);
__CrestUChar(&param4[74][1]);
__CrestUChar(&param4[74][2]);
__CrestUChar(&param4[75][0]);
__CrestUChar(&param4[75][1]);
__CrestUChar(&param4[75][2]);
__CrestUChar(&param4[76][0]);
__CrestUChar(&param4[76][1]);
__CrestUChar(&param4[76][2]);
__CrestUChar(&param4[77][0]);
__CrestUChar(&param4[77][1]);
__CrestUChar(&param4[77][2]);
__CrestUChar(&param4[78][0]);
__CrestUChar(&param4[78][1]);
__CrestUChar(&param4[78][2]);
__CrestUChar(&param4[79][0]);
__CrestUChar(&param4[79][1]);
__CrestUChar(&param4[79][2]);
__CrestUChar(&param4[80][0]);
__CrestUChar(&param4[80][1]);
__CrestUChar(&param4[80][2]);
__CrestUChar(&param4[81][0]);
__CrestUChar(&param4[81][1]);
__CrestUChar(&param4[81][2]);
__CrestUChar(&param4[82][0]);
__CrestUChar(&param4[82][1]);
__CrestUChar(&param4[82][2]);
__CrestUChar(&param4[83][0]);
__CrestUChar(&param4[83][1]);
__CrestUChar(&param4[83][2]);
__CrestUChar(&param4[84][0]);
__CrestUChar(&param4[84][1]);
__CrestUChar(&param4[84][2]);
__CrestUChar(&param4[85][0]);
__CrestUChar(&param4[85][1]);
__CrestUChar(&param4[85][2]);
__CrestUChar(&param4[86][0]);
__CrestUChar(&param4[86][1]);
__CrestUChar(&param4[86][2]);
__CrestUChar(&param4[87][0]);
__CrestUChar(&param4[87][1]);
__CrestUChar(&param4[87][2]);
__CrestUChar(&param4[88][0]);
__CrestUChar(&param4[88][1]);
__CrestUChar(&param4[88][2]);
__CrestUChar(&param4[89][0]);
__CrestUChar(&param4[89][1]);
__CrestUChar(&param4[89][2]);
__CrestUChar(&param4[90][0]);
__CrestUChar(&param4[90][1]);
__CrestUChar(&param4[90][2]);
__CrestUChar(&param4[91][0]);
__CrestUChar(&param4[91][1]);
__CrestUChar(&param4[91][2]);
__CrestUChar(&param4[92][0]);
__CrestUChar(&param4[92][1]);
__CrestUChar(&param4[92][2]);
__CrestUChar(&param4[93][0]);
__CrestUChar(&param4[93][1]);
__CrestUChar(&param4[93][2]);
__CrestUChar(&param4[94][0]);
__CrestUChar(&param4[94][1]);
__CrestUChar(&param4[94][2]);
__CrestUChar(&param4[95][0]);
__CrestUChar(&param4[95][1]);
__CrestUChar(&param4[95][2]);
__CrestUChar(&param4[96][0]);
__CrestUChar(&param4[96][1]);
__CrestUChar(&param4[96][2]);
__CrestUChar(&param4[97][0]);
__CrestUChar(&param4[97][1]);
__CrestUChar(&param4[97][2]);
__CrestUChar(&param4[98][0]);
__CrestUChar(&param4[98][1]);
__CrestUChar(&param4[98][2]);
__CrestUChar(&param4[99][0]);
__CrestUChar(&param4[99][1]);
__CrestUChar(&param4[99][2]);
__CrestUChar(&param4[100][0]);
__CrestUChar(&param4[100][1]);
__CrestUChar(&param4[100][2]);
__CrestUChar(&param4[101][0]);
__CrestUChar(&param4[101][1]);
__CrestUChar(&param4[101][2]);
__CrestUChar(&param4[102][0]);
__CrestUChar(&param4[102][1]);
__CrestUChar(&param4[102][2]);
__CrestUChar(&param4[103][0]);
__CrestUChar(&param4[103][1]);
__CrestUChar(&param4[103][2]);
__CrestUChar(&param4[104][0]);
__CrestUChar(&param4[104][1]);
__CrestUChar(&param4[104][2]);
__CrestUChar(&param4[105][0]);
__CrestUChar(&param4[105][1]);
__CrestUChar(&param4[105][2]);
__CrestUChar(&param4[106][0]);
__CrestUChar(&param4[106][1]);
__CrestUChar(&param4[106][2]);
__CrestUChar(&param4[107][0]);
__CrestUChar(&param4[107][1]);
__CrestUChar(&param4[107][2]);
__CrestUChar(&param4[108][0]);
__CrestUChar(&param4[108][1]);
__CrestUChar(&param4[108][2]);
__CrestUChar(&param4[109][0]);
__CrestUChar(&param4[109][1]);
__CrestUChar(&param4[109][2]);
__CrestUChar(&param4[110][0]);
__CrestUChar(&param4[110][1]);
__CrestUChar(&param4[110][2]);
__CrestUChar(&param4[111][0]);
__CrestUChar(&param4[111][1]);
__CrestUChar(&param4[111][2]);
__CrestUChar(&param4[112][0]);
__CrestUChar(&param4[112][1]);
__CrestUChar(&param4[112][2]);
__CrestUChar(&param4[113][0]);
__CrestUChar(&param4[113][1]);
__CrestUChar(&param4[113][2]);
__CrestUChar(&param4[114][0]);
__CrestUChar(&param4[114][1]);
__CrestUChar(&param4[114][2]);
__CrestUChar(&param4[115][0]);
__CrestUChar(&param4[115][1]);
__CrestUChar(&param4[115][2]);
__CrestUChar(&param4[116][0]);
__CrestUChar(&param4[116][1]);
__CrestUChar(&param4[116][2]);
__CrestUChar(&param4[117][0]);
__CrestUChar(&param4[117][1]);
__CrestUChar(&param4[117][2]);
__CrestUChar(&param4[118][0]);
__CrestUChar(&param4[118][1]);
__CrestUChar(&param4[118][2]);
__CrestUChar(&param4[119][0]);
__CrestUChar(&param4[119][1]);
__CrestUChar(&param4[119][2]);
__CrestUChar(&param4[120][0]);
__CrestUChar(&param4[120][1]);
__CrestUChar(&param4[120][2]);
__CrestUChar(&param4[121][0]);
__CrestUChar(&param4[121][1]);
__CrestUChar(&param4[121][2]);
__CrestUChar(&param4[122][0]);
__CrestUChar(&param4[122][1]);
__CrestUChar(&param4[122][2]);
__CrestUChar(&param4[123][0]);
__CrestUChar(&param4[123][1]);
__CrestUChar(&param4[123][2]);
__CrestUChar(&param4[124][0]);
__CrestUChar(&param4[124][1]);
__CrestUChar(&param4[124][2]);
__CrestUChar(&param4[125][0]);
__CrestUChar(&param4[125][1]);
__CrestUChar(&param4[125][2]);
__CrestUChar(&param4[126][0]);
__CrestUChar(&param4[126][1]);
__CrestUChar(&param4[126][2]);
__CrestUChar(&param4[127][0]);
__CrestUChar(&param4[127][1]);
__CrestUChar(&param4[127][2]);
__CrestUChar(&param4[128][0]);
__CrestUChar(&param4[128][1]);
__CrestUChar(&param4[128][2]);
__CrestUChar(&param4[129][0]);
__CrestUChar(&param4[129][1]);
__CrestUChar(&param4[129][2]);
__CrestUChar(&param4[130][0]);
__CrestUChar(&param4[130][1]);
__CrestUChar(&param4[130][2]);
__CrestUChar(&param4[131][0]);
__CrestUChar(&param4[131][1]);
__CrestUChar(&param4[131][2]);
__CrestUChar(&param4[132][0]);
__CrestUChar(&param4[132][1]);
__CrestUChar(&param4[132][2]);
__CrestUChar(&param4[133][0]);
__CrestUChar(&param4[133][1]);
__CrestUChar(&param4[133][2]);
__CrestUChar(&param4[134][0]);
__CrestUChar(&param4[134][1]);
__CrestUChar(&param4[134][2]);
__CrestUChar(&param4[135][0]);
__CrestUChar(&param4[135][1]);
__CrestUChar(&param4[135][2]);
__CrestUChar(&param4[136][0]);
__CrestUChar(&param4[136][1]);
__CrestUChar(&param4[136][2]);
__CrestUChar(&param4[137][0]);
__CrestUChar(&param4[137][1]);
__CrestUChar(&param4[137][2]);
__CrestUChar(&param4[138][0]);
__CrestUChar(&param4[138][1]);
__CrestUChar(&param4[138][2]);
__CrestUChar(&param4[139][0]);
__CrestUChar(&param4[139][1]);
__CrestUChar(&param4[139][2]);
__CrestUChar(&param4[140][0]);
__CrestUChar(&param4[140][1]);
__CrestUChar(&param4[140][2]);
__CrestUChar(&param4[141][0]);
__CrestUChar(&param4[141][1]);
__CrestUChar(&param4[141][2]);
__CrestUChar(&param4[142][0]);
__CrestUChar(&param4[142][1]);
__CrestUChar(&param4[142][2]);
__CrestUChar(&param4[143][0]);
__CrestUChar(&param4[143][1]);
__CrestUChar(&param4[143][2]);
__CrestUChar(&param4[144][0]);
__CrestUChar(&param4[144][1]);
__CrestUChar(&param4[144][2]);
__CrestUChar(&param4[145][0]);
__CrestUChar(&param4[145][1]);
__CrestUChar(&param4[145][2]);
__CrestUChar(&param4[146][0]);
__CrestUChar(&param4[146][1]);
__CrestUChar(&param4[146][2]);
__CrestUChar(&param4[147][0]);
__CrestUChar(&param4[147][1]);
__CrestUChar(&param4[147][2]);
__CrestUChar(&param4[148][0]);
__CrestUChar(&param4[148][1]);
__CrestUChar(&param4[148][2]);
__CrestUChar(&param4[149][0]);
__CrestUChar(&param4[149][1]);
__CrestUChar(&param4[149][2]);
__CrestUChar(&param4[150][0]);
__CrestUChar(&param4[150][1]);
__CrestUChar(&param4[150][2]);
__CrestUChar(&param4[151][0]);
__CrestUChar(&param4[151][1]);
__CrestUChar(&param4[151][2]);
__CrestUChar(&param4[152][0]);
__CrestUChar(&param4[152][1]);
__CrestUChar(&param4[152][2]);
__CrestUChar(&param4[153][0]);
__CrestUChar(&param4[153][1]);
__CrestUChar(&param4[153][2]);
__CrestUChar(&param4[154][0]);
__CrestUChar(&param4[154][1]);
__CrestUChar(&param4[154][2]);
__CrestUChar(&param4[155][0]);
__CrestUChar(&param4[155][1]);
__CrestUChar(&param4[155][2]);
__CrestUChar(&param4[156][0]);
__CrestUChar(&param4[156][1]);
__CrestUChar(&param4[156][2]);
__CrestUChar(&param4[157][0]);
__CrestUChar(&param4[157][1]);
__CrestUChar(&param4[157][2]);
__CrestUChar(&param4[158][0]);
__CrestUChar(&param4[158][1]);
__CrestUChar(&param4[158][2]);
__CrestUChar(&param4[159][0]);
__CrestUChar(&param4[159][1]);
__CrestUChar(&param4[159][2]);
__CrestUChar(&param4[160][0]);
__CrestUChar(&param4[160][1]);
__CrestUChar(&param4[160][2]);
__CrestUChar(&param4[161][0]);
__CrestUChar(&param4[161][1]);
__CrestUChar(&param4[161][2]);
__CrestUChar(&param4[162][0]);
__CrestUChar(&param4[162][1]);
__CrestUChar(&param4[162][2]);
__CrestUChar(&param4[163][0]);
__CrestUChar(&param4[163][1]);
__CrestUChar(&param4[163][2]);
__CrestUChar(&param4[164][0]);
__CrestUChar(&param4[164][1]);
__CrestUChar(&param4[164][2]);
__CrestUChar(&param4[165][0]);
__CrestUChar(&param4[165][1]);
__CrestUChar(&param4[165][2]);
__CrestUChar(&param4[166][0]);
__CrestUChar(&param4[166][1]);
__CrestUChar(&param4[166][2]);
__CrestUChar(&param4[167][0]);
__CrestUChar(&param4[167][1]);
__CrestUChar(&param4[167][2]);
__CrestUChar(&param4[168][0]);
__CrestUChar(&param4[168][1]);
__CrestUChar(&param4[168][2]);
__CrestUChar(&param4[169][0]);
__CrestUChar(&param4[169][1]);
__CrestUChar(&param4[169][2]);
__CrestUChar(&param4[170][0]);
__CrestUChar(&param4[170][1]);
__CrestUChar(&param4[170][2]);
__CrestUChar(&param4[171][0]);
__CrestUChar(&param4[171][1]);
__CrestUChar(&param4[171][2]);
__CrestUChar(&param4[172][0]);
__CrestUChar(&param4[172][1]);
__CrestUChar(&param4[172][2]);
__CrestUChar(&param4[173][0]);
__CrestUChar(&param4[173][1]);
__CrestUChar(&param4[173][2]);
__CrestUChar(&param4[174][0]);
__CrestUChar(&param4[174][1]);
__CrestUChar(&param4[174][2]);
__CrestUChar(&param4[175][0]);
__CrestUChar(&param4[175][1]);
__CrestUChar(&param4[175][2]);
__CrestUChar(&param4[176][0]);
__CrestUChar(&param4[176][1]);
__CrestUChar(&param4[176][2]);
__CrestUChar(&param4[177][0]);
__CrestUChar(&param4[177][1]);
__CrestUChar(&param4[177][2]);
__CrestUChar(&param4[178][0]);
__CrestUChar(&param4[178][1]);
__CrestUChar(&param4[178][2]);
__CrestUChar(&param4[179][0]);
__CrestUChar(&param4[179][1]);
__CrestUChar(&param4[179][2]);
__CrestUChar(&param4[180][0]);
__CrestUChar(&param4[180][1]);
__CrestUChar(&param4[180][2]);
__CrestUChar(&param4[181][0]);
__CrestUChar(&param4[181][1]);
__CrestUChar(&param4[181][2]);
__CrestUChar(&param4[182][0]);
__CrestUChar(&param4[182][1]);
__CrestUChar(&param4[182][2]);
__CrestUChar(&param4[183][0]);
__CrestUChar(&param4[183][1]);
__CrestUChar(&param4[183][2]);
__CrestUChar(&param4[184][0]);
__CrestUChar(&param4[184][1]);
__CrestUChar(&param4[184][2]);
__CrestUChar(&param4[185][0]);
__CrestUChar(&param4[185][1]);
__CrestUChar(&param4[185][2]);
__CrestUChar(&param4[186][0]);
__CrestUChar(&param4[186][1]);
__CrestUChar(&param4[186][2]);
__CrestUChar(&param4[187][0]);
__CrestUChar(&param4[187][1]);
__CrestUChar(&param4[187][2]);
__CrestUChar(&param4[188][0]);
__CrestUChar(&param4[188][1]);
__CrestUChar(&param4[188][2]);
__CrestUChar(&param4[189][0]);
__CrestUChar(&param4[189][1]);
__CrestUChar(&param4[189][2]);
__CrestUChar(&param4[190][0]);
__CrestUChar(&param4[190][1]);
__CrestUChar(&param4[190][2]);
__CrestUChar(&param4[191][0]);
__CrestUChar(&param4[191][1]);
__CrestUChar(&param4[191][2]);
__CrestUChar(&param4[192][0]);
__CrestUChar(&param4[192][1]);
__CrestUChar(&param4[192][2]);
__CrestUChar(&param4[193][0]);
__CrestUChar(&param4[193][1]);
__CrestUChar(&param4[193][2]);
__CrestUChar(&param4[194][0]);
__CrestUChar(&param4[194][1]);
__CrestUChar(&param4[194][2]);
__CrestUChar(&param4[195][0]);
__CrestUChar(&param4[195][1]);
__CrestUChar(&param4[195][2]);
__CrestUChar(&param4[196][0]);
__CrestUChar(&param4[196][1]);
__CrestUChar(&param4[196][2]);
__CrestUChar(&param4[197][0]);
__CrestUChar(&param4[197][1]);
__CrestUChar(&param4[197][2]);
__CrestUChar(&param4[198][0]);
__CrestUChar(&param4[198][1]);
__CrestUChar(&param4[198][2]);
__CrestUChar(&param4[199][0]);
__CrestUChar(&param4[199][1]);
__CrestUChar(&param4[199][2]);
__CrestUChar(&param4[200][0]);
__CrestUChar(&param4[200][1]);
__CrestUChar(&param4[200][2]);
__CrestUChar(&param4[201][0]);
__CrestUChar(&param4[201][1]);
__CrestUChar(&param4[201][2]);
__CrestUChar(&param4[202][0]);
__CrestUChar(&param4[202][1]);
__CrestUChar(&param4[202][2]);
__CrestUChar(&param4[203][0]);
__CrestUChar(&param4[203][1]);
__CrestUChar(&param4[203][2]);
__CrestUChar(&param4[204][0]);
__CrestUChar(&param4[204][1]);
__CrestUChar(&param4[204][2]);
__CrestUChar(&param4[205][0]);
__CrestUChar(&param4[205][1]);
__CrestUChar(&param4[205][2]);
__CrestUChar(&param4[206][0]);
__CrestUChar(&param4[206][1]);
__CrestUChar(&param4[206][2]);
__CrestUChar(&param4[207][0]);
__CrestUChar(&param4[207][1]);
__CrestUChar(&param4[207][2]);
__CrestUChar(&param4[208][0]);
__CrestUChar(&param4[208][1]);
__CrestUChar(&param4[208][2]);
__CrestUChar(&param4[209][0]);
__CrestUChar(&param4[209][1]);
__CrestUChar(&param4[209][2]);
__CrestUChar(&param4[210][0]);
__CrestUChar(&param4[210][1]);
__CrestUChar(&param4[210][2]);
__CrestUChar(&param4[211][0]);
__CrestUChar(&param4[211][1]);
__CrestUChar(&param4[211][2]);
__CrestUChar(&param4[212][0]);
__CrestUChar(&param4[212][1]);
__CrestUChar(&param4[212][2]);
__CrestUChar(&param4[213][0]);
__CrestUChar(&param4[213][1]);
__CrestUChar(&param4[213][2]);
__CrestUChar(&param4[214][0]);
__CrestUChar(&param4[214][1]);
__CrestUChar(&param4[214][2]);
__CrestUChar(&param4[215][0]);
__CrestUChar(&param4[215][1]);
__CrestUChar(&param4[215][2]);
__CrestUChar(&param4[216][0]);
__CrestUChar(&param4[216][1]);
__CrestUChar(&param4[216][2]);
__CrestUChar(&param4[217][0]);
__CrestUChar(&param4[217][1]);
__CrestUChar(&param4[217][2]);
__CrestUChar(&param4[218][0]);
__CrestUChar(&param4[218][1]);
__CrestUChar(&param4[218][2]);
__CrestUChar(&param4[219][0]);
__CrestUChar(&param4[219][1]);
__CrestUChar(&param4[219][2]);
__CrestUChar(&param4[220][0]);
__CrestUChar(&param4[220][1]);
__CrestUChar(&param4[220][2]);
__CrestUChar(&param4[221][0]);
__CrestUChar(&param4[221][1]);
__CrestUChar(&param4[221][2]);
__CrestUChar(&param4[222][0]);
__CrestUChar(&param4[222][1]);
__CrestUChar(&param4[222][2]);
__CrestUChar(&param4[223][0]);
__CrestUChar(&param4[223][1]);
__CrestUChar(&param4[223][2]);
__CrestUChar(&param4[224][0]);
__CrestUChar(&param4[224][1]);
__CrestUChar(&param4[224][2]);
__CrestUChar(&param4[225][0]);
__CrestUChar(&param4[225][1]);
__CrestUChar(&param4[225][2]);
__CrestUChar(&param4[226][0]);
__CrestUChar(&param4[226][1]);
__CrestUChar(&param4[226][2]);
__CrestUChar(&param4[227][0]);
__CrestUChar(&param4[227][1]);
__CrestUChar(&param4[227][2]);
__CrestUChar(&param4[228][0]);
__CrestUChar(&param4[228][1]);
__CrestUChar(&param4[228][2]);
__CrestUChar(&param4[229][0]);
__CrestUChar(&param4[229][1]);
__CrestUChar(&param4[229][2]);
__CrestUChar(&param4[230][0]);
__CrestUChar(&param4[230][1]);
__CrestUChar(&param4[230][2]);
__CrestUChar(&param4[231][0]);
__CrestUChar(&param4[231][1]);
__CrestUChar(&param4[231][2]);
__CrestUChar(&param4[232][0]);
__CrestUChar(&param4[232][1]);
__CrestUChar(&param4[232][2]);
__CrestUChar(&param4[233][0]);
__CrestUChar(&param4[233][1]);
__CrestUChar(&param4[233][2]);
__CrestUChar(&param4[234][0]);
__CrestUChar(&param4[234][1]);
__CrestUChar(&param4[234][2]);
__CrestUChar(&param4[235][0]);
__CrestUChar(&param4[235][1]);
__CrestUChar(&param4[235][2]);
__CrestUChar(&param4[236][0]);
__CrestUChar(&param4[236][1]);
__CrestUChar(&param4[236][2]);
__CrestUChar(&param4[237][0]);
__CrestUChar(&param4[237][1]);
__CrestUChar(&param4[237][2]);
__CrestUChar(&param4[238][0]);
__CrestUChar(&param4[238][1]);
__CrestUChar(&param4[238][2]);
__CrestUChar(&param4[239][0]);
__CrestUChar(&param4[239][1]);
__CrestUChar(&param4[239][2]);
__CrestUChar(&param4[240][0]);
__CrestUChar(&param4[240][1]);
__CrestUChar(&param4[240][2]);
__CrestUChar(&param4[241][0]);
__CrestUChar(&param4[241][1]);
__CrestUChar(&param4[241][2]);
__CrestUChar(&param4[242][0]);
__CrestUChar(&param4[242][1]);
__CrestUChar(&param4[242][2]);
__CrestUChar(&param4[243][0]);
__CrestUChar(&param4[243][1]);
__CrestUChar(&param4[243][2]);
__CrestUChar(&param4[244][0]);
__CrestUChar(&param4[244][1]);
__CrestUChar(&param4[244][2]);
__CrestUChar(&param4[245][0]);
__CrestUChar(&param4[245][1]);
__CrestUChar(&param4[245][2]);
__CrestUChar(&param4[246][0]);
__CrestUChar(&param4[246][1]);
__CrestUChar(&param4[246][2]);
__CrestUChar(&param4[247][0]);
__CrestUChar(&param4[247][1]);
__CrestUChar(&param4[247][2]);
__CrestUChar(&param4[248][0]);
__CrestUChar(&param4[248][1]);
__CrestUChar(&param4[248][2]);
__CrestUChar(&param4[249][0]);
__CrestUChar(&param4[249][1]);
__CrestUChar(&param4[249][2]);
__CrestUChar(&param4[250][0]);
__CrestUChar(&param4[250][1]);
__CrestUChar(&param4[250][2]);
__CrestUChar(&param4[251][0]);
__CrestUChar(&param4[251][1]);
__CrestUChar(&param4[251][2]);
__CrestUChar(&param4[252][0]);
__CrestUChar(&param4[252][1]);
__CrestUChar(&param4[252][2]);
__CrestUChar(&param4[253][0]);
__CrestUChar(&param4[253][1]);
__CrestUChar(&param4[253][2]);
__CrestUChar(&param4[254][0]);
__CrestUChar(&param4[254][1]);
__CrestUChar(&param4[254][2]);
__CrestUChar(&param4[255][0]);
__CrestUChar(&param4[255][1]);
__CrestUChar(&param4[255][2]);
__CrestInt(&param5);
__CrestInt(&param6);
__CrestInt(&param7);
__CrestInt(&param8);
__CrestChar(&Bitmap_File_Head.zzMagic[0]);
__CrestChar(&Bitmap_File_Head.zzMagic[1]);
__CrestULong(&Bitmap_File_Head.bfSize);
__CrestUShort(&Bitmap_File_Head.zzHotX);
__CrestUShort(&Bitmap_File_Head.zzHotY);
__CrestULong(&Bitmap_File_Head.bfOffs);
__CrestULong(&Bitmap_File_Head.biSize);
__CrestULong(&Bitmap_Head.biWidth);
__CrestULong(&Bitmap_Head.biHeight);
__CrestUShort(&Bitmap_Head.biPlanes);
__CrestUShort(&Bitmap_Head.biBitCnt);
__CrestULong(&Bitmap_Head.biCompr);
__CrestULong(&Bitmap_Head.biSizeIm);
__CrestULong(&Bitmap_Head.biXPels);
__CrestULong(&Bitmap_Head.biYPels);
__CrestULong(&Bitmap_Head.biClrUsed);
__CrestULong(&Bitmap_Head.biClrImp);
at_log_file = malloc(1*sizeof(struct _IO_FILE));
__CrestInt(&at_log_file[0]._flags);
at_log_file[0]._IO_read_ptr = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._IO_read_ptr[0]);
__CrestChar(&at_log_file[0]._IO_read_ptr[1]);
__CrestChar(&at_log_file[0]._IO_read_ptr[2]);
at_log_file[0]._IO_read_end = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._IO_read_end[0]);
__CrestChar(&at_log_file[0]._IO_read_end[1]);
__CrestChar(&at_log_file[0]._IO_read_end[2]);
at_log_file[0]._IO_read_base = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._IO_read_base[0]);
__CrestChar(&at_log_file[0]._IO_read_base[1]);
__CrestChar(&at_log_file[0]._IO_read_base[2]);
at_log_file[0]._IO_write_base = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._IO_write_base[0]);
__CrestChar(&at_log_file[0]._IO_write_base[1]);
__CrestChar(&at_log_file[0]._IO_write_base[2]);
at_log_file[0]._IO_write_ptr = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._IO_write_ptr[0]);
__CrestChar(&at_log_file[0]._IO_write_ptr[1]);
__CrestChar(&at_log_file[0]._IO_write_ptr[2]);
at_log_file[0]._IO_write_end = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._IO_write_end[0]);
__CrestChar(&at_log_file[0]._IO_write_end[1]);
__CrestChar(&at_log_file[0]._IO_write_end[2]);
at_log_file[0]._IO_buf_base = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._IO_buf_base[0]);
__CrestChar(&at_log_file[0]._IO_buf_base[1]);
__CrestChar(&at_log_file[0]._IO_buf_base[2]);
at_log_file[0]._IO_buf_end = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._IO_buf_end[0]);
__CrestChar(&at_log_file[0]._IO_buf_end[1]);
__CrestChar(&at_log_file[0]._IO_buf_end[2]);
at_log_file[0]._IO_save_base = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._IO_save_base[0]);
__CrestChar(&at_log_file[0]._IO_save_base[1]);
__CrestChar(&at_log_file[0]._IO_save_base[2]);
at_log_file[0]._IO_backup_base = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._IO_backup_base[0]);
__CrestChar(&at_log_file[0]._IO_backup_base[1]);
__CrestChar(&at_log_file[0]._IO_backup_base[2]);
at_log_file[0]._IO_save_end = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._IO_save_end[0]);
__CrestChar(&at_log_file[0]._IO_save_end[1]);
__CrestChar(&at_log_file[0]._IO_save_end[2]);
at_log_file[0]._markers = malloc(1*sizeof(struct _IO_marker));
at_log_file[0]._markers[0]._next = malloc(1*sizeof(struct _IO_marker));
// Pointer Type: struct _IO_marker * of at_log_file[0]._markers[0]._next[0]._next is set as NULL
at_log_file[0]._markers[0]._next[0]._next = 0;
// Pointer Type: struct _IO_FILE * of at_log_file[0]._markers[0]._next[0]._sbuf is set as NULL
at_log_file[0]._markers[0]._next[0]._sbuf = 0;
__CrestInt(&at_log_file[0]._markers[0]._next[0]._pos);
at_log_file[0]._markers[0]._sbuf = malloc(1*sizeof(struct _IO_FILE));
__CrestInt(&at_log_file[0]._markers[0]._sbuf[0]._flags);
// Pointer Type: char * of at_log_file[0]._markers[0]._sbuf[0]._IO_read_ptr is set as NULL
at_log_file[0]._markers[0]._sbuf[0]._IO_read_ptr = 0;
// Pointer Type: char * of at_log_file[0]._markers[0]._sbuf[0]._IO_read_end is set as NULL
at_log_file[0]._markers[0]._sbuf[0]._IO_read_end = 0;
// Pointer Type: char * of at_log_file[0]._markers[0]._sbuf[0]._IO_read_base is set as NULL
at_log_file[0]._markers[0]._sbuf[0]._IO_read_base = 0;
// Pointer Type: char * of at_log_file[0]._markers[0]._sbuf[0]._IO_write_base is set as NULL
at_log_file[0]._markers[0]._sbuf[0]._IO_write_base = 0;
// Pointer Type: char * of at_log_file[0]._markers[0]._sbuf[0]._IO_write_ptr is set as NULL
at_log_file[0]._markers[0]._sbuf[0]._IO_write_ptr = 0;
// Pointer Type: char * of at_log_file[0]._markers[0]._sbuf[0]._IO_write_end is set as NULL
at_log_file[0]._markers[0]._sbuf[0]._IO_write_end = 0;
// Pointer Type: char * of at_log_file[0]._markers[0]._sbuf[0]._IO_buf_base is set as NULL
at_log_file[0]._markers[0]._sbuf[0]._IO_buf_base = 0;
// Pointer Type: char * of at_log_file[0]._markers[0]._sbuf[0]._IO_buf_end is set as NULL
at_log_file[0]._markers[0]._sbuf[0]._IO_buf_end = 0;
// Pointer Type: char * of at_log_file[0]._markers[0]._sbuf[0]._IO_save_base is set as NULL
at_log_file[0]._markers[0]._sbuf[0]._IO_save_base = 0;
// Pointer Type: char * of at_log_file[0]._markers[0]._sbuf[0]._IO_backup_base is set as NULL
at_log_file[0]._markers[0]._sbuf[0]._IO_backup_base = 0;
// Pointer Type: char * of at_log_file[0]._markers[0]._sbuf[0]._IO_save_end is set as NULL
at_log_file[0]._markers[0]._sbuf[0]._IO_save_end = 0;
// Pointer Type: struct _IO_marker * of at_log_file[0]._markers[0]._sbuf[0]._markers is set as NULL
at_log_file[0]._markers[0]._sbuf[0]._markers = 0;
// Pointer Type: struct _IO_FILE * of at_log_file[0]._markers[0]._sbuf[0]._chain is set as NULL
at_log_file[0]._markers[0]._sbuf[0]._chain = 0;
__CrestInt(&at_log_file[0]._markers[0]._sbuf[0]._fileno);
__CrestInt(&at_log_file[0]._markers[0]._sbuf[0]._flags2);
__CrestLong(&at_log_file[0]._markers[0]._sbuf[0]._old_offset);
__CrestUShort(&at_log_file[0]._markers[0]._sbuf[0]._cur_column);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._vtable_offset);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._shortbuf[0]);
// Pointer Type: void * of at_log_file[0]._markers[0]._sbuf[0]._lock is set as NULL
at_log_file[0]._markers[0]._sbuf[0]._lock = 0;
__CrestLong(&at_log_file[0]._markers[0]._sbuf[0]._offset);
// Pointer Type: void * of at_log_file[0]._markers[0]._sbuf[0].__pad1 is set as NULL
at_log_file[0]._markers[0]._sbuf[0].__pad1 = 0;
// Pointer Type: void * of at_log_file[0]._markers[0]._sbuf[0].__pad2 is set as NULL
at_log_file[0]._markers[0]._sbuf[0].__pad2 = 0;
// Pointer Type: void * of at_log_file[0]._markers[0]._sbuf[0].__pad3 is set as NULL
at_log_file[0]._markers[0]._sbuf[0].__pad3 = 0;
// Pointer Type: void * of at_log_file[0]._markers[0]._sbuf[0].__pad4 is set as NULL
at_log_file[0]._markers[0]._sbuf[0].__pad4 = 0;
param2 = param3 = 256;
__CrestULong(&at_log_file[0]._markers[0]._sbuf[0].__pad5);
__CrestInt(&at_log_file[0]._markers[0]._sbuf[0]._mode);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[0]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[1]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[2]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[3]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[4]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[5]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[6]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[7]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[8]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[9]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[10]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[11]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[12]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[13]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[14]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[15]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[16]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[17]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[18]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[19]);
__CrestInt(&at_log_file[0]._markers[0]._pos);
at_log_file[0]._chain = malloc(1*sizeof(struct _IO_FILE));
__CrestInt(&at_log_file[0]._chain[0]._flags);
at_log_file[0]._chain[0]._IO_read_ptr = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._chain[0]._IO_read_ptr[0]);
__CrestChar(&at_log_file[0]._chain[0]._IO_read_ptr[1]);
__CrestChar(&at_log_file[0]._chain[0]._IO_read_ptr[2]);
at_log_file[0]._chain[0]._IO_read_end = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._chain[0]._IO_read_end[0]);
__CrestChar(&at_log_file[0]._chain[0]._IO_read_end[1]);
__CrestChar(&at_log_file[0]._chain[0]._IO_read_end[2]);
at_log_file[0]._chain[0]._IO_read_base = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._chain[0]._IO_read_base[0]);
__CrestChar(&at_log_file[0]._chain[0]._IO_read_base[1]);
__CrestChar(&at_log_file[0]._chain[0]._IO_read_base[2]);
at_log_file[0]._chain[0]._IO_write_base = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._chain[0]._IO_write_base[0]);
__CrestChar(&at_log_file[0]._chain[0]._IO_write_base[1]);
__CrestChar(&at_log_file[0]._chain[0]._IO_write_base[2]);
at_log_file[0]._chain[0]._IO_write_ptr = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._chain[0]._IO_write_ptr[0]);
__CrestChar(&at_log_file[0]._chain[0]._IO_write_ptr[1]);
__CrestChar(&at_log_file[0]._chain[0]._IO_write_ptr[2]);
at_log_file[0]._chain[0]._IO_write_end = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._chain[0]._IO_write_end[0]);
__CrestChar(&at_log_file[0]._chain[0]._IO_write_end[1]);
__CrestChar(&at_log_file[0]._chain[0]._IO_write_end[2]);
at_log_file[0]._chain[0]._IO_buf_base = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._chain[0]._IO_buf_base[0]);
__CrestChar(&at_log_file[0]._chain[0]._IO_buf_base[1]);
__CrestChar(&at_log_file[0]._chain[0]._IO_buf_base[2]);
at_log_file[0]._chain[0]._IO_buf_end = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._chain[0]._IO_buf_end[0]);
__CrestChar(&at_log_file[0]._chain[0]._IO_buf_end[1]);
__CrestChar(&at_log_file[0]._chain[0]._IO_buf_end[2]);
at_log_file[0]._chain[0]._IO_save_base = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._chain[0]._IO_save_base[0]);
__CrestChar(&at_log_file[0]._chain[0]._IO_save_base[1]);
__CrestChar(&at_log_file[0]._chain[0]._IO_save_base[2]);
at_log_file[0]._chain[0]._IO_backup_base = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._chain[0]._IO_backup_base[0]);
__CrestChar(&at_log_file[0]._chain[0]._IO_backup_base[1]);
__CrestChar(&at_log_file[0]._chain[0]._IO_backup_base[2]);
at_log_file[0]._chain[0]._IO_save_end = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._chain[0]._IO_save_end[0]);
__CrestChar(&at_log_file[0]._chain[0]._IO_save_end[1]);
__CrestChar(&at_log_file[0]._chain[0]._IO_save_end[2]);
at_log_file[0]._chain[0]._markers = malloc(1*sizeof(struct _IO_marker));
// Pointer Type: struct _IO_marker * of at_log_file[0]._chain[0]._markers[0]._next is set as NULL
at_log_file[0]._chain[0]._markers[0]._next = 0;
// Pointer Type: struct _IO_FILE * of at_log_file[0]._chain[0]._markers[0]._sbuf is set as NULL
at_log_file[0]._chain[0]._markers[0]._sbuf = 0;
__CrestInt(&at_log_file[0]._chain[0]._markers[0]._pos);
at_log_file[0]._chain[0]._chain = malloc(1*sizeof(struct _IO_FILE));
__CrestInt(&at_log_file[0]._chain[0]._chain[0]._flags);
// Pointer Type: char * of at_log_file[0]._chain[0]._chain[0]._IO_read_ptr is set as NULL
at_log_file[0]._chain[0]._chain[0]._IO_read_ptr = 0;
// Pointer Type: char * of at_log_file[0]._chain[0]._chain[0]._IO_read_end is set as NULL
at_log_file[0]._chain[0]._chain[0]._IO_read_end = 0;
// Pointer Type: char * of at_log_file[0]._chain[0]._chain[0]._IO_read_base is set as NULL
at_log_file[0]._chain[0]._chain[0]._IO_read_base = 0;
// Pointer Type: char * of at_log_file[0]._chain[0]._chain[0]._IO_write_base is set as NULL
at_log_file[0]._chain[0]._chain[0]._IO_write_base = 0;
// Pointer Type: char * of at_log_file[0]._chain[0]._chain[0]._IO_write_ptr is set as NULL
at_log_file[0]._chain[0]._chain[0]._IO_write_ptr = 0;
// Pointer Type: char * of at_log_file[0]._chain[0]._chain[0]._IO_write_end is set as NULL
at_log_file[0]._chain[0]._chain[0]._IO_write_end = 0;
// Pointer Type: char * of at_log_file[0]._chain[0]._chain[0]._IO_buf_base is set as NULL
at_log_file[0]._chain[0]._chain[0]._IO_buf_base = 0;
// Pointer Type: char * of at_log_file[0]._chain[0]._chain[0]._IO_buf_end is set as NULL
at_log_file[0]._chain[0]._chain[0]._IO_buf_end = 0;
// Pointer Type: char * of at_log_file[0]._chain[0]._chain[0]._IO_save_base is set as NULL
at_log_file[0]._chain[0]._chain[0]._IO_save_base = 0;
// Pointer Type: char * of at_log_file[0]._chain[0]._chain[0]._IO_backup_base is set as NULL
at_log_file[0]._chain[0]._chain[0]._IO_backup_base = 0;
// Pointer Type: char * of at_log_file[0]._chain[0]._chain[0]._IO_save_end is set as NULL
at_log_file[0]._chain[0]._chain[0]._IO_save_end = 0;
// Pointer Type: struct _IO_marker * of at_log_file[0]._chain[0]._chain[0]._markers is set as NULL
at_log_file[0]._chain[0]._chain[0]._markers = 0;
// Pointer Type: struct _IO_FILE * of at_log_file[0]._chain[0]._chain[0]._chain is set as NULL
at_log_file[0]._chain[0]._chain[0]._chain = 0;
__CrestInt(&at_log_file[0]._chain[0]._chain[0]._fileno);
__CrestInt(&at_log_file[0]._chain[0]._chain[0]._flags2);
__CrestLong(&at_log_file[0]._chain[0]._chain[0]._old_offset);
__CrestUShort(&at_log_file[0]._chain[0]._chain[0]._cur_column);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._vtable_offset);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._shortbuf[0]);
// Pointer Type: void * of at_log_file[0]._chain[0]._chain[0]._lock is set as NULL
at_log_file[0]._chain[0]._chain[0]._lock = 0;
__CrestLong(&at_log_file[0]._chain[0]._chain[0]._offset);
// Pointer Type: void * of at_log_file[0]._chain[0]._chain[0].__pad1 is set as NULL
at_log_file[0]._chain[0]._chain[0].__pad1 = 0;
// Pointer Type: void * of at_log_file[0]._chain[0]._chain[0].__pad2 is set as NULL
at_log_file[0]._chain[0]._chain[0].__pad2 = 0;
// Pointer Type: void * of at_log_file[0]._chain[0]._chain[0].__pad3 is set as NULL
at_log_file[0]._chain[0]._chain[0].__pad3 = 0;
// Pointer Type: void * of at_log_file[0]._chain[0]._chain[0].__pad4 is set as NULL
at_log_file[0]._chain[0]._chain[0].__pad4 = 0;
__CrestULong(&at_log_file[0]._chain[0]._chain[0].__pad5);
__CrestInt(&at_log_file[0]._chain[0]._chain[0]._mode);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[0]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[1]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[2]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[3]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[4]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[5]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[6]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[7]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[8]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[9]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[10]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[11]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[12]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[13]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[14]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[15]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[16]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[17]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[18]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[19]);
__CrestInt(&at_log_file[0]._chain[0]._fileno);
__CrestInt(&at_log_file[0]._chain[0]._flags2);
__CrestLong(&at_log_file[0]._chain[0]._old_offset);
__CrestUShort(&at_log_file[0]._chain[0]._cur_column);
__CrestChar(&at_log_file[0]._chain[0]._vtable_offset);
__CrestChar(&at_log_file[0]._chain[0]._shortbuf[0]);
// Pointee type 'void' is an incomplete type
at_log_file[0]._chain[0]._lock = 0;
__CrestLong(&at_log_file[0]._chain[0]._offset);
// Pointee type 'void' is an incomplete type
at_log_file[0]._chain[0].__pad1 = 0;
// Pointee type 'void' is an incomplete type
at_log_file[0]._chain[0].__pad2 = 0;
// Pointee type 'void' is an incomplete type
at_log_file[0]._chain[0].__pad3 = 0;
// Pointee type 'void' is an incomplete type
at_log_file[0]._chain[0].__pad4 = 0;
__CrestULong(&at_log_file[0]._chain[0].__pad5);
__CrestInt(&at_log_file[0]._chain[0]._mode);
__CrestChar(&at_log_file[0]._chain[0]._unused2[0]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[1]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[2]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[3]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[4]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[5]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[6]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[7]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[8]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[9]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[10]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[11]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[12]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[13]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[14]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[15]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[16]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[17]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[18]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[19]);
__CrestInt(&at_log_file[0]._fileno);
__CrestInt(&at_log_file[0]._flags2);
__CrestLong(&at_log_file[0]._old_offset);
__CrestUShort(&at_log_file[0]._cur_column);
__CrestChar(&at_log_file[0]._vtable_offset);
__CrestChar(&at_log_file[0]._shortbuf[0]);
// Pointee type 'void' is an incomplete type
at_log_file[0]._lock = 0;
__CrestLong(&at_log_file[0]._offset);
// Pointee type 'void' is an incomplete type
at_log_file[0].__pad1 = 0;
// Pointee type 'void' is an incomplete type
at_log_file[0].__pad2 = 0;
// Pointee type 'void' is an incomplete type
at_log_file[0].__pad3 = 0;
// Pointee type 'void' is an incomplete type
at_log_file[0].__pad4 = 0;
__CrestULong(&at_log_file[0].__pad5);
__CrestInt(&at_log_file[0]._mode);
__CrestChar(&at_log_file[0]._unused2[0]);
__CrestChar(&at_log_file[0]._unused2[1]);
__CrestChar(&at_log_file[0]._unused2[2]);
__CrestChar(&at_log_file[0]._unused2[3]);
__CrestChar(&at_log_file[0]._unused2[4]);
__CrestChar(&at_log_file[0]._unused2[5]);
__CrestChar(&at_log_file[0]._unused2[6]);
__CrestChar(&at_log_file[0]._unused2[7]);
__CrestChar(&at_log_file[0]._unused2[8]);
__CrestChar(&at_log_file[0]._unused2[9]);
__CrestChar(&at_log_file[0]._unused2[10]);
__CrestChar(&at_log_file[0]._unused2[11]);
__CrestChar(&at_log_file[0]._unused2[12]);
__CrestChar(&at_log_file[0]._unused2[13]);
__CrestChar(&at_log_file[0]._unused2[14]);
__CrestChar(&at_log_file[0]._unused2[15]);
__CrestChar(&at_log_file[0]._unused2[16]);
__CrestChar(&at_log_file[0]._unused2[17]);
__CrestChar(&at_log_file[0]._unused2[18]);
__CrestChar(&at_log_file[0]._unused2[19]);
// stdin will be set by C standard library
// stdout will be set by C standard library
return ReadImage(param1,param2,param3,param4,param5,param6,param7,param8);
}
int test_main(){
ReadImage_driver();
 return 0;}

void init_input_bmp_i(){
__CrestChar(&Bitmap_File_Head.zzMagic[0]);
__CrestChar(&Bitmap_File_Head.zzMagic[1]);
__CrestULong(&Bitmap_File_Head.bfSize);
__CrestUShort(&Bitmap_File_Head.zzHotX);
__CrestUShort(&Bitmap_File_Head.zzHotY);
__CrestULong(&Bitmap_File_Head.bfOffs);
__CrestULong(&Bitmap_File_Head.biSize);
__CrestULong(&Bitmap_Head.biWidth);
__CrestULong(&Bitmap_Head.biHeight);
__CrestUShort(&Bitmap_Head.biPlanes);
__CrestUShort(&Bitmap_Head.biBitCnt);
__CrestULong(&Bitmap_Head.biCompr);
__CrestULong(&Bitmap_Head.biSizeIm);
__CrestULong(&Bitmap_Head.biXPels);
__CrestULong(&Bitmap_Head.biYPels);
__CrestULong(&Bitmap_Head.biClrUsed);
__CrestULong(&Bitmap_Head.biClrImp);
at_log_file = malloc(1*sizeof(struct _IO_FILE));
__CrestInt(&at_log_file[0]._flags);
at_log_file[0]._IO_read_ptr = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._IO_read_ptr[0]);
__CrestChar(&at_log_file[0]._IO_read_ptr[1]);
__CrestChar(&at_log_file[0]._IO_read_ptr[2]);
at_log_file[0]._IO_read_end = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._IO_read_end[0]);
__CrestChar(&at_log_file[0]._IO_read_end[1]);
__CrestChar(&at_log_file[0]._IO_read_end[2]);
at_log_file[0]._IO_read_base = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._IO_read_base[0]);
__CrestChar(&at_log_file[0]._IO_read_base[1]);
__CrestChar(&at_log_file[0]._IO_read_base[2]);
at_log_file[0]._IO_write_base = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._IO_write_base[0]);
__CrestChar(&at_log_file[0]._IO_write_base[1]);
__CrestChar(&at_log_file[0]._IO_write_base[2]);
at_log_file[0]._IO_write_ptr = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._IO_write_ptr[0]);
__CrestChar(&at_log_file[0]._IO_write_ptr[1]);
__CrestChar(&at_log_file[0]._IO_write_ptr[2]);
at_log_file[0]._IO_write_end = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._IO_write_end[0]);
__CrestChar(&at_log_file[0]._IO_write_end[1]);
__CrestChar(&at_log_file[0]._IO_write_end[2]);
at_log_file[0]._IO_buf_base = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._IO_buf_base[0]);
__CrestChar(&at_log_file[0]._IO_buf_base[1]);
__CrestChar(&at_log_file[0]._IO_buf_base[2]);
at_log_file[0]._IO_buf_end = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._IO_buf_end[0]);
__CrestChar(&at_log_file[0]._IO_buf_end[1]);
__CrestChar(&at_log_file[0]._IO_buf_end[2]);
at_log_file[0]._IO_save_base = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._IO_save_base[0]);
__CrestChar(&at_log_file[0]._IO_save_base[1]);
__CrestChar(&at_log_file[0]._IO_save_base[2]);
at_log_file[0]._IO_backup_base = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._IO_backup_base[0]);
__CrestChar(&at_log_file[0]._IO_backup_base[1]);
__CrestChar(&at_log_file[0]._IO_backup_base[2]);
at_log_file[0]._IO_save_end = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._IO_save_end[0]);
__CrestChar(&at_log_file[0]._IO_save_end[1]);
__CrestChar(&at_log_file[0]._IO_save_end[2]);
at_log_file[0]._markers = malloc(1*sizeof(struct _IO_marker));
at_log_file[0]._markers[0]._next = malloc(1*sizeof(struct _IO_marker));
// Pointer Type: struct _IO_marker * of at_log_file[0]._markers[0]._next[0]._next is set as NULL
at_log_file[0]._markers[0]._next[0]._next = 0;
// Pointer Type: struct _IO_FILE * of at_log_file[0]._markers[0]._next[0]._sbuf is set as NULL
at_log_file[0]._markers[0]._next[0]._sbuf = 0;
__CrestInt(&at_log_file[0]._markers[0]._next[0]._pos);
at_log_file[0]._markers[0]._sbuf = malloc(1*sizeof(struct _IO_FILE));
__CrestInt(&at_log_file[0]._markers[0]._sbuf[0]._flags);
// Pointer Type: char * of at_log_file[0]._markers[0]._sbuf[0]._IO_read_ptr is set as NULL
at_log_file[0]._markers[0]._sbuf[0]._IO_read_ptr = 0;
// Pointer Type: char * of at_log_file[0]._markers[0]._sbuf[0]._IO_read_end is set as NULL
at_log_file[0]._markers[0]._sbuf[0]._IO_read_end = 0;
// Pointer Type: char * of at_log_file[0]._markers[0]._sbuf[0]._IO_read_base is set as NULL
at_log_file[0]._markers[0]._sbuf[0]._IO_read_base = 0;
// Pointer Type: char * of at_log_file[0]._markers[0]._sbuf[0]._IO_write_base is set as NULL
at_log_file[0]._markers[0]._sbuf[0]._IO_write_base = 0;
// Pointer Type: char * of at_log_file[0]._markers[0]._sbuf[0]._IO_write_ptr is set as NULL
at_log_file[0]._markers[0]._sbuf[0]._IO_write_ptr = 0;
// Pointer Type: char * of at_log_file[0]._markers[0]._sbuf[0]._IO_write_end is set as NULL
at_log_file[0]._markers[0]._sbuf[0]._IO_write_end = 0;
// Pointer Type: char * of at_log_file[0]._markers[0]._sbuf[0]._IO_buf_base is set as NULL
at_log_file[0]._markers[0]._sbuf[0]._IO_buf_base = 0;
// Pointer Type: char * of at_log_file[0]._markers[0]._sbuf[0]._IO_buf_end is set as NULL
at_log_file[0]._markers[0]._sbuf[0]._IO_buf_end = 0;
// Pointer Type: char * of at_log_file[0]._markers[0]._sbuf[0]._IO_save_base is set as NULL
at_log_file[0]._markers[0]._sbuf[0]._IO_save_base = 0;
// Pointer Type: char * of at_log_file[0]._markers[0]._sbuf[0]._IO_backup_base is set as NULL
at_log_file[0]._markers[0]._sbuf[0]._IO_backup_base = 0;
// Pointer Type: char * of at_log_file[0]._markers[0]._sbuf[0]._IO_save_end is set as NULL
at_log_file[0]._markers[0]._sbuf[0]._IO_save_end = 0;
// Pointer Type: struct _IO_marker * of at_log_file[0]._markers[0]._sbuf[0]._markers is set as NULL
at_log_file[0]._markers[0]._sbuf[0]._markers = 0;
// Pointer Type: struct _IO_FILE * of at_log_file[0]._markers[0]._sbuf[0]._chain is set as NULL
at_log_file[0]._markers[0]._sbuf[0]._chain = 0;
__CrestInt(&at_log_file[0]._markers[0]._sbuf[0]._fileno);
__CrestInt(&at_log_file[0]._markers[0]._sbuf[0]._flags2);
__CrestLong(&at_log_file[0]._markers[0]._sbuf[0]._old_offset);
__CrestUShort(&at_log_file[0]._markers[0]._sbuf[0]._cur_column);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._vtable_offset);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._shortbuf[0]);
// Pointer Type: void * of at_log_file[0]._markers[0]._sbuf[0]._lock is set as NULL
at_log_file[0]._markers[0]._sbuf[0]._lock = 0;
__CrestLong(&at_log_file[0]._markers[0]._sbuf[0]._offset);
// Pointer Type: void * of at_log_file[0]._markers[0]._sbuf[0].__pad1 is set as NULL
at_log_file[0]._markers[0]._sbuf[0].__pad1 = 0;
// Pointer Type: void * of at_log_file[0]._markers[0]._sbuf[0].__pad2 is set as NULL
at_log_file[0]._markers[0]._sbuf[0].__pad2 = 0;
// Pointer Type: void * of at_log_file[0]._markers[0]._sbuf[0].__pad3 is set as NULL
at_log_file[0]._markers[0]._sbuf[0].__pad3 = 0;
// Pointer Type: void * of at_log_file[0]._markers[0]._sbuf[0].__pad4 is set as NULL
at_log_file[0]._markers[0]._sbuf[0].__pad4 = 0;
__CrestULong(&at_log_file[0]._markers[0]._sbuf[0].__pad5);
__CrestInt(&at_log_file[0]._markers[0]._sbuf[0]._mode);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[0]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[1]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[2]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[3]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[4]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[5]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[6]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[7]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[8]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[9]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[10]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[11]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[12]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[13]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[14]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[15]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[16]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[17]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[18]);
__CrestChar(&at_log_file[0]._markers[0]._sbuf[0]._unused2[19]);
__CrestInt(&at_log_file[0]._markers[0]._pos);
at_log_file[0]._chain = malloc(1*sizeof(struct _IO_FILE));
__CrestInt(&at_log_file[0]._chain[0]._flags);
at_log_file[0]._chain[0]._IO_read_ptr = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._chain[0]._IO_read_ptr[0]);
__CrestChar(&at_log_file[0]._chain[0]._IO_read_ptr[1]);
__CrestChar(&at_log_file[0]._chain[0]._IO_read_ptr[2]);
at_log_file[0]._chain[0]._IO_read_end = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._chain[0]._IO_read_end[0]);
__CrestChar(&at_log_file[0]._chain[0]._IO_read_end[1]);
__CrestChar(&at_log_file[0]._chain[0]._IO_read_end[2]);
at_log_file[0]._chain[0]._IO_read_base = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._chain[0]._IO_read_base[0]);
__CrestChar(&at_log_file[0]._chain[0]._IO_read_base[1]);
__CrestChar(&at_log_file[0]._chain[0]._IO_read_base[2]);
at_log_file[0]._chain[0]._IO_write_base = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._chain[0]._IO_write_base[0]);
__CrestChar(&at_log_file[0]._chain[0]._IO_write_base[1]);
__CrestChar(&at_log_file[0]._chain[0]._IO_write_base[2]);
at_log_file[0]._chain[0]._IO_write_ptr = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._chain[0]._IO_write_ptr[0]);
__CrestChar(&at_log_file[0]._chain[0]._IO_write_ptr[1]);
__CrestChar(&at_log_file[0]._chain[0]._IO_write_ptr[2]);
at_log_file[0]._chain[0]._IO_write_end = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._chain[0]._IO_write_end[0]);
__CrestChar(&at_log_file[0]._chain[0]._IO_write_end[1]);
__CrestChar(&at_log_file[0]._chain[0]._IO_write_end[2]);
at_log_file[0]._chain[0]._IO_buf_base = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._chain[0]._IO_buf_base[0]);
__CrestChar(&at_log_file[0]._chain[0]._IO_buf_base[1]);
__CrestChar(&at_log_file[0]._chain[0]._IO_buf_base[2]);
at_log_file[0]._chain[0]._IO_buf_end = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._chain[0]._IO_buf_end[0]);
__CrestChar(&at_log_file[0]._chain[0]._IO_buf_end[1]);
__CrestChar(&at_log_file[0]._chain[0]._IO_buf_end[2]);
at_log_file[0]._chain[0]._IO_save_base = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._chain[0]._IO_save_base[0]);
__CrestChar(&at_log_file[0]._chain[0]._IO_save_base[1]);
__CrestChar(&at_log_file[0]._chain[0]._IO_save_base[2]);
at_log_file[0]._chain[0]._IO_backup_base = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._chain[0]._IO_backup_base[0]);
__CrestChar(&at_log_file[0]._chain[0]._IO_backup_base[1]);
__CrestChar(&at_log_file[0]._chain[0]._IO_backup_base[2]);
at_log_file[0]._chain[0]._IO_save_end = malloc(3*sizeof(char));
__CrestChar(&at_log_file[0]._chain[0]._IO_save_end[0]);
__CrestChar(&at_log_file[0]._chain[0]._IO_save_end[1]);
__CrestChar(&at_log_file[0]._chain[0]._IO_save_end[2]);
at_log_file[0]._chain[0]._markers = malloc(1*sizeof(struct _IO_marker));
// Pointer Type: struct _IO_marker * of at_log_file[0]._chain[0]._markers[0]._next is set as NULL
at_log_file[0]._chain[0]._markers[0]._next = 0;
// Pointer Type: struct _IO_FILE * of at_log_file[0]._chain[0]._markers[0]._sbuf is set as NULL
at_log_file[0]._chain[0]._markers[0]._sbuf = 0;
__CrestInt(&at_log_file[0]._chain[0]._markers[0]._pos);
at_log_file[0]._chain[0]._chain = malloc(1*sizeof(struct _IO_FILE));
__CrestInt(&at_log_file[0]._chain[0]._chain[0]._flags);
// Pointer Type: char * of at_log_file[0]._chain[0]._chain[0]._IO_read_ptr is set as NULL
at_log_file[0]._chain[0]._chain[0]._IO_read_ptr = 0;
// Pointer Type: char * of at_log_file[0]._chain[0]._chain[0]._IO_read_end is set as NULL
at_log_file[0]._chain[0]._chain[0]._IO_read_end = 0;
// Pointer Type: char * of at_log_file[0]._chain[0]._chain[0]._IO_read_base is set as NULL
at_log_file[0]._chain[0]._chain[0]._IO_read_base = 0;
// Pointer Type: char * of at_log_file[0]._chain[0]._chain[0]._IO_write_base is set as NULL
at_log_file[0]._chain[0]._chain[0]._IO_write_base = 0;
// Pointer Type: char * of at_log_file[0]._chain[0]._chain[0]._IO_write_ptr is set as NULL
at_log_file[0]._chain[0]._chain[0]._IO_write_ptr = 0;
// Pointer Type: char * of at_log_file[0]._chain[0]._chain[0]._IO_write_end is set as NULL
at_log_file[0]._chain[0]._chain[0]._IO_write_end = 0;
// Pointer Type: char * of at_log_file[0]._chain[0]._chain[0]._IO_buf_base is set as NULL
at_log_file[0]._chain[0]._chain[0]._IO_buf_base = 0;
// Pointer Type: char * of at_log_file[0]._chain[0]._chain[0]._IO_buf_end is set as NULL
at_log_file[0]._chain[0]._chain[0]._IO_buf_end = 0;
// Pointer Type: char * of at_log_file[0]._chain[0]._chain[0]._IO_save_base is set as NULL
at_log_file[0]._chain[0]._chain[0]._IO_save_base = 0;
// Pointer Type: char * of at_log_file[0]._chain[0]._chain[0]._IO_backup_base is set as NULL
at_log_file[0]._chain[0]._chain[0]._IO_backup_base = 0;
// Pointer Type: char * of at_log_file[0]._chain[0]._chain[0]._IO_save_end is set as NULL
at_log_file[0]._chain[0]._chain[0]._IO_save_end = 0;
// Pointer Type: struct _IO_marker * of at_log_file[0]._chain[0]._chain[0]._markers is set as NULL
at_log_file[0]._chain[0]._chain[0]._markers = 0;
// Pointer Type: struct _IO_FILE * of at_log_file[0]._chain[0]._chain[0]._chain is set as NULL
at_log_file[0]._chain[0]._chain[0]._chain = 0;
__CrestInt(&at_log_file[0]._chain[0]._chain[0]._fileno);
__CrestInt(&at_log_file[0]._chain[0]._chain[0]._flags2);
__CrestLong(&at_log_file[0]._chain[0]._chain[0]._old_offset);
__CrestUShort(&at_log_file[0]._chain[0]._chain[0]._cur_column);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._vtable_offset);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._shortbuf[0]);
// Pointer Type: void * of at_log_file[0]._chain[0]._chain[0]._lock is set as NULL
at_log_file[0]._chain[0]._chain[0]._lock = 0;
__CrestLong(&at_log_file[0]._chain[0]._chain[0]._offset);
// Pointer Type: void * of at_log_file[0]._chain[0]._chain[0].__pad1 is set as NULL
at_log_file[0]._chain[0]._chain[0].__pad1 = 0;
// Pointer Type: void * of at_log_file[0]._chain[0]._chain[0].__pad2 is set as NULL
at_log_file[0]._chain[0]._chain[0].__pad2 = 0;
// Pointer Type: void * of at_log_file[0]._chain[0]._chain[0].__pad3 is set as NULL
at_log_file[0]._chain[0]._chain[0].__pad3 = 0;
// Pointer Type: void * of at_log_file[0]._chain[0]._chain[0].__pad4 is set as NULL
at_log_file[0]._chain[0]._chain[0].__pad4 = 0;
__CrestULong(&at_log_file[0]._chain[0]._chain[0].__pad5);
__CrestInt(&at_log_file[0]._chain[0]._chain[0]._mode);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[0]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[1]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[2]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[3]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[4]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[5]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[6]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[7]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[8]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[9]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[10]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[11]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[12]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[13]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[14]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[15]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[16]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[17]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[18]);
__CrestChar(&at_log_file[0]._chain[0]._chain[0]._unused2[19]);
__CrestInt(&at_log_file[0]._chain[0]._fileno);
__CrestInt(&at_log_file[0]._chain[0]._flags2);
__CrestLong(&at_log_file[0]._chain[0]._old_offset);
__CrestUShort(&at_log_file[0]._chain[0]._cur_column);
__CrestChar(&at_log_file[0]._chain[0]._vtable_offset);
__CrestChar(&at_log_file[0]._chain[0]._shortbuf[0]);
// Pointee type 'void' is an incomplete type
at_log_file[0]._chain[0]._lock = 0;
__CrestLong(&at_log_file[0]._chain[0]._offset);
// Pointee type 'void' is an incomplete type
at_log_file[0]._chain[0].__pad1 = 0;
// Pointee type 'void' is an incomplete type
at_log_file[0]._chain[0].__pad2 = 0;
// Pointee type 'void' is an incomplete type
at_log_file[0]._chain[0].__pad3 = 0;
// Pointee type 'void' is an incomplete type
at_log_file[0]._chain[0].__pad4 = 0;
__CrestULong(&at_log_file[0]._chain[0].__pad5);
__CrestInt(&at_log_file[0]._chain[0]._mode);
__CrestChar(&at_log_file[0]._chain[0]._unused2[0]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[1]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[2]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[3]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[4]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[5]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[6]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[7]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[8]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[9]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[10]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[11]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[12]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[13]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[14]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[15]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[16]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[17]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[18]);
__CrestChar(&at_log_file[0]._chain[0]._unused2[19]);
__CrestInt(&at_log_file[0]._fileno);
__CrestInt(&at_log_file[0]._flags2);
__CrestLong(&at_log_file[0]._old_offset);
__CrestUShort(&at_log_file[0]._cur_column);
__CrestChar(&at_log_file[0]._vtable_offset);
__CrestChar(&at_log_file[0]._shortbuf[0]);
// Pointee type 'void' is an incomplete type
at_log_file[0]._lock = 0;
__CrestLong(&at_log_file[0]._offset);
// Pointee type 'void' is an incomplete type
at_log_file[0].__pad1 = 0;
// Pointee type 'void' is an incomplete type
at_log_file[0].__pad2 = 0;
// Pointee type 'void' is an incomplete type
at_log_file[0].__pad3 = 0;
// Pointee type 'void' is an incomplete type
at_log_file[0].__pad4 = 0;
__CrestULong(&at_log_file[0].__pad5);
__CrestInt(&at_log_file[0]._mode);
__CrestChar(&at_log_file[0]._unused2[0]);
__CrestChar(&at_log_file[0]._unused2[1]);
__CrestChar(&at_log_file[0]._unused2[2]);
__CrestChar(&at_log_file[0]._unused2[3]);
__CrestChar(&at_log_file[0]._unused2[4]);
__CrestChar(&at_log_file[0]._unused2[5]);
__CrestChar(&at_log_file[0]._unused2[6]);
__CrestChar(&at_log_file[0]._unused2[7]);
__CrestChar(&at_log_file[0]._unused2[8]);
__CrestChar(&at_log_file[0]._unused2[9]);
__CrestChar(&at_log_file[0]._unused2[10]);
__CrestChar(&at_log_file[0]._unused2[11]);
__CrestChar(&at_log_file[0]._unused2[12]);
__CrestChar(&at_log_file[0]._unused2[13]);
__CrestChar(&at_log_file[0]._unused2[14]);
__CrestChar(&at_log_file[0]._unused2[15]);
__CrestChar(&at_log_file[0]._unused2[16]);
__CrestChar(&at_log_file[0]._unused2[17]);
__CrestChar(&at_log_file[0]._unused2[18]);
__CrestChar(&at_log_file[0]._unused2[19]);
// stdin will be set by C standard library
// stdout will be set by C standard library
}
static int __sym_ReadColorMap(FILE * param0, unsigned char param1[][3], int param2, int param3, int * param4, at_exception_type * param5, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static unsigned char * __sym_ReadImage(FILE * param0, int param1, int param2, unsigned char param3[][3], int param4, int param5, int param6, int param7, ...){
  unsigned char * ret;
ret = malloc(3*sizeof(unsigned char));
__CrestUChar(&ret[0]);
__CrestUChar(&ret[1]);
__CrestUChar(&ret[2]);
  return ret;
}
static long __sym_ToL(unsigned char * param0, ...){
  long ret;
__CrestLong(&ret);
  return ret;
}
static short __sym_ToS(unsigned char * param0, ...){
  short ret;
__CrestShort(&ret);
  return ret;
}
static int __sym__IO_getc(_IO_FILE * param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym__IO_putc(int param0, _IO_FILE * param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym___assert_fail(const char * param0, const char * param1, unsigned int param2, const char * param3, ...){
}
static int __sym___overflow(_IO_FILE * param0, int param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void * __sym___rawmemchr(const void * param0, int param1, ...){
  void * ret;
// Pointee type 'void' is an incomplete type
ret = 0;
  return ret;
}
static int __sym___uflow(_IO_FILE * param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static struct _at_bitmap_type __sym_at_bitmap_init(unsigned char * param0, unsigned short param1, unsigned short param2, unsigned int param3, ...){
  struct _at_bitmap_type ret;
__CrestUShort(&ret.height);
__CrestUShort(&ret.width);
ret.bitmap = malloc(3*sizeof(unsigned char));
__CrestUChar(&ret.bitmap[0]);
__CrestUChar(&ret.bitmap[1]);
__CrestUChar(&ret.bitmap[2]);
__CrestUInt(&ret.np);
  return ret;
}
static void __sym_at_exception_fatal(at_exception_type * param0, at_string param1, ...){
}
static at_bool __sym_at_exception_got_fatal(at_exception_type * param0, ...){
  at_bool ret;
__CrestInt(&ret);
  return ret;
}
static struct _at_exception_type __sym_at_exception_new(void * param0, at_address param1, ...){
  struct _at_exception_type ret;
__CrestInt(&ret.msg_type);
// Function pointer type: void (*)(char *, enum _at_msg_type, void *) of ret.client_func is not supported
ret.client_func = 0;
ret.client_data = malloc(1*sizeof(void *));
// Pointee type 'void' is an incomplete type
ret.client_data[0] = 0;
  return ret;
}
static int __sym_fclose(FILE * param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static struct _IO_FILE * __sym_fopen(const char * param0, const char * param1, ...){
  struct _IO_FILE * ret;
ret = malloc(1*sizeof(struct _IO_FILE));
__CrestInt(&ret[0]._flags);
ret[0]._IO_read_ptr = malloc(3*sizeof(char));
__CrestChar(&ret[0]._IO_read_ptr[0]);
__CrestChar(&ret[0]._IO_read_ptr[1]);
__CrestChar(&ret[0]._IO_read_ptr[2]);
ret[0]._IO_read_end = malloc(3*sizeof(char));
__CrestChar(&ret[0]._IO_read_end[0]);
__CrestChar(&ret[0]._IO_read_end[1]);
__CrestChar(&ret[0]._IO_read_end[2]);
ret[0]._IO_read_base = malloc(3*sizeof(char));
__CrestChar(&ret[0]._IO_read_base[0]);
__CrestChar(&ret[0]._IO_read_base[1]);
__CrestChar(&ret[0]._IO_read_base[2]);
ret[0]._IO_write_base = malloc(3*sizeof(char));
__CrestChar(&ret[0]._IO_write_base[0]);
__CrestChar(&ret[0]._IO_write_base[1]);
__CrestChar(&ret[0]._IO_write_base[2]);
ret[0]._IO_write_ptr = malloc(3*sizeof(char));
__CrestChar(&ret[0]._IO_write_ptr[0]);
__CrestChar(&ret[0]._IO_write_ptr[1]);
__CrestChar(&ret[0]._IO_write_ptr[2]);
ret[0]._IO_write_end = malloc(3*sizeof(char));
__CrestChar(&ret[0]._IO_write_end[0]);
__CrestChar(&ret[0]._IO_write_end[1]);
__CrestChar(&ret[0]._IO_write_end[2]);
ret[0]._IO_buf_base = malloc(3*sizeof(char));
__CrestChar(&ret[0]._IO_buf_base[0]);
__CrestChar(&ret[0]._IO_buf_base[1]);
__CrestChar(&ret[0]._IO_buf_base[2]);
ret[0]._IO_buf_end = malloc(3*sizeof(char));
__CrestChar(&ret[0]._IO_buf_end[0]);
__CrestChar(&ret[0]._IO_buf_end[1]);
__CrestChar(&ret[0]._IO_buf_end[2]);
ret[0]._IO_save_base = malloc(3*sizeof(char));
__CrestChar(&ret[0]._IO_save_base[0]);
__CrestChar(&ret[0]._IO_save_base[1]);
__CrestChar(&ret[0]._IO_save_base[2]);
ret[0]._IO_backup_base = malloc(3*sizeof(char));
__CrestChar(&ret[0]._IO_backup_base[0]);
__CrestChar(&ret[0]._IO_backup_base[1]);
__CrestChar(&ret[0]._IO_backup_base[2]);
ret[0]._IO_save_end = malloc(3*sizeof(char));
__CrestChar(&ret[0]._IO_save_end[0]);
__CrestChar(&ret[0]._IO_save_end[1]);
__CrestChar(&ret[0]._IO_save_end[2]);
ret[0]._markers = malloc(1*sizeof(struct _IO_marker));
ret[0]._markers[0]._next = malloc(1*sizeof(struct _IO_marker));
// Pointer Type: struct _IO_marker * of ret[0]._markers[0]._next[0]._next is set as NULL
ret[0]._markers[0]._next[0]._next = 0;
// Pointer Type: struct _IO_FILE * of ret[0]._markers[0]._next[0]._sbuf is set as NULL
ret[0]._markers[0]._next[0]._sbuf = 0;
__CrestInt(&ret[0]._markers[0]._next[0]._pos);
ret[0]._markers[0]._sbuf = malloc(1*sizeof(struct _IO_FILE));
__CrestInt(&ret[0]._markers[0]._sbuf[0]._flags);
// Pointer Type: char * of ret[0]._markers[0]._sbuf[0]._IO_read_ptr is set as NULL
ret[0]._markers[0]._sbuf[0]._IO_read_ptr = 0;
// Pointer Type: char * of ret[0]._markers[0]._sbuf[0]._IO_read_end is set as NULL
ret[0]._markers[0]._sbuf[0]._IO_read_end = 0;
// Pointer Type: char * of ret[0]._markers[0]._sbuf[0]._IO_read_base is set as NULL
ret[0]._markers[0]._sbuf[0]._IO_read_base = 0;
// Pointer Type: char * of ret[0]._markers[0]._sbuf[0]._IO_write_base is set as NULL
ret[0]._markers[0]._sbuf[0]._IO_write_base = 0;
// Pointer Type: char * of ret[0]._markers[0]._sbuf[0]._IO_write_ptr is set as NULL
ret[0]._markers[0]._sbuf[0]._IO_write_ptr = 0;
// Pointer Type: char * of ret[0]._markers[0]._sbuf[0]._IO_write_end is set as NULL
ret[0]._markers[0]._sbuf[0]._IO_write_end = 0;
// Pointer Type: char * of ret[0]._markers[0]._sbuf[0]._IO_buf_base is set as NULL
ret[0]._markers[0]._sbuf[0]._IO_buf_base = 0;
// Pointer Type: char * of ret[0]._markers[0]._sbuf[0]._IO_buf_end is set as NULL
ret[0]._markers[0]._sbuf[0]._IO_buf_end = 0;
// Pointer Type: char * of ret[0]._markers[0]._sbuf[0]._IO_save_base is set as NULL
ret[0]._markers[0]._sbuf[0]._IO_save_base = 0;
// Pointer Type: char * of ret[0]._markers[0]._sbuf[0]._IO_backup_base is set as NULL
ret[0]._markers[0]._sbuf[0]._IO_backup_base = 0;
// Pointer Type: char * of ret[0]._markers[0]._sbuf[0]._IO_save_end is set as NULL
ret[0]._markers[0]._sbuf[0]._IO_save_end = 0;
// Pointer Type: struct _IO_marker * of ret[0]._markers[0]._sbuf[0]._markers is set as NULL
ret[0]._markers[0]._sbuf[0]._markers = 0;
// Pointer Type: struct _IO_FILE * of ret[0]._markers[0]._sbuf[0]._chain is set as NULL
ret[0]._markers[0]._sbuf[0]._chain = 0;
__CrestInt(&ret[0]._markers[0]._sbuf[0]._fileno);
__CrestInt(&ret[0]._markers[0]._sbuf[0]._flags2);
__CrestLong(&ret[0]._markers[0]._sbuf[0]._old_offset);
__CrestUShort(&ret[0]._markers[0]._sbuf[0]._cur_column);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._vtable_offset);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._shortbuf[0]);
// Pointer Type: void * of ret[0]._markers[0]._sbuf[0]._lock is set as NULL
ret[0]._markers[0]._sbuf[0]._lock = 0;
__CrestLong(&ret[0]._markers[0]._sbuf[0]._offset);
// Pointer Type: void * of ret[0]._markers[0]._sbuf[0].__pad1 is set as NULL
ret[0]._markers[0]._sbuf[0].__pad1 = 0;
// Pointer Type: void * of ret[0]._markers[0]._sbuf[0].__pad2 is set as NULL
ret[0]._markers[0]._sbuf[0].__pad2 = 0;
// Pointer Type: void * of ret[0]._markers[0]._sbuf[0].__pad3 is set as NULL
ret[0]._markers[0]._sbuf[0].__pad3 = 0;
// Pointer Type: void * of ret[0]._markers[0]._sbuf[0].__pad4 is set as NULL
ret[0]._markers[0]._sbuf[0].__pad4 = 0;
__CrestULong(&ret[0]._markers[0]._sbuf[0].__pad5);
__CrestInt(&ret[0]._markers[0]._sbuf[0]._mode);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[0]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[1]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[2]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[3]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[4]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[5]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[6]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[7]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[8]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[9]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[10]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[11]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[12]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[13]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[14]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[15]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[16]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[17]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[18]);
__CrestChar(&ret[0]._markers[0]._sbuf[0]._unused2[19]);
__CrestInt(&ret[0]._markers[0]._pos);
ret[0]._chain = malloc(1*sizeof(struct _IO_FILE));
__CrestInt(&ret[0]._chain[0]._flags);
ret[0]._chain[0]._IO_read_ptr = malloc(3*sizeof(char));
__CrestChar(&ret[0]._chain[0]._IO_read_ptr[0]);
__CrestChar(&ret[0]._chain[0]._IO_read_ptr[1]);
__CrestChar(&ret[0]._chain[0]._IO_read_ptr[2]);
ret[0]._chain[0]._IO_read_end = malloc(3*sizeof(char));
__CrestChar(&ret[0]._chain[0]._IO_read_end[0]);
__CrestChar(&ret[0]._chain[0]._IO_read_end[1]);
__CrestChar(&ret[0]._chain[0]._IO_read_end[2]);
ret[0]._chain[0]._IO_read_base = malloc(3*sizeof(char));
__CrestChar(&ret[0]._chain[0]._IO_read_base[0]);
__CrestChar(&ret[0]._chain[0]._IO_read_base[1]);
__CrestChar(&ret[0]._chain[0]._IO_read_base[2]);
ret[0]._chain[0]._IO_write_base = malloc(3*sizeof(char));
__CrestChar(&ret[0]._chain[0]._IO_write_base[0]);
__CrestChar(&ret[0]._chain[0]._IO_write_base[1]);
__CrestChar(&ret[0]._chain[0]._IO_write_base[2]);
ret[0]._chain[0]._IO_write_ptr = malloc(3*sizeof(char));
__CrestChar(&ret[0]._chain[0]._IO_write_ptr[0]);
__CrestChar(&ret[0]._chain[0]._IO_write_ptr[1]);
__CrestChar(&ret[0]._chain[0]._IO_write_ptr[2]);
ret[0]._chain[0]._IO_write_end = malloc(3*sizeof(char));
__CrestChar(&ret[0]._chain[0]._IO_write_end[0]);
__CrestChar(&ret[0]._chain[0]._IO_write_end[1]);
__CrestChar(&ret[0]._chain[0]._IO_write_end[2]);
ret[0]._chain[0]._IO_buf_base = malloc(3*sizeof(char));
__CrestChar(&ret[0]._chain[0]._IO_buf_base[0]);
__CrestChar(&ret[0]._chain[0]._IO_buf_base[1]);
__CrestChar(&ret[0]._chain[0]._IO_buf_base[2]);
ret[0]._chain[0]._IO_buf_end = malloc(3*sizeof(char));
__CrestChar(&ret[0]._chain[0]._IO_buf_end[0]);
__CrestChar(&ret[0]._chain[0]._IO_buf_end[1]);
__CrestChar(&ret[0]._chain[0]._IO_buf_end[2]);
ret[0]._chain[0]._IO_save_base = malloc(3*sizeof(char));
__CrestChar(&ret[0]._chain[0]._IO_save_base[0]);
__CrestChar(&ret[0]._chain[0]._IO_save_base[1]);
__CrestChar(&ret[0]._chain[0]._IO_save_base[2]);
ret[0]._chain[0]._IO_backup_base = malloc(3*sizeof(char));
__CrestChar(&ret[0]._chain[0]._IO_backup_base[0]);
__CrestChar(&ret[0]._chain[0]._IO_backup_base[1]);
__CrestChar(&ret[0]._chain[0]._IO_backup_base[2]);
ret[0]._chain[0]._IO_save_end = malloc(3*sizeof(char));
__CrestChar(&ret[0]._chain[0]._IO_save_end[0]);
__CrestChar(&ret[0]._chain[0]._IO_save_end[1]);
__CrestChar(&ret[0]._chain[0]._IO_save_end[2]);
ret[0]._chain[0]._markers = malloc(1*sizeof(struct _IO_marker));
// Pointer Type: struct _IO_marker * of ret[0]._chain[0]._markers[0]._next is set as NULL
ret[0]._chain[0]._markers[0]._next = 0;
// Pointer Type: struct _IO_FILE * of ret[0]._chain[0]._markers[0]._sbuf is set as NULL
ret[0]._chain[0]._markers[0]._sbuf = 0;
__CrestInt(&ret[0]._chain[0]._markers[0]._pos);
ret[0]._chain[0]._chain = malloc(1*sizeof(struct _IO_FILE));
__CrestInt(&ret[0]._chain[0]._chain[0]._flags);
// Pointer Type: char * of ret[0]._chain[0]._chain[0]._IO_read_ptr is set as NULL
ret[0]._chain[0]._chain[0]._IO_read_ptr = 0;
// Pointer Type: char * of ret[0]._chain[0]._chain[0]._IO_read_end is set as NULL
ret[0]._chain[0]._chain[0]._IO_read_end = 0;
// Pointer Type: char * of ret[0]._chain[0]._chain[0]._IO_read_base is set as NULL
ret[0]._chain[0]._chain[0]._IO_read_base = 0;
// Pointer Type: char * of ret[0]._chain[0]._chain[0]._IO_write_base is set as NULL
ret[0]._chain[0]._chain[0]._IO_write_base = 0;
// Pointer Type: char * of ret[0]._chain[0]._chain[0]._IO_write_ptr is set as NULL
ret[0]._chain[0]._chain[0]._IO_write_ptr = 0;
// Pointer Type: char * of ret[0]._chain[0]._chain[0]._IO_write_end is set as NULL
ret[0]._chain[0]._chain[0]._IO_write_end = 0;
// Pointer Type: char * of ret[0]._chain[0]._chain[0]._IO_buf_base is set as NULL
ret[0]._chain[0]._chain[0]._IO_buf_base = 0;
// Pointer Type: char * of ret[0]._chain[0]._chain[0]._IO_buf_end is set as NULL
ret[0]._chain[0]._chain[0]._IO_buf_end = 0;
// Pointer Type: char * of ret[0]._chain[0]._chain[0]._IO_save_base is set as NULL
ret[0]._chain[0]._chain[0]._IO_save_base = 0;
// Pointer Type: char * of ret[0]._chain[0]._chain[0]._IO_backup_base is set as NULL
ret[0]._chain[0]._chain[0]._IO_backup_base = 0;
// Pointer Type: char * of ret[0]._chain[0]._chain[0]._IO_save_end is set as NULL
ret[0]._chain[0]._chain[0]._IO_save_end = 0;
// Pointer Type: struct _IO_marker * of ret[0]._chain[0]._chain[0]._markers is set as NULL
ret[0]._chain[0]._chain[0]._markers = 0;
// Pointer Type: struct _IO_FILE * of ret[0]._chain[0]._chain[0]._chain is set as NULL
ret[0]._chain[0]._chain[0]._chain = 0;
__CrestInt(&ret[0]._chain[0]._chain[0]._fileno);
__CrestInt(&ret[0]._chain[0]._chain[0]._flags2);
__CrestLong(&ret[0]._chain[0]._chain[0]._old_offset);
__CrestUShort(&ret[0]._chain[0]._chain[0]._cur_column);
__CrestChar(&ret[0]._chain[0]._chain[0]._vtable_offset);
__CrestChar(&ret[0]._chain[0]._chain[0]._shortbuf[0]);
// Pointer Type: void * of ret[0]._chain[0]._chain[0]._lock is set as NULL
ret[0]._chain[0]._chain[0]._lock = 0;
__CrestLong(&ret[0]._chain[0]._chain[0]._offset);
// Pointer Type: void * of ret[0]._chain[0]._chain[0].__pad1 is set as NULL
ret[0]._chain[0]._chain[0].__pad1 = 0;
// Pointer Type: void * of ret[0]._chain[0]._chain[0].__pad2 is set as NULL
ret[0]._chain[0]._chain[0].__pad2 = 0;
// Pointer Type: void * of ret[0]._chain[0]._chain[0].__pad3 is set as NULL
ret[0]._chain[0]._chain[0].__pad3 = 0;
// Pointer Type: void * of ret[0]._chain[0]._chain[0].__pad4 is set as NULL
ret[0]._chain[0]._chain[0].__pad4 = 0;
__CrestULong(&ret[0]._chain[0]._chain[0].__pad5);
__CrestInt(&ret[0]._chain[0]._chain[0]._mode);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[0]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[1]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[2]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[3]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[4]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[5]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[6]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[7]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[8]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[9]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[10]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[11]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[12]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[13]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[14]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[15]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[16]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[17]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[18]);
__CrestChar(&ret[0]._chain[0]._chain[0]._unused2[19]);
__CrestInt(&ret[0]._chain[0]._fileno);
__CrestInt(&ret[0]._chain[0]._flags2);
__CrestLong(&ret[0]._chain[0]._old_offset);
__CrestUShort(&ret[0]._chain[0]._cur_column);
__CrestChar(&ret[0]._chain[0]._vtable_offset);
__CrestChar(&ret[0]._chain[0]._shortbuf[0]);
// Pointee type 'void' is an incomplete type
ret[0]._chain[0]._lock = 0;
__CrestLong(&ret[0]._chain[0]._offset);
// Pointee type 'void' is an incomplete type
ret[0]._chain[0].__pad1 = 0;
// Pointee type 'void' is an incomplete type
ret[0]._chain[0].__pad2 = 0;
// Pointee type 'void' is an incomplete type
ret[0]._chain[0].__pad3 = 0;
// Pointee type 'void' is an incomplete type
ret[0]._chain[0].__pad4 = 0;
__CrestULong(&ret[0]._chain[0].__pad5);
__CrestInt(&ret[0]._chain[0]._mode);
__CrestChar(&ret[0]._chain[0]._unused2[0]);
__CrestChar(&ret[0]._chain[0]._unused2[1]);
__CrestChar(&ret[0]._chain[0]._unused2[2]);
__CrestChar(&ret[0]._chain[0]._unused2[3]);
__CrestChar(&ret[0]._chain[0]._unused2[4]);
__CrestChar(&ret[0]._chain[0]._unused2[5]);
__CrestChar(&ret[0]._chain[0]._unused2[6]);
__CrestChar(&ret[0]._chain[0]._unused2[7]);
__CrestChar(&ret[0]._chain[0]._unused2[8]);
__CrestChar(&ret[0]._chain[0]._unused2[9]);
__CrestChar(&ret[0]._chain[0]._unused2[10]);
__CrestChar(&ret[0]._chain[0]._unused2[11]);
__CrestChar(&ret[0]._chain[0]._unused2[12]);
__CrestChar(&ret[0]._chain[0]._unused2[13]);
__CrestChar(&ret[0]._chain[0]._unused2[14]);
__CrestChar(&ret[0]._chain[0]._unused2[15]);
__CrestChar(&ret[0]._chain[0]._unused2[16]);
__CrestChar(&ret[0]._chain[0]._unused2[17]);
__CrestChar(&ret[0]._chain[0]._unused2[18]);
__CrestChar(&ret[0]._chain[0]._unused2[19]);
__CrestInt(&ret[0]._fileno);
__CrestInt(&ret[0]._flags2);
__CrestLong(&ret[0]._old_offset);
__CrestUShort(&ret[0]._cur_column);
__CrestChar(&ret[0]._vtable_offset);
__CrestChar(&ret[0]._shortbuf[0]);
// Pointee type 'void' is an incomplete type
ret[0]._lock = 0;
__CrestLong(&ret[0]._offset);
// Pointee type 'void' is an incomplete type
ret[0].__pad1 = 0;
// Pointee type 'void' is an incomplete type
ret[0].__pad2 = 0;
// Pointee type 'void' is an incomplete type
ret[0].__pad3 = 0;
// Pointee type 'void' is an incomplete type
ret[0].__pad4 = 0;
__CrestULong(&ret[0].__pad5);
__CrestInt(&ret[0]._mode);
__CrestChar(&ret[0]._unused2[0]);
__CrestChar(&ret[0]._unused2[1]);
__CrestChar(&ret[0]._unused2[2]);
__CrestChar(&ret[0]._unused2[3]);
__CrestChar(&ret[0]._unused2[4]);
__CrestChar(&ret[0]._unused2[5]);
__CrestChar(&ret[0]._unused2[6]);
__CrestChar(&ret[0]._unused2[7]);
__CrestChar(&ret[0]._unused2[8]);
__CrestChar(&ret[0]._unused2[9]);
__CrestChar(&ret[0]._unused2[10]);
__CrestChar(&ret[0]._unused2[11]);
__CrestChar(&ret[0]._unused2[12]);
__CrestChar(&ret[0]._unused2[13]);
__CrestChar(&ret[0]._unused2[14]);
__CrestChar(&ret[0]._unused2[15]);
__CrestChar(&ret[0]._unused2[16]);
__CrestChar(&ret[0]._unused2[17]);
__CrestChar(&ret[0]._unused2[18]);
__CrestChar(&ret[0]._unused2[19]);
  return ret;
}
static int __sym_fprintf(FILE * param0, const char * param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_fputs(const char * param0, FILE * param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static unsigned long __sym_fread(void * param0, size_t param1, size_t param2, FILE * param3, ...){
  unsigned long ret;
__CrestULong(&ret);
  return ret;
}
static void __sym_free(void * param0, ...){
}
static unsigned long __sym_strlen(const char * param0, ...){
  unsigned long ret;
__CrestULong(&ret);
  return ret;
}
static int __sym_strncmp(const char * param0, const char * param1, size_t param2, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static double __sym_strtod(const char * param0, char ** param1, ...){
  double ret;
// Floting Type: double of ret is not supported
ret = 0;
  return ret;
}
static long __sym_strtol(const char * param0, char ** param1, int param2, ...){
  long ret;
__CrestLong(&ret);
  return ret;
}
static long long __sym_strtoll(const char * param0, char ** param1, int param2, ...){
  long long ret;
__CrestLongLong(&ret);
  return ret;
}
static int __sym_vfprintf(FILE * param0, const char * param1, __gnuc_va_list param2, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
int main(){
    ReadImage_driver();
    return 0;
}
