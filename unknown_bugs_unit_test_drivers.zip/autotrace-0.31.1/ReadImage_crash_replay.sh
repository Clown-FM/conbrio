#!/bin/bash
cp ReadImage_crash_input input
./ReadImage_driver
rm -f input
