#!/bin/bash
cp ReadImageTga_crash_input input
./ReadImageTga_driver
rm -f input
