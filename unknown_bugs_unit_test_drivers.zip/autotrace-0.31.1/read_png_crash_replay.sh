#!/bin/bash
cp read_png_crash_input input
./read_png_driver
rm -f input
