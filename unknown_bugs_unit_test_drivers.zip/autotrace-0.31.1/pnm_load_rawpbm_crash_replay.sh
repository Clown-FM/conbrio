#!/bin/bash
cp pnm_load_rawpbm_crash_input input
./pnm_load_rawpbm_driver
rm -f input
