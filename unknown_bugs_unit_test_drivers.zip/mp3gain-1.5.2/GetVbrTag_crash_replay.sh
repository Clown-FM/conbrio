#!/bin/bash
cp GetVbrTag_crash_input input
./GetVbrTag_driver
rm -f input
