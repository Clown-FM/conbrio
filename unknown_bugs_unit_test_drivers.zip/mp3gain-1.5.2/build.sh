#!/bin/bash
gcc -w -g -o III_dequantize_sample_driver III_dequantize_sample_driver.c -lcrestr -L../lib -L.
gcc -g -o GetVbrTag_driver GetVbrTag_driver.c -lcrestr -L../lib -L. -D__H_
