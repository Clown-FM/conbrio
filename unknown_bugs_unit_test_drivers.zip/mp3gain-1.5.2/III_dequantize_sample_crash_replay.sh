#!/bin/bash
cp III_dequantize_sample_crash_input input
./III_dequantize_sample_driver
rm -f input
