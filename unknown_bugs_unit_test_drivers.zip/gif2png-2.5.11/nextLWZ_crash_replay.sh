#!/bin/bash
cp nextLWZ_crash_input input
./nextLWZ_driver
rm -f input
