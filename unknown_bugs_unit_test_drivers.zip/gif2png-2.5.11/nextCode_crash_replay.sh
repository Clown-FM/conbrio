#!/bin/bash
cp nextCode_crash_input input
./nextCode_driver
rm -f input
