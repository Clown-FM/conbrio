#!/bin/bash
gcc -w -g -o nextCode_driver nextCode_driver.c -lcrestr -L../lib -L. -D__H_
gcc -w -g -o nextLWZ_driver nextLWZ_driver.c -lcrestr -L../lib -L. -D__H_
