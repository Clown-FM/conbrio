#!/bin/bash
gcc -w -g -o exif_entry_cb_driver exif_entry_cb_driver.c -lcrestr -L../lib -L. -D__H_ -lglib-2.0
