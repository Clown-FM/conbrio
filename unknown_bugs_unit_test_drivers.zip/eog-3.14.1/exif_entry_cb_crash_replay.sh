#!/bin/bash
cp exif_entry_cb_crash_input input
./exif_entry_cb_driver
rm -f input
