#!/bin/bash
cp string_concatenate_crash_input input
./string_concatenate_driver
rm -f input
