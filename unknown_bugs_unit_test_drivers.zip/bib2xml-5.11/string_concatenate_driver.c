#include <assert.h>






























typedef long unsigned int size_t;








typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;







typedef long int __quad_t;
typedef unsigned long int __u_quad_t;





typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned long int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef long int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef __quad_t *__qaddr_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;


struct _IO_FILE;



typedef struct _IO_FILE FILE;






typedef struct _IO_FILE __FILE;












#ifdef __H_
typedef struct
{
  int __count;
  union
  {

    unsigned int __wch;



    char __wchb[4];
  } __value;
} __mbstate_t;

typedef struct
{
  __off_t __pos;
  __mbstate_t __state;
} _G_fpos_t;
typedef struct
{
  __off64_t __pos;
  __mbstate_t __state;
} _G_fpos64_t;




typedef __builtin_va_list __gnuc_va_list;


struct _IO_jump_t; struct _IO_FILE;

typedef void _IO_lock_t;





struct _IO_marker {
  struct _IO_marker *_next;
  struct _IO_FILE *_sbuf;



  int _pos;

};


enum __codecvt_result
{
  __codecvt_ok,
  __codecvt_partial,
  __codecvt_error,
  __codecvt_noconv
};

struct _IO_FILE {
  int _flags;




  char* _IO_read_ptr;
  char* _IO_read_end;
  char* _IO_read_base;
  char* _IO_write_base;
  char* _IO_write_ptr;
  char* _IO_write_end;
  char* _IO_buf_base;
  char* _IO_buf_end;

  char *_IO_save_base;
  char *_IO_backup_base;
  char *_IO_save_end;

  struct _IO_marker *_markers;

  struct _IO_FILE *_chain;

  int _fileno;



  int _flags2;

  __off_t _old_offset;



  unsigned short _cur_column;
  signed char _vtable_offset;
  char _shortbuf[1];



  _IO_lock_t *_lock;

  __off64_t _offset;

  void *__pad1;
  void *__pad2;
  void *__pad3;
  void *__pad4;
  size_t __pad5;

  int _mode;

  char _unused2[15 * sizeof (int) - 4 * sizeof (void *) - sizeof (size_t)];

};


typedef struct _IO_FILE _IO_FILE;


struct _IO_FILE_plus;

extern struct _IO_FILE_plus _IO_2_1_stdin_;
extern struct _IO_FILE_plus _IO_2_1_stdout_;
extern struct _IO_FILE_plus _IO_2_1_stderr_;

typedef __ssize_t __io_read_fn (void *__cookie, char *__buf, size_t __nbytes);







typedef __ssize_t __io_write_fn (void *__cookie, const char *__buf,
     size_t __n);







typedef int __io_seek_fn (void *__cookie, __off64_t *__pos, int __w);


typedef int __io_close_fn (void *__cookie);

extern int __underflow (_IO_FILE *);
extern int __uflow (_IO_FILE *);
extern int __overflow (_IO_FILE *, int);

extern int _IO_getc (_IO_FILE *__fp);
extern int _IO_putc (int __c, _IO_FILE *__fp);
extern int _IO_feof (_IO_FILE *__fp) __attribute__ ((__nothrow__ , __leaf__));
extern int _IO_ferror (_IO_FILE *__fp) __attribute__ ((__nothrow__ , __leaf__));

extern int _IO_peekc_locked (_IO_FILE *__fp);





extern void _IO_flockfile (_IO_FILE *) __attribute__ ((__nothrow__ , __leaf__));
extern void _IO_funlockfile (_IO_FILE *) __attribute__ ((__nothrow__ , __leaf__));
extern int _IO_ftrylockfile (_IO_FILE *) __attribute__ ((__nothrow__ , __leaf__));

extern int _IO_vfscanf (_IO_FILE * __restrict, const char * __restrict,
   __gnuc_va_list, int *__restrict);
extern int _IO_vfprintf (_IO_FILE *__restrict, const char *__restrict,
    __gnuc_va_list);
extern __ssize_t _IO_padn (_IO_FILE *, int, __ssize_t);
extern size_t _IO_sgetn (_IO_FILE *, void *, size_t);

extern __off64_t _IO_seekoff (_IO_FILE *, __off64_t, int, int);
extern __off64_t _IO_seekpos (_IO_FILE *, __off64_t, int);

extern void _IO_free_backup_area (_IO_FILE *) __attribute__ ((__nothrow__ , __leaf__));





typedef __gnuc_va_list va_list;

typedef __off_t off_t;

typedef __ssize_t ssize_t;







typedef _G_fpos_t fpos_t;










extern struct _IO_FILE *stdin;
extern struct _IO_FILE *stdout;
extern struct _IO_FILE *stderr;







extern int remove (const char *__filename) __attribute__ ((__nothrow__ , __leaf__));

extern int rename (const char *__old, const char *__new) __attribute__ ((__nothrow__ , __leaf__));




extern int renameat (int __oldfd, const char *__old, int __newfd,
       const char *__new) __attribute__ ((__nothrow__ , __leaf__));








extern FILE *tmpfile (void) ;

extern char *tmpnam (char *__s) __attribute__ ((__nothrow__ , __leaf__)) ;





extern char *tmpnam_r (char *__s) __attribute__ ((__nothrow__ , __leaf__)) ;

extern char *tempnam (const char *__dir, const char *__pfx)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) ;








extern int fclose (FILE *__stream);




extern int fflush (FILE *__stream);


extern int fflush_unlocked (FILE *__stream);







extern FILE *fopen (const char *__restrict __filename,
      const char *__restrict __modes) ;




extern FILE *freopen (const char *__restrict __filename,
        const char *__restrict __modes,
        FILE *__restrict __stream) ;



extern FILE *fdopen (int __fd, const char *__modes) __attribute__ ((__nothrow__ , __leaf__)) ;

extern FILE *fmemopen (void *__s, size_t __len, const char *__modes)
  __attribute__ ((__nothrow__ , __leaf__)) ;




extern FILE *open_memstream (char **__bufloc, size_t *__sizeloc) __attribute__ ((__nothrow__ , __leaf__)) ;






extern void setbuf (FILE *__restrict __stream, char *__restrict __buf) __attribute__ ((__nothrow__ , __leaf__));



extern int setvbuf (FILE *__restrict __stream, char *__restrict __buf,
      int __modes, size_t __n) __attribute__ ((__nothrow__ , __leaf__));





extern void setbuffer (FILE *__restrict __stream, char *__restrict __buf,
         size_t __size) __attribute__ ((__nothrow__ , __leaf__));


extern void setlinebuf (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__));








extern int fprintf (FILE *__restrict __stream,
      const char *__restrict __format, ...);




extern int printf (const char *__restrict __format, ...);

extern int sprintf (char *__restrict __s,
      const char *__restrict __format, ...) __attribute__ ((__nothrow__));





extern int vfprintf (FILE *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg);




extern int vprintf (const char *__restrict __format, __gnuc_va_list __arg);

extern int vsprintf (char *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg) __attribute__ ((__nothrow__));





extern int snprintf (char *__restrict __s, size_t __maxlen,
       const char *__restrict __format, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 4)));

extern int vsnprintf (char *__restrict __s, size_t __maxlen,
        const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 0)));


extern int vdprintf (int __fd, const char *__restrict __fmt,
       __gnuc_va_list __arg)
     __attribute__ ((__format__ (__printf__, 2, 0)));
extern int dprintf (int __fd, const char *__restrict __fmt, ...)
     __attribute__ ((__format__ (__printf__, 2, 3)));








extern int fscanf (FILE *__restrict __stream,
     const char *__restrict __format, ...) ;




extern int scanf (const char *__restrict __format, ...) ;

extern int sscanf (const char *__restrict __s,
     const char *__restrict __format, ...) __attribute__ ((__nothrow__ , __leaf__));

extern int fscanf (FILE *__restrict __stream, const char *__restrict __format, ...) __asm__ ("" "__isoc99_fscanf")

                               ;
extern int scanf (const char *__restrict __format, ...) __asm__ ("" "__isoc99_scanf")
                              ;
extern int sscanf (const char *__restrict __s, const char *__restrict __format, ...) __asm__ ("" "__isoc99_sscanf") __attribute__ ((__nothrow__ , __leaf__))

                      ;









extern int vfscanf (FILE *__restrict __s, const char *__restrict __format,
      __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 2, 0))) ;





extern int vscanf (const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 1, 0))) ;


extern int vsscanf (const char *__restrict __s,
      const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__format__ (__scanf__, 2, 0)));

extern int vfscanf (FILE *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc99_vfscanf")



     __attribute__ ((__format__ (__scanf__, 2, 0))) ;
extern int vscanf (const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc99_vscanf")

     __attribute__ ((__format__ (__scanf__, 1, 0))) ;
extern int vsscanf (const char *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc99_vsscanf") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__format__ (__scanf__, 2, 0)));










extern int fgetc (FILE *__stream);
extern int getc (FILE *__stream);





extern int getchar (void);


extern int getc_unlocked (FILE *__stream);
extern int getchar_unlocked (void);

extern int fgetc_unlocked (FILE *__stream);











extern int fputc (int __c, FILE *__stream);
extern int putc (int __c, FILE *__stream);





extern int putchar (int __c);


extern int fputc_unlocked (int __c, FILE *__stream);







extern int putc_unlocked (int __c, FILE *__stream);
extern int putchar_unlocked (int __c);






extern int getw (FILE *__stream);


extern int putw (int __w, FILE *__stream);








extern char *fgets (char *__restrict __s, int __n, FILE *__restrict __stream)
     ;

extern char *gets (char *__s) __attribute__ ((__deprecated__));



extern __ssize_t __getdelim (char **__restrict __lineptr,
          size_t *__restrict __n, int __delimiter,
          FILE *__restrict __stream) ;
extern __ssize_t getdelim (char **__restrict __lineptr,
        size_t *__restrict __n, int __delimiter,
        FILE *__restrict __stream) ;







extern __ssize_t getline (char **__restrict __lineptr,
       size_t *__restrict __n,
       FILE *__restrict __stream) ;








extern int fputs (const char *__restrict __s, FILE *__restrict __stream);





extern int puts (const char *__s);






extern int ungetc (int __c, FILE *__stream);






extern size_t fread (void *__restrict __ptr, size_t __size,
       size_t __n, FILE *__restrict __stream) ;




extern size_t fwrite (const void *__restrict __ptr, size_t __size,
        size_t __n, FILE *__restrict __s);


extern size_t fread_unlocked (void *__restrict __ptr, size_t __size,
         size_t __n, FILE *__restrict __stream) ;
extern size_t fwrite_unlocked (const void *__restrict __ptr, size_t __size,
          size_t __n, FILE *__restrict __stream);








extern int fseek (FILE *__stream, long int __off, int __whence);




extern long int ftell (FILE *__stream) ;




extern void rewind (FILE *__stream);


extern int fseeko (FILE *__stream, __off_t __off, int __whence);




extern __off_t ftello (FILE *__stream) ;







extern int fgetpos (FILE *__restrict __stream, fpos_t *__restrict __pos);




extern int fsetpos (FILE *__stream, const fpos_t *__pos);





extern void clearerr (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__));

extern int feof (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) ;

extern int ferror (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) ;




extern void clearerr_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__));
extern int feof_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) ;
extern int ferror_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) ;








extern void perror (const char *__s);








extern int sys_nerr;
extern const char *const sys_errlist[];





extern int fileno (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) ;




extern int fileno_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) ;

extern FILE *popen (const char *__command, const char *__modes) ;





extern int pclose (FILE *__stream);





extern char *ctermid (char *__s) __attribute__ ((__nothrow__ , __leaf__));

extern void flockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__));



extern int ftrylockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) ;


extern void funlockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__));







typedef int wchar_t;











typedef enum
{
  P_ALL,
  P_PID,
  P_PGID
} idtype_t;





















static __inline unsigned int
__bswap_32 (unsigned int __bsx)
{
  return __builtin_bswap32 (__bsx);
}

static __inline __uint64_t
__bswap_64 (__uint64_t __bsx)
{
  return __builtin_bswap64 (__bsx);
}



union wait
  {
    int w_status;
    struct
      {

 unsigned int __w_termsig:7;
 unsigned int __w_coredump:1;
 unsigned int __w_retcode:8;
 unsigned int:16;







      } __wait_terminated;
    struct
      {

 unsigned int __w_stopval:8;
 unsigned int __w_stopsig:8;
 unsigned int:16;






      } __wait_stopped;
  };


typedef union
  {
    union wait *__uptr;
    int *__iptr;
  } __WAIT_STATUS __attribute__ ((__transparent_union__));



typedef struct
  {
    int quot;
    int rem;
  } div_t;



typedef struct
  {
    long int quot;
    long int rem;
  } ldiv_t;







__extension__ typedef struct
  {
    long long int quot;
    long long int rem;
  } lldiv_t;



extern size_t __ctype_get_mb_cur_max (void) __attribute__ ((__nothrow__ , __leaf__)) ;




extern double atof (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

extern int atoi (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

extern long int atol (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;





__extension__ extern long long int atoll (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;





extern double strtod (const char *__restrict __nptr,
        char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern float strtof (const char *__restrict __nptr,
       char **__restrict __endptr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern long double strtold (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern long int strtol (const char *__restrict __nptr,
   char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern unsigned long int strtoul (const char *__restrict __nptr,
      char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));




__extension__
extern long long int strtoq (const char *__restrict __nptr,
        char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtouq (const char *__restrict __nptr,
           char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





__extension__
extern long long int strtoll (const char *__restrict __nptr,
         char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr,
     char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern char *l64a (long int __n) __attribute__ ((__nothrow__ , __leaf__)) ;


extern long int a64l (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;












typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;




typedef __loff_t loff_t;



typedef __ino_t ino_t;

typedef __dev_t dev_t;




typedef __gid_t gid_t;




typedef __mode_t mode_t;




typedef __nlink_t nlink_t;




typedef __uid_t uid_t;

typedef __pid_t pid_t;





typedef __id_t id_t;

typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;





typedef __key_t key_t;





typedef __clock_t clock_t;






typedef __time_t time_t;




typedef __clockid_t clockid_t;

typedef __timer_t timer_t;







typedef unsigned long int ulong;
typedef unsigned short int ushort;
typedef unsigned int uint;

typedef int int8_t __attribute__ ((__mode__ (__QI__)));
typedef int int16_t __attribute__ ((__mode__ (__HI__)));
typedef int int32_t __attribute__ ((__mode__ (__SI__)));
typedef int int64_t __attribute__ ((__mode__ (__DI__)));


typedef unsigned int u_int8_t __attribute__ ((__mode__ (__QI__)));
typedef unsigned int u_int16_t __attribute__ ((__mode__ (__HI__)));
typedef unsigned int u_int32_t __attribute__ ((__mode__ (__SI__)));
typedef unsigned int u_int64_t __attribute__ ((__mode__ (__DI__)));

typedef int register_t __attribute__ ((__mode__ (__word__)));












typedef int __sig_atomic_t;




typedef struct
  {
    unsigned long int __val[(1024 / (8 * sizeof (unsigned long int)))];
  } __sigset_t;




typedef __sigset_t sigset_t;







struct timespec
  {
    __time_t tv_sec;
    __syscall_slong_t tv_nsec;
  };




struct timeval
  {
    __time_t tv_sec;
    __suseconds_t tv_usec;
  };



typedef __suseconds_t suseconds_t;





typedef long int __fd_mask;

typedef struct
  {






    __fd_mask __fds_bits[1024 / (8 * (int) sizeof (__fd_mask))];


  } fd_set;






typedef __fd_mask fd_mask;



extern int select (int __nfds, fd_set *__restrict __readfds,
     fd_set *__restrict __writefds,
     fd_set *__restrict __exceptfds,
     struct timeval *__restrict __timeout);

extern int pselect (int __nfds, fd_set *__restrict __readfds,
      fd_set *__restrict __writefds,
      fd_set *__restrict __exceptfds,
      const struct timespec *__restrict __timeout,
      const __sigset_t *__restrict __sigmask);









__extension__
extern unsigned int gnu_dev_major (unsigned long long int __dev)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
__extension__
extern unsigned int gnu_dev_minor (unsigned long long int __dev)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
__extension__
extern unsigned long long int gnu_dev_makedev (unsigned int __major,
            unsigned int __minor)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));








typedef __blksize_t blksize_t;






typedef __blkcnt_t blkcnt_t;



typedef __fsblkcnt_t fsblkcnt_t;



typedef __fsfilcnt_t fsfilcnt_t;






typedef unsigned long int pthread_t;


union pthread_attr_t
{
  char __size[56];
  long int __align;
};

typedef union pthread_attr_t pthread_attr_t;





typedef struct __pthread_internal_list
{
  struct __pthread_internal_list *__prev;
  struct __pthread_internal_list *__next;
} __pthread_list_t;

typedef union
{
  struct __pthread_mutex_s
  {
    int __lock;
    unsigned int __count;
    int __owner;

    unsigned int __nusers;



    int __kind;

    short __spins;
    short __elision;
    __pthread_list_t __list;

  } __data;
  char __size[40];
  long int __align;
} pthread_mutex_t;

typedef union
{
  char __size[4];
  int __align;
} pthread_mutexattr_t;




typedef union
{
  struct
  {
    int __lock;
    unsigned int __futex;
    __extension__ unsigned long long int __total_seq;
    __extension__ unsigned long long int __wakeup_seq;
    __extension__ unsigned long long int __woken_seq;
    void *__mutex;
    unsigned int __nwaiters;
    unsigned int __broadcast_seq;
  } __data;
  char __size[48];
  __extension__ long long int __align;
} pthread_cond_t;

typedef union
{
  char __size[4];
  int __align;
} pthread_condattr_t;



typedef unsigned int pthread_key_t;



typedef int pthread_once_t;





typedef union
{

  struct
  {
    int __lock;
    unsigned int __nr_readers;
    unsigned int __readers_wakeup;
    unsigned int __writer_wakeup;
    unsigned int __nr_readers_queued;
    unsigned int __nr_writers_queued;
    int __writer;
    int __shared;
    unsigned long int __pad1;
    unsigned long int __pad2;


    unsigned int __flags;

  } __data;

  char __size[56];
  long int __align;
} pthread_rwlock_t;

typedef union
{
  char __size[8];
  long int __align;
} pthread_rwlockattr_t;





typedef volatile int pthread_spinlock_t;




typedef union
{
  char __size[32];
  long int __align;
} pthread_barrier_t;

typedef union
{
  char __size[4];
  int __align;
} pthread_barrierattr_t;











extern long int random (void) __attribute__ ((__nothrow__ , __leaf__));


extern void srandom (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));





extern char *initstate (unsigned int __seed, char *__statebuf,
   size_t __statelen) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *setstate (char *__statebuf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







struct random_data
  {
    int32_t *fptr;
    int32_t *rptr;
    int32_t *state;
    int rand_type;
    int rand_deg;
    int rand_sep;
    int32_t *end_ptr;
  };

extern int random_r (struct random_data *__restrict __buf,
       int32_t *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern int srandom_r (unsigned int __seed, struct random_data *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

extern int initstate_r (unsigned int __seed, char *__restrict __statebuf,
   size_t __statelen,
   struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)));

extern int setstate_r (char *__restrict __statebuf,
         struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));






extern int rand (void) __attribute__ ((__nothrow__ , __leaf__));

extern void srand (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));




extern int rand_r (unsigned int *__seed) __attribute__ ((__nothrow__ , __leaf__));







extern double drand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern double erand48 (unsigned short int __xsubi[3]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern long int lrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern long int nrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern long int mrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern long int jrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void srand48 (long int __seedval) __attribute__ ((__nothrow__ , __leaf__));
extern unsigned short int *seed48 (unsigned short int __seed16v[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern void lcong48 (unsigned short int __param[7]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





struct drand48_data
  {
    unsigned short int __x[3];
    unsigned short int __old_x[3];
    unsigned short int __c;
    unsigned short int __init;
    __extension__ unsigned long long int __a;

  };


extern int drand48_r (struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int erand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int lrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int nrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int mrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int jrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int srand48_r (long int __seedval, struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

extern int seed48_r (unsigned short int __seed16v[3],
       struct drand48_data *__buffer) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern int lcong48_r (unsigned short int __param[7],
        struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));









extern void *malloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) ;

extern void *calloc (size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) ;










extern void *realloc (void *__ptr, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));

extern void free (void *__ptr) __attribute__ ((__nothrow__ , __leaf__));




extern void cfree (void *__ptr) __attribute__ ((__nothrow__ , __leaf__));














extern void *alloca (size_t __size) __attribute__ ((__nothrow__ , __leaf__));












extern void *valloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) ;




extern int posix_memalign (void **__memptr, size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;



extern void abort (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));



extern int atexit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern int on_exit (void (*__func) (int __status, void *__arg), void *__arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern void exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));













extern void _Exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));






extern char *getenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;


extern int putenv (char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern int setenv (const char *__name, const char *__value, int __replace)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));


extern int unsetenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern int clearenv (void) __attribute__ ((__nothrow__ , __leaf__));

extern char *mktemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern int mkstemp (char *__template) __attribute__ ((__nonnull__ (1))) ;

extern int mkstemps (char *__template, int __suffixlen) __attribute__ ((__nonnull__ (1))) ;

extern char *mkdtemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;






extern int system (const char *__command) ;


extern char *realpath (const char *__restrict __name,
         char *__restrict __resolved) __attribute__ ((__nothrow__ , __leaf__)) ;






typedef int (*__compar_fn_t) (const void *, const void *);




extern void *bsearch (const void *__key, const void *__base,
        size_t __nmemb, size_t __size, __compar_fn_t __compar)
     __attribute__ ((__nonnull__ (1, 2, 5))) ;







extern void qsort (void *__base, size_t __nmemb, size_t __size,
     __compar_fn_t __compar) __attribute__ ((__nonnull__ (1, 4)));

extern int abs (int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
extern long int labs (long int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;



__extension__ extern long long int llabs (long long int __x)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;







extern div_t div (int __numer, int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
extern ldiv_t ldiv (long int __numer, long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;




__extension__ extern lldiv_t lldiv (long long int __numer,
        long long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;


extern char *ecvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;




extern char *fcvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;




extern char *gcvt (double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3))) ;




extern char *qecvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;
extern char *qfcvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;
extern char *qgcvt (long double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3))) ;




extern int ecvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int fcvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));

extern int qecvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int qfcvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));






extern int mblen (const char *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int mbtowc (wchar_t *__restrict __pwc,
     const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int wctomb (char *__s, wchar_t __wchar) __attribute__ ((__nothrow__ , __leaf__));



extern size_t mbstowcs (wchar_t *__restrict __pwcs,
   const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));

extern size_t wcstombs (char *__restrict __s,
   const wchar_t *__restrict __pwcs, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__));








extern int rpmatch (const char *__response) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;

extern int getsubopt (char **__restrict __optionp,
        char *const *__restrict __tokens,
        char **__restrict __valuep)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2, 3))) ;

extern int getloadavg (double __loadavg[], int __nelem)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



















extern void *memcpy (void *__restrict __dest, const void *__restrict __src,
       size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void *memmove (void *__dest, const void *__src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));






extern void *memccpy (void *__restrict __dest, const void *__restrict __src,
        int __c, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));





extern void *memset (void *__s, int __c, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern void *memchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));





extern char *strcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strcat (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncat (char *__restrict __dest, const char *__restrict __src,
        size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcoll (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern size_t strxfrm (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));








typedef struct __locale_struct
{

  struct __locale_data *__locales[13];


  const unsigned short int *__ctype_b;
  const int *__ctype_tolower;
  const int *__ctype_toupper;


  const char *__names[13];
} *__locale_t;


typedef __locale_t locale_t;



extern int strcoll_l (const char *__s1, const char *__s2, __locale_t __l)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));

extern size_t strxfrm_l (char *__dest, const char *__src, size_t __n,
    __locale_t __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)));





extern char *strdup (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));






extern char *strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));



extern char *strchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));

extern char *strrchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));






extern size_t strcspn (const char *__s, const char *__reject)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern size_t strspn (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strpbrk (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strstr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strtok (char *__restrict __s, const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));




extern char *__strtok_r (char *__restrict __s,
    const char *__restrict __delim,
    char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));

extern char *strtok_r (char *__restrict __s, const char *__restrict __delim,
         char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));



extern size_t strlen (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));





extern size_t strnlen (const char *__string, size_t __maxlen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));





extern char *strerror (int __errnum) __attribute__ ((__nothrow__ , __leaf__));


extern int strerror_r (int __errnum, char *__buf, size_t __buflen) __asm__ ("" "__xpg_strerror_r") __attribute__ ((__nothrow__ , __leaf__))

                        __attribute__ ((__nonnull__ (2)));

extern char *strerror_l (int __errnum, __locale_t __l) __attribute__ ((__nothrow__ , __leaf__));





extern void __bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern void bcopy (const void *__src, void *__dest, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int bcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *index (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));

extern char *rindex (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern int ffs (int __i) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));

extern int strcasecmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strncasecmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strsep (char **__restrict __stringp,
       const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strsignal (int __sig) __attribute__ ((__nothrow__ , __leaf__));


extern char *__stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



extern char *__stpncpy (char *__restrict __dest,
   const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));







enum
{
  _ISupper = ((0) < 8 ? ((1 << (0)) << 8) : ((1 << (0)) >> 8)),
  _ISlower = ((1) < 8 ? ((1 << (1)) << 8) : ((1 << (1)) >> 8)),
  _ISalpha = ((2) < 8 ? ((1 << (2)) << 8) : ((1 << (2)) >> 8)),
  _ISdigit = ((3) < 8 ? ((1 << (3)) << 8) : ((1 << (3)) >> 8)),
  _ISxdigit = ((4) < 8 ? ((1 << (4)) << 8) : ((1 << (4)) >> 8)),
  _ISspace = ((5) < 8 ? ((1 << (5)) << 8) : ((1 << (5)) >> 8)),
  _ISprint = ((6) < 8 ? ((1 << (6)) << 8) : ((1 << (6)) >> 8)),
  _ISgraph = ((7) < 8 ? ((1 << (7)) << 8) : ((1 << (7)) >> 8)),
  _ISblank = ((8) < 8 ? ((1 << (8)) << 8) : ((1 << (8)) >> 8)),
  _IScntrl = ((9) < 8 ? ((1 << (9)) << 8) : ((1 << (9)) >> 8)),
  _ISpunct = ((10) < 8 ? ((1 << (10)) << 8) : ((1 << (10)) >> 8)),
  _ISalnum = ((11) < 8 ? ((1 << (11)) << 8) : ((1 << (11)) >> 8))
};

extern const unsigned short int **__ctype_b_loc (void)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
extern const __int32_t **__ctype_tolower_loc (void)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
extern const __int32_t **__ctype_toupper_loc (void)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));







extern int isalnum (int) __attribute__ ((__nothrow__ , __leaf__));
extern int isalpha (int) __attribute__ ((__nothrow__ , __leaf__));
extern int iscntrl (int) __attribute__ ((__nothrow__ , __leaf__));
extern int isdigit (int) __attribute__ ((__nothrow__ , __leaf__));
extern int islower (int) __attribute__ ((__nothrow__ , __leaf__));
extern int isgraph (int) __attribute__ ((__nothrow__ , __leaf__));
extern int isprint (int) __attribute__ ((__nothrow__ , __leaf__));
extern int ispunct (int) __attribute__ ((__nothrow__ , __leaf__));
extern int isspace (int) __attribute__ ((__nothrow__ , __leaf__));
extern int isupper (int) __attribute__ ((__nothrow__ , __leaf__));
extern int isxdigit (int) __attribute__ ((__nothrow__ , __leaf__));



extern int tolower (int __c) __attribute__ ((__nothrow__ , __leaf__));


extern int toupper (int __c) __attribute__ ((__nothrow__ , __leaf__));








extern int isblank (int) __attribute__ ((__nothrow__ , __leaf__));



extern int isascii (int __c) __attribute__ ((__nothrow__ , __leaf__));



extern int toascii (int __c) __attribute__ ((__nothrow__ , __leaf__));



extern int _toupper (int) __attribute__ ((__nothrow__ , __leaf__));
extern int _tolower (int) __attribute__ ((__nothrow__ , __leaf__));

extern int isalnum_l (int, __locale_t) __attribute__ ((__nothrow__ , __leaf__));
extern int isalpha_l (int, __locale_t) __attribute__ ((__nothrow__ , __leaf__));
extern int iscntrl_l (int, __locale_t) __attribute__ ((__nothrow__ , __leaf__));
extern int isdigit_l (int, __locale_t) __attribute__ ((__nothrow__ , __leaf__));
extern int islower_l (int, __locale_t) __attribute__ ((__nothrow__ , __leaf__));
extern int isgraph_l (int, __locale_t) __attribute__ ((__nothrow__ , __leaf__));
extern int isprint_l (int, __locale_t) __attribute__ ((__nothrow__ , __leaf__));
extern int ispunct_l (int, __locale_t) __attribute__ ((__nothrow__ , __leaf__));
extern int isspace_l (int, __locale_t) __attribute__ ((__nothrow__ , __leaf__));
extern int isupper_l (int, __locale_t) __attribute__ ((__nothrow__ , __leaf__));
extern int isxdigit_l (int, __locale_t) __attribute__ ((__nothrow__ , __leaf__));

extern int isblank_l (int, __locale_t) __attribute__ ((__nothrow__ , __leaf__));



extern int __tolower_l (int __c, __locale_t __l) __attribute__ ((__nothrow__ , __leaf__));
extern int tolower_l (int __c, __locale_t __l) __attribute__ ((__nothrow__ , __leaf__));


extern int __toupper_l (int __c, __locale_t __l) __attribute__ ((__nothrow__ , __leaf__));
extern int toupper_l (int __c, __locale_t __l) __attribute__ ((__nothrow__ , __leaf__));





extern int is_ws( char ch );
extern char *skip_ws( char *p );
extern char *skip_notws( char *p );



typedef struct newstr {
 char *data;
 unsigned long dim;
 unsigned long len;
} newstr;

newstr *newstr_new ( void );
void newstr_delete ( newstr *s );

void newstr_init ( newstr *s );
void newstr_initstr ( newstr *s, const char *initstr );
void newstr_empty ( newstr *s );
void newstr_free ( newstr *s );
newstr * newstr_strdup ( const char *p );

void newstrs_init ( newstr *s, ... );
void newstrs_empty ( newstr *s, ... );
void newstrs_free ( newstr *s, ... );

char * newstr_cstr ( newstr *s );

void newstr_mergestrs ( newstr *s, ... );
void newstr_fill ( newstr *s, unsigned long n, char fillchar );
void newstr_addchar ( newstr *s, char newchar );
void newstr_reverse ( newstr *s );
void newstr_strcat ( newstr *s, const char *addstr );
void newstr_newstrcat ( newstr *s, newstr *old );
void newstr_segcat ( newstr *s, const char *startat, const char *endat );
void newstr_plcat ( newstr *s, const char *startat, unsigned long n );
char * newstr_cpytodelim( newstr *s, char *p, const char *delim, unsigned char finalstep );
char * newstr_cattodelim( newstr *s, char *p, const char *delim, unsigned char finalstep );
void newstr_prepend ( newstr *s, const char *addstr );
void newstr_strcpy ( newstr *s, const char *addstr );
void newstr_newstrcpy ( newstr *s, newstr *old );
void newstr_segcpy ( newstr *s, const char *startat, const char *endat );
void newstr_plcpy ( newstr *s, const char *startat, unsigned long n );
void newstr_segdel ( newstr *s, char *startat, char *endat );
void newstr_indxcpy ( newstr *s, char *p, unsigned long start, unsigned long stop );
void newstr_indxcat ( newstr *s, char *p, unsigned long start, unsigned long stop );
void newstr_fprintf ( FILE *fp, newstr *s );
int newstr_fget ( FILE *fp, char *buf, int bufsize, int *pbufpos, newstr *outs );
char newstr_char ( newstr *s, unsigned long n );
char newstr_revchar ( newstr *s, unsigned long n );
int newstr_fgetline ( newstr *s, FILE *fp );
void newstr_toupper ( newstr *s );
void newstr_tolower ( newstr *s );
int newstr_findreplace( newstr *s, const char *find, const char *replace );
void newstr_trimstartingws( newstr *s );
void newstr_trimendingws( newstr *s );
void newstr_swapstrings( newstr *s1, newstr *s2 );
void newstr_stripws ( newstr *s );

const char *newstr_addutf8( newstr *s, const char *p );

int newstr_match_first ( newstr *s, char ch );
int newstr_match_end ( newstr *s, char ch );
void newstr_trimbegin ( newstr *s, unsigned long n );
void newstr_trimend ( newstr *s, unsigned long n );

void newstr_pad ( newstr *s, unsigned long len, char ch );
void newstr_copyposlen ( newstr *s, newstr *in, unsigned long pos, unsigned long len );

void newstr_makepath ( newstr *path, const char *dirname, const char *filename, char sep );


int newstr_is_mixedcase( newstr *s );
int newstr_is_lowercase( newstr *s );
int newstr_is_uppercase( newstr *s );

int newstr_newstrcmp ( const newstr *s, const newstr *t );

int newstr_memerr( newstr *s );



int utf8_encode( unsigned int value, unsigned char out[6] );
void utf8_encode_str( unsigned int value, char outstr[7] );
unsigned int utf8_decode( char *s, unsigned int *pi );
void utf8_writebom( FILE *outptr );
int utf8_is_emdash( char *p );
int utf8_is_endash( char *p );



extern int newstr_convert( newstr *s,
  int charsetin, int latexin, int utf8in, int xmlin,
  int charsetout, int latexout, int utf8out, int xmlout );








typedef struct vplist {
 int n, max;
 void **data;
} vplist;

typedef void (*vplist_ptrfree)(void*);

extern void vplist_init( vplist *vpl );
extern vplist * vplist_new( void );
extern int vplist_add( vplist *vpl, void *v );
extern int vplist_copy( vplist *to, vplist *from );
extern int vplist_append( vplist *to, vplist *from );
extern void * vplist_get( vplist *vpl, int n );
extern void vplist_set( vplist *vpl, int n, void *v );
extern void vplist_swap( vplist *vpl, int n1, int n2 );
extern void vplist_remove( vplist *vpl, int n );
extern void vplist_removevp( vplist *vpl, void *v );
extern int vplist_find( vplist *vpl, void *v );

extern void vplist_empty( vplist *vpl );
extern void vplist_emptyfn( vplist *vpl, vplist_ptrfree fn );





extern void vplist_free( vplist *vpl );
extern void vplist_freefn( vplist *vpl, vplist_ptrfree fn );




extern void vplist_delete( vplist **vpl );
extern void vplist_deletefn( vplist **vpl, vplist_ptrfree fn );


typedef struct fields {
 newstr *tag;
 newstr *data;
 int *used;
 int *level;
 int n;
 int max;
} fields;

void fields_init( fields *f );
fields *fields_new( void );
void fields_free( fields *f );

int _fields_add( fields *f, char *tag, char *data, int level, int mode );
int _fields_add_tagsuffix( fields *f, char *tag, char *suffix,
  char *data, int level, int mode );

int fields_maxlevel( fields *f );
void fields_clearused( fields *f );
void fields_setused( fields *f, int n );
int fields_replace_or_add( fields *f, char *tag, char *data, int level );

int fields_num( fields *f );
int fields_used( fields *f, int n );
int fields_notag( fields *f, int n );
int fields_nodata( fields *f, int n );

int fields_match_level( fields *f, int n, int level );
int fields_match_tag( fields *f, int n, char *tag );
int fields_match_casetag( fields *f, int n, char *tag );
int fields_match_tag_level( fields *f, int n, char *tag, int level );
int fields_match_casetag_level( fields *f, int n, char *tag, int level );

void fields_report( fields *f, FILE *fp );

void *fields_tag( fields *f, int n, int mode );
void *fields_value( fields *f, int n, int mode );
int fields_level( fields *f, int n );

int fields_find( fields *f, char *searchtag, int level );

void *fields_findv( fields *f, int level, int mode, char *tag );
void *fields_findv_firstof( fields *f, int level, int mode, ... );

void fields_findv_each( fields *f, int level, int mode, vplist *a, char *tag );
void fields_findv_eachof( fields *f, int level, int mode, vplist *a, ... );



typedef struct list {
 int n, max;
 newstr *str;
 unsigned char sorted;
} list;


void lists_init( list *a, ... );
void lists_free( list *a, ... );
void lists_empty( list *a, ... );

void list_init( list *a );
int list_init_values ( list *a, ... );
int list_init_valuesc( list *a, ... );
void list_free( list *a );
void list_empty( list *a );

list * list_new( void );
void list_delete( list * );

list* list_dup( list *a );
int list_copy( list *to, list *from );

newstr * list_addvp( list *a, unsigned char mode, void *vp );
newstr * list_addc( list *a, const char *value );
newstr * list_add( list *a, newstr *value );

int list_addvp_all( list *a, unsigned char mode, ... );
int list_addc_all( list *a, ... );
int list_add_all( list *a, ... );

newstr * list_addvp_unique( list *a, unsigned char mode, void *vp );
newstr * list_addc_unique( list *a, const char *value );
newstr * list_add_unique( list *a, newstr *value );

int list_append( list *a, list *toadd );
int list_append_unique( list *a, list *toadd );

int list_remove( list *a, int n );

newstr* list_get( list *a, int n );
char* list_getc( list *a, int n );

newstr* list_set( list *a, int n, newstr *s );
newstr* list_setc( list *a, int n, const char *s );

void list_sort( list *a );

void list_swap( list *a, int n1, int n2 );

int list_find( list *a, const char *searchstr );
int list_findnocase( list *a, const char *searchstr );
int list_match_entry( list *a, int n, char *s );
void list_trimend( list *a, int n );

int list_fill( list *a, const char *filename, unsigned char skip_blank_lines );
int list_fillfp( list *a, FILE *fp, unsigned char skip_blank_lines );
int list_tokenize( list *tokens, newstr *in, const char *delim, int merge_delim );
int list_tokenizec( list *tokens, char *p, const char *delim, int merge_delim );



extern int name_add( fields *info, char *tag, char *q, int level, list *asis, list *corps );
extern void name_build_withcomma( newstr *s, char *p );
extern int name_parse( newstr *outname, newstr *inname, list *asis, list *corps );
extern int name_addsingleelement( fields *info, char *tag, char *name, int level, int corp );
extern int name_addmultielement( fields *info, char *tag, list *tokens, int begin, int end, int level );
extern int name_findetal( list *tokens );



int title_process( fields *info, char *tag, char *data, int level, unsigned char nosplittitle );
void title_combine( newstr *fullttl, newstr *mainttl, newstr *subttl );



int is_doi( char *s );
int is_uri_remote_scheme( char *p );
int is_embedded_link( char *s );

void doi_to_url( fields *info, int n, char *urltag, newstr *doi_url );
void pmid_to_url( fields *info, int n, char *urltag, newstr *pmid_url );
void pmc_to_url( fields *info, int n, char *urltag, newstr *pmid_url );
void arxiv_to_url( fields *info, int n, char *urltag, newstr *arxiv_url );
void jstor_to_url( fields *info, int n, char *urltag, newstr *jstor_url );
void mrnumber_to_url( fields *info, int n, char *urltag, newstr *jstor_url );

int urls_merge_and_add( fields *in, int lvl_in, fields *out, char *tag_out, int lvl_out, list *types );
int urls_split_and_add( char *value_in, fields *out, int lvl_out );



typedef struct {
 char *oldstr;
 char *newstr;
 int processingtype;
 int level;
} lookups;

typedef struct {
 char type[25];
 lookups *tags;
 int ntags;
} variants;

int get_reftype( char *q, long refnum, char *progname, variants *all, int nall, char *tag, int *is_default, int chattiness );
int process_findoldtag( char *oldtag, int reftype, variants all[], int nall );
int translate_oldtag( char *oldtag, int reftype, variants all[], int nall, int *processingtype, int *level, char **newtag );







typedef struct {
 long nrefs;
 long maxrefs;
 fields **ref;
} bibl;

extern void bibl_init( bibl *b );
extern int bibl_addref( bibl *b, fields *ref );
extern void bibl_free( bibl *b );
extern int bibl_copy( bibl *bout, bibl *bin );




extern char * charset_get_xmlname( int n );
extern int charset_find( char *name );
extern void charset_list_all( FILE *fp );
extern unsigned int charset_lookupchar( int charsetin, char c );
extern unsigned int charset_lookupuni( int charsetout, unsigned int unicode );


typedef unsigned char uchar;

typedef struct param {

 int readformat;
 int writeformat;

 int charsetin;
 uchar charsetin_src;
 uchar latexin;
 uchar utf8in;
 uchar xmlin;
 uchar nosplittitle;

 int charsetout;
 uchar charsetout_src;
 uchar latexout;
 uchar utf8out;
 uchar utf8bom;
 uchar xmlout;

 int format_opts;
 int addcount;
 uchar output_raw;
 uchar verbose;
 uchar singlerefperfile;

 list asis;
 list corps;

 char *progname;


        int (*readf)(FILE*,char*,int,int*,newstr*,newstr*,int*);
        int (*processf)(fields*,char*,char*,long,struct param*);
        int (*cleanf)(bibl*,struct param*);
        int (*typef) (fields*,char*,int,struct param*);
        int (*convertf)(fields*,fields*,int,struct param*);
        void (*headerf)(FILE*,struct param*);
        void (*footerf)(FILE*);
        int (*writef)(fields*,FILE*,struct param*,unsigned long);
        variants *all;
        int nall;


} param;

extern void bibl_initparams( param *p, int readmode, int writemode,
 char *progname );
extern void bibl_freeparams( param *p );
extern int bibl_readasis( param *p, char *filename );
extern int bibl_addtoasis( param *p, char *entry );
extern int bibl_readcorps( param *p, char *filename );
extern int bibl_addtocorps( param *p, char *entry );
extern int bibl_read( bibl *b, FILE *fp, char *filename, param *p );
extern int bibl_write( bibl *b, FILE *fp, param *p );
extern void bibl_reporterr( int err );


void adsout_initparams( param *p, const char *progname );
void biblatexin_initparams( param *p, const char *progname );
void bibtexin_initparams( param *p, const char *progname );
void bibtexout_initparams( param *p, const char *progname );
void copacin_initparams( param *p, const char *progname );
void ebiin_initparams( param *p, const char *progname );
void endin_initparams( param *p, const char *progname );
void endout_initparams( param *p, const char *progname );
void endxmlin_initparams( param *p, const char *progname );
void isiin_initparams( param *p, const char *progname );
void isiout_initparams( param *p, const char *progname );
void medin_initparams( param *p, const char *progname );
void modsin_initparams( param *p, const char *progname );
void modsout_initparams( param *p, const char *progname );
void nbibin_initparams( param *p, const char *progname );
void risin_initparams( param *p, const char *progname );
void risout_initparams( param *p, const char *progname );
void wordin_initparams( param *p, const char *progname );
void wordout_initparams( param *p, const char *progname );
static int __sym__fields_add(fields * param0, char * param1, char * param2, int param3, int param4);
static void __sym_fields_setused(fields * param0, int param1, ...);
static int __sym_urls_split_and_add(char * param0, fields * param1, int param2);
static int __sym_title_process(fields * param0, char * param1, char * param2, int param3, unsigned char param4, ...)
    ;



int generic_null ( fields *bibin, int n, newstr *intag, newstr *invalue, int level, param *pm, char *outtag, fields *bibout );
int generic_url ( fields *bibin, int n, newstr *intag, newstr *invalue, int level, param *pm, char *outtag, fields *bibout );
int generic_notes ( fields *bibin, int n, newstr *intag, newstr *invalue, int level, param *pm, char *outtag, fields *bibout );
int generic_pages ( fields *bibin, int n, newstr *intag, newstr *invalue, int level, param *pm, char *outtag, fields *bibout );
int generic_person ( fields *bibin, int n, newstr *intag, newstr *invalue, int level, param *pm, char *outtag, fields *bibout );
int generic_serialno( fields *bibin, int n, newstr *intag, newstr *invalue, int level, param *pm, char *outtag, fields *bibout );
int generic_simple ( fields *bibin, int n, newstr *intag, newstr *invalue, int level, param *pm, char *outtag, fields *bibout );
int generic_skip ( fields *bibin, int n, newstr *intag, newstr *invalue, int level, param *pm, char *outtag, fields *bibout );
int generic_title ( fields *bibin, int n, newstr *intag, newstr *invalue, int level, param *pm, char *outtag, fields *bibout );


static list find = { 0, 0, ((void *)0), 0 };
static list replace = { 0, 0, ((void *)0), 0 };

/*extern*/ variants bibtex_all[];
/*extern*/ int bibtex_nall;



int
generic_null( fields *bibin, int n, newstr *intag, newstr *invalue, int level, param *pm, char *outtag, fields *bibout )
{
 return (0);
}

int
generic_url( fields *bibin, int n, newstr *intag, newstr *invalue, int level, param *pm, char *outtag, fields *bibout )
{
 return __sym_urls_split_and_add( invalue->data, bibout, level );
}

int
generic_notes( fields *bibin, int n, newstr *intag, newstr *invalue, int level, param *pm, char *outtag, fields *bibout )
{
        if ( __sym__fields_add( bibout, outtag, invalue->data, level, (1) ) == (1) ) return (0);
        else return (-2);
}

int
generic_pages( fields *bibin, int n, newstr *intag, newstr *invalue, int level, param *pm, char *outtag, fields *bibout )
{
        if ( __sym__fields_add( bibout, outtag, invalue->data, level, (1) ) == (1) ) return (0);
        else return (-2);
}

int
generic_person( fields *bibin, int n, newstr *intag, newstr *invalue, int level, param *pm, char *outtag, fields *bibout )
{
        if ( __sym__fields_add( bibout, outtag, invalue->data, level, (1) ) == (1) ) return (0);
        else return (-2);
}

int
generic_serialno( fields *bibin, int n, newstr *intag, newstr *invalue, int level, param *pm, char *outtag, fields *bibout )
{
 if ( __sym__fields_add( bibout, outtag, invalue->data, level, (1) ) == (1) ) return (0);
 return (-2);
}


int
generic_simple( fields *bibin, int n, newstr *intag, newstr *invalue, int level, param *pm, char *outtag, fields *bibout )
{
 if ( __sym__fields_add( bibout, outtag, invalue->data, level, (1) ) == (1) ) return (0);
 else return (-2);
}


int
generic_skip( fields *bibin, int n, newstr *intag, newstr *invalue, int level, param *pm, char *outtag, fields *bibout )
{
 __sym_fields_setused( bibin, n );
 return (0);
}

int
generic_title( fields *bibin, int n, newstr *intag, newstr *invalue, int level, param *pm, char *outtag, fields *bibout )
{
        if ( __sym_title_process( bibout, outtag, invalue->data, level, pm->nosplittitle ) ) return (0);
        else return (-2);
}


static int bibtexin_convertf( fields *bibin, fields *info, int reftype, param *p );
static int bibtexin_processf( fields *bibin, char *data, char *filename, long nref, param *p );
static int bibtexin_cleanf( bibl *bin, param *p );
static int bibtexin_readf( FILE *fp, char *buf, int bufsize, int *bufpos, newstr *line, newstr *reference, int *fcharset );
static int bibtexin_typef( fields *bibin, char *filename, int nrefs, param *p );

static void __sym_list_init(list * param0, ...);
static char * __sym_strdup(const char * param0, ...);
void
bibtexin_initparams( param *p, const char *progname )
{
 p->readformat = ((100)+1);
 p->charsetin = (-2);
 p->charsetin_src = (0);
 p->latexin = 1;
 p->xmlin = 0;
 p->utf8in = 0;
 p->nosplittitle = 0;
 p->verbose = 0;
 p->addcount = 0;
 p->output_raw = 0;

 p->readf = bibtexin_readf;
 p->processf = bibtexin_processf;
 p->cleanf = bibtexin_cleanf;
 p->typef = bibtexin_typef;
 p->convertf = bibtexin_convertf;
 p->all = bibtex_all;
 p->nall = bibtex_nall;

 __sym_list_init( &(p->asis) );
 __sym_list_init( &(p->corps) );

 if ( !progname ) p->progname = ((void *)0);
 else p->progname = __sym_strdup( progname );
}

static int __sym_newstr_fget(FILE * param0, char * param1, int param2, int * param3, newstr * param4, ...);
static int
readmore( FILE *fp, char *buf, int bufsize, int *bufpos, newstr *line )
{
 if ( line->len ) return 1;
 else return __sym_newstr_fget( fp, buf, bufsize, bufpos, line );
}







static int __sym_readmore(FILE * param0, char * param1, int param2, int * param3, newstr * param4, ...);
static char * __sym_skip_ws(char * param0, ...);
static void __sym_newstr_empty(newstr * param0, ...);
static void __sym_newstr_strcat(newstr * param0, const char * param1, ...);
static void __sym_newstr_addchar(newstr * param0, char param1, ...);
static int
bibtexin_readf( FILE *fp, char *buf, int bufsize, int *bufpos, newstr *line, newstr *reference, int *fcharset )
{
 int haveref = 0;
 char *p;
 *fcharset = (-1);
 while ( haveref!=2 && __sym_readmore( fp, buf, bufsize, bufpos, line ) ) {
  if ( line->len == 0 ) continue;
  p = &(line->data[0]);

  if ( line->len > 2 &&
    (unsigned char)(p[0])==0xEF &&
    (unsigned char)(p[1])==0xBB &&
    (unsigned char)(p[2])==0xBF ) {
   *fcharset = (-2);
   p += 3;
  }
  p = __sym_skip_ws( p );
  if ( *p == '%' ) {
   __sym_newstr_empty( line );
   continue;
  }
  if ( *p == '@' ) haveref++;
  if ( haveref && haveref<2 ) {
   __sym_newstr_strcat( reference, p );
   __sym_newstr_addchar( reference, '\n' );
   __sym_newstr_empty( line );
  } else if ( !haveref ) __sym_newstr_empty( line );

 }
 return haveref;
}





static void __sym_newstr_init(newstr * param0, ...);
static char * __sym_newstr_cpytodelim(newstr * param0, char * param1, const char * param2, unsigned char param3, ...);
static void __sym_newstr_strcpy(newstr * param0, const char * param1, ...);
static void __sym_newstr_free(newstr * param0, ...);
static char*
process_bibtextype( char *p, newstr *type )
{
 newstr tmp;
 __sym_newstr_init( &tmp );

 if ( *p=='@' ) p++;
 p = __sym_newstr_cpytodelim( &tmp, p, "{( \t\r\n", 0 );
 p = __sym_skip_ws( p );
 if ( *p=='{' || *p=='(' ) p++;
 p = __sym_skip_ws( p );

 if ( tmp.len ) __sym_newstr_strcpy( type, tmp.data );
 else __sym_newstr_empty( type );

 __sym_newstr_free( &tmp );
 return p;
}

static char * __sym_strchr(const char * param0, int param1, ...);
static char*
process_bibtexid( char *p, newstr *id )
{
 char *start_p = p;
 newstr tmp;

 __sym_newstr_init( &tmp );
 p = __sym_newstr_cpytodelim( &tmp, p, ",", 1 );

 if ( tmp.len ) {
  if ( __sym_strchr( tmp.data, '=' ) ) {





   p = start_p;
   __sym_newstr_empty( id );
  } else {
   __sym_newstr_strcpy( id, tmp.data );
  }
 } else {
  __sym_newstr_empty( id );
 }

 __sym_newstr_free( &tmp );
 return __sym_skip_ws( p );
}

static int __sym_newstr_memerr(newstr * param0, ...);
static char *
bibtex_tag( char *p, newstr *tag )
{
 p = __sym_newstr_cpytodelim( tag, __sym_skip_ws( p ), "= \t\r\n", 0 );
 if ( __sym_newstr_memerr( tag ) ) return ((void *)0);
 return __sym_skip_ws( p );
}

static struct newstr * __sym_list_add(list * param0, newstr * param1, ...);
static int __sym_is_ws(char param0, ...);
static int __sym_fprintf(FILE * param0, const char * param1, ...);
static char *
bibtex_data( char *p, fields *bibin, list *tokens, long nref, param *pm )
{
 unsigned int nbracket = 0, nquotes = 0;
 char *startp = p;
 newstr tok, *t;

 __sym_newstr_init( &tok );
 while ( p && *p ) {
  if ( !nquotes && !nbracket ) {
   if ( *p==',' || *p=='=' || *p=='}' || *p==')' )
    goto out;
  }
  if ( *p=='\"' && nbracket==0 && ( p==startp || *(p-1)!='\\' ) ) {
   nquotes = !nquotes;
   __sym_newstr_addchar( &tok, *p );
   if ( !nquotes ) {
    if ( __sym_newstr_memerr( &tok ) ) { p=((void *)0); goto out; }
    t = __sym_list_add( tokens, &tok );
    if ( !t ) { p=((void *)0); goto out0; }
    __sym_newstr_empty( &tok );
   }
  } else if ( *p=='#' && !nquotes && !nbracket ) {
   if ( tok.len ) {
    if ( __sym_newstr_memerr( &tok ) ) { p=((void *)0); goto out; }
    t = __sym_list_add( tokens, &tok );
    if ( !t ) { p=((void *)0); goto out0; }
   }
   __sym_newstr_strcpy( &tok, "#" );
   t = __sym_list_add( tokens, &tok );
   if ( !t ) { p=((void *)0); goto out0; }
   __sym_newstr_empty( &tok );
  } else if ( *p=='{' && !nquotes && ( p==startp || *(p-1)!='\\' ) ) {
   nbracket++;
   __sym_newstr_addchar( &tok, *p );
  } else if ( *p=='}' && !nquotes && ( p==startp || *(p-1)!='\\' ) ) {
   nbracket--;
   __sym_newstr_addchar( &tok, *p );
   if ( nbracket==0 ) {
    if ( __sym_newstr_memerr( &tok ) ) { p=((void *)0); goto out; }
    t = __sym_list_add( tokens, &tok );
    if ( !t ) { p=((void *)0); goto out; }
    __sym_newstr_empty( &tok );
   }
  } else if ( !__sym_is_ws( *p ) || nquotes || nbracket ) {
   if ( !__sym_is_ws( *p ) ) __sym_newstr_addchar( &tok, *p );
   else {
    if ( tok.len!=0 && *p!='\n' && *p!='\r' )
     __sym_newstr_addchar( &tok, *p );
    else if ( tok.len!=0 && (*p=='\n' || *p=='\r')) {
     __sym_newstr_addchar( &tok, ' ' );
     while ( __sym_is_ws( *(p+1) ) ) p++;
    }
   }
  } else if ( __sym_is_ws( *p ) ) {
   if ( tok.len ) {
    if ( __sym_newstr_memerr( &tok ) ) { p=((void *)0); goto out; }
    t = __sym_list_add( tokens, &tok );
    if ( !t ) { p=((void *)0); goto out; }
    __sym_newstr_empty( &tok );
   }
  }
  p++;
 }
out:
 if ( nbracket!=0 ) {
  __sym_fprintf( stderr, "%s: Mismatch in number of brackets in reference %ld.\n", pm->progname, nref );
 }
 if ( nquotes!=0 ) {
  __sym_fprintf( stderr, "%s: Mismatch in number of quotes in reference %ld.\n", pm->progname, nref );
 }
 if ( tok.len ) {
  if ( __sym_newstr_memerr( &tok ) ) { p = ((void *)0); goto out; }
  t = __sym_list_add( tokens, &tok );
  if ( !t ) p = ((void *)0);
 }
out0:
 __sym_newstr_free( &tok );
 return p;
}
#endif



#ifdef __H_




static struct newstr * __sym_list_get(list * param0, int param1, ...);
static int __sym_strcmp(const char * param0, const char * param1, ...);
static int __sym_list_find(list * param0, const char * param1, ...);
static void __sym_newstr_newstrcpy(newstr * param0, newstr * param1, ...);
static const unsigned short ** __sym___ctype_b_loc(void);
static void
replace_strings( list *tokens, fields *bibin, param *pm )
{
 int i, n, ok;
 newstr *s;
 char *q;
 i = 0;
 while ( i < tokens->n ) {
  s = __sym_list_get( tokens, i );
  if ( !__sym_strcmp( s->data, "#" ) ) {
  } else if ( s->data[0]!='\"' && s->data[0]!='{' ) {
   n = __sym_list_find( &find, s->data );
   if ( n!=-1 ) {
    __sym_newstr_newstrcpy( s, __sym_list_get( &replace, n ) );
   } else {
    q = s->data;
    ok = 1;
    while ( *q && ok ) {
     if ( !((*__sym___ctype_b_loc ())[(int) ((*q))] & (unsigned short int) _ISdigit) ) ok = 0;
     q++;
    }
    if ( !ok ) {
     __sym_fprintf( stderr, "%s: Warning: Non-numeric "
        "BibTeX elements should be in quotations or "
        "curly brackets in reference.\n", pm->progname );
    }
   }
  }
  i++;
 }
}

static int __sym_list_remove(list * param0, int param1, ...);
static void __sym_newstr_trimend(newstr * param0, unsigned long param1, ...);
static void __sym_newstr_trimbegin(newstr * param0, unsigned long param1, ...);
static void __sym_newstr_newstrcat(newstr * param0, newstr * param1, ...);
static int
string_concatenate( list *tokens, fields *bibin, long nref, param *pm )
{
 newstr *s, *t;
 int i, status;
 i = 0;
 while ( i < tokens->n ) {
  s = __sym_list_get( tokens, i );
  if ( !__sym_strcmp( s->data, "#" ) ) {
   if ( i==0 || i==tokens->n-1 ) {
    __sym_fprintf( stderr, "%s: Warning: Stray string concatenation "
     "('#' character) in reference %ld\n", pm->progname, nref );
    status = __sym_list_remove( tokens, i );
   }
   s = __sym_list_get( tokens, i-1 );
   assert(s->len-1 < 128);
   if ( s->data[0]!='\"' && s->data[s->len-1]!='\"' )
    __sym_fprintf( stderr, "%s: Warning: String concentation should "
     "be used in context of quotations marks in reference %ld\n", pm->progname, nref );
   t = __sym_list_get( tokens, i+1 );
   assert(s->len-1 < 128);
   if ( t->data[0]!='\"' && t->data[s->len-1]!='\"' )
    __sym_fprintf( stderr, "%s: Warning: String concentation should "
     "be used in context of quotations marks in reference %ld\n", pm->progname, nref );
   assert(s->len-1 < 128);
   if ( ( s->data[s->len-1]=='\"' && t->data[0]=='\"') || (s->data[s->len-1]=='}' && t->data[0]=='{') ) {
    __sym_newstr_trimend( s, 1 );
    __sym_newstr_trimbegin( t, 1 );
    __sym_newstr_newstrcat( s, t );
   } else {
    __sym_newstr_newstrcat( s, t );
   }
   status = __sym_list_remove( tokens, i );
   if ( status!=(1) ) return (-2);
   status = __sym_list_remove( tokens, i );
   if ( status!=(1) ) return (-2);
  } else i++;
 }
 return (0);
}


static char * __sym_bibtex_tag(char * param0, newstr * param1, ...);
static char * __sym_bibtex_data(char * param0, fields * param1, list * param2, long param3, param * param4, ...);
static void __sym_replace_strings(list * param0, fields * param1, param * param2, ...);
static int __sym_string_concatenate(list * param0, fields * param1, long param2, param * param3, ...);
static void __sym_list_free(list * param0, ...);
static char *
process_bibtexline( char *p, newstr *tag, newstr *data, uchar stripquotes, fields *bibin, long nref, param *pm )
{
 int i, status;
 list tokens;
 newstr *s;

 __sym_newstr_empty( data );

 p = __sym_bibtex_tag( p, tag );
 if ( p==((void *)0) || tag->len==0 ) return p;

 __sym_list_init( &tokens );

 if ( *p=='=' ) {
  p = __sym_bibtex_data( p+1, bibin, &tokens, nref, pm );
  if ( p==((void *)0) ) goto out;
 }

 __sym_replace_strings( &tokens, bibin, pm );

 status = __sym_string_concatenate( &tokens, bibin, nref, pm );
 if ( status!=(0) ) {
  p = ((void *)0);
  goto out;
 }

 for ( i=0; i<tokens.n; i++ ) {
  s = __sym_list_get( &tokens, i );
  if ( ( stripquotes && s->data[0]=='\"' && s->data[s->len-1]=='\"' ) ||
       ( s->data[0]=='{' && s->data[s->len-1]=='}' ) ) {
   __sym_newstr_trimbegin( s, 1 );
   __sym_newstr_trimend( s, 1 );
  }
  __sym_newstr_newstrcat( data, __sym_list_get( &tokens, i ) );
 }
out:
 __sym_list_free( &tokens );
 return p;
}




static void __sym_newstrs_init(newstr * param0, ...);
static char * __sym_process_bibtextype(char * param0, newstr * param1, ...);
static char * __sym_process_bibtexid(char * param0, newstr * param1, ...);
static char * __sym_process_bibtexline(char * param0, newstr * param1, newstr * param2, uchar param3, fields * param4, long param5, param * param6, ...);
static void __sym_newstrs_empty(newstr * param0, ...);
static void __sym_newstrs_free(newstr * param0, ...);
static int
process_cite( fields *bibin, char *p, char *filename, long nref, param *pm )
{
 int fstatus, status = (0);
 newstr tag, data;

 __sym_newstrs_init( &tag, &data, ((void *)0) );

 p = __sym_process_bibtextype( p, &data );
 if ( data.len ) {
  fstatus = __sym__fields_add( bibin, "INTERNAL_TYPE", data.data, 0, (1) );
  if ( fstatus!=(1) ) { status = (-2); goto out; }
 }

 p = __sym_process_bibtexid( p, &data );
 if ( data.len ) {
  fstatus = __sym__fields_add( bibin, "REFNUM", data.data, 0, (1) );
  if ( fstatus!=(1) ) { status = (-2); goto out; }
 }

 while ( *p ) {
  p = __sym_process_bibtexline( p, &tag, &data, 1, bibin, nref, pm );
  if ( p==((void *)0) ) { status = (-2); goto out; }

  if ( tag.len && data.len ) {
   fstatus = __sym__fields_add( bibin, tag.data, data.data, 0, (1) );
   if ( fstatus!=(1) ) { status = (-2); goto out; }
  }
  __sym_newstrs_empty( &tag, &data, ((void *)0) );
 }
out:
 __sym_newstrs_free( &tag, &data, ((void *)0) );
 return status;
}

static int __sym_newstr_findreplace(newstr * param0, const char * param1, const char * param2, ...);
static struct newstr * __sym_list_addc(list * param0, const char * param1, ...);
static struct newstr * __sym_list_set(list * param0, int param1, newstr * param2, ...);
static struct newstr * __sym_list_setc(list * param0, int param1, const char * param2, ...);
static int
process_string( char *p, long nref, param *pm )
{
 int n, status = (0);
 newstr s1, s2, *t;
 __sym_newstrs_init( &s1, &s2, ((void *)0) );
 while ( *p && *p!='{' && *p!='(' ) p++;
 if ( *p=='{' || *p=='(' ) p++;
 p = __sym_process_bibtexline( __sym_skip_ws( p ), &s1, &s2, 0, ((void *)0), nref, pm );
 if ( p==((void *)0) ) { status = (-2); goto out; }
 if ( s2.data ) {
  __sym_newstr_findreplace( &s2, "\\ ", " " );
 }
 if ( s1.data ) {
  n = __sym_list_find( &find, s1.data );
  if ( n==-1 ) {
   t = __sym_list_add( &find, &s1 );
   if ( t==((void *)0) ) { status = (-2); goto out; }
   if ( s2.data ) t = __sym_list_add( &replace, &s2 );
   else t = __sym_list_addc( &replace, "" );
   if ( t==((void *)0) ) { status = (-2); goto out; }
  } else {
   if ( s2.data ) t = __sym_list_set( &replace, n, &s2 );
   else t = __sym_list_setc( &replace, n, "" );
   if ( t==((void *)0) ) { status = (-2); goto out; }
  }
 }
out:
 __sym_newstrs_free( &s1, &s2, ((void *)0) );
 return status;
}





static int __sym_strncasecmp(const char * param0, const char * param1, size_t param2, ...);
static int __sym_process_string(char * param0, long param1, param * param2, ...);
static int __sym_process_cite(fields * param0, char * param1, char * param2, long param3, param * param4, ...);
static int
bibtexin_processf( fields *bibin, char *data, char *filename, long nref, param *p )
{
 if ( !__sym_strncasecmp( data, "@STRING", 7 ) ) {
  __sym_process_string( data+7, nref, p );
  return 0;
 } else if ( !__sym_strncasecmp( data, "@COMMENT", 8 ) ) {

  return 0;
 } else {
  __sym_process_cite( bibin, data, filename, nref, p );
  return 1;
 }
}





static int
bibtex_protected( newstr *data )
{
 if ( data->data[0]=='{' && data->data[data->len-1]=='}' ) return 1;
 if ( data->data[0]=='\"' && data->data[data->len-1]=='\"' ) return 1;
 return 0;
}

static void __sym_newstr_trimstartingws(newstr * param0, ...);
static void __sym_newstr_trimendingws(newstr * param0, ...);
static int
bibtex_split( list *tokens, newstr *s )
{
 int i, n = s->len, nbrackets = 0, status = (0);
 newstr tok, *t;

 __sym_newstr_init( &tok );

 for ( i=0; i<n; ++i ) {
  if ( s->data[i]=='{' && ( i==0 || s->data[i-1]!='\\' ) ) {
   nbrackets++;
   __sym_newstr_addchar( &tok, '{' );
  } else if ( s->data[i]=='}' && ( i==0 || s->data[i-1]!='\\' ) ) {
   nbrackets--;
   __sym_newstr_addchar( &tok, '}' );
  } else if ( !__sym_is_ws( s->data[i] ) || nbrackets ) {
   __sym_newstr_addchar( &tok, s->data[i] );
  } else if ( __sym_is_ws( s->data[i] ) ) {
   if ( tok.len ) {
    t = __sym_list_add( tokens, &tok );
    if ( !t ) {
     status = (-2);
     goto out;
    }
   }
   __sym_newstr_empty( &tok );
  }
 }
 if ( tok.len ) {
  t = __sym_list_add( tokens, &tok );
  if ( !t ) {
   status = (-2);
   goto out;
  }
 }

 for ( i=0; i<tokens->n; ++i ) {
  __sym_newstr_trimstartingws( __sym_list_get( tokens, i ) );
  __sym_newstr_trimendingws( __sym_list_get( tokens, i ) );
 }
out:
 __sym_newstr_free( &tok );
 return status;
}

static void __sym_newstr_swapstrings(newstr * param0, newstr * param1, ...);
static int
bibtex_addtitleurl( fields *info, newstr *in )
{
 int fstatus, status = (0);
 newstr s;
 char *p;

 __sym_newstr_init( &s );


 p = __sym_newstr_cpytodelim( &s, in->data + 6, "}", 1 );
 if ( __sym_newstr_memerr( &s ) ) { status = (-2); goto out; }


 fstatus = __sym__fields_add( info, "URL", s.data, 0, (1) );
 if ( fstatus!=(1) ) { status = (-2); goto out; }


 p = __sym_newstr_cpytodelim( &s, p, "", 0 );
 if ( __sym_newstr_memerr( &s ) ) { status = (-2); goto out; }
 __sym_newstr_swapstrings( &s, in );

out:
 __sym_newstr_free( &s );
 return status;
}

static int __sym_strcasecmp(const char * param0, const char * param1, ...);
static int
is_url_tag( newstr *tag )
{
 if ( tag->len ) {
  if ( !__sym_strcasecmp( tag->data, "url" ) ) return 1;
 }
 return 0;
}

static int
is_name_tag( newstr *tag )
{
 if ( tag->len ) {
  if ( !__sym_strcasecmp( tag->data, "author" ) ) return 1;
  if ( !__sym_strcasecmp( tag->data, "editor" ) ) return 1;
 }
 return 0;
}

static void
bibtex_process_tilde( newstr *s )
{
 char *p, *q;
 int n = 0;

 p = q = s->data;
 if ( !p ) return;
 while ( *p ) {
  if ( *p=='~' ) {
   *q = ' ';
  } else if ( *p=='\\' && *(p+1)=='~' ) {
   n++;
   p++;
   *q = '~';
  } else {
   *q = *p;
  }
  p++;
  q++;
 }
 *q = '\0';
 s->len -= n;
}

static void
bibtex_process_bracket( newstr *s )
{
 char *p, *q;
 int n = 0;

 p = q = s->data;
 if ( !p ) return;
 while ( *p ) {
  if ( *p=='\\' && ( *(p+1)=='{' || *(p+1)=='}' ) ) {
   n++;
   p++;
   *q = *p;
   q++;
  } else if ( *p=='{' || *p=='}' ) {
   n++;
  } else {
   *q = *p;
   q++;
  }
  p++;
 }
 *q = '\0';
 s->len -= n;
}

static void __sym_bibtex_process_bracket(newstr * param0, ...);
static void __sym_bibtex_process_tilde(newstr * param0, ...);
static void
bibtex_cleantoken( newstr *s )
{

 __sym_newstr_findreplace( s, "\\textit", "" );
 __sym_newstr_findreplace( s, "\\textbf", "" );
 __sym_newstr_findreplace( s, "\\textsl", "" );
 __sym_newstr_findreplace( s, "\\textsc", "" );
 __sym_newstr_findreplace( s, "\\textsf", "" );
 __sym_newstr_findreplace( s, "\\texttt", "" );
 __sym_newstr_findreplace( s, "\\textsubscript", "" );
 __sym_newstr_findreplace( s, "\\textsuperscript", "" );
 __sym_newstr_findreplace( s, "\\emph", "" );
 __sym_newstr_findreplace( s, "\\url", "" );
 __sym_newstr_findreplace( s, "\\mbox", "" );


 __sym_newstr_findreplace( s, "\\it ", "" );
 __sym_newstr_findreplace( s, "\\em ", "" );

 __sym_newstr_findreplace( s, "\\%", "%" );
 __sym_newstr_findreplace( s, "\\$", "$" );
 while ( __sym_newstr_findreplace( s, "  ", " " ) ) {}


 __sym_newstr_findreplace( s, "\\textdollar", "$" );
 __sym_newstr_findreplace( s, "\\textunderscore", "_" );

 __sym_bibtex_process_bracket( s );
 __sym_bibtex_process_tilde( s );

}

static int __sym_is_url_tag(newstr * param0, ...);
static int __sym_bibtex_split(list * param0, newstr * param1, ...);
static int __sym_bibtex_protected(newstr * param0, ...);
static int __sym_bibtex_addtitleurl(fields * param0, newstr * param1, ...);
static int __sym_is_name_tag(newstr * param0, ...);
static void __sym_bibtex_cleantoken(newstr * param0, ...);
static int
bibtex_cleandata( newstr *tag, newstr *s, fields *info, param *p )
{
 int i, status;
 list tokens;
 newstr *tok;
 if ( !s->len ) return (0);

 if ( __sym_is_url_tag( tag ) ) return (0);
 __sym_list_init( &tokens );
 status = __sym_bibtex_split( &tokens, s );
 if ( status!=(0) ) goto out;
 for ( i=0; i<tokens.n; ++i ) {
  tok = __sym_list_get( &tokens, i );
  if ( __sym_bibtex_protected( tok ) ) {
   if (!__sym_strncasecmp(tok->data,"\\href{", 6)) {
    __sym_bibtex_addtitleurl( info, tok );
   }
  }
  if ( p->latexin && !__sym_is_name_tag( tag ) && !__sym_is_url_tag( tag ) )
   __sym_bibtex_cleantoken( tok );
 }
 __sym_newstr_empty( s );
 for ( i=0; i<tokens.n; ++i ) {
  tok = __sym_list_get( &tokens, i );
  if ( i>0 ) __sym_newstr_addchar( s, ' ' );
  __sym_newstr_newstrcat( s, tok );
 }
out:
 __sym_list_free( &tokens );
 return status;
}

static int __sym_fields_num(fields * param0, ...);
static void * __sym_fields_tag(fields * param0, int param1, int param2, ...);
static void * __sym_fields_value(fields * param0, int param1, int param2, ...);
static int __sym_bibtex_cleandata(newstr * param0, newstr * param1, fields * param2, param * param3, ...);
static int
bibtexin_cleanref( fields *bibin, param *p )
{
 int i, n, status;
 newstr *t, *d;
 n = __sym_fields_num( bibin );
 for ( i=0; i<n; ++i ) {
  t = __sym_fields_tag( bibin, i, ( (2) ) );
  d = __sym_fields_value( bibin, i, ( (2) ) );
  status = __sym_bibtex_cleandata( t, d, bibin, p );
  if ( status!=(0) ) return status;
 }
 return (0);
}

static int __sym_fields_find(fields * param0, char * param1, int param2, ...);
static long
bibtexin_findref( bibl *bin, char *citekey )
{
 int n;
 long i;
 for ( i=0; i<bin->nrefs; ++i ) {
  n = __sym_fields_find( bin->ref[i], "refnum", (-1) );
  if ( n==-1 ) continue;
  if ( !__sym_strcmp( bin->ref[i]->data[n].data, citekey ) ) return i;
 }
 return -1;
}

static void
bibtexin_nocrossref( bibl *bin, long i, int n, param *p )
{
 int n1 = __sym_fields_find( bin->ref[i], "REFNUM", (-1) );
 if ( p->progname ) __sym_fprintf( stderr, "%s: ", p->progname );
 __sym_fprintf( stderr, "Cannot find cross-reference '%s'",
   bin->ref[i]->data[n].data );
 if ( n1!=-1 ) __sym_fprintf( stderr, " for reference '%s'\n",
   bin->ref[i]->data[n1].data );
 __sym_fprintf( stderr, "\n" );
}

static int __sym_fields_level(fields * param0, int param1, ...);
static int
bibtexin_crossref_oneref( fields *bibref, fields *bibcross )
{
 int j, n, nl, ntype, fstatus, status = (0);
 char *type, *nt, *nv;

 ntype = __sym_fields_find( bibref, "INTERNAL_TYPE", (-1) );
 type = ( char * ) __sym_fields_value( bibref, ntype, ( 0 ) );

 n = __sym_fields_num( bibcross );
 for ( j=0; j<n; ++j ) {
  nt = ( char * ) __sym_fields_tag( bibcross, j, ( 0 ) );
  if ( !__sym_strcasecmp( nt, "INTERNAL_TYPE" ) ) continue;
  if ( !__sym_strcasecmp( nt, "REFNUM" ) ) continue;
  if ( !__sym_strcasecmp( nt, "TITLE" ) ) {
   if ( !__sym_strcasecmp( type, "Inproceedings" ) ||
        !__sym_strcasecmp( type, "Incollection" ) )
    nt = "booktitle";
  }
  nv = ( char * ) __sym_fields_value( bibcross, j, ( 0 ) );
  nl = __sym_fields_level( bibcross, j ) + 1;
  fstatus = __sym__fields_add( bibref, nt, nv, nl, (1) );
  if ( fstatus!=(1) ) {
   status = (-2);
   goto out;
  }
 }
out:
 return status;
}

static long __sym_bibtexin_findref(bibl * param0, char * param1, ...);
static void __sym_bibtexin_nocrossref(bibl * param0, long param1, int param2, param * param3, ...);
static int __sym_bibtexin_crossref_oneref(fields * param0, fields * param1, ...);
static int
bibtexin_crossref( bibl *bin, param *p )
{
 int i, n, ncross, status = (0);
 fields *bibref, *bibcross;

 for ( i=0; i<bin->nrefs; ++i ) {
  bibref = bin->ref[i];
  n = __sym_fields_find( bibref, "CROSSREF", (-1) );
  if ( n==-1 ) continue;
  __sym_fields_setused( bibref, n );
  ncross = __sym_bibtexin_findref( bin, (char*) __sym_fields_value( bibref, n, ((16) ) ) );
  if ( ncross==-1 ) {
   __sym_bibtexin_nocrossref( bin, i, n, p );
   continue;
  }
  bibcross = bin->ref[ncross];
  status = __sym_bibtexin_crossref_oneref( bibref, bibcross );
  if ( status!=(0) ) goto out;
 }
out:
 return status;
}

static int __sym_bibtexin_cleanref(fields * param0, param * param1, ...);
static int __sym_bibtexin_crossref(bibl * param0, param * param1, ...);
static int
bibtexin_cleanf( bibl *bin, param *p )
{
 int status = (0);
 long i;

        for ( i=0; i<bin->nrefs; ++i )
  status = __sym_bibtexin_cleanref( bin->ref[i], p );
 __sym_bibtexin_crossref( bin, p );
 return status;
}





static int __sym_get_reftype(char * param0, long param1, char * param2, variants * param3, int param4, char * param5, int * param6, int param7, ...);
static int
bibtexin_typef( fields *bibin, char *filename, int nrefs, param *p )
{
 int ntypename, nrefname, is_default;
 char *refname = "", *typename = "";

 ntypename = __sym_fields_find( bibin, "INTERNAL_TYPE", (0) );
 nrefname = __sym_fields_find( bibin, "REFNUM", (0) );
 if ( nrefname!=-1 ) refname = __sym_fields_value( bibin, nrefname, ( 0 ) );
 if ( ntypename!=-1 ) typename = __sym_fields_value( bibin, ntypename, ( 0 ) );

 return __sym_get_reftype( typename, nrefs, p->progname, p->all, p->nall, refname, &is_default, (0) );
}





static char * __sym_list_getc(list * param0, int param1, ...);
static void __sym_newstr_initstr(newstr * param0, const char * param1, ...);
static int
bibtex_matches_list( fields *bibout, char *tag, char *suffix, newstr *data, int level,
  list *names, int *match )
{
 int i, fstatus, status = (0);
 newstr newtag;

 *match = 0;
 if ( names->n==0 ) return status;

 __sym_newstr_init( &newtag );

 for ( i=0; i<names->n; ++i ) {
  if ( __sym_strcmp( data->data, __sym_list_getc( names, i ) ) ) continue;
  __sym_newstr_initstr( &newtag, tag );
  __sym_newstr_strcat( &newtag, suffix );
  fstatus = __sym__fields_add( bibout, newtag.data, data->data, level, (1) );
  if ( fstatus!=(1) ) {
   status = (-2);
   goto out;
  }
  *match = 1;
  goto out;
 }

out:
 __sym_newstr_free( &newtag );
 return status;
}

static int
bibtexin_btorg( fields *bibin, int m, newstr *intag, newstr *invalue, int level, param *pm, char *outtag, fields *bibout )
{
 int n, fstatus;
 n = __sym_fields_find( bibin, "publisher", (-1) );
 if ( n==-1 )
  fstatus = __sym__fields_add( bibout, "PUBLISHER", invalue->data, level, (1) );
 else
  fstatus = __sym__fields_add( bibout, "ORGANIZER:CORP", invalue->data, level, (1) );
 if ( fstatus==(1) ) return (0);
 else return (-2);
}

static int
bibtexin_btsente( fields *bibin, int n, newstr *intag, newstr *invalue, int level, param *pm, char *outtag, fields *bibout )
{
 int fstatus, status = (0);
 newstr link;

 __sym_newstr_init( &link );
 __sym_newstr_cpytodelim( &link, __sym_skip_ws( invalue->data ), ",", 0 );
 __sym_newstr_trimendingws( &link );
 if ( __sym_newstr_memerr( &link ) ) status = (-2);

 if ( status==(0) && link.len ) {
  fstatus = __sym__fields_add( bibout, "FILEATTACH", link.data, level, (1) );
  if ( fstatus!=(1) ) status = (-2);
 }

 __sym_newstr_free( &link );
 return status;
}



static int
count_colons( char *p )
{
 int n = 0;
 while ( *p ) {
  if ( *p==':' ) n++;
  p++;
 }
 return n;
}

static int
first_colon( char *p )
{
 int n = 0;
 while ( p[n] && p[n]!=':' ) n++;
 return n;
}

static unsigned long __sym_strlen(const char * param0, ...);
static int
last_colon( char *p )
{
 int n = __sym_strlen( p ) - 1;
 while ( n>0 && p[n]!=':' ) n--;
 return n;
}




static int __sym_count_colons(char * param0, ...);
static int __sym_first_colon(char * param0, ...);
static int __sym_last_colon(char * param0, ...);
static int
bibtexin_linkedfile( fields *bibin, int m, newstr *intag, newstr *invalue, int level, param *pm, char *outtag, fields *bibout )
{
 int fstatus, status = (0);
 char *p = invalue->data;
 int i, n, n1, n2;
 newstr link;

 n = __sym_count_colons( p );
 if ( n > 1 ) {


  n1 = __sym_first_colon( p ) + 1;
  n2 = __sym_last_colon( p );
  __sym_newstr_init( &link );
  for ( i=n1; i<n2; ++i ) {
   __sym_newstr_addchar( &link, p[i] );
  }
  __sym_newstr_trimstartingws( &link );
  __sym_newstr_trimendingws( &link );
  if ( __sym_newstr_memerr( &link ) ) {
   status = (-2);
   goto out;
  }
  if ( link.len ) {
   fstatus = __sym__fields_add( bibout, "FILEATTACH", link.data, level, (1) );
   if ( fstatus!=(1) ) status = (-2);
  }
out:
  __sym_newstr_free( &link );
 } else {

  fstatus = __sym__fields_add( bibout, "FILEATTACH", p, level, (1) );
  if ( fstatus!=(1) ) status = (-2);
 }
 return status;

}

static int __sym_fields_replace_or_add(fields * param0, char * param1, char * param2, int param3, ...);
static int __sym_is_embedded_link(char * param0, ...);
static int
bibtexin_howpublished( fields *bibin, int n, newstr *intag, newstr *invalue, int level, param *pm, char *outtag, fields *bibout )
{
 int fstatus, status = (0);
 if ( !__sym_strncasecmp( invalue->data, "Diplom", 6 ) ) {
  fstatus = __sym_fields_replace_or_add( bibout, "GENRE", "Diploma thesis", level );
  if ( fstatus!=(1) ) status = (-2);
 } else if ( !__sym_strncasecmp( invalue->data, "Habilitation", 13 ) ) {
  fstatus = __sym_fields_replace_or_add( bibout, "GENRE", "Habilitation thesis", level );
  if ( fstatus!=(1) ) status = (-2);
 } else if ( __sym_is_embedded_link( invalue->data ) ) {
  status = __sym_urls_split_and_add( invalue->data, bibout, level );
 } else {
  fstatus = __sym__fields_add( bibout, "PUBLISHER", invalue->data, level, (1) );
  if ( fstatus!=(1) ) status = (-2);
 }
 return status;
}

static void __sym_newstr_mergestrs(newstr * param0, ...);
static int
process_eprint_with_prefix( fields *bibout, char *prefix, newstr *value, int level )
{
 int fstatus, status = (0);
 newstr merge;

 if ( !__sym_strcmp( prefix, "arXiv" ) ) {
  fstatus = __sym__fields_add( bibout, "ARXIV", value->data, level, (1) );
  if ( fstatus!=(1) ) status = (-2);
 }

 else if ( !__sym_strcmp( prefix, "jstor" ) ) {
  fstatus = __sym__fields_add( bibout, "JSTOR", value->data, level, (1) );
  if ( fstatus!=(1) ) status = (-2);
 }

 else if ( !__sym_strcmp( prefix, "medline" ) ) {
  fstatus = __sym__fields_add( bibout, "MEDLINE", value->data, level, (1) );
  if ( fstatus!=(1) ) status = (-2);
 }

 else if ( !__sym_strcmp( prefix, "pubmed" ) ) {
  fstatus = __sym__fields_add( bibout, "PMID", value->data, level, (1) );
  if ( fstatus!=(1) ) status = (-2);
 }


 else {
  __sym_newstr_init( &merge );
  __sym_newstr_mergestrs( &merge, prefix, ":", value->data, ((void *)0) );
  fstatus = __sym__fields_add( bibout, "URL", merge.data, level, (1) );
  if ( fstatus!=(1) ) status = (-2);
  __sym_newstr_free( &merge );
 }

 return status;
}
static int
process_eprint_without_prefix( fields *bibout, newstr *value, int level )
{
 int fstatus;


 fstatus = __sym__fields_add( bibout, "URL", value->data, level, (1) );

 if ( fstatus!=(1) ) return (-2);
 else return (0);
}

static int __sym_process_eprint_with_prefix(fields * param0, char * param1, newstr * param2, int param3, ...);
static int __sym_process_eprint_without_prefix(fields * param0, newstr * param1, int param2, ...);
static int
bibtexin_eprint( fields *bibin, int m, newstr *intag, newstr *invalue, int level, param *pm, char *outtag, fields *bibout )
{
 char *prefix;
 int n;


 n = __sym_fields_find( bibin, "ARCHIVEPREFIX", level );
 if ( n==-1 ) n = __sym_fields_find( bibin, "EPRINTTYPE", level );
 if ( n!=-1 ) {
  prefix = __sym_fields_value( bibin, n, ((16) ) );
  return __sym_process_eprint_with_prefix( bibout, prefix, invalue, level );
 }


 return __sym_process_eprint_without_prefix( bibout, invalue, level );
}

static int
bibtexin_keyword( fields *bibin, int m, newstr *intag, newstr *invalue, int level, param *pm, char *outtag, fields *bibout )
{
 int fstatus, status = (0);
 newstr keyword;
 char *p;

 p = invalue->data;
 __sym_newstr_init( &keyword );

 while ( *p ) {
  p = __sym_newstr_cpytodelim( &keyword, __sym_skip_ws( p ), ";", 1 );
  __sym_newstr_trimendingws( &keyword );
  if ( __sym_newstr_memerr( &keyword ) ) {
   status = (-2);
   goto out;
  }
  if ( keyword.len ) {
   fstatus = __sym__fields_add( bibout, "KEYWORD", keyword.data, level, (1) );
   if ( fstatus!=(1) ) {
    status = (-2);
    goto out;
   }
  }
 }
out:
 __sym_newstr_free( &keyword );
 return status;
}

static int __sym_bibtex_matches_list(fields * param0, char * param1, char * param2, newstr * param3, int param4, list * param5, int * param6, ...);
static int __sym_name_findetal(list * param0, ...);
static int __sym_name_addsingleelement(fields * param0, char * param1, char * param2, int param3, int param4, ...);
static int __sym_name_addmultielement(fields * param0, char * param1, list * param2, int param3, int param4, int param5, ...);
static int
bibtexin_person( fields *bibin, int m, newstr *intag, newstr *invalue, int level, param *pm, char *outtag, fields *bibout )
{
 int begin, end, ok, n, etal, i, status, match;
 list tokens;


 status = __sym_bibtex_matches_list( bibout, outtag, ":ASIS", invalue, level, &(pm->asis), &match );
 if ( match==1 || status!=(0) ) return status;
 status = __sym_bibtex_matches_list( bibout, outtag, ":CORP", invalue, level, &(pm->corps), &match );
 if ( match==1 || status!=(0) ) return status;

 __sym_list_init( &tokens );

 __sym_bibtex_split( &tokens, invalue );
 for ( i=0; i<tokens.n; ++i )
  __sym_bibtex_cleantoken( __sym_list_get( &tokens, i ) );

 etal = __sym_name_findetal( &tokens );

 begin = 0;
 n = tokens.n - etal;
 while ( begin < n ) {

  end = begin + 1;

  while ( end < n && __sym_strcasecmp( __sym_list_getc( &tokens, end ), "and" ) )
   end++;

  if ( end - begin == 1 ) {
   ok = __sym_name_addsingleelement( bibout, outtag, __sym_list_getc( &tokens, begin ), level, 0 );
   if ( !ok ) { status = (-2); goto out; }
  } else {
   ok = __sym_name_addmultielement( bibout, outtag, &tokens, begin, end, level );
   if ( !ok ) { status = (-2); goto out; }
  }

  begin = end + 1;


  while ( begin < n && !__sym_strcasecmp( __sym_list_getc( &tokens, begin ), "and" ) )
   begin++;
 }

 if ( etal ) {
  ok = __sym_name_addsingleelement( bibout, outtag, "et al.", level, 0 );
  if ( !ok ) status = (-2);
 }

out:
 __sym_list_free( &tokens );
 return status;

}

static int
bibtexin_titleinbook_isbooktitle( fields *bibin, char *intag )
{
 int n;


 if ( __sym_strcasecmp( intag, "TITLE" ) ) return 0;


 n = __sym_fields_find( bibin, "INTERNAL_TYPE", (-1) );
 if ( n==-1 ) return 0;
 if ( __sym_strcasecmp( __sym_fields_value( bibin, n, ((16) ) ), "INBOOK" ) ) return 0;


 n = __sym_fields_find( bibin, "BOOKTITLE", (-1) );
 if ( n==-1 ) return 0;
 else return 1;
}

static int __sym_bibtexin_titleinbook_isbooktitle(fields * param0, char * param1, ...);
static int
bibtexin_title( fields *bibin, int n, newstr *intag, newstr *invalue, int level, param *pm, char *outtag, fields *bibout )
{
 int ok;

 if ( __sym_bibtexin_titleinbook_isbooktitle( bibin, intag->data ) ) level=(0);
 ok = __sym_title_process( bibout, "TITLE", invalue->data, level, pm->nosplittitle );
 if ( ok ) return (0);
 else return (-2);
}

static void
bibtexin_notag( param *p, char *tag )
{
 if ( p->verbose && __sym_strcmp( tag, "INTERNAL_TYPE" ) ) {
  if ( p->progname ) __sym_fprintf( stderr, "%s: ", p->progname );
  __sym_fprintf( stderr, "Cannot find tag '%s'\n", tag );
 }
}

static int __sym_fields_used(fields * param0, int param1, ...);
static int __sym_fields_notag(fields * param0, int param1, ...);
static int __sym_fields_nodata(fields * param0, int param1, ...);
static int __sym_translate_oldtag(char * param0, int param1, variants param2[], int param3, int * param4, int * param5, char ** param6, ...);
static void __sym_bibtexin_notag(param * param0, char * param1, ...);
static void __sym_fields_report(fields * param0, FILE * param1, ...);

static int
bibtexin_convertf( fields *bibin, fields *bibout, int reftype, param *p )
{
 static int (*convertfns[(25)])(fields *, int, newstr *, newstr *, int, param *, char *, fields *) = {
  [ 0 ... (25)-1 ] = generic_null,
  [ (2) ] = generic_simple,
  [ (8) ] = bibtexin_title,
  [ (4) ] = bibtexin_person,
  [ (6) ] = generic_pages,
  [ (13) ] = bibtexin_keyword,
  [ (24) ] = bibtexin_eprint,
  [ (11) ] = bibtexin_howpublished,
  [ (12) ] = bibtexin_linkedfile,
  [ (9) ] = generic_notes,
  [ (15) ] = bibtexin_btsente,
  [ (18) ] = bibtexin_btorg,
  [ (14) ] = generic_url
 };

 int process, level, i, nfields, status = (0);
 newstr *intag, *invalue;
 char *outtag;

 nfields = __sym_fields_num( bibin );
 for ( i=0; i<nfields; ++i ) {

  if ( __sym_fields_used( bibin, i ) ) continue;
  if ( __sym_fields_notag( bibin, i ) ) continue;
  if ( __sym_fields_nodata( bibin, i ) ) continue;

  intag = __sym_fields_tag( bibin, i, ((16) | (2) ) );
  invalue = __sym_fields_value( bibin, i, ((16) | (2) ) );

  if ( !__sym_translate_oldtag( intag->data, reftype, p->all, p->nall, &process, &level, &outtag ) ) {
   __sym_bibtexin_notag( p, intag->data );
   continue;
  }

  status = convertfns[ process ] ( bibin, i, intag, invalue, level, p, outtag, bibout );
  if ( status!=(0) ) return status;
 }

 if ( status==(0) && p->verbose ) __sym_fields_report( bibout, stderr );

 return status;
}

// Test driver for function string_concatenate returning int
int string_concatenate_driver()
{
struct list * param1;
struct fields * param2;
long param3;
struct param * param4;
param1 = malloc(1*sizeof(struct list));
__CrestInt(&param1[0].n);
__CrestInt(&param1[0].max);
param1[0].str = malloc(1*sizeof(struct newstr));
param1[0].str[0].data = malloc(3*sizeof(char));
__CrestChar(&param1[0].str[0].data[0]);
__CrestChar(&param1[0].str[0].data[1]);
__CrestChar(&param1[0].str[0].data[2]);
__CrestULong(&param1[0].str[0].dim);
__CrestULong(&param1[0].str[0].len);
__CrestUChar(&param1[0].sorted);
param2 = malloc(1*sizeof(struct fields));
param2[0].tag = malloc(1*sizeof(struct newstr));
param2[0].tag[0].data = malloc(3*sizeof(char));
__CrestChar(&param2[0].tag[0].data[0]);
__CrestChar(&param2[0].tag[0].data[1]);
__CrestChar(&param2[0].tag[0].data[2]);
__CrestULong(&param2[0].tag[0].dim);
__CrestULong(&param2[0].tag[0].len);
param2[0].data = malloc(1*sizeof(struct newstr));
param2[0].data[0].data = malloc(3*sizeof(char));
__CrestChar(&param2[0].data[0].data[0]);
__CrestChar(&param2[0].data[0].data[1]);
__CrestChar(&param2[0].data[0].data[2]);
__CrestULong(&param2[0].data[0].dim);
__CrestULong(&param2[0].data[0].len);
param2[0].used = malloc(3*sizeof(int));
__CrestInt(&param2[0].used[0]);
__CrestInt(&param2[0].used[1]);
__CrestInt(&param2[0].used[2]);
param2[0].level = malloc(3*sizeof(int));
__CrestInt(&param2[0].level[0]);
__CrestInt(&param2[0].level[1]);
__CrestInt(&param2[0].level[2]);
__CrestInt(&param2[0].n);
__CrestInt(&param2[0].max);
__CrestLong(&param3);
param4 = malloc(1*sizeof(struct param));
__CrestInt(&param4[0].readformat);
__CrestInt(&param4[0].writeformat);
__CrestInt(&param4[0].charsetin);
__CrestUChar(&param4[0].charsetin_src);
__CrestUChar(&param4[0].latexin);
__CrestUChar(&param4[0].utf8in);
__CrestUChar(&param4[0].xmlin);
__CrestUChar(&param4[0].nosplittitle);
__CrestInt(&param4[0].charsetout);
__CrestUChar(&param4[0].charsetout_src);
__CrestUChar(&param4[0].latexout);
__CrestUChar(&param4[0].utf8out);
__CrestUChar(&param4[0].utf8bom);
__CrestUChar(&param4[0].xmlout);
__CrestInt(&param4[0].format_opts);
__CrestInt(&param4[0].addcount);
__CrestUChar(&param4[0].output_raw);
__CrestUChar(&param4[0].verbose);
__CrestUChar(&param4[0].singlerefperfile);
__CrestInt(&param4[0].asis.n);
__CrestInt(&param4[0].asis.max);
param4[0].asis.str = malloc(1*sizeof(struct newstr));
param4[0].asis.str[0].data = malloc(3*sizeof(char));
__CrestChar(&param4[0].asis.str[0].data[0]);
__CrestChar(&param4[0].asis.str[0].data[1]);
__CrestChar(&param4[0].asis.str[0].data[2]);
__CrestULong(&param4[0].asis.str[0].dim);
__CrestULong(&param4[0].asis.str[0].len);
__CrestUChar(&param4[0].asis.sorted);
__CrestInt(&param4[0].corps.n);
__CrestInt(&param4[0].corps.max);
param4[0].corps.str = malloc(1*sizeof(struct newstr));
param4[0].corps.str[0].data = malloc(3*sizeof(char));
__CrestChar(&param4[0].corps.str[0].data[0]);
__CrestChar(&param4[0].corps.str[0].data[1]);
__CrestChar(&param4[0].corps.str[0].data[2]);
__CrestULong(&param4[0].corps.str[0].dim);
__CrestULong(&param4[0].corps.str[0].len);
__CrestUChar(&param4[0].corps.sorted);
param4[0].progname = malloc(3*sizeof(char));
__CrestChar(&param4[0].progname[0]);
__CrestChar(&param4[0].progname[1]);
__CrestChar(&param4[0].progname[2]);
// Function pointer type: int (*)(struct _IO_FILE *, char *, int, int *, struct newstr *, struct newstr *, int *) of param4[0].readf is not supported
param4[0].readf = 0;
// Function pointer type: int (*)(struct fields *, char *, char *, long, struct param *) of param4[0].processf is not supported
param4[0].processf = 0;
// Function pointer type: int (*)(bibl *, struct param *) of param4[0].cleanf is not supported
param4[0].cleanf = 0;
// Function pointer type: int (*)(struct fields *, char *, int, struct param *) of param4[0].typef is not supported
param4[0].typef = 0;
// Function pointer type: int (*)(struct fields *, struct fields *, int, struct param *) of param4[0].convertf is not supported
param4[0].convertf = 0;
// Function pointer type: void (*)(struct _IO_FILE *, struct param *) of param4[0].headerf is not supported
param4[0].headerf = 0;
// Function pointer type: void (*)(struct _IO_FILE *) of param4[0].footerf is not supported
param4[0].footerf = 0;
// Function pointer type: int (*)(struct fields *, struct _IO_FILE *, struct param *, unsigned long) of param4[0].writef is not supported
param4[0].writef = 0;
param4[0].all = malloc(1*sizeof(variants));
__CrestChar(&param4[0].all[0].type[0]);
__CrestChar(&param4[0].all[0].type[1]);
__CrestChar(&param4[0].all[0].type[2]);
__CrestChar(&param4[0].all[0].type[3]);
__CrestChar(&param4[0].all[0].type[4]);
__CrestChar(&param4[0].all[0].type[5]);
__CrestChar(&param4[0].all[0].type[6]);
__CrestChar(&param4[0].all[0].type[7]);
__CrestChar(&param4[0].all[0].type[8]);
__CrestChar(&param4[0].all[0].type[9]);
__CrestChar(&param4[0].all[0].type[10]);
__CrestChar(&param4[0].all[0].type[11]);
__CrestChar(&param4[0].all[0].type[12]);
__CrestChar(&param4[0].all[0].type[13]);
__CrestChar(&param4[0].all[0].type[14]);
__CrestChar(&param4[0].all[0].type[15]);
__CrestChar(&param4[0].all[0].type[16]);
__CrestChar(&param4[0].all[0].type[17]);
__CrestChar(&param4[0].all[0].type[18]);
__CrestChar(&param4[0].all[0].type[19]);
__CrestChar(&param4[0].all[0].type[20]);
__CrestChar(&param4[0].all[0].type[21]);
__CrestChar(&param4[0].all[0].type[22]);
__CrestChar(&param4[0].all[0].type[23]);
__CrestChar(&param4[0].all[0].type[24]);
param4[0].all[0].tags = malloc(1*sizeof(lookups));
// Pointer Type: char * of param4[0].all[0].tags[0].oldstr is set as NULL
param4[0].all[0].tags[0].oldstr = 0;
// Pointer Type: char * of param4[0].all[0].tags[0].newstr is set as NULL
param4[0].all[0].tags[0].newstr = 0;
param2[0].n = 5;
param1[0].n = 5;
__CrestInt(&param4[0].all[0].tags[0].processingtype);
__CrestInt(&param4[0].all[0].tags[0].level);
__CrestInt(&param4[0].all[0].ntags);
__CrestInt(&param4[0].nall);
__CrestChar(&bibtex_all[0].type[0]);
__CrestChar(&bibtex_all[0].type[1]);
__CrestChar(&bibtex_all[0].type[2]);
__CrestChar(&bibtex_all[0].type[3]);
__CrestChar(&bibtex_all[0].type[4]);
__CrestChar(&bibtex_all[0].type[5]);
__CrestChar(&bibtex_all[0].type[6]);
__CrestChar(&bibtex_all[0].type[7]);
__CrestChar(&bibtex_all[0].type[8]);
__CrestChar(&bibtex_all[0].type[9]);
__CrestChar(&bibtex_all[0].type[10]);
__CrestChar(&bibtex_all[0].type[11]);
__CrestChar(&bibtex_all[0].type[12]);
__CrestChar(&bibtex_all[0].type[13]);
__CrestChar(&bibtex_all[0].type[14]);
__CrestChar(&bibtex_all[0].type[15]);
__CrestChar(&bibtex_all[0].type[16]);
__CrestChar(&bibtex_all[0].type[17]);
__CrestChar(&bibtex_all[0].type[18]);
__CrestChar(&bibtex_all[0].type[19]);
__CrestChar(&bibtex_all[0].type[20]);
__CrestChar(&bibtex_all[0].type[21]);
__CrestChar(&bibtex_all[0].type[22]);
__CrestChar(&bibtex_all[0].type[23]);
__CrestChar(&bibtex_all[0].type[24]);
bibtex_all[0].tags = malloc(1*sizeof(lookups));
bibtex_all[0].tags[0].oldstr = malloc(3*sizeof(char));
__CrestChar(&bibtex_all[0].tags[0].oldstr[0]);
__CrestChar(&bibtex_all[0].tags[0].oldstr[1]);
__CrestChar(&bibtex_all[0].tags[0].oldstr[2]);
bibtex_all[0].tags[0].newstr = malloc(3*sizeof(char));
__CrestChar(&bibtex_all[0].tags[0].newstr[0]);
__CrestChar(&bibtex_all[0].tags[0].newstr[1]);
__CrestChar(&bibtex_all[0].tags[0].newstr[2]);
__CrestInt(&bibtex_all[0].tags[0].processingtype);
__CrestInt(&bibtex_all[0].tags[0].level);
__CrestInt(&bibtex_all[0].ntags);
__CrestInt(&bibtex_nall);
__CrestInt(&find.n);
__CrestInt(&find.max);
find.str = malloc(1*sizeof(struct newstr));
find.str[0].data = malloc(3*sizeof(char));
__CrestChar(&find.str[0].data[0]);
__CrestChar(&find.str[0].data[1]);
__CrestChar(&find.str[0].data[2]);
__CrestULong(&find.str[0].dim);
__CrestULong(&find.str[0].len);
__CrestUChar(&find.sorted);
__CrestInt(&replace.n);
__CrestInt(&replace.max);
replace.str = malloc(1*sizeof(struct newstr));
replace.str[0].data = malloc(3*sizeof(char));
__CrestChar(&replace.str[0].data[0]);
__CrestChar(&replace.str[0].data[1]);
__CrestChar(&replace.str[0].data[2]);
__CrestULong(&replace.str[0].dim);
__CrestULong(&replace.str[0].len);
__CrestUChar(&replace.sorted);
// stderr will be set by C standard library
return string_concatenate(param1,param2,param3,param4);
}
int test_main(){
string_concatenate_driver();
 return 0;}

void init_bibtexin_i(){
__CrestChar(&bibtex_all[0].type[0]);
__CrestChar(&bibtex_all[0].type[1]);
__CrestChar(&bibtex_all[0].type[2]);
__CrestChar(&bibtex_all[0].type[3]);
__CrestChar(&bibtex_all[0].type[4]);
__CrestChar(&bibtex_all[0].type[5]);
__CrestChar(&bibtex_all[0].type[6]);
__CrestChar(&bibtex_all[0].type[7]);
__CrestChar(&bibtex_all[0].type[8]);
__CrestChar(&bibtex_all[0].type[9]);
__CrestChar(&bibtex_all[0].type[10]);
__CrestChar(&bibtex_all[0].type[11]);
__CrestChar(&bibtex_all[0].type[12]);
__CrestChar(&bibtex_all[0].type[13]);
__CrestChar(&bibtex_all[0].type[14]);
__CrestChar(&bibtex_all[0].type[15]);
__CrestChar(&bibtex_all[0].type[16]);
__CrestChar(&bibtex_all[0].type[17]);
__CrestChar(&bibtex_all[0].type[18]);
__CrestChar(&bibtex_all[0].type[19]);
__CrestChar(&bibtex_all[0].type[20]);
__CrestChar(&bibtex_all[0].type[21]);
__CrestChar(&bibtex_all[0].type[22]);
__CrestChar(&bibtex_all[0].type[23]);
__CrestChar(&bibtex_all[0].type[24]);
bibtex_all[0].tags = malloc(1*sizeof(lookups));
bibtex_all[0].tags[0].oldstr = malloc(3*sizeof(char));
__CrestChar(&bibtex_all[0].tags[0].oldstr[0]);
__CrestChar(&bibtex_all[0].tags[0].oldstr[1]);
__CrestChar(&bibtex_all[0].tags[0].oldstr[2]);
bibtex_all[0].tags[0].newstr = malloc(3*sizeof(char));
__CrestChar(&bibtex_all[0].tags[0].newstr[0]);
__CrestChar(&bibtex_all[0].tags[0].newstr[1]);
__CrestChar(&bibtex_all[0].tags[0].newstr[2]);
__CrestInt(&bibtex_all[0].tags[0].processingtype);
__CrestInt(&bibtex_all[0].tags[0].level);
__CrestInt(&bibtex_all[0].ntags);
__CrestInt(&bibtex_nall);
__CrestInt(&find.n);
__CrestInt(&find.max);
find.str = malloc(1*sizeof(struct newstr));
find.str[0].data = malloc(3*sizeof(char));
__CrestChar(&find.str[0].data[0]);
__CrestChar(&find.str[0].data[1]);
__CrestChar(&find.str[0].data[2]);
__CrestULong(&find.str[0].dim);
__CrestULong(&find.str[0].len);
__CrestUChar(&find.sorted);
__CrestInt(&replace.n);
__CrestInt(&replace.max);
replace.str = malloc(1*sizeof(struct newstr));
replace.str[0].data = malloc(3*sizeof(char));
__CrestChar(&replace.str[0].data[0]);
__CrestChar(&replace.str[0].data[1]);
__CrestChar(&replace.str[0].data[2]);
__CrestULong(&replace.str[0].dim);
__CrestULong(&replace.str[0].len);
__CrestUChar(&replace.sorted);
// stderr will be set by C standard library
}
static const unsigned short ** __sym___ctype_b_loc(void){
  const unsigned short ** ret;
ret = malloc(1*sizeof(const unsigned short *));
// Pointee type 'unsigned short' is a constant
{
unsigned short *__tmp__1;
__tmp__1 = malloc(3*sizeof(unsigned short));
__CrestUShort(&__tmp__1[0]);
__CrestUShort(&__tmp__1[1]);
__CrestUShort(&__tmp__1[2]);
ret[0] = __tmp__1;
}
  return ret;
}
static int __sym__fields_add(fields * param0, char * param1, char * param2, int param3, int param4){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_bibtex_addtitleurl(fields * param0, newstr * param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_bibtex_cleandata(newstr * param0, newstr * param1, fields * param2, param * param3, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym_bibtex_cleantoken(newstr * param0, ...){
}
static char * __sym_bibtex_data(char * param0, fields * param1, list * param2, long param3, param * param4, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static int __sym_bibtex_matches_list(fields * param0, char * param1, char * param2, newstr * param3, int param4, list * param5, int * param6, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym_bibtex_process_bracket(newstr * param0, ...){
}
static void __sym_bibtex_process_tilde(newstr * param0, ...){
}
static int __sym_bibtex_protected(newstr * param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_bibtex_split(list * param0, newstr * param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static char * __sym_bibtex_tag(char * param0, newstr * param1, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static int __sym_bibtexin_cleanref(fields * param0, param * param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_bibtexin_crossref(bibl * param0, param * param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_bibtexin_crossref_oneref(fields * param0, fields * param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static long __sym_bibtexin_findref(bibl * param0, char * param1, ...){
  long ret;
__CrestLong(&ret);
  return ret;
}
static void __sym_bibtexin_nocrossref(bibl * param0, long param1, int param2, param * param3, ...){
}
static void __sym_bibtexin_notag(param * param0, char * param1, ...){
}
static int __sym_bibtexin_titleinbook_isbooktitle(fields * param0, char * param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_count_colons(char * param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_fields_find(fields * param0, char * param1, int param2, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_fields_level(fields * param0, int param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_fields_nodata(fields * param0, int param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_fields_notag(fields * param0, int param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_fields_num(fields * param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_fields_replace_or_add(fields * param0, char * param1, char * param2, int param3, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym_fields_report(fields * param0, FILE * param1, ...){
}
static void __sym_fields_setused(fields * param0, int param1, ...){
}
static void * __sym_fields_tag(fields * param0, int param1, int param2, ...){
  void * ret;
// Pointee type 'void' is an incomplete type
ret = 0;
  return ret;
}
static int __sym_fields_used(fields * param0, int param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void * __sym_fields_value(fields * param0, int param1, int param2, ...){
  void * ret;
// Pointee type 'void' is an incomplete type
ret = 0;
  return ret;
}
static int __sym_first_colon(char * param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_fprintf(FILE * param0, const char * param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_get_reftype(char * param0, long param1, char * param2, variants * param3, int param4, char * param5, int * param6, int param7, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_is_embedded_link(char * param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_is_name_tag(newstr * param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_is_url_tag(newstr * param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_is_ws(char param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_last_colon(char * param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static struct newstr * __sym_list_add(list * param0, newstr * param1, ...){
  struct newstr * ret;
ret = malloc(1*sizeof(struct newstr));
ret[0].data = malloc(3*sizeof(char));
__CrestChar(&ret[0].data[0]);
__CrestChar(&ret[0].data[1]);
__CrestChar(&ret[0].data[2]);
__CrestULong(&ret[0].dim);
__CrestULong(&ret[0].len);
  return ret;
}
static struct newstr * __sym_list_addc(list * param0, const char * param1, ...){
  struct newstr * ret;
ret = malloc(1*sizeof(struct newstr));
ret[0].data = malloc(3*sizeof(char));
__CrestChar(&ret[0].data[0]);
__CrestChar(&ret[0].data[1]);
__CrestChar(&ret[0].data[2]);
__CrestULong(&ret[0].dim);
__CrestULong(&ret[0].len);
  return ret;
}
static int __sym_list_find(list * param0, const char * param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym_list_free(list * param0, ...){
}
static struct newstr * __sym_list_get(list * param0, int param1, ...){
  struct newstr * ret;
ret = malloc(1*sizeof(struct newstr));
ret[0].data = malloc(3*sizeof(char));
__CrestChar(&ret[0].data[0]);
__CrestChar(&ret[0].data[1]);
__CrestChar(&ret[0].data[2]);
__CrestULong(&ret[0].dim);
__CrestULong(&ret[0].len);
ret[0].len = 150;
  return ret;
}
static char * __sym_list_getc(list * param0, int param1, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static void __sym_list_init(list * param0, ...){
}
static int __sym_list_remove(list * param0, int param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static struct newstr * __sym_list_set(list * param0, int param1, newstr * param2, ...){
  struct newstr * ret;
ret = malloc(1*sizeof(struct newstr));
ret[0].data = malloc(3*sizeof(char));
__CrestChar(&ret[0].data[0]);
__CrestChar(&ret[0].data[1]);
__CrestChar(&ret[0].data[2]);
__CrestULong(&ret[0].dim);
__CrestULong(&ret[0].len);
  return ret;
}
static struct newstr * __sym_list_setc(list * param0, int param1, const char * param2, ...){
  struct newstr * ret;
ret = malloc(1*sizeof(struct newstr));
ret[0].data = malloc(3*sizeof(char));
__CrestChar(&ret[0].data[0]);
__CrestChar(&ret[0].data[1]);
__CrestChar(&ret[0].data[2]);
__CrestULong(&ret[0].dim);
__CrestULong(&ret[0].len);
  return ret;
}
static int __sym_name_addmultielement(fields * param0, char * param1, list * param2, int param3, int param4, int param5, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_name_addsingleelement(fields * param0, char * param1, char * param2, int param3, int param4, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_name_findetal(list * param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym_newstr_addchar(newstr * param0, char param1, ...){
}
static char * __sym_newstr_cpytodelim(newstr * param0, char * param1, const char * param2, unsigned char param3, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static void __sym_newstr_empty(newstr * param0, ...){
}
static int __sym_newstr_fget(FILE * param0, char * param1, int param2, int * param3, newstr * param4, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_newstr_findreplace(newstr * param0, const char * param1, const char * param2, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym_newstr_free(newstr * param0, ...){
}
static void __sym_newstr_init(newstr * param0, ...){
}
static void __sym_newstr_initstr(newstr * param0, const char * param1, ...){
}
static int __sym_newstr_memerr(newstr * param0, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym_newstr_mergestrs(newstr * param0, ...){
}
static void __sym_newstr_newstrcat(newstr * param0, newstr * param1, ...){
}
static void __sym_newstr_newstrcpy(newstr * param0, newstr * param1, ...){
}
static void __sym_newstr_strcat(newstr * param0, const char * param1, ...){
}
static void __sym_newstr_strcpy(newstr * param0, const char * param1, ...){
}
static void __sym_newstr_swapstrings(newstr * param0, newstr * param1, ...){
}
static void __sym_newstr_trimbegin(newstr * param0, unsigned long param1, ...){
}
static void __sym_newstr_trimend(newstr * param0, unsigned long param1, ...){
}
static void __sym_newstr_trimendingws(newstr * param0, ...){
}
static void __sym_newstr_trimstartingws(newstr * param0, ...){
}
static void __sym_newstrs_empty(newstr * param0, ...){
}
static void __sym_newstrs_free(newstr * param0, ...){
}
static void __sym_newstrs_init(newstr * param0, ...){
}

static char * __sym_process_bibtexid(char * param0, newstr * param1, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static char * __sym_process_bibtexline(char * param0, newstr * param1, newstr * param2, uchar param3, fields * param4, long param5, param * param6, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static char * __sym_process_bibtextype(char * param0, newstr * param1, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static int __sym_process_cite(fields * param0, char * param1, char * param2, long param3, param * param4, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_process_eprint_with_prefix(fields * param0, char * param1, newstr * param2, int param3, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_process_eprint_without_prefix(fields * param0, newstr * param1, int param2, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_process_string(char * param0, long param1, param * param2, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_readmore(FILE * param0, char * param1, int param2, int * param3, newstr * param4, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static void __sym_replace_strings(list * param0, fields * param1, param * param2, ...){
}
static char * __sym_skip_ws(char * param0, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static int __sym_strcasecmp(const char * param0, const char * param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static char * __sym_strchr(const char * param0, int param1, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static int __sym_strcmp(const char * param0, const char * param1, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static char * __sym_strdup(const char * param0, ...){
  char * ret;
ret = malloc(3*sizeof(char));
__CrestChar(&ret[0]);
__CrestChar(&ret[1]);
__CrestChar(&ret[2]);
  return ret;
}
static int __sym_string_concatenate(list * param0, fields * param1, long param2, param * param3, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static unsigned long __sym_strlen(const char * param0, ...){
  unsigned long ret;
__CrestULong(&ret);
  return ret;
}
static int __sym_strncasecmp(const char * param0, const char * param1, size_t param2, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_title_process(fields * param0, char * param1, char * param2, int param3, unsigned char param4, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_translate_oldtag(char * param0, int param1, variants param2[], int param3, int * param4, int * param5, char ** param6, ...){
  int ret;
__CrestInt(&ret);
  return ret;
}
static int __sym_urls_split_and_add(char * param0, fields * param1, int param2){
  int ret;
__CrestInt(&ret);
  return ret;
}
#endif
int main(){
  string_concatenate_driver();
  return 0;
}
