#!/bin/bash
gcc -w -g -o string_concatenate_driver string_concatenate_driver.c -lcrestr -L../lib -L. -D__H_
