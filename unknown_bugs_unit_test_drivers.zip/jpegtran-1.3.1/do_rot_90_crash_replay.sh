#!/bin/bash
cp do_rot_90_crash_input input
./do_rot_90_driver
rm -f input
