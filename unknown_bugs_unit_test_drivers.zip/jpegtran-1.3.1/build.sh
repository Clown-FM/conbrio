#!/bin/bash
gcc -w -g -o do_rot_90_driver do_rot_90_driver.c -lcrestr -L../lib -L. -D__H_
