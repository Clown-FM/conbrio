#!/bin/bash
gcc -o grep.exe grep.c -I. -I../../lib -g
