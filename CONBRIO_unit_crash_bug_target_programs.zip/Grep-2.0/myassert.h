#ifndef _MY_ASSERT
#define _MY_ASSERT
#include <assert.h>
#include <execinfo.h>
#include <stdio.h>
#include <stdlib.h>
void
print_trace (void)
{
  void *array[10];
  size_t size;
  char **strings;
  size_t i;

  size = backtrace (array, 10);
  strings = backtrace_symbols (array, size);

  printf ("Obtained %zd stack frames.\n", size);

  for (i = 1; i < size; i++)
     printf ("%s\n", strings[i]);

  free (strings);
}

# define myassert(expr)                           \
  ((expr)                               \
   ? __ASSERT_VOID_CAST (0)                     \
   : __assert_fail (__STRING(expr), __FILE__, __LINE__, __ASSERT_FUNCTION))
#endif
