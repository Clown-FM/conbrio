#!/bin/bash
chmod +x ./configure
chmod +x ./support/config.sub
chmod +x ./support/config.guess
./configure
make
